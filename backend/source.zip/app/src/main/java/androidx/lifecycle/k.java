package androidx.lifecycle;

import java.util.Iterator;
import java.util.Map;
/* loaded from: classes.dex */
public class k<T> extends m<T> {

    /* renamed from: k  reason: collision with root package name */
    private i.b<LiveData<?>, a<?>> f1867k = new i.b<>();

    /* loaded from: classes.dex */
    private static class a<V> implements n<V> {

        /* renamed from: a  reason: collision with root package name */
        final LiveData<V> f1868a;

        /* renamed from: b  reason: collision with root package name */
        final n<? super V> f1869b;

        /* renamed from: c  reason: collision with root package name */
        int f1870c = -1;

        a(LiveData<V> liveData, n<? super V> nVar) {
            this.f1868a = liveData;
            this.f1869b = nVar;
        }

        void a() {
            this.f1868a.h(this);
        }

        void b() {
            this.f1868a.l(this);
        }

        @Override // androidx.lifecycle.n
        public void c(V v2) {
            if (this.f1870c != this.f1868a.e()) {
                this.f1870c = this.f1868a.e();
                this.f1869b.c(v2);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.lifecycle.LiveData
    public void i() {
        Iterator<Map.Entry<LiveData<?>, a<?>>> it = this.f1867k.iterator();
        while (it.hasNext()) {
            it.next().getValue().a();
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.lifecycle.LiveData
    public void j() {
        Iterator<Map.Entry<LiveData<?>, a<?>>> it = this.f1867k.iterator();
        while (it.hasNext()) {
            it.next().getValue().b();
        }
    }

    public <S> void n(LiveData<S> liveData, n<? super S> nVar) {
        a<?> aVar = new a<>(liveData, nVar);
        a<?> i2 = this.f1867k.i(liveData, aVar);
        if (i2 != null && i2.f1869b != nVar) {
            throw new IllegalArgumentException("This source was already added with the different observer");
        }
        if (i2 == null && f()) {
            aVar.a();
        }
    }
}
