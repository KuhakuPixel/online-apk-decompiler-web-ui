package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.XmlResourceParser;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.util.Xml;
import java.lang.ref.WeakReference;
import java.util.WeakHashMap;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
/* loaded from: classes.dex */
public final class j0 {

    /* renamed from: i  reason: collision with root package name */
    private static j0 f813i;

    /* renamed from: a  reason: collision with root package name */
    private WeakHashMap<Context, l.h<ColorStateList>> f815a;

    /* renamed from: b  reason: collision with root package name */
    private l.g<String, d> f816b;

    /* renamed from: c  reason: collision with root package name */
    private l.h<String> f817c;

    /* renamed from: d  reason: collision with root package name */
    private final WeakHashMap<Context, l.d<WeakReference<Drawable.ConstantState>>> f818d = new WeakHashMap<>(0);

    /* renamed from: e  reason: collision with root package name */
    private TypedValue f819e;

    /* renamed from: f  reason: collision with root package name */
    private boolean f820f;

    /* renamed from: g  reason: collision with root package name */
    private e f821g;

    /* renamed from: h  reason: collision with root package name */
    private static final PorterDuff.Mode f812h = PorterDuff.Mode.SRC_IN;

    /* renamed from: j  reason: collision with root package name */
    private static final c f814j = new c(6);

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public static class a implements d {
        a() {
        }

        @Override // androidx.appcompat.widget.j0.d
        public Drawable a(Context context, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme) {
            try {
                return d.a.m(context, context.getResources(), xmlPullParser, attributeSet, theme);
            } catch (Exception e2) {
                Log.e("AsldcInflateDelegate", "Exception while inflating <animated-selector>", e2);
                return null;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public static class b implements d {
        b() {
        }

        @Override // androidx.appcompat.widget.j0.d
        public Drawable a(Context context, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme) {
            try {
                return androidx.vectordrawable.graphics.drawable.b.a(context, context.getResources(), xmlPullParser, attributeSet, theme);
            } catch (Exception e2) {
                Log.e("AvdcInflateDelegate", "Exception while inflating <animated-vector>", e2);
                return null;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public static class c extends l.e<Integer, PorterDuffColorFilter> {
        public c(int i2) {
            super(i2);
        }

        private static int h(int i2, PorterDuff.Mode mode) {
            return ((i2 + 31) * 31) + mode.hashCode();
        }

        PorterDuffColorFilter i(int i2, PorterDuff.Mode mode) {
            return c(Integer.valueOf(h(i2, mode)));
        }

        PorterDuffColorFilter j(int i2, PorterDuff.Mode mode, PorterDuffColorFilter porterDuffColorFilter) {
            return d(Integer.valueOf(h(i2, mode)), porterDuffColorFilter);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public interface d {
        Drawable a(Context context, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public interface e {
        Drawable a(j0 j0Var, Context context, int i2);

        boolean b(Context context, int i2, Drawable drawable);

        ColorStateList c(Context context, int i2);

        boolean d(Context context, int i2, Drawable drawable);

        PorterDuff.Mode e(int i2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public static class f implements d {
        f() {
        }

        @Override // androidx.appcompat.widget.j0.d
        public Drawable a(Context context, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme) {
            try {
                return androidx.vectordrawable.graphics.drawable.g.c(context.getResources(), xmlPullParser, attributeSet, theme);
            } catch (Exception e2) {
                Log.e("VdcInflateDelegate", "Exception while inflating <vector>", e2);
                return null;
            }
        }
    }

    private void a(String str, d dVar) {
        if (this.f816b == null) {
            this.f816b = new l.g<>();
        }
        this.f816b.put(str, dVar);
    }

    private synchronized boolean b(Context context, long j2, Drawable drawable) {
        boolean z2;
        Drawable.ConstantState constantState = drawable.getConstantState();
        if (constantState != null) {
            l.d<WeakReference<Drawable.ConstantState>> dVar = this.f818d.get(context);
            if (dVar == null) {
                dVar = new l.d<>();
                this.f818d.put(context, dVar);
            }
            dVar.i(j2, new WeakReference<>(constantState));
            z2 = true;
        } else {
            z2 = false;
        }
        return z2;
    }

    private void c(Context context, int i2, ColorStateList colorStateList) {
        if (this.f815a == null) {
            this.f815a = new WeakHashMap<>();
        }
        l.h<ColorStateList> hVar = this.f815a.get(context);
        if (hVar == null) {
            hVar = new l.h<>();
            this.f815a.put(context, hVar);
        }
        hVar.a(i2, colorStateList);
    }

    private void d(Context context) {
        if (this.f820f) {
            return;
        }
        this.f820f = true;
        Drawable j2 = j(context, e.a.abc_vector_test);
        if (j2 == null || !q(j2)) {
            this.f820f = false;
            throw new IllegalStateException("This app has been built with an incorrect configuration. Please configure your build for VectorDrawableCompat.");
        }
    }

    private static long e(TypedValue typedValue) {
        return (typedValue.assetCookie << 32) | typedValue.data;
    }

    private Drawable f(Context context, int i2) {
        if (this.f819e == null) {
            this.f819e = new TypedValue();
        }
        TypedValue typedValue = this.f819e;
        context.getResources().getValue(i2, typedValue, true);
        long e2 = e(typedValue);
        Drawable i3 = i(context, e2);
        if (i3 != null) {
            return i3;
        }
        e eVar = this.f821g;
        Drawable a2 = eVar == null ? null : eVar.a(this, context, i2);
        if (a2 != null) {
            a2.setChangingConfigurations(typedValue.changingConfigurations);
            b(context, e2, a2);
        }
        return a2;
    }

    private static PorterDuffColorFilter g(ColorStateList colorStateList, PorterDuff.Mode mode, int[] iArr) {
        if (colorStateList == null || mode == null) {
            return null;
        }
        return l(colorStateList.getColorForState(iArr, 0), mode);
    }

    public static synchronized j0 h() {
        j0 j0Var;
        synchronized (j0.class) {
            if (f813i == null) {
                j0 j0Var2 = new j0();
                f813i = j0Var2;
                p(j0Var2);
            }
            j0Var = f813i;
        }
        return j0Var;
    }

    private synchronized Drawable i(Context context, long j2) {
        l.d<WeakReference<Drawable.ConstantState>> dVar = this.f818d.get(context);
        if (dVar == null) {
            return null;
        }
        WeakReference<Drawable.ConstantState> e2 = dVar.e(j2);
        if (e2 != null) {
            Drawable.ConstantState constantState = e2.get();
            if (constantState != null) {
                return constantState.newDrawable(context.getResources());
            }
            dVar.j(j2);
        }
        return null;
    }

    public static synchronized PorterDuffColorFilter l(int i2, PorterDuff.Mode mode) {
        PorterDuffColorFilter i3;
        synchronized (j0.class) {
            c cVar = f814j;
            i3 = cVar.i(i2, mode);
            if (i3 == null) {
                i3 = new PorterDuffColorFilter(i2, mode);
                cVar.j(i2, mode, i3);
            }
        }
        return i3;
    }

    private ColorStateList n(Context context, int i2) {
        l.h<ColorStateList> hVar;
        WeakHashMap<Context, l.h<ColorStateList>> weakHashMap = this.f815a;
        if (weakHashMap == null || (hVar = weakHashMap.get(context)) == null) {
            return null;
        }
        return hVar.e(i2);
    }

    private static void p(j0 j0Var) {
        if (Build.VERSION.SDK_INT < 24) {
            j0Var.a("vector", new f());
            j0Var.a("animated-vector", new b());
            j0Var.a("animated-selector", new a());
        }
    }

    private static boolean q(Drawable drawable) {
        return (drawable instanceof androidx.vectordrawable.graphics.drawable.g) || "android.graphics.drawable.VectorDrawable".equals(drawable.getClass().getName());
    }

    private Drawable r(Context context, int i2) {
        int next;
        l.g<String, d> gVar = this.f816b;
        if (gVar == null || gVar.isEmpty()) {
            return null;
        }
        l.h<String> hVar = this.f817c;
        if (hVar != null) {
            String e2 = hVar.e(i2);
            if ("appcompat_skip_skip".equals(e2) || (e2 != null && this.f816b.get(e2) == null)) {
                return null;
            }
        } else {
            this.f817c = new l.h<>();
        }
        if (this.f819e == null) {
            this.f819e = new TypedValue();
        }
        TypedValue typedValue = this.f819e;
        Resources resources = context.getResources();
        resources.getValue(i2, typedValue, true);
        long e3 = e(typedValue);
        Drawable i3 = i(context, e3);
        if (i3 != null) {
            return i3;
        }
        CharSequence charSequence = typedValue.string;
        if (charSequence != null && charSequence.toString().endsWith(".xml")) {
            try {
                XmlResourceParser xml = resources.getXml(i2);
                AttributeSet asAttributeSet = Xml.asAttributeSet(xml);
                do {
                    next = xml.next();
                    if (next == 2) {
                        break;
                    }
                } while (next != 1);
                if (next != 2) {
                    throw new XmlPullParserException("No start tag found");
                }
                String name = xml.getName();
                this.f817c.a(i2, name);
                d dVar = this.f816b.get(name);
                if (dVar != null) {
                    i3 = dVar.a(context, xml, asAttributeSet, context.getTheme());
                }
                if (i3 != null) {
                    i3.setChangingConfigurations(typedValue.changingConfigurations);
                    b(context, e3, i3);
                }
            } catch (Exception e4) {
                Log.e("ResourceManagerInternal", "Exception while inflating drawable", e4);
            }
        }
        if (i3 == null) {
            this.f817c.a(i2, "appcompat_skip_skip");
        }
        return i3;
    }

    private Drawable v(Context context, int i2, boolean z2, Drawable drawable) {
        ColorStateList m2 = m(context, i2);
        if (m2 == null) {
            e eVar = this.f821g;
            if ((eVar == null || !eVar.d(context, i2, drawable)) && !x(context, i2, drawable) && z2) {
                return null;
            }
            return drawable;
        }
        if (c0.a(drawable)) {
            drawable = drawable.mutate();
        }
        Drawable r2 = x.a.r(drawable);
        x.a.o(r2, m2);
        PorterDuff.Mode o2 = o(i2);
        if (o2 != null) {
            x.a.p(r2, o2);
            return r2;
        }
        return r2;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void w(Drawable drawable, r0 r0Var, int[] iArr) {
        if (c0.a(drawable) && drawable.mutate() != drawable) {
            Log.d("ResourceManagerInternal", "Mutated drawable is not the same instance as the input.");
            return;
        }
        boolean z2 = r0Var.f907d;
        if (z2 || r0Var.f906c) {
            drawable.setColorFilter(g(z2 ? r0Var.f904a : null, r0Var.f906c ? r0Var.f905b : f812h, iArr));
        } else {
            drawable.clearColorFilter();
        }
        if (Build.VERSION.SDK_INT <= 23) {
            drawable.invalidateSelf();
        }
    }

    public synchronized Drawable j(Context context, int i2) {
        return k(context, i2, false);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public synchronized Drawable k(Context context, int i2, boolean z2) {
        Drawable r2;
        d(context);
        r2 = r(context, i2);
        if (r2 == null) {
            r2 = f(context, i2);
        }
        if (r2 == null) {
            r2 = u.a.c(context, i2);
        }
        if (r2 != null) {
            r2 = v(context, i2, z2, r2);
        }
        if (r2 != null) {
            c0.b(r2);
        }
        return r2;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public synchronized ColorStateList m(Context context, int i2) {
        ColorStateList n2;
        n2 = n(context, i2);
        if (n2 == null) {
            e eVar = this.f821g;
            n2 = eVar == null ? null : eVar.c(context, i2);
            if (n2 != null) {
                c(context, i2, n2);
            }
        }
        return n2;
    }

    PorterDuff.Mode o(int i2) {
        e eVar = this.f821g;
        if (eVar == null) {
            return null;
        }
        return eVar.e(i2);
    }

    public synchronized void s(Context context) {
        l.d<WeakReference<Drawable.ConstantState>> dVar = this.f818d.get(context);
        if (dVar != null) {
            dVar.b();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public synchronized Drawable t(Context context, y0 y0Var, int i2) {
        Drawable r2 = r(context, i2);
        if (r2 == null) {
            r2 = y0Var.c(i2);
        }
        if (r2 != null) {
            return v(context, i2, false, r2);
        }
        return null;
    }

    public synchronized void u(e eVar) {
        this.f821g = eVar;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public boolean x(Context context, int i2, Drawable drawable) {
        e eVar = this.f821g;
        return eVar != null && eVar.b(context, i2, drawable);
    }
}
