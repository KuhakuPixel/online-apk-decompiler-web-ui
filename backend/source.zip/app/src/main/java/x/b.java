package x;
/* loaded from: classes.dex */
public interface b {
}
