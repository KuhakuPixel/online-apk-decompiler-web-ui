package androidx.activity;

import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;
/* loaded from: classes.dex */
public abstract class b {

    /* renamed from: a  reason: collision with root package name */
    private boolean f209a;

    /* renamed from: b  reason: collision with root package name */
    private CopyOnWriteArrayList<a> f210b = new CopyOnWriteArrayList<>();

    public b(boolean z2) {
        this.f209a = z2;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void a(a aVar) {
        this.f210b.add(aVar);
    }

    public abstract void b();

    public final boolean c() {
        return this.f209a;
    }

    public final void d() {
        Iterator<a> it = this.f210b.iterator();
        while (it.hasNext()) {
            it.next().cancel();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void e(a aVar) {
        this.f210b.remove(aVar);
    }

    public final void f(boolean z2) {
        this.f209a = z2;
    }
}
