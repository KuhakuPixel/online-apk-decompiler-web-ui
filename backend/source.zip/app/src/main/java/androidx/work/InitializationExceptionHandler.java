package androidx.work;
/* loaded from: classes.dex */
public interface InitializationExceptionHandler {
    void handleException(Throwable throwable);
}
