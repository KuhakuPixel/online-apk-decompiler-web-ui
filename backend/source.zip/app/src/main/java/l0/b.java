package l0;
/* loaded from: classes.dex */
public final class b {

    /* renamed from: a */
    public static final int fragment_container_view_tag = 2131361965;

    /* renamed from: b */
    public static final int visible_removing_fragment_view_tag = 2131362223;
}
