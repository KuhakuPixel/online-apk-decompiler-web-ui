package androidx.appcompat.widget;

import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;
import androidx.appcompat.widget.LinearLayoutCompat;
import b.a;
/* loaded from: classes.dex */
public class m0 extends HorizontalScrollView implements AdapterView.OnItemSelectedListener {

    /* renamed from: k  reason: collision with root package name */
    private static final Interpolator f836k = new DecelerateInterpolator();

    /* renamed from: b  reason: collision with root package name */
    Runnable f837b;

    /* renamed from: c  reason: collision with root package name */
    private c f838c;

    /* renamed from: d  reason: collision with root package name */
    LinearLayoutCompat f839d;

    /* renamed from: e  reason: collision with root package name */
    private Spinner f840e;

    /* renamed from: f  reason: collision with root package name */
    private boolean f841f;

    /* renamed from: g  reason: collision with root package name */
    int f842g;

    /* renamed from: h  reason: collision with root package name */
    int f843h;

    /* renamed from: i  reason: collision with root package name */
    private int f844i;

    /* renamed from: j  reason: collision with root package name */
    private int f845j;

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public class a implements Runnable {

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ View f846b;

        a(View view) {
            this.f846b = view;
        }

        @Override // java.lang.Runnable
        public void run() {
            m0.this.smoothScrollTo(this.f846b.getLeft() - ((m0.this.getWidth() - this.f846b.getWidth()) / 2), 0);
            m0.this.f837b = null;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public class b extends BaseAdapter {
        b() {
        }

        @Override // android.widget.Adapter
        public int getCount() {
            return m0.this.f839d.getChildCount();
        }

        @Override // android.widget.Adapter
        public Object getItem(int i2) {
            return ((d) m0.this.f839d.getChildAt(i2)).b();
        }

        @Override // android.widget.Adapter
        public long getItemId(int i2) {
            return i2;
        }

        @Override // android.widget.Adapter
        public View getView(int i2, View view, ViewGroup viewGroup) {
            if (view == null) {
                return m0.this.c((a.c) getItem(i2), true);
            }
            ((d) view).a((a.c) getItem(i2));
            return view;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public class c implements View.OnClickListener {
        c() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            ((d) view).b().e();
            int childCount = m0.this.f839d.getChildCount();
            for (int i2 = 0; i2 < childCount; i2++) {
                View childAt = m0.this.f839d.getChildAt(i2);
                childAt.setSelected(childAt == view);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public class d extends LinearLayout {

        /* renamed from: b  reason: collision with root package name */
        private final int[] f850b;

        /* renamed from: c  reason: collision with root package name */
        private a.c f851c;

        /* renamed from: d  reason: collision with root package name */
        private TextView f852d;

        /* renamed from: e  reason: collision with root package name */
        private ImageView f853e;

        /* renamed from: f  reason: collision with root package name */
        private View f854f;

        /* JADX WARN: Illegal instructions before constructor call */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public d(android.content.Context r6, b.a.c r7, boolean r8) {
            /*
                r4 = this;
                androidx.appcompat.widget.m0.this = r5
                int r5 = a.a.actionBarTabStyle
                r0 = 0
                r4.<init>(r6, r0, r5)
                r1 = 1
                int[] r1 = new int[r1]
                r2 = 16842964(0x10100d4, float:2.3694152E-38)
                r3 = 0
                r1[r3] = r2
                r4.f850b = r1
                r4.f851c = r7
                androidx.appcompat.widget.t0 r5 = androidx.appcompat.widget.t0.v(r6, r0, r1, r5, r3)
                boolean r6 = r5.s(r3)
                if (r6 == 0) goto L26
                android.graphics.drawable.Drawable r6 = r5.g(r3)
                r4.setBackgroundDrawable(r6)
            L26:
                r5.w()
                if (r8 == 0) goto L31
                r5 = 8388627(0x800013, float:1.175497E-38)
                r4.setGravity(r5)
            L31:
                r4.c()
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.m0.d.<init>(androidx.appcompat.widget.m0, android.content.Context, b.a$c, boolean):void");
        }

        public void a(a.c cVar) {
            this.f851c = cVar;
            c();
        }

        public a.c b() {
            return this.f851c;
        }

        public void c() {
            a.c cVar = this.f851c;
            View b2 = cVar.b();
            if (b2 != null) {
                ViewParent parent = b2.getParent();
                if (parent != this) {
                    if (parent != null) {
                        ((ViewGroup) parent).removeView(b2);
                    }
                    addView(b2);
                }
                this.f854f = b2;
                TextView textView = this.f852d;
                if (textView != null) {
                    textView.setVisibility(8);
                }
                ImageView imageView = this.f853e;
                if (imageView != null) {
                    imageView.setVisibility(8);
                    this.f853e.setImageDrawable(null);
                    return;
                }
                return;
            }
            View view = this.f854f;
            if (view != null) {
                removeView(view);
                this.f854f = null;
            }
            Drawable c2 = cVar.c();
            CharSequence d2 = cVar.d();
            if (c2 != null) {
                if (this.f853e == null) {
                    AppCompatImageView appCompatImageView = new AppCompatImageView(getContext());
                    LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
                    layoutParams.gravity = 16;
                    appCompatImageView.setLayoutParams(layoutParams);
                    addView(appCompatImageView, 0);
                    this.f853e = appCompatImageView;
                }
                this.f853e.setImageDrawable(c2);
                this.f853e.setVisibility(0);
            } else {
                ImageView imageView2 = this.f853e;
                if (imageView2 != null) {
                    imageView2.setVisibility(8);
                    this.f853e.setImageDrawable(null);
                }
            }
            boolean z2 = !TextUtils.isEmpty(d2);
            if (z2) {
                if (this.f852d == null) {
                    AppCompatTextView appCompatTextView = new AppCompatTextView(getContext(), null, a.a.actionBarTabTextStyle);
                    appCompatTextView.setEllipsize(TextUtils.TruncateAt.END);
                    LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-2, -2);
                    layoutParams2.gravity = 16;
                    appCompatTextView.setLayoutParams(layoutParams2);
                    addView(appCompatTextView);
                    this.f852d = appCompatTextView;
                }
                this.f852d.setText(d2);
                this.f852d.setVisibility(0);
            } else {
                TextView textView2 = this.f852d;
                if (textView2 != null) {
                    textView2.setVisibility(8);
                    this.f852d.setText((CharSequence) null);
                }
            }
            ImageView imageView3 = this.f853e;
            if (imageView3 != null) {
                imageView3.setContentDescription(cVar.a());
            }
            v0.a(this, z2 ? null : cVar.a());
        }

        @Override // android.view.View
        public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
            super.onInitializeAccessibilityEvent(accessibilityEvent);
            accessibilityEvent.setClassName("androidx.appcompat.app.ActionBar$Tab");
        }

        @Override // android.view.View
        public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
            super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
            accessibilityNodeInfo.setClassName("androidx.appcompat.app.ActionBar$Tab");
        }

        @Override // android.widget.LinearLayout, android.view.View
        public void onMeasure(int i2, int i3) {
            super.onMeasure(i2, i3);
            if (m0.this.f842g > 0) {
                int measuredWidth = getMeasuredWidth();
                int i4 = m0.this.f842g;
                if (measuredWidth > i4) {
                    super.onMeasure(View.MeasureSpec.makeMeasureSpec(i4, 1073741824), i3);
                }
            }
        }

        @Override // android.view.View
        public void setSelected(boolean z2) {
            boolean z3 = isSelected() != z2;
            super.setSelected(z2);
            if (z3 && z2) {
                sendAccessibilityEvent(4);
            }
        }
    }

    private Spinner b() {
        v vVar = new v(getContext(), null, a.a.actionDropDownStyle);
        vVar.setLayoutParams(new LinearLayoutCompat.a(-2, -1));
        vVar.setOnItemSelectedListener(this);
        return vVar;
    }

    private boolean d() {
        Spinner spinner = this.f840e;
        return spinner != null && spinner.getParent() == this;
    }

    private void e() {
        if (d()) {
            return;
        }
        if (this.f840e == null) {
            this.f840e = b();
        }
        removeView(this.f839d);
        addView(this.f840e, new ViewGroup.LayoutParams(-2, -1));
        if (this.f840e.getAdapter() == null) {
            this.f840e.setAdapter((SpinnerAdapter) new b());
        }
        Runnable runnable = this.f837b;
        if (runnable != null) {
            removeCallbacks(runnable);
            this.f837b = null;
        }
        this.f840e.setSelection(this.f845j);
    }

    private boolean f() {
        if (d()) {
            removeView(this.f840e);
            addView(this.f839d, new ViewGroup.LayoutParams(-2, -1));
            setTabSelected(this.f840e.getSelectedItemPosition());
            return false;
        }
        return false;
    }

    public void a(int i2) {
        View childAt = this.f839d.getChildAt(i2);
        Runnable runnable = this.f837b;
        if (runnable != null) {
            removeCallbacks(runnable);
        }
        a aVar = new a(childAt);
        this.f837b = aVar;
        post(aVar);
    }

    d c(a.c cVar, boolean z2) {
        d dVar = new d(getContext(), cVar, z2);
        if (z2) {
            dVar.setBackgroundDrawable(null);
            dVar.setLayoutParams(new AbsListView.LayoutParams(-1, this.f844i));
        } else {
            dVar.setFocusable(true);
            if (this.f838c == null) {
                this.f838c = new c();
            }
            dVar.setOnClickListener(this.f838c);
        }
        return dVar;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        Runnable runnable = this.f837b;
        if (runnable != null) {
            post(runnable);
        }
    }

    @Override // android.view.View
    protected void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        f.a b2 = f.a.b(getContext());
        setContentHeight(b2.f());
        this.f843h = b2.e();
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        Runnable runnable = this.f837b;
        if (runnable != null) {
            removeCallbacks(runnable);
        }
    }

    @Override // android.widget.AdapterView.OnItemSelectedListener
    public void onItemSelected(AdapterView<?> adapterView, View view, int i2, long j2) {
        ((d) view).b().e();
    }

    @Override // android.widget.HorizontalScrollView, android.widget.FrameLayout, android.view.View
    public void onMeasure(int i2, int i3) {
        int i4;
        int mode = View.MeasureSpec.getMode(i2);
        boolean z2 = mode == 1073741824;
        setFillViewport(z2);
        int childCount = this.f839d.getChildCount();
        if (childCount <= 1 || !(mode == 1073741824 || mode == Integer.MIN_VALUE)) {
            i4 = -1;
        } else {
            if (childCount > 2) {
                this.f842g = (int) (View.MeasureSpec.getSize(i2) * 0.4f);
            } else {
                this.f842g = View.MeasureSpec.getSize(i2) / 2;
            }
            i4 = Math.min(this.f842g, this.f843h);
        }
        this.f842g = i4;
        int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(this.f844i, 1073741824);
        if (!z2 && this.f841f) {
            this.f839d.measure(0, makeMeasureSpec);
            if (this.f839d.getMeasuredWidth() > View.MeasureSpec.getSize(i2)) {
                e();
                int measuredWidth = getMeasuredWidth();
                super.onMeasure(i2, makeMeasureSpec);
                int measuredWidth2 = getMeasuredWidth();
                if (z2 || measuredWidth == measuredWidth2) {
                }
                setTabSelected(this.f845j);
                return;
            }
        }
        f();
        int measuredWidth3 = getMeasuredWidth();
        super.onMeasure(i2, makeMeasureSpec);
        int measuredWidth22 = getMeasuredWidth();
        if (z2) {
        }
    }

    @Override // android.widget.AdapterView.OnItemSelectedListener
    public void onNothingSelected(AdapterView<?> adapterView) {
    }

    public void setAllowCollapse(boolean z2) {
        this.f841f = z2;
    }

    public void setContentHeight(int i2) {
        this.f844i = i2;
        requestLayout();
    }

    public void setTabSelected(int i2) {
        this.f845j = i2;
        int childCount = this.f839d.getChildCount();
        int i3 = 0;
        while (i3 < childCount) {
            View childAt = this.f839d.getChildAt(i3);
            boolean z2 = i3 == i2;
            childAt.setSelected(z2);
            if (z2) {
                a(i2);
            }
            i3++;
        }
        Spinner spinner = this.f840e;
        if (spinner == null || i2 < 0) {
            return;
        }
        spinner.setSelection(i2);
    }
}
