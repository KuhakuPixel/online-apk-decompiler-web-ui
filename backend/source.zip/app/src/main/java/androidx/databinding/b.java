package androidx.databinding;

import java.util.ArrayList;
import java.util.List;
/* loaded from: classes.dex */
public class b<C, T, A> implements Cloneable {

    /* renamed from: b  reason: collision with root package name */
    private List<C> f1509b = new ArrayList();

    /* renamed from: c  reason: collision with root package name */
    private long f1510c = 0;

    /* renamed from: d  reason: collision with root package name */
    private long[] f1511d;

    /* renamed from: e  reason: collision with root package name */
    private int f1512e;

    /* renamed from: f  reason: collision with root package name */
    private final a<C, T, A> f1513f;

    /* loaded from: classes.dex */
    public static abstract class a<C, T, A> {
        public abstract void a(C c2, T t2, int i2, A a2);
    }

    public b(a<C, T, A> aVar) {
        this.f1513f = aVar;
    }

    private boolean c(int i2) {
        int i3;
        if (i2 < 64) {
            return ((1 << i2) & this.f1510c) != 0;
        }
        long[] jArr = this.f1511d;
        if (jArr != null && (i3 = (i2 / 64) - 1) < jArr.length) {
            return ((1 << (i2 % 64)) & jArr[i3]) != 0;
        }
        return false;
    }

    private void e(T t2, int i2, A a2, int i3, int i4, long j2) {
        long j3 = 1;
        while (i3 < i4) {
            if ((j2 & j3) == 0) {
                this.f1513f.a(this.f1509b.get(i3), t2, i2, a2);
            }
            j3 <<= 1;
            i3++;
        }
    }

    private void f(T t2, int i2, A a2) {
        e(t2, i2, a2, 0, Math.min(64, this.f1509b.size()), this.f1510c);
    }

    private void g(T t2, int i2, A a2) {
        int size = this.f1509b.size();
        int length = this.f1511d == null ? -1 : r0.length - 1;
        h(t2, i2, a2, length);
        e(t2, i2, a2, (length + 2) * 64, size, 0L);
    }

    private void h(T t2, int i2, A a2, int i3) {
        if (i3 < 0) {
            f(t2, i2, a2);
            return;
        }
        long j2 = this.f1511d[i3];
        int i4 = (i3 + 1) * 64;
        int min = Math.min(this.f1509b.size(), i4 + 64);
        h(t2, i2, a2, i3 - 1);
        e(t2, i2, a2, i4, min, j2);
    }

    private void j(int i2, long j2) {
        long j3 = Long.MIN_VALUE;
        for (int i3 = (i2 + 64) - 1; i3 >= i2; i3--) {
            if ((j2 & j3) != 0) {
                this.f1509b.remove(i3);
            }
            j3 >>>= 1;
        }
    }

    private void k(int i2) {
        if (i2 < 64) {
            this.f1510c = (1 << i2) | this.f1510c;
            return;
        }
        int i3 = (i2 / 64) - 1;
        long[] jArr = this.f1511d;
        if (jArr == null) {
            this.f1511d = new long[this.f1509b.size() / 64];
        } else if (jArr.length <= i3) {
            long[] jArr2 = new long[this.f1509b.size() / 64];
            long[] jArr3 = this.f1511d;
            System.arraycopy(jArr3, 0, jArr2, 0, jArr3.length);
            this.f1511d = jArr2;
        }
        long j2 = 1 << (i2 % 64);
        long[] jArr4 = this.f1511d;
        jArr4[i3] = j2 | jArr4[i3];
    }

    public synchronized void a(C c2) {
        if (c2 == null) {
            throw new IllegalArgumentException("callback cannot be null");
        }
        int lastIndexOf = this.f1509b.lastIndexOf(c2);
        if (lastIndexOf < 0 || c(lastIndexOf)) {
            this.f1509b.add(c2);
        }
    }

    /* renamed from: b  reason: merged with bridge method [inline-methods] */
    public synchronized b<C, T, A> clone() {
        b<C, T, A> bVar;
        CloneNotSupportedException e2;
        try {
            bVar = (b) super.clone();
            try {
                bVar.f1510c = 0L;
                bVar.f1511d = null;
                bVar.f1512e = 0;
                bVar.f1509b = new ArrayList();
                int size = this.f1509b.size();
                for (int i2 = 0; i2 < size; i2++) {
                    if (!c(i2)) {
                        bVar.f1509b.add(this.f1509b.get(i2));
                    }
                }
            } catch (CloneNotSupportedException e3) {
                e2 = e3;
                e2.printStackTrace();
                return bVar;
            }
        } catch (CloneNotSupportedException e4) {
            bVar = null;
            e2 = e4;
        }
        return bVar;
    }

    public synchronized void d(T t2, int i2, A a2) {
        this.f1512e++;
        g(t2, i2, a2);
        int i3 = this.f1512e - 1;
        this.f1512e = i3;
        if (i3 == 0) {
            long[] jArr = this.f1511d;
            if (jArr != null) {
                for (int length = jArr.length - 1; length >= 0; length--) {
                    long j2 = this.f1511d[length];
                    if (j2 != 0) {
                        j((length + 1) * 64, j2);
                        this.f1511d[length] = 0;
                    }
                }
            }
            long j3 = this.f1510c;
            if (j3 != 0) {
                j(0, j3);
                this.f1510c = 0L;
            }
        }
    }

    public synchronized void i(C c2) {
        if (this.f1512e == 0) {
            this.f1509b.remove(c2);
        } else {
            int lastIndexOf = this.f1509b.lastIndexOf(c2);
            if (lastIndexOf >= 0) {
                k(lastIndexOf);
            }
        }
    }
}
