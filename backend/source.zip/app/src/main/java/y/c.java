package y;

import android.view.SubMenu;
/* loaded from: classes.dex */
public interface c extends a, SubMenu {
}
