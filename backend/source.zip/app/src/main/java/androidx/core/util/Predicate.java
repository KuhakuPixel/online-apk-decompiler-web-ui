package androidx.core.util;
/* loaded from: classes.dex */
public interface Predicate<T> {
    boolean test(T t);
}
