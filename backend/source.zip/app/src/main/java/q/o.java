package q;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
/* loaded from: classes.dex */
public class o {

    /* renamed from: g  reason: collision with root package name */
    static int f5043g;

    /* renamed from: b  reason: collision with root package name */
    int f5045b;

    /* renamed from: d  reason: collision with root package name */
    int f5047d;

    /* renamed from: a  reason: collision with root package name */
    ArrayList<p.e> f5044a = new ArrayList<>();

    /* renamed from: c  reason: collision with root package name */
    boolean f5046c = false;

    /* renamed from: e  reason: collision with root package name */
    ArrayList<a> f5048e = null;

    /* renamed from: f  reason: collision with root package name */
    private int f5049f = -1;

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public class a {

        /* renamed from: a  reason: collision with root package name */
        WeakReference<p.e> f5050a;

        /* renamed from: b  reason: collision with root package name */
        int f5051b;

        /* renamed from: c  reason: collision with root package name */
        int f5052c;

        /* renamed from: d  reason: collision with root package name */
        int f5053d;

        /* renamed from: e  reason: collision with root package name */
        int f5054e;

        /* renamed from: f  reason: collision with root package name */
        int f5055f;

        /* renamed from: g  reason: collision with root package name */
        int f5056g;

        public a(p.e eVar, o.d dVar, int i2) {
            this.f5050a = new WeakReference<>(eVar);
            this.f5051b = dVar.x(eVar.H);
            this.f5052c = dVar.x(eVar.I);
            this.f5053d = dVar.x(eVar.J);
            this.f5054e = dVar.x(eVar.K);
            this.f5055f = dVar.x(eVar.L);
            this.f5056g = i2;
        }
    }

    public o(int i2) {
        int i3 = f5043g;
        f5043g = i3 + 1;
        this.f5045b = i3;
        this.f5047d = i2;
    }

    private String e() {
        int i2 = this.f5047d;
        return i2 == 0 ? "Horizontal" : i2 == 1 ? "Vertical" : i2 == 2 ? "Both" : "Unknown";
    }

    private int j(o.d dVar, ArrayList<p.e> arrayList, int i2) {
        int x2;
        p.d dVar2;
        p.f fVar = (p.f) arrayList.get(0).I();
        dVar.D();
        fVar.g(dVar, false);
        for (int i3 = 0; i3 < arrayList.size(); i3++) {
            arrayList.get(i3).g(dVar, false);
        }
        if (i2 == 0 && fVar.N0 > 0) {
            p.b.b(fVar, dVar, arrayList, 0);
        }
        if (i2 == 1 && fVar.O0 > 0) {
            p.b.b(fVar, dVar, arrayList, 1);
        }
        try {
            dVar.z();
        } catch (Exception e2) {
            e2.printStackTrace();
        }
        this.f5048e = new ArrayList<>();
        for (int i4 = 0; i4 < arrayList.size(); i4++) {
            this.f5048e.add(new a(arrayList.get(i4), dVar, i2));
        }
        if (i2 == 0) {
            x2 = dVar.x(fVar.H);
            dVar2 = fVar.J;
        } else {
            x2 = dVar.x(fVar.I);
            dVar2 = fVar.K;
        }
        int x3 = dVar.x(dVar2);
        dVar.D();
        return x3 - x2;
    }

    public boolean a(p.e eVar) {
        if (this.f5044a.contains(eVar)) {
            return false;
        }
        this.f5044a.add(eVar);
        return true;
    }

    public void b(ArrayList<o> arrayList) {
        int size = this.f5044a.size();
        if (this.f5049f != -1 && size > 0) {
            for (int i2 = 0; i2 < arrayList.size(); i2++) {
                o oVar = arrayList.get(i2);
                if (this.f5049f == oVar.f5045b) {
                    g(this.f5047d, oVar);
                }
            }
        }
        if (size == 0) {
            arrayList.remove(this);
        }
    }

    public int c() {
        return this.f5045b;
    }

    public int d() {
        return this.f5047d;
    }

    public int f(o.d dVar, int i2) {
        if (this.f5044a.size() == 0) {
            return 0;
        }
        return j(dVar, this.f5044a, i2);
    }

    public void g(int i2, o oVar) {
        Iterator<p.e> it = this.f5044a.iterator();
        while (it.hasNext()) {
            p.e next = it.next();
            oVar.a(next);
            int c2 = oVar.c();
            if (i2 == 0) {
                next.A0 = c2;
            } else {
                next.B0 = c2;
            }
        }
        this.f5049f = oVar.f5045b;
    }

    public void h(boolean z2) {
        this.f5046c = z2;
    }

    public void i(int i2) {
        this.f5047d = i2;
    }

    public String toString() {
        String str = e() + " [" + this.f5045b + "] <";
        Iterator<p.e> it = this.f5044a.iterator();
        while (it.hasNext()) {
            str = str + " " + it.next().r();
        }
        return str + " >";
    }
}
