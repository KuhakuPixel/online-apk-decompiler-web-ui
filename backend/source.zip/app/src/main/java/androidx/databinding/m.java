package androidx.databinding;

import java.lang.ref.ReferenceQueue;
import java.lang.ref.WeakReference;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes.dex */
public class m<T> extends WeakReference<ViewDataBinding> {

    /* renamed from: a  reason: collision with root package name */
    private final j<T> f1518a;

    /* renamed from: b  reason: collision with root package name */
    protected final int f1519b;

    /* renamed from: c  reason: collision with root package name */
    private T f1520c;

    public m(ViewDataBinding viewDataBinding, int i2, j<T> jVar, ReferenceQueue<ViewDataBinding> referenceQueue) {
        super(viewDataBinding, referenceQueue);
        this.f1519b = i2;
        this.f1518a = jVar;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public ViewDataBinding a() {
        ViewDataBinding viewDataBinding = (ViewDataBinding) get();
        if (viewDataBinding == null) {
            e();
        }
        return viewDataBinding;
    }

    public T b() {
        return this.f1520c;
    }

    public void c(androidx.lifecycle.g gVar) {
        this.f1518a.b(gVar);
    }

    public void d(T t2) {
        e();
        this.f1520c = t2;
        if (t2 != null) {
            this.f1518a.a(t2);
        }
    }

    public boolean e() {
        boolean z2;
        T t2 = this.f1520c;
        if (t2 != null) {
            this.f1518a.d(t2);
            z2 = true;
        } else {
            z2 = false;
        }
        this.f1520c = null;
        return z2;
    }
}
