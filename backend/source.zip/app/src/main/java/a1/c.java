package a1;
/* loaded from: classes.dex */
public final class c {

    /* renamed from: a */
    public static final int design_error = 2131099722;

    /* renamed from: b */
    public static final int material_timepicker_clockface = 2131099774;

    /* renamed from: c */
    public static final int mtrl_filled_background_color = 2131099803;

    /* renamed from: d */
    public static final int mtrl_textinput_default_box_stroke_color = 2131099822;

    /* renamed from: e */
    public static final int mtrl_textinput_disabled_color = 2131099823;

    /* renamed from: f */
    public static final int mtrl_textinput_hovered_box_stroke_color = 2131099826;
}
