package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.Bitmap;
import android.util.AttributeSet;
import android.view.View;
import android.widget.RatingBar;
/* loaded from: classes.dex */
public class s extends RatingBar {

    /* renamed from: b  reason: collision with root package name */
    private final q f908b;

    public s(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, a.a.ratingBarStyle);
    }

    public s(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        o0.a(this, getContext());
        q qVar = new q(this);
        this.f908b = qVar;
        qVar.c(attributeSet, i2);
    }

    @Override // android.widget.RatingBar, android.widget.AbsSeekBar, android.widget.ProgressBar, android.view.View
    protected synchronized void onMeasure(int i2, int i3) {
        super.onMeasure(i2, i3);
        Bitmap b2 = this.f908b.b();
        if (b2 != null) {
            setMeasuredDimension(View.resolveSizeAndState(b2.getWidth() * getNumStars(), i2, 0), getMeasuredHeight());
        }
    }
}
