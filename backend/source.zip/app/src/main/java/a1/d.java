package a1;
/* loaded from: classes.dex */
public final class d {

    /* renamed from: A */
    public static final int mtrl_calendar_days_of_week_height = 2131165426;

    /* renamed from: B */
    public static final int mtrl_calendar_dialog_background_inset = 2131165427;

    /* renamed from: C */
    public static final int mtrl_calendar_month_horizontal_padding = 2131165439;

    /* renamed from: D */
    public static final int mtrl_calendar_month_vertical_padding = 2131165440;

    /* renamed from: E */
    public static final int mtrl_calendar_navigation_bottom_padding = 2131165441;

    /* renamed from: F */
    public static final int mtrl_calendar_navigation_height = 2131165442;

    /* renamed from: G */
    public static final int mtrl_calendar_navigation_top_padding = 2131165443;

    /* renamed from: H */
    public static final int mtrl_edittext_rectangle_top_offset = 2131165465;

    /* renamed from: I */
    public static final int mtrl_exposed_dropdown_menu_popup_elevation = 2131165466;

    /* renamed from: J */
    public static final int mtrl_exposed_dropdown_menu_popup_vertical_padding = 2131165468;

    /* renamed from: K */
    public static final int mtrl_min_touch_target_size = 2131165499;

    /* renamed from: L */
    public static final int mtrl_shape_corner_size_small_component = 2131165522;

    /* renamed from: M */
    public static final int mtrl_snackbar_background_corner_radius = 2131165534;

    /* renamed from: N */
    public static final int mtrl_textinput_box_label_cutout_padding = 2131165542;

    /* renamed from: O */
    public static final int mtrl_textinput_box_stroke_width_default = 2131165543;

    /* renamed from: P */
    public static final int mtrl_textinput_box_stroke_width_focused = 2131165544;

    /* renamed from: Q */
    public static final int mtrl_textinput_counter_margin_start = 2131165545;

    /* renamed from: a */
    public static final int design_appbar_elevation = 2131165279;

    /* renamed from: b */
    public static final int design_bottom_sheet_peek_height_min = 2131165294;

    /* renamed from: c */
    public static final int design_fab_size_mini = 2131165298;

    /* renamed from: d */
    public static final int design_fab_size_normal = 2131165299;

    /* renamed from: e */
    public static final int design_navigation_icon_size = 2131165304;

    /* renamed from: f */
    public static final int design_snackbar_padding_vertical = 2131165318;

    /* renamed from: g */
    public static final int design_snackbar_padding_vertical_2lines = 2131165319;

    /* renamed from: h */
    public static final int design_textinput_caption_translate_y = 2131165325;

    /* renamed from: i */
    public static final int material_clock_hand_center_dot_radius = 2131165346;

    /* renamed from: j */
    public static final int material_clock_hand_padding = 2131165347;

    /* renamed from: k */
    public static final int material_clock_hand_stroke_width = 2131165348;

    /* renamed from: l */
    public static final int material_filled_edittext_font_1_3_padding_bottom = 2131165360;

    /* renamed from: m */
    public static final int material_filled_edittext_font_1_3_padding_top = 2131165361;

    /* renamed from: n */
    public static final int material_filled_edittext_font_2_0_padding_bottom = 2131165362;

    /* renamed from: o */
    public static final int material_filled_edittext_font_2_0_padding_top = 2131165363;

    /* renamed from: p */
    public static final int material_font_1_3_box_collapsed_padding_top = 2131165364;

    /* renamed from: q */
    public static final int material_font_2_0_box_collapsed_padding_top = 2131165365;

    /* renamed from: r */
    public static final int material_helper_text_default_padding_top = 2131165366;

    /* renamed from: s */
    public static final int material_helper_text_font_1_3_padding_horizontal = 2131165367;

    /* renamed from: t */
    public static final int material_helper_text_font_1_3_padding_top = 2131165368;

    /* renamed from: u */
    public static final int material_input_text_to_prefix_suffix_padding = 2131165369;

    /* renamed from: v */
    public static final int mtrl_bottomappbar_fab_bottom_margin = 2131165387;

    /* renamed from: w */
    public static final int mtrl_calendar_bottom_padding = 2131165418;

    /* renamed from: x */
    public static final int mtrl_calendar_content_padding = 2131165419;

    /* renamed from: y */
    public static final int mtrl_calendar_day_height = 2131165421;

    /* renamed from: z */
    public static final int mtrl_calendar_day_width = 2131165425;
}
