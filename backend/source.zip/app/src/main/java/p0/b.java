package p0;

import android.annotation.SuppressLint;
import androidx.navigation.l;
import java.util.HashSet;
import java.util.Set;
/* loaded from: classes.dex */
public final class b {

    /* renamed from: a  reason: collision with root package name */
    private final Set<Integer> f4959a;

    /* renamed from: b  reason: collision with root package name */
    private final i0.c f4960b;

    /* renamed from: c  reason: collision with root package name */
    private final c f4961c;

    /* renamed from: p0.b$b  reason: collision with other inner class name */
    /* loaded from: classes.dex */
    public static final class C0067b {

        /* renamed from: a  reason: collision with root package name */
        private final Set<Integer> f4962a;

        /* renamed from: b  reason: collision with root package name */
        private i0.c f4963b;

        /* renamed from: c  reason: collision with root package name */
        private c f4964c;

        public C0067b(l lVar) {
            HashSet hashSet = new HashSet();
            this.f4962a = hashSet;
            hashSet.add(Integer.valueOf(p0.c.a(lVar).k()));
        }

        @SuppressLint({"SyntheticAccessor"})
        public b a() {
            return new b(this.f4962a, this.f4963b, this.f4964c);
        }
    }

    /* loaded from: classes.dex */
    public interface c {
        boolean a();
    }

    private b(Set<Integer> set, i0.c cVar, c cVar2) {
        this.f4959a = set;
        this.f4960b = cVar;
        this.f4961c = cVar2;
    }

    public c a() {
        return this.f4961c;
    }

    public i0.c b() {
        return this.f4960b;
    }

    public Set<Integer> c() {
        return this.f4959a;
    }
}
