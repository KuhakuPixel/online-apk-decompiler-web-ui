package o;
/* loaded from: classes.dex */
public class c {

    /* renamed from: a  reason: collision with root package name */
    f<b> f4724a = new g(256);

    /* renamed from: b  reason: collision with root package name */
    f<b> f4725b = new g(256);

    /* renamed from: c  reason: collision with root package name */
    f<i> f4726c = new g(256);

    /* renamed from: d  reason: collision with root package name */
    i[] f4727d = new i[32];
}
