package androidx.navigation;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.net.Uri;
import android.os.Bundle;
import android.util.AttributeSet;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
/* loaded from: classes.dex */
public class k {

    /* renamed from: j  reason: collision with root package name */
    private static final HashMap<String, Class<?>> f2000j = new HashMap<>();

    /* renamed from: b  reason: collision with root package name */
    private final String f2001b;

    /* renamed from: c  reason: collision with root package name */
    private l f2002c;

    /* renamed from: d  reason: collision with root package name */
    private int f2003d;

    /* renamed from: e  reason: collision with root package name */
    private String f2004e;

    /* renamed from: f  reason: collision with root package name */
    private CharSequence f2005f;

    /* renamed from: g  reason: collision with root package name */
    private ArrayList<h> f2006g;

    /* renamed from: h  reason: collision with root package name */
    private l.h<c> f2007h;

    /* renamed from: i  reason: collision with root package name */
    private HashMap<String, d> f2008i;

    /* loaded from: classes.dex */
    static class a implements Comparable<a> {

        /* renamed from: b  reason: collision with root package name */
        private final k f2009b;

        /* renamed from: c  reason: collision with root package name */
        private final Bundle f2010c;

        /* renamed from: d  reason: collision with root package name */
        private final boolean f2011d;

        /* renamed from: e  reason: collision with root package name */
        private final boolean f2012e;

        /* renamed from: f  reason: collision with root package name */
        private final int f2013f;

        a(k kVar, Bundle bundle, boolean z2, boolean z3, int i2) {
            this.f2009b = kVar;
            this.f2010c = bundle;
            this.f2011d = z2;
            this.f2012e = z3;
            this.f2013f = i2;
        }

        @Override // java.lang.Comparable
        /* renamed from: a  reason: merged with bridge method [inline-methods] */
        public int compareTo(a aVar) {
            boolean z2 = this.f2011d;
            if (!z2 || aVar.f2011d) {
                if (z2 || !aVar.f2011d) {
                    Bundle bundle = this.f2010c;
                    if (bundle == null || aVar.f2010c != null) {
                        if (bundle != null || aVar.f2010c == null) {
                            if (bundle != null) {
                                int size = bundle.size() - aVar.f2010c.size();
                                if (size > 0) {
                                    return 1;
                                }
                                if (size < 0) {
                                    return -1;
                                }
                            }
                            boolean z3 = this.f2012e;
                            if (!z3 || aVar.f2012e) {
                                if (z3 || !aVar.f2012e) {
                                    return this.f2013f - aVar.f2013f;
                                }
                                return -1;
                            }
                            return 1;
                        }
                        return -1;
                    }
                    return 1;
                }
                return -1;
            }
            return 1;
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public k b() {
            return this.f2009b;
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public Bundle c() {
            return this.f2010c;
        }
    }

    public k(s<? extends k> sVar) {
        this(t.c(sVar.getClass()));
    }

    public k(String str) {
        this.f2001b = str;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String j(Context context, int i2) {
        if (i2 <= 16777215) {
            return Integer.toString(i2);
        }
        try {
            return context.getResources().getResourceName(i2);
        } catch (Resources.NotFoundException unused) {
            return Integer.toString(i2);
        }
    }

    public final void c(String str, d dVar) {
        if (this.f2008i == null) {
            this.f2008i = new HashMap<>();
        }
        this.f2008i.put(str, dVar);
    }

    public final void d(h hVar) {
        if (this.f2006g == null) {
            this.f2006g = new ArrayList<>();
        }
        this.f2006g.add(hVar);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public Bundle e(Bundle bundle) {
        HashMap<String, d> hashMap;
        if (bundle == null && ((hashMap = this.f2008i) == null || hashMap.isEmpty())) {
            return null;
        }
        Bundle bundle2 = new Bundle();
        HashMap<String, d> hashMap2 = this.f2008i;
        if (hashMap2 != null) {
            for (Map.Entry<String, d> entry : hashMap2.entrySet()) {
                entry.getValue().c(entry.getKey(), bundle2);
            }
        }
        if (bundle != null) {
            bundle2.putAll(bundle);
            HashMap<String, d> hashMap3 = this.f2008i;
            if (hashMap3 != null) {
                for (Map.Entry<String, d> entry2 : hashMap3.entrySet()) {
                    if (!entry2.getValue().d(entry2.getKey(), bundle2)) {
                        throw new IllegalArgumentException("Wrong argument type for '" + entry2.getKey() + "' in argument bundle. " + entry2.getValue().a().c() + " expected.");
                    }
                }
            }
        }
        return bundle2;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public int[] f() {
        ArrayDeque arrayDeque = new ArrayDeque();
        k kVar = this;
        while (true) {
            l n2 = kVar.n();
            if (n2 == null || n2.z() != kVar.k()) {
                arrayDeque.addFirst(kVar);
            }
            if (n2 == null) {
                break;
            }
            kVar = n2;
        }
        int[] iArr = new int[arrayDeque.size()];
        int i2 = 0;
        Iterator it = arrayDeque.iterator();
        while (it.hasNext()) {
            iArr[i2] = ((k) it.next()).k();
            i2++;
        }
        return iArr;
    }

    public final c g(int i2) {
        l.h<c> hVar = this.f2007h;
        c e2 = hVar == null ? null : hVar.e(i2);
        if (e2 != null) {
            return e2;
        }
        if (n() != null) {
            return n().g(i2);
        }
        return null;
    }

    public final Map<String, d> h() {
        HashMap<String, d> hashMap = this.f2008i;
        return hashMap == null ? Collections.emptyMap() : Collections.unmodifiableMap(hashMap);
    }

    public String i() {
        if (this.f2004e == null) {
            this.f2004e = Integer.toString(this.f2003d);
        }
        return this.f2004e;
    }

    public final int k() {
        return this.f2003d;
    }

    public final CharSequence l() {
        return this.f2005f;
    }

    public final String m() {
        return this.f2001b;
    }

    public final l n() {
        return this.f2002c;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public a o(j jVar) {
        ArrayList<h> arrayList = this.f2006g;
        if (arrayList == null) {
            return null;
        }
        Iterator<h> it = arrayList.iterator();
        a aVar = null;
        while (it.hasNext()) {
            h next = it.next();
            Uri c2 = jVar.c();
            Bundle c3 = c2 != null ? next.c(c2, h()) : null;
            String a2 = jVar.a();
            boolean z2 = a2 != null && a2.equals(next.b());
            String b2 = jVar.b();
            int d2 = b2 != null ? next.d(b2) : -1;
            if (c3 != null || z2 || d2 > -1) {
                a aVar2 = new a(this, c3, next.e(), z2, d2);
                if (aVar == null || aVar2.compareTo(aVar) > 0) {
                    aVar = aVar2;
                }
            }
        }
        return aVar;
    }

    public void p(Context context, AttributeSet attributeSet) {
        TypedArray obtainAttributes = context.getResources().obtainAttributes(attributeSet, o0.a.A);
        r(obtainAttributes.getResourceId(o0.a.C, 0));
        this.f2004e = j(context, this.f2003d);
        s(obtainAttributes.getText(o0.a.B));
        obtainAttributes.recycle();
    }

    public final void q(int i2, c cVar) {
        if (u()) {
            if (i2 == 0) {
                throw new IllegalArgumentException("Cannot have an action with actionId 0");
            }
            if (this.f2007h == null) {
                this.f2007h = new l.h<>();
            }
            this.f2007h.i(i2, cVar);
            return;
        }
        throw new UnsupportedOperationException("Cannot add action " + i2 + " to " + this + " as it does not support actions, indicating that it is a terminal destination in your navigation graph and will never trigger actions.");
    }

    public final void r(int i2) {
        this.f2003d = i2;
        this.f2004e = null;
    }

    public final void s(CharSequence charSequence) {
        this.f2005f = charSequence;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final void t(l lVar) {
        this.f2002c = lVar;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append("(");
        String str = this.f2004e;
        if (str == null) {
            sb.append("0x");
            str = Integer.toHexString(this.f2003d);
        }
        sb.append(str);
        sb.append(")");
        if (this.f2005f != null) {
            sb.append(" label=");
            sb.append(this.f2005f);
        }
        return sb.toString();
    }

    boolean u() {
        return true;
    }
}
