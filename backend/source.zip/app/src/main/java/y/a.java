package y;

import android.view.Menu;
/* loaded from: classes.dex */
public interface a extends Menu {
}
