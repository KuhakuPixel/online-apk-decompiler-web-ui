package y1;

import android.view.View;
/* loaded from: classes.dex */
public final class a implements View.OnClickListener {

    /* renamed from: b  reason: collision with root package name */
    final InterfaceC0083a f5652b;

    /* renamed from: c  reason: collision with root package name */
    final int f5653c;

    /* renamed from: y1.a$a  reason: collision with other inner class name */
    /* loaded from: classes.dex */
    public interface InterfaceC0083a {
        void b(int i2, View view);
    }

    public a(InterfaceC0083a interfaceC0083a, int i2) {
        this.f5652b = interfaceC0083a;
        this.f5653c = i2;
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        this.f5652b.b(this.f5653c, view);
    }
}
