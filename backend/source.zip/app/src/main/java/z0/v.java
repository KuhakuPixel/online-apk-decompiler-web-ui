package z0;

import java.util.NoSuchElementException;
/* loaded from: classes.dex */
abstract class v extends j {

    /* renamed from: b  reason: collision with root package name */
    private final int f5705b;

    /* renamed from: c  reason: collision with root package name */
    private int f5706c;

    /* JADX INFO: Access modifiers changed from: protected */
    public v(int i2, int i3) {
        t.b(i3, i2, "index");
        this.f5705b = i2;
        this.f5706c = i3;
    }

    protected abstract Object a(int i2);

    @Override // java.util.Iterator, java.util.ListIterator
    public final boolean hasNext() {
        return this.f5706c < this.f5705b;
    }

    @Override // java.util.ListIterator
    public final boolean hasPrevious() {
        return this.f5706c > 0;
    }

    @Override // java.util.Iterator, java.util.ListIterator
    public final Object next() {
        if (hasNext()) {
            int i2 = this.f5706c;
            this.f5706c = i2 + 1;
            return a(i2);
        }
        throw new NoSuchElementException();
    }

    @Override // java.util.ListIterator
    public final int nextIndex() {
        return this.f5706c;
    }

    @Override // java.util.ListIterator
    public final Object previous() {
        if (hasPrevious()) {
            int i2 = this.f5706c - 1;
            this.f5706c = i2;
            return a(i2);
        }
        throw new NoSuchElementException();
    }

    @Override // java.util.ListIterator
    public final int previousIndex() {
        return this.f5706c - 1;
    }
}
