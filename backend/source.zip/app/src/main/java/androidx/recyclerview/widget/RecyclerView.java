package androidx.recyclerview.widget;

import android.animation.LayoutTransition;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.database.Observable;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.PointF;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.Display;
import android.view.FocusFinder;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import android.view.animation.Interpolator;
import android.widget.EdgeEffect;
import android.widget.OverScroller;
import androidx.recyclerview.widget.a;
import androidx.recyclerview.widget.b;
import androidx.recyclerview.widget.e;
import androidx.recyclerview.widget.k;
import androidx.recyclerview.widget.o;
import androidx.recyclerview.widget.p;
import f0.c;
import java.lang.ref.WeakReference;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
/* loaded from: classes.dex */
public class RecyclerView extends ViewGroup implements e0.j {
    static final boolean A0;
    static final boolean B0;
    static final boolean C0;
    static final boolean D0;
    private static final boolean E0;
    private static final boolean F0;
    private static final Class<?>[] G0;
    static final Interpolator H0;

    /* renamed from: z0  reason: collision with root package name */
    private static final int[] f2116z0 = {16843830};
    private int A;
    boolean B;
    private final AccessibilityManager C;
    private List<q> D;
    boolean E;
    boolean F;
    private int G;
    private int H;
    private k I;
    private EdgeEffect J;
    private EdgeEffect K;
    private EdgeEffect L;
    private EdgeEffect M;
    l N;
    private int O;
    private int P;
    private VelocityTracker Q;
    private int R;
    private int S;
    private int T;
    private int U;
    private int V;
    private r W;

    /* renamed from: a0  reason: collision with root package name */
    private final int f2117a0;

    /* renamed from: b  reason: collision with root package name */
    private final x f2118b;

    /* renamed from: b0  reason: collision with root package name */
    private final int f2119b0;

    /* renamed from: c  reason: collision with root package name */
    final v f2120c;

    /* renamed from: c0  reason: collision with root package name */
    private float f2121c0;

    /* renamed from: d  reason: collision with root package name */
    private y f2122d;

    /* renamed from: d0  reason: collision with root package name */
    private float f2123d0;

    /* renamed from: e  reason: collision with root package name */
    androidx.recyclerview.widget.a f2124e;

    /* renamed from: e0  reason: collision with root package name */
    private boolean f2125e0;

    /* renamed from: f  reason: collision with root package name */
    androidx.recyclerview.widget.b f2126f;

    /* renamed from: f0  reason: collision with root package name */
    final c0 f2127f0;

    /* renamed from: g  reason: collision with root package name */
    final androidx.recyclerview.widget.p f2128g;

    /* renamed from: g0  reason: collision with root package name */
    androidx.recyclerview.widget.e f2129g0;

    /* renamed from: h  reason: collision with root package name */
    boolean f2130h;

    /* renamed from: h0  reason: collision with root package name */
    e.b f2131h0;

    /* renamed from: i  reason: collision with root package name */
    final Runnable f2132i;

    /* renamed from: i0  reason: collision with root package name */
    final a0 f2133i0;

    /* renamed from: j  reason: collision with root package name */
    final Rect f2134j;

    /* renamed from: j0  reason: collision with root package name */
    private t f2135j0;

    /* renamed from: k  reason: collision with root package name */
    private final Rect f2136k;

    /* renamed from: k0  reason: collision with root package name */
    private List<t> f2137k0;

    /* renamed from: l  reason: collision with root package name */
    final RectF f2138l;

    /* renamed from: l0  reason: collision with root package name */
    boolean f2139l0;

    /* renamed from: m  reason: collision with root package name */
    g f2140m;

    /* renamed from: m0  reason: collision with root package name */
    boolean f2141m0;

    /* renamed from: n  reason: collision with root package name */
    o f2142n;

    /* renamed from: n0  reason: collision with root package name */
    private l.b f2143n0;

    /* renamed from: o  reason: collision with root package name */
    w f2144o;

    /* renamed from: o0  reason: collision with root package name */
    boolean f2145o0;

    /* renamed from: p  reason: collision with root package name */
    final ArrayList<n> f2146p;

    /* renamed from: p0  reason: collision with root package name */
    androidx.recyclerview.widget.k f2147p0;

    /* renamed from: q  reason: collision with root package name */
    private final ArrayList<s> f2148q;

    /* renamed from: q0  reason: collision with root package name */
    private j f2149q0;

    /* renamed from: r  reason: collision with root package name */
    private s f2150r;

    /* renamed from: r0  reason: collision with root package name */
    private final int[] f2151r0;

    /* renamed from: s  reason: collision with root package name */
    boolean f2152s;

    /* renamed from: s0  reason: collision with root package name */
    private e0.k f2153s0;

    /* renamed from: t  reason: collision with root package name */
    boolean f2154t;

    /* renamed from: t0  reason: collision with root package name */
    private final int[] f2155t0;

    /* renamed from: u  reason: collision with root package name */
    boolean f2156u;

    /* renamed from: u0  reason: collision with root package name */
    private final int[] f2157u0;

    /* renamed from: v  reason: collision with root package name */
    boolean f2158v;

    /* renamed from: v0  reason: collision with root package name */
    final int[] f2159v0;

    /* renamed from: w  reason: collision with root package name */
    private int f2160w;

    /* renamed from: w0  reason: collision with root package name */
    final List<d0> f2161w0;

    /* renamed from: x  reason: collision with root package name */
    boolean f2162x;

    /* renamed from: x0  reason: collision with root package name */
    private Runnable f2163x0;

    /* renamed from: y  reason: collision with root package name */
    boolean f2164y;

    /* renamed from: y0  reason: collision with root package name */
    private final p.b f2165y0;

    /* renamed from: z  reason: collision with root package name */
    private boolean f2166z;

    /* loaded from: classes.dex */
    class a implements Runnable {
        a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            RecyclerView recyclerView = RecyclerView.this;
            if (!recyclerView.f2158v || recyclerView.isLayoutRequested()) {
                return;
            }
            RecyclerView recyclerView2 = RecyclerView.this;
            if (!recyclerView2.f2152s) {
                recyclerView2.requestLayout();
            } else if (recyclerView2.f2164y) {
                recyclerView2.f2162x = true;
            } else {
                recyclerView2.u();
            }
        }
    }

    /* loaded from: classes.dex */
    public static class a0 {

        /* renamed from: b  reason: collision with root package name */
        private SparseArray<Object> f2169b;

        /* renamed from: m  reason: collision with root package name */
        int f2180m;

        /* renamed from: n  reason: collision with root package name */
        long f2181n;

        /* renamed from: o  reason: collision with root package name */
        int f2182o;

        /* renamed from: p  reason: collision with root package name */
        int f2183p;

        /* renamed from: q  reason: collision with root package name */
        int f2184q;

        /* renamed from: a  reason: collision with root package name */
        int f2168a = -1;

        /* renamed from: c  reason: collision with root package name */
        int f2170c = 0;

        /* renamed from: d  reason: collision with root package name */
        int f2171d = 0;

        /* renamed from: e  reason: collision with root package name */
        int f2172e = 1;

        /* renamed from: f  reason: collision with root package name */
        int f2173f = 0;

        /* renamed from: g  reason: collision with root package name */
        boolean f2174g = false;

        /* renamed from: h  reason: collision with root package name */
        boolean f2175h = false;

        /* renamed from: i  reason: collision with root package name */
        boolean f2176i = false;

        /* renamed from: j  reason: collision with root package name */
        boolean f2177j = false;

        /* renamed from: k  reason: collision with root package name */
        boolean f2178k = false;

        /* renamed from: l  reason: collision with root package name */
        boolean f2179l = false;

        void a(int i2) {
            if ((this.f2172e & i2) != 0) {
                return;
            }
            throw new IllegalStateException("Layout state should be one of " + Integer.toBinaryString(i2) + " but it is " + Integer.toBinaryString(this.f2172e));
        }

        public int b() {
            return this.f2175h ? this.f2170c - this.f2171d : this.f2173f;
        }

        public int c() {
            return this.f2168a;
        }

        public boolean d() {
            return this.f2168a != -1;
        }

        public boolean e() {
            return this.f2175h;
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public void f(g gVar) {
            this.f2172e = 1;
            this.f2173f = gVar.c();
            this.f2175h = false;
            this.f2176i = false;
            this.f2177j = false;
        }

        public boolean g() {
            return this.f2179l;
        }

        public String toString() {
            return "State{mTargetPosition=" + this.f2168a + ", mData=" + this.f2169b + ", mItemCount=" + this.f2173f + ", mIsMeasuring=" + this.f2177j + ", mPreviousLayoutItemCount=" + this.f2170c + ", mDeletedInvisibleItemCountSincePreviousLayout=" + this.f2171d + ", mStructureChanged=" + this.f2174g + ", mInPreLayout=" + this.f2175h + ", mRunSimpleAnimations=" + this.f2178k + ", mRunPredictiveAnimations=" + this.f2179l + '}';
        }
    }

    /* loaded from: classes.dex */
    class b implements Runnable {
        b() {
        }

        @Override // java.lang.Runnable
        public void run() {
            l lVar = RecyclerView.this.N;
            if (lVar != null) {
                lVar.u();
            }
            RecyclerView.this.f2145o0 = false;
        }
    }

    /* loaded from: classes.dex */
    public static abstract class b0 {
    }

    /* loaded from: classes.dex */
    static class c implements Interpolator {
        c() {
        }

        @Override // android.animation.TimeInterpolator
        public float getInterpolation(float f2) {
            float f3 = f2 - 1.0f;
            return (f3 * f3 * f3 * f3 * f3) + 1.0f;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public class c0 implements Runnable {

        /* renamed from: b  reason: collision with root package name */
        private int f2186b;

        /* renamed from: c  reason: collision with root package name */
        private int f2187c;

        /* renamed from: d  reason: collision with root package name */
        OverScroller f2188d;

        /* renamed from: e  reason: collision with root package name */
        Interpolator f2189e;

        /* renamed from: f  reason: collision with root package name */
        private boolean f2190f;

        /* renamed from: g  reason: collision with root package name */
        private boolean f2191g;

        c0() {
            Interpolator interpolator = RecyclerView.H0;
            this.f2189e = interpolator;
            this.f2190f = false;
            this.f2191g = false;
            this.f2188d = new OverScroller(RecyclerView.this.getContext(), interpolator);
        }

        private int a(int i2, int i3, int i4, int i5) {
            int i6;
            int abs = Math.abs(i2);
            int abs2 = Math.abs(i3);
            boolean z2 = abs > abs2;
            int sqrt = (int) Math.sqrt((i4 * i4) + (i5 * i5));
            int sqrt2 = (int) Math.sqrt((i2 * i2) + (i3 * i3));
            RecyclerView recyclerView = RecyclerView.this;
            int width = z2 ? recyclerView.getWidth() : recyclerView.getHeight();
            int i7 = width / 2;
            float f2 = width;
            float f3 = i7;
            float b2 = f3 + (b(Math.min(1.0f, (sqrt2 * 1.0f) / f2)) * f3);
            if (sqrt > 0) {
                i6 = Math.round(Math.abs(b2 / sqrt) * 1000.0f) * 4;
            } else {
                if (!z2) {
                    abs = abs2;
                }
                i6 = (int) (((abs / f2) + 1.0f) * 300.0f);
            }
            return Math.min(i6, 2000);
        }

        private float b(float f2) {
            return (float) Math.sin((f2 - 0.5f) * 0.47123894f);
        }

        private void d() {
            RecyclerView.this.removeCallbacks(this);
            e0.q.c0(RecyclerView.this, this);
        }

        public void c(int i2, int i3) {
            RecyclerView.this.setScrollState(2);
            this.f2187c = 0;
            this.f2186b = 0;
            Interpolator interpolator = this.f2189e;
            Interpolator interpolator2 = RecyclerView.H0;
            if (interpolator != interpolator2) {
                this.f2189e = interpolator2;
                this.f2188d = new OverScroller(RecyclerView.this.getContext(), interpolator2);
            }
            this.f2188d.fling(0, 0, i2, i3, Integer.MIN_VALUE, Integer.MAX_VALUE, Integer.MIN_VALUE, Integer.MAX_VALUE);
            e();
        }

        void e() {
            if (this.f2190f) {
                this.f2191g = true;
            } else {
                d();
            }
        }

        public void f(int i2, int i3, int i4, Interpolator interpolator) {
            if (i4 == Integer.MIN_VALUE) {
                i4 = a(i2, i3, 0, 0);
            }
            int i5 = i4;
            if (interpolator == null) {
                interpolator = RecyclerView.H0;
            }
            if (this.f2189e != interpolator) {
                this.f2189e = interpolator;
                this.f2188d = new OverScroller(RecyclerView.this.getContext(), interpolator);
            }
            this.f2187c = 0;
            this.f2186b = 0;
            RecyclerView.this.setScrollState(2);
            this.f2188d.startScroll(0, 0, i2, i3, i5);
            if (Build.VERSION.SDK_INT < 23) {
                this.f2188d.computeScrollOffset();
            }
            e();
        }

        public void g() {
            RecyclerView.this.removeCallbacks(this);
            this.f2188d.abortAnimation();
        }

        @Override // java.lang.Runnable
        public void run() {
            int i2;
            int i3;
            RecyclerView recyclerView = RecyclerView.this;
            if (recyclerView.f2142n == null) {
                g();
                return;
            }
            this.f2191g = false;
            this.f2190f = true;
            recyclerView.u();
            OverScroller overScroller = this.f2188d;
            if (overScroller.computeScrollOffset()) {
                int currX = overScroller.getCurrX();
                int currY = overScroller.getCurrY();
                int i4 = currX - this.f2186b;
                int i5 = currY - this.f2187c;
                this.f2186b = currX;
                this.f2187c = currY;
                RecyclerView recyclerView2 = RecyclerView.this;
                int[] iArr = recyclerView2.f2159v0;
                iArr[0] = 0;
                iArr[1] = 0;
                if (recyclerView2.F(i4, i5, iArr, null, 1)) {
                    int[] iArr2 = RecyclerView.this.f2159v0;
                    i4 -= iArr2[0];
                    i5 -= iArr2[1];
                }
                if (RecyclerView.this.getOverScrollMode() != 2) {
                    RecyclerView.this.t(i4, i5);
                }
                RecyclerView recyclerView3 = RecyclerView.this;
                if (recyclerView3.f2140m != null) {
                    int[] iArr3 = recyclerView3.f2159v0;
                    iArr3[0] = 0;
                    iArr3[1] = 0;
                    recyclerView3.f1(i4, i5, iArr3);
                    RecyclerView recyclerView4 = RecyclerView.this;
                    int[] iArr4 = recyclerView4.f2159v0;
                    i3 = iArr4[0];
                    i2 = iArr4[1];
                    i4 -= i3;
                    i5 -= i2;
                    z zVar = recyclerView4.f2142n.f2234g;
                    if (zVar != null && !zVar.g() && zVar.h()) {
                        int b2 = RecyclerView.this.f2133i0.b();
                        if (b2 == 0) {
                            zVar.r();
                        } else {
                            if (zVar.f() >= b2) {
                                zVar.p(b2 - 1);
                            }
                            zVar.j(i3, i2);
                        }
                    }
                } else {
                    i2 = 0;
                    i3 = 0;
                }
                if (!RecyclerView.this.f2146p.isEmpty()) {
                    RecyclerView.this.invalidate();
                }
                RecyclerView recyclerView5 = RecyclerView.this;
                int[] iArr5 = recyclerView5.f2159v0;
                iArr5[0] = 0;
                iArr5[1] = 0;
                recyclerView5.G(i3, i2, i4, i5, null, 1, iArr5);
                RecyclerView recyclerView6 = RecyclerView.this;
                int[] iArr6 = recyclerView6.f2159v0;
                int i6 = i4 - iArr6[0];
                int i7 = i5 - iArr6[1];
                if (i3 != 0 || i2 != 0) {
                    recyclerView6.I(i3, i2);
                }
                if (!RecyclerView.this.awakenScrollBars()) {
                    RecyclerView.this.invalidate();
                }
                boolean z2 = overScroller.isFinished() || (((overScroller.getCurrX() == overScroller.getFinalX()) || i6 != 0) && ((overScroller.getCurrY() == overScroller.getFinalY()) || i7 != 0));
                z zVar2 = RecyclerView.this.f2142n.f2234g;
                if ((zVar2 != null && zVar2.g()) || !z2) {
                    e();
                    RecyclerView recyclerView7 = RecyclerView.this;
                    androidx.recyclerview.widget.e eVar = recyclerView7.f2129g0;
                    if (eVar != null) {
                        eVar.f(recyclerView7, i3, i2);
                    }
                } else {
                    if (RecyclerView.this.getOverScrollMode() != 2) {
                        int currVelocity = (int) overScroller.getCurrVelocity();
                        int i8 = i6 < 0 ? -currVelocity : i6 > 0 ? currVelocity : 0;
                        if (i7 < 0) {
                            currVelocity = -currVelocity;
                        } else if (i7 <= 0) {
                            currVelocity = 0;
                        }
                        RecyclerView.this.a(i8, currVelocity);
                    }
                    if (RecyclerView.D0) {
                        RecyclerView.this.f2131h0.b();
                    }
                }
            }
            z zVar3 = RecyclerView.this.f2142n.f2234g;
            if (zVar3 != null && zVar3.g()) {
                zVar3.j(0, 0);
            }
            this.f2190f = false;
            if (this.f2191g) {
                d();
                return;
            }
            RecyclerView.this.setScrollState(0);
            RecyclerView.this.s1(1);
        }
    }

    /* loaded from: classes.dex */
    class d implements p.b {
        d() {
        }

        @Override // androidx.recyclerview.widget.p.b
        public void a(d0 d0Var) {
            RecyclerView recyclerView = RecyclerView.this;
            recyclerView.f2142n.m1(d0Var.f2195a, recyclerView.f2120c);
        }

        @Override // androidx.recyclerview.widget.p.b
        public void b(d0 d0Var, l.c cVar, l.c cVar2) {
            RecyclerView.this.l(d0Var, cVar, cVar2);
        }

        @Override // androidx.recyclerview.widget.p.b
        public void c(d0 d0Var, l.c cVar, l.c cVar2) {
            RecyclerView.this.f2120c.J(d0Var);
            RecyclerView.this.n(d0Var, cVar, cVar2);
        }

        @Override // androidx.recyclerview.widget.p.b
        public void d(d0 d0Var, l.c cVar, l.c cVar2) {
            d0Var.G(false);
            RecyclerView recyclerView = RecyclerView.this;
            boolean z2 = recyclerView.E;
            l lVar = recyclerView.N;
            if (z2) {
                if (!lVar.b(d0Var, d0Var, cVar, cVar2)) {
                    return;
                }
            } else if (!lVar.d(d0Var, cVar, cVar2)) {
                return;
            }
            RecyclerView.this.L0();
        }
    }

    /* loaded from: classes.dex */
    public static abstract class d0 {

        /* renamed from: s  reason: collision with root package name */
        private static final List<Object> f2194s = Collections.emptyList();

        /* renamed from: a  reason: collision with root package name */
        public final View f2195a;

        /* renamed from: b  reason: collision with root package name */
        WeakReference<RecyclerView> f2196b;

        /* renamed from: j  reason: collision with root package name */
        int f2204j;

        /* renamed from: r  reason: collision with root package name */
        RecyclerView f2212r;

        /* renamed from: c  reason: collision with root package name */
        int f2197c = -1;

        /* renamed from: d  reason: collision with root package name */
        int f2198d = -1;

        /* renamed from: e  reason: collision with root package name */
        long f2199e = -1;

        /* renamed from: f  reason: collision with root package name */
        int f2200f = -1;

        /* renamed from: g  reason: collision with root package name */
        int f2201g = -1;

        /* renamed from: h  reason: collision with root package name */
        d0 f2202h = null;

        /* renamed from: i  reason: collision with root package name */
        d0 f2203i = null;

        /* renamed from: k  reason: collision with root package name */
        List<Object> f2205k = null;

        /* renamed from: l  reason: collision with root package name */
        List<Object> f2206l = null;

        /* renamed from: m  reason: collision with root package name */
        private int f2207m = 0;

        /* renamed from: n  reason: collision with root package name */
        v f2208n = null;

        /* renamed from: o  reason: collision with root package name */
        boolean f2209o = false;

        /* renamed from: p  reason: collision with root package name */
        private int f2210p = 0;

        /* renamed from: q  reason: collision with root package name */
        int f2211q = -1;

        public d0(View view) {
            if (view == null) {
                throw new IllegalArgumentException("itemView may not be null");
            }
            this.f2195a = view;
        }

        private void g() {
            if (this.f2205k == null) {
                ArrayList arrayList = new ArrayList();
                this.f2205k = arrayList;
                this.f2206l = Collections.unmodifiableList(arrayList);
            }
        }

        void A(int i2, boolean z2) {
            if (this.f2198d == -1) {
                this.f2198d = this.f2197c;
            }
            if (this.f2201g == -1) {
                this.f2201g = this.f2197c;
            }
            if (z2) {
                this.f2201g += i2;
            }
            this.f2197c += i2;
            if (this.f2195a.getLayoutParams() != null) {
                ((p) this.f2195a.getLayoutParams()).f2254c = true;
            }
        }

        void B(RecyclerView recyclerView) {
            int i2 = this.f2211q;
            if (i2 == -1) {
                i2 = e0.q.z(this.f2195a);
            }
            this.f2210p = i2;
            recyclerView.i1(this, 4);
        }

        void C(RecyclerView recyclerView) {
            recyclerView.i1(this, this.f2210p);
            this.f2210p = 0;
        }

        void D() {
            this.f2204j = 0;
            this.f2197c = -1;
            this.f2198d = -1;
            this.f2199e = -1L;
            this.f2201g = -1;
            this.f2207m = 0;
            this.f2202h = null;
            this.f2203i = null;
            d();
            this.f2210p = 0;
            this.f2211q = -1;
            RecyclerView.r(this);
        }

        void E() {
            if (this.f2198d == -1) {
                this.f2198d = this.f2197c;
            }
        }

        void F(int i2, int i3) {
            this.f2204j = (i2 & i3) | (this.f2204j & (~i3));
        }

        public final void G(boolean z2) {
            int i2;
            int i3 = this.f2207m;
            int i4 = z2 ? i3 - 1 : i3 + 1;
            this.f2207m = i4;
            if (i4 < 0) {
                this.f2207m = 0;
                Log.e("View", "isRecyclable decremented below 0: unmatched pair of setIsRecyable() calls for " + this);
                return;
            }
            if (!z2 && i4 == 1) {
                i2 = this.f2204j | 16;
            } else if (!z2 || i4 != 0) {
                return;
            } else {
                i2 = this.f2204j & (-17);
            }
            this.f2204j = i2;
        }

        void H(v vVar, boolean z2) {
            this.f2208n = vVar;
            this.f2209o = z2;
        }

        boolean I() {
            return (this.f2204j & 16) != 0;
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public boolean J() {
            return (this.f2204j & 128) != 0;
        }

        void K() {
            this.f2208n.J(this);
        }

        boolean L() {
            return (this.f2204j & 32) != 0;
        }

        void a(Object obj) {
            if (obj == null) {
                b(1024);
            } else if ((1024 & this.f2204j) == 0) {
                g();
                this.f2205k.add(obj);
            }
        }

        void b(int i2) {
            this.f2204j = i2 | this.f2204j;
        }

        void c() {
            this.f2198d = -1;
            this.f2201g = -1;
        }

        void d() {
            List<Object> list = this.f2205k;
            if (list != null) {
                list.clear();
            }
            this.f2204j &= -1025;
        }

        void e() {
            this.f2204j &= -33;
        }

        void f() {
            this.f2204j &= -257;
        }

        boolean h() {
            return (this.f2204j & 16) == 0 && e0.q.N(this.f2195a);
        }

        void i(int i2, int i3, boolean z2) {
            b(8);
            A(i3, z2);
            this.f2197c = i2;
        }

        public final int j() {
            RecyclerView recyclerView = this.f2212r;
            if (recyclerView == null) {
                return -1;
            }
            return recyclerView.b0(this);
        }

        public final long k() {
            return this.f2199e;
        }

        public final int l() {
            return this.f2200f;
        }

        public final int m() {
            int i2 = this.f2201g;
            return i2 == -1 ? this.f2197c : i2;
        }

        public final int n() {
            return this.f2198d;
        }

        List<Object> o() {
            if ((this.f2204j & 1024) == 0) {
                List<Object> list = this.f2205k;
                return (list == null || list.size() == 0) ? f2194s : this.f2206l;
            }
            return f2194s;
        }

        boolean p(int i2) {
            return (i2 & this.f2204j) != 0;
        }

        boolean q() {
            return (this.f2204j & 512) != 0 || t();
        }

        boolean r() {
            return (this.f2195a.getParent() == null || this.f2195a.getParent() == this.f2212r) ? false : true;
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public boolean s() {
            return (this.f2204j & 1) != 0;
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public boolean t() {
            return (this.f2204j & 4) != 0;
        }

        public String toString() {
            StringBuilder sb = new StringBuilder((getClass().isAnonymousClass() ? "ViewHolder" : getClass().getSimpleName()) + "{" + Integer.toHexString(hashCode()) + " position=" + this.f2197c + " id=" + this.f2199e + ", oldPos=" + this.f2198d + ", pLpos:" + this.f2201g);
            if (w()) {
                sb.append(" scrap ");
                sb.append(this.f2209o ? "[changeScrap]" : "[attachedScrap]");
            }
            if (t()) {
                sb.append(" invalid");
            }
            if (!s()) {
                sb.append(" unbound");
            }
            if (z()) {
                sb.append(" update");
            }
            if (v()) {
                sb.append(" removed");
            }
            if (J()) {
                sb.append(" ignored");
            }
            if (x()) {
                sb.append(" tmpDetached");
            }
            if (!u()) {
                sb.append(" not recyclable(" + this.f2207m + ")");
            }
            if (q()) {
                sb.append(" undefined adapter position");
            }
            if (this.f2195a.getParent() == null) {
                sb.append(" no parent");
            }
            sb.append("}");
            return sb.toString();
        }

        public final boolean u() {
            return (this.f2204j & 16) == 0 && !e0.q.N(this.f2195a);
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public boolean v() {
            return (this.f2204j & 8) != 0;
        }

        boolean w() {
            return this.f2208n != null;
        }

        boolean x() {
            return (this.f2204j & 256) != 0;
        }

        boolean y() {
            return (this.f2204j & 2) != 0;
        }

        boolean z() {
            return (this.f2204j & 2) != 0;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public class e implements b.InterfaceC0016b {
        e() {
        }

        @Override // androidx.recyclerview.widget.b.InterfaceC0016b
        public View a(int i2) {
            return RecyclerView.this.getChildAt(i2);
        }

        @Override // androidx.recyclerview.widget.b.InterfaceC0016b
        public void b(View view) {
            d0 f02 = RecyclerView.f0(view);
            if (f02 != null) {
                f02.B(RecyclerView.this);
            }
        }

        @Override // androidx.recyclerview.widget.b.InterfaceC0016b
        public void c(int i2) {
            View childAt = RecyclerView.this.getChildAt(i2);
            if (childAt != null) {
                RecyclerView.this.z(childAt);
                childAt.clearAnimation();
            }
            RecyclerView.this.removeViewAt(i2);
        }

        @Override // androidx.recyclerview.widget.b.InterfaceC0016b
        public void d() {
            int k2 = k();
            for (int i2 = 0; i2 < k2; i2++) {
                View a2 = a(i2);
                RecyclerView.this.z(a2);
                a2.clearAnimation();
            }
            RecyclerView.this.removeAllViews();
        }

        @Override // androidx.recyclerview.widget.b.InterfaceC0016b
        public d0 e(View view) {
            return RecyclerView.f0(view);
        }

        @Override // androidx.recyclerview.widget.b.InterfaceC0016b
        public void f(int i2) {
            d0 f02;
            View a2 = a(i2);
            if (a2 != null && (f02 = RecyclerView.f0(a2)) != null) {
                if (f02.x() && !f02.J()) {
                    throw new IllegalArgumentException("called detach on an already detached child " + f02 + RecyclerView.this.P());
                }
                f02.b(256);
            }
            RecyclerView.this.detachViewFromParent(i2);
        }

        @Override // androidx.recyclerview.widget.b.InterfaceC0016b
        public void g(View view) {
            d0 f02 = RecyclerView.f0(view);
            if (f02 != null) {
                f02.C(RecyclerView.this);
            }
        }

        @Override // androidx.recyclerview.widget.b.InterfaceC0016b
        public void h(View view, int i2, ViewGroup.LayoutParams layoutParams) {
            d0 f02 = RecyclerView.f0(view);
            if (f02 != null) {
                if (!f02.x() && !f02.J()) {
                    throw new IllegalArgumentException("Called attach on a child which is not detached: " + f02 + RecyclerView.this.P());
                }
                f02.f();
            }
            RecyclerView.this.attachViewToParent(view, i2, layoutParams);
        }

        @Override // androidx.recyclerview.widget.b.InterfaceC0016b
        public void i(View view, int i2) {
            RecyclerView.this.addView(view, i2);
            RecyclerView.this.y(view);
        }

        @Override // androidx.recyclerview.widget.b.InterfaceC0016b
        public int j(View view) {
            return RecyclerView.this.indexOfChild(view);
        }

        @Override // androidx.recyclerview.widget.b.InterfaceC0016b
        public int k() {
            return RecyclerView.this.getChildCount();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public class f implements a.InterfaceC0015a {
        f() {
        }

        @Override // androidx.recyclerview.widget.a.InterfaceC0015a
        public void a(int i2, int i3) {
            RecyclerView.this.B0(i2, i3);
            RecyclerView.this.f2139l0 = true;
        }

        @Override // androidx.recyclerview.widget.a.InterfaceC0015a
        public void b(a.b bVar) {
            i(bVar);
        }

        @Override // androidx.recyclerview.widget.a.InterfaceC0015a
        public d0 c(int i2) {
            d0 Z = RecyclerView.this.Z(i2, true);
            if (Z == null || RecyclerView.this.f2126f.n(Z.f2195a)) {
                return null;
            }
            return Z;
        }

        @Override // androidx.recyclerview.widget.a.InterfaceC0015a
        public void d(int i2, int i3) {
            RecyclerView.this.C0(i2, i3, true);
            RecyclerView recyclerView = RecyclerView.this;
            recyclerView.f2139l0 = true;
            recyclerView.f2133i0.f2171d += i3;
        }

        @Override // androidx.recyclerview.widget.a.InterfaceC0015a
        public void e(int i2, int i3) {
            RecyclerView.this.C0(i2, i3, false);
            RecyclerView.this.f2139l0 = true;
        }

        @Override // androidx.recyclerview.widget.a.InterfaceC0015a
        public void f(a.b bVar) {
            i(bVar);
        }

        @Override // androidx.recyclerview.widget.a.InterfaceC0015a
        public void g(int i2, int i3) {
            RecyclerView.this.A0(i2, i3);
            RecyclerView.this.f2139l0 = true;
        }

        @Override // androidx.recyclerview.widget.a.InterfaceC0015a
        public void h(int i2, int i3, Object obj) {
            RecyclerView.this.v1(i2, i3, obj);
            RecyclerView.this.f2141m0 = true;
        }

        void i(a.b bVar) {
            int i2 = bVar.f2335a;
            if (i2 == 1) {
                RecyclerView recyclerView = RecyclerView.this;
                recyclerView.f2142n.R0(recyclerView, bVar.f2336b, bVar.f2338d);
            } else if (i2 == 2) {
                RecyclerView recyclerView2 = RecyclerView.this;
                recyclerView2.f2142n.U0(recyclerView2, bVar.f2336b, bVar.f2338d);
            } else if (i2 == 4) {
                RecyclerView recyclerView3 = RecyclerView.this;
                recyclerView3.f2142n.W0(recyclerView3, bVar.f2336b, bVar.f2338d, bVar.f2337c);
            } else if (i2 != 8) {
            } else {
                RecyclerView recyclerView4 = RecyclerView.this;
                recyclerView4.f2142n.T0(recyclerView4, bVar.f2336b, bVar.f2338d, 1);
            }
        }
    }

    /* loaded from: classes.dex */
    public static abstract class g<VH extends d0> {

        /* renamed from: a  reason: collision with root package name */
        private final h f2215a = new h();

        /* renamed from: b  reason: collision with root package name */
        private boolean f2216b = false;

        public final void a(VH vh, int i2) {
            vh.f2197c = i2;
            if (g()) {
                vh.f2199e = d(i2);
            }
            vh.F(1, 519);
            a0.b.a("RV OnBindView");
            k(vh, i2, vh.o());
            vh.d();
            ViewGroup.LayoutParams layoutParams = vh.f2195a.getLayoutParams();
            if (layoutParams instanceof p) {
                ((p) layoutParams).f2254c = true;
            }
            a0.b.b();
        }

        public final VH b(ViewGroup viewGroup, int i2) {
            try {
                a0.b.a("RV CreateView");
                VH l2 = l(viewGroup, i2);
                if (l2.f2195a.getParent() == null) {
                    l2.f2200f = i2;
                    return l2;
                }
                throw new IllegalStateException("ViewHolder views must not be attached when created. Ensure that you are not passing 'true' to the attachToRoot parameter of LayoutInflater.inflate(..., boolean attachToRoot)");
            } finally {
                a0.b.b();
            }
        }

        public abstract int c();

        public long d(int i2) {
            return -1L;
        }

        public int e(int i2) {
            return 0;
        }

        public final boolean f() {
            return this.f2215a.a();
        }

        public final boolean g() {
            return this.f2216b;
        }

        public final void h() {
            this.f2215a.b();
        }

        public void i(RecyclerView recyclerView) {
        }

        public abstract void j(VH vh, int i2);

        public void k(VH vh, int i2, List<Object> list) {
            j(vh, i2);
        }

        public abstract VH l(ViewGroup viewGroup, int i2);

        public void m(RecyclerView recyclerView) {
        }

        public boolean n(VH vh) {
            return false;
        }

        public void o(VH vh) {
        }

        public void p(VH vh) {
        }

        public void q(VH vh) {
        }

        public void r(i iVar) {
            this.f2215a.registerObserver(iVar);
        }

        public void s(boolean z2) {
            if (f()) {
                throw new IllegalStateException("Cannot change whether this adapter has stable IDs while the adapter has registered observers.");
            }
            this.f2216b = z2;
        }

        public void t(i iVar) {
            this.f2215a.unregisterObserver(iVar);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public static class h extends Observable<i> {
        h() {
        }

        public boolean a() {
            return !((Observable) this).mObservers.isEmpty();
        }

        public void b() {
            for (int size = ((Observable) this).mObservers.size() - 1; size >= 0; size--) {
                ((i) ((Observable) this).mObservers.get(size)).a();
            }
        }
    }

    /* loaded from: classes.dex */
    public static abstract class i {
        public void a() {
        }
    }

    /* loaded from: classes.dex */
    public interface j {
        int a(int i2, int i3);
    }

    /* loaded from: classes.dex */
    public static class k {
        protected EdgeEffect a(RecyclerView recyclerView, int i2) {
            return new EdgeEffect(recyclerView.getContext());
        }
    }

    /* loaded from: classes.dex */
    public static abstract class l {

        /* renamed from: a  reason: collision with root package name */
        private b f2217a = null;

        /* renamed from: b  reason: collision with root package name */
        private ArrayList<a> f2218b = new ArrayList<>();

        /* renamed from: c  reason: collision with root package name */
        private long f2219c = 120;

        /* renamed from: d  reason: collision with root package name */
        private long f2220d = 120;

        /* renamed from: e  reason: collision with root package name */
        private long f2221e = 250;

        /* renamed from: f  reason: collision with root package name */
        private long f2222f = 250;

        /* loaded from: classes.dex */
        public interface a {
            void a();
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        /* loaded from: classes.dex */
        public interface b {
            void a(d0 d0Var);
        }

        /* loaded from: classes.dex */
        public static class c {

            /* renamed from: a  reason: collision with root package name */
            public int f2223a;

            /* renamed from: b  reason: collision with root package name */
            public int f2224b;

            /* renamed from: c  reason: collision with root package name */
            public int f2225c;

            /* renamed from: d  reason: collision with root package name */
            public int f2226d;

            public c a(d0 d0Var) {
                return b(d0Var, 0);
            }

            public c b(d0 d0Var, int i2) {
                View view = d0Var.f2195a;
                this.f2223a = view.getLeft();
                this.f2224b = view.getTop();
                this.f2225c = view.getRight();
                this.f2226d = view.getBottom();
                return this;
            }
        }

        static int e(d0 d0Var) {
            int i2 = d0Var.f2204j & 14;
            if (d0Var.t()) {
                return 4;
            }
            if ((i2 & 4) == 0) {
                int n2 = d0Var.n();
                int j2 = d0Var.j();
                return (n2 == -1 || j2 == -1 || n2 == j2) ? i2 : i2 | 2048;
            }
            return i2;
        }

        public abstract boolean a(d0 d0Var, c cVar, c cVar2);

        public abstract boolean b(d0 d0Var, d0 d0Var2, c cVar, c cVar2);

        public abstract boolean c(d0 d0Var, c cVar, c cVar2);

        public abstract boolean d(d0 d0Var, c cVar, c cVar2);

        public abstract boolean f(d0 d0Var);

        public boolean g(d0 d0Var, List<Object> list) {
            return f(d0Var);
        }

        public final void h(d0 d0Var) {
            r(d0Var);
            b bVar = this.f2217a;
            if (bVar != null) {
                bVar.a(d0Var);
            }
        }

        public final void i() {
            int size = this.f2218b.size();
            for (int i2 = 0; i2 < size; i2++) {
                this.f2218b.get(i2).a();
            }
            this.f2218b.clear();
        }

        public abstract void j(d0 d0Var);

        public abstract void k();

        public long l() {
            return this.f2219c;
        }

        public long m() {
            return this.f2222f;
        }

        public long n() {
            return this.f2221e;
        }

        public long o() {
            return this.f2220d;
        }

        public abstract boolean p();

        public c q() {
            return new c();
        }

        public void r(d0 d0Var) {
        }

        public c s(a0 a0Var, d0 d0Var) {
            return q().a(d0Var);
        }

        public c t(a0 a0Var, d0 d0Var, int i2, List<Object> list) {
            return q().a(d0Var);
        }

        public abstract void u();

        void v(b bVar) {
            this.f2217a = bVar;
        }
    }

    /* loaded from: classes.dex */
    private class m implements l.b {
        m() {
        }

        @Override // androidx.recyclerview.widget.RecyclerView.l.b
        public void a(d0 d0Var) {
            d0Var.G(true);
            if (d0Var.f2202h != null && d0Var.f2203i == null) {
                d0Var.f2202h = null;
            }
            d0Var.f2203i = null;
            if (d0Var.I() || RecyclerView.this.U0(d0Var.f2195a) || !d0Var.x()) {
                return;
            }
            RecyclerView.this.removeDetachedView(d0Var.f2195a, false);
        }
    }

    /* loaded from: classes.dex */
    public static abstract class n {
        @Deprecated
        public void d(Rect rect, int i2, RecyclerView recyclerView) {
            rect.set(0, 0, 0, 0);
        }

        public void e(Rect rect, View view, RecyclerView recyclerView, a0 a0Var) {
            d(rect, ((p) view.getLayoutParams()).a(), recyclerView);
        }

        @Deprecated
        public void f(Canvas canvas, RecyclerView recyclerView) {
        }

        public void g(Canvas canvas, RecyclerView recyclerView, a0 a0Var) {
            f(canvas, recyclerView);
        }

        @Deprecated
        public void h(Canvas canvas, RecyclerView recyclerView) {
        }

        public void i(Canvas canvas, RecyclerView recyclerView, a0 a0Var) {
            h(canvas, recyclerView);
        }
    }

    /* loaded from: classes.dex */
    public static abstract class o {

        /* renamed from: a  reason: collision with root package name */
        androidx.recyclerview.widget.b f2228a;

        /* renamed from: b  reason: collision with root package name */
        RecyclerView f2229b;

        /* renamed from: c  reason: collision with root package name */
        private final o.b f2230c;

        /* renamed from: d  reason: collision with root package name */
        private final o.b f2231d;

        /* renamed from: e  reason: collision with root package name */
        androidx.recyclerview.widget.o f2232e;

        /* renamed from: f  reason: collision with root package name */
        androidx.recyclerview.widget.o f2233f;

        /* renamed from: g  reason: collision with root package name */
        z f2234g;

        /* renamed from: h  reason: collision with root package name */
        boolean f2235h;

        /* renamed from: i  reason: collision with root package name */
        boolean f2236i;

        /* renamed from: j  reason: collision with root package name */
        boolean f2237j;

        /* renamed from: k  reason: collision with root package name */
        private boolean f2238k;

        /* renamed from: l  reason: collision with root package name */
        private boolean f2239l;

        /* renamed from: m  reason: collision with root package name */
        int f2240m;

        /* renamed from: n  reason: collision with root package name */
        boolean f2241n;

        /* renamed from: o  reason: collision with root package name */
        private int f2242o;

        /* renamed from: p  reason: collision with root package name */
        private int f2243p;

        /* renamed from: q  reason: collision with root package name */
        private int f2244q;

        /* renamed from: r  reason: collision with root package name */
        private int f2245r;

        /* loaded from: classes.dex */
        class a implements o.b {
            a() {
            }

            @Override // androidx.recyclerview.widget.o.b
            public View a(int i2) {
                return o.this.I(i2);
            }

            @Override // androidx.recyclerview.widget.o.b
            public int b() {
                return o.this.o0() - o.this.f0();
            }

            @Override // androidx.recyclerview.widget.o.b
            public int c() {
                return o.this.e0();
            }

            @Override // androidx.recyclerview.widget.o.b
            public int d(View view) {
                return o.this.T(view) + ((ViewGroup.MarginLayoutParams) ((p) view.getLayoutParams())).rightMargin;
            }

            @Override // androidx.recyclerview.widget.o.b
            public int e(View view) {
                return o.this.Q(view) - ((ViewGroup.MarginLayoutParams) ((p) view.getLayoutParams())).leftMargin;
            }
        }

        /* loaded from: classes.dex */
        class b implements o.b {
            b() {
            }

            @Override // androidx.recyclerview.widget.o.b
            public View a(int i2) {
                return o.this.I(i2);
            }

            @Override // androidx.recyclerview.widget.o.b
            public int b() {
                return o.this.W() - o.this.d0();
            }

            @Override // androidx.recyclerview.widget.o.b
            public int c() {
                return o.this.g0();
            }

            @Override // androidx.recyclerview.widget.o.b
            public int d(View view) {
                return o.this.O(view) + ((ViewGroup.MarginLayoutParams) ((p) view.getLayoutParams())).bottomMargin;
            }

            @Override // androidx.recyclerview.widget.o.b
            public int e(View view) {
                return o.this.U(view) - ((ViewGroup.MarginLayoutParams) ((p) view.getLayoutParams())).topMargin;
            }
        }

        /* loaded from: classes.dex */
        public interface c {
            void a(int i2, int i3);
        }

        /* loaded from: classes.dex */
        public static class d {

            /* renamed from: a  reason: collision with root package name */
            public int f2248a;

            /* renamed from: b  reason: collision with root package name */
            public int f2249b;

            /* renamed from: c  reason: collision with root package name */
            public boolean f2250c;

            /* renamed from: d  reason: collision with root package name */
            public boolean f2251d;
        }

        public o() {
            a aVar = new a();
            this.f2230c = aVar;
            b bVar = new b();
            this.f2231d = bVar;
            this.f2232e = new androidx.recyclerview.widget.o(aVar);
            this.f2233f = new androidx.recyclerview.widget.o(bVar);
            this.f2235h = false;
            this.f2236i = false;
            this.f2237j = false;
            this.f2238k = true;
            this.f2239l = true;
        }

        /* JADX WARN: Code restructure failed: missing block: B:9:0x0017, code lost:
            if (r5 == 1073741824) goto L14;
         */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public static int K(int r4, int r5, int r6, int r7, boolean r8) {
            /*
                int r4 = r4 - r6
                r6 = 0
                int r4 = java.lang.Math.max(r6, r4)
                r0 = -2
                r1 = -1
                r2 = -2147483648(0xffffffff80000000, float:-0.0)
                r3 = 1073741824(0x40000000, float:2.0)
                if (r8 == 0) goto L1a
                if (r7 < 0) goto L11
                goto L1c
            L11:
                if (r7 != r1) goto L2f
                if (r5 == r2) goto L21
                if (r5 == 0) goto L2f
                if (r5 == r3) goto L21
                goto L2f
            L1a:
                if (r7 < 0) goto L1f
            L1c:
                r5 = 1073741824(0x40000000, float:2.0)
                goto L31
            L1f:
                if (r7 != r1) goto L23
            L21:
                r7 = r4
                goto L31
            L23:
                if (r7 != r0) goto L2f
                if (r5 == r2) goto L2c
                if (r5 != r3) goto L2a
                goto L2c
            L2a:
                r5 = 0
                goto L21
            L2c:
                r5 = -2147483648(0xffffffff80000000, float:-0.0)
                goto L21
            L2f:
                r5 = 0
                r7 = 0
            L31:
                int r4 = android.view.View.MeasureSpec.makeMeasureSpec(r7, r5)
                return r4
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.RecyclerView.o.K(int, int, int, int, boolean):int");
        }

        private int[] L(View view, Rect rect) {
            int[] iArr = new int[2];
            int e02 = e0();
            int g02 = g0();
            int o02 = o0() - f0();
            int W = W() - d0();
            int left = (view.getLeft() + rect.left) - view.getScrollX();
            int top = (view.getTop() + rect.top) - view.getScrollY();
            int width = rect.width() + left;
            int height = rect.height() + top;
            int i2 = left - e02;
            int min = Math.min(0, i2);
            int i3 = top - g02;
            int min2 = Math.min(0, i3);
            int i4 = width - o02;
            int max = Math.max(0, i4);
            int max2 = Math.max(0, height - W);
            if (Z() != 1) {
                if (min == 0) {
                    min = Math.min(i2, max);
                }
                max = min;
            } else if (max == 0) {
                max = Math.max(min, i4);
            }
            if (min2 == 0) {
                min2 = Math.min(i3, max2);
            }
            iArr[0] = max;
            iArr[1] = min2;
            return iArr;
        }

        private void f(View view, int i2, boolean z2) {
            d0 f02 = RecyclerView.f0(view);
            if (z2 || f02.v()) {
                this.f2229b.f2128g.b(f02);
            } else {
                this.f2229b.f2128g.p(f02);
            }
            p pVar = (p) view.getLayoutParams();
            if (f02.L() || f02.w()) {
                if (f02.w()) {
                    f02.K();
                } else {
                    f02.e();
                }
                this.f2228a.c(view, i2, view.getLayoutParams(), false);
            } else if (view.getParent() == this.f2229b) {
                int m2 = this.f2228a.m(view);
                if (i2 == -1) {
                    i2 = this.f2228a.g();
                }
                if (m2 == -1) {
                    throw new IllegalStateException("Added View has RecyclerView as parent but view is not a real child. Unfiltered index:" + this.f2229b.indexOfChild(view) + this.f2229b.P());
                } else if (m2 != i2) {
                    this.f2229b.f2142n.B0(m2, i2);
                }
            } else {
                this.f2228a.a(view, i2, false);
                pVar.f2254c = true;
                z zVar = this.f2234g;
                if (zVar != null && zVar.h()) {
                    this.f2234g.k(view);
                }
            }
            if (pVar.f2255d) {
                f02.f2195a.invalidate();
                pVar.f2255d = false;
            }
        }

        public static d i0(Context context, AttributeSet attributeSet, int i2, int i3) {
            d dVar = new d();
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, q0.c.f5079f, i2, i3);
            dVar.f2248a = obtainStyledAttributes.getInt(q0.c.f5080g, 1);
            dVar.f2249b = obtainStyledAttributes.getInt(q0.c.f5090q, 1);
            dVar.f2250c = obtainStyledAttributes.getBoolean(q0.c.f5089p, false);
            dVar.f2251d = obtainStyledAttributes.getBoolean(q0.c.f5091r, false);
            obtainStyledAttributes.recycle();
            return dVar;
        }

        public static int n(int i2, int i3, int i4) {
            int mode = View.MeasureSpec.getMode(i2);
            int size = View.MeasureSpec.getSize(i2);
            return mode != Integer.MIN_VALUE ? mode != 1073741824 ? Math.max(i3, i4) : size : Math.min(size, Math.max(i3, i4));
        }

        private boolean t0(RecyclerView recyclerView, int i2, int i3) {
            View focusedChild = recyclerView.getFocusedChild();
            if (focusedChild == null) {
                return false;
            }
            int e02 = e0();
            int g02 = g0();
            int o02 = o0() - f0();
            int W = W() - d0();
            Rect rect = this.f2229b.f2134j;
            P(focusedChild, rect);
            return rect.left - i2 < o02 && rect.right - i2 > e02 && rect.top - i3 < W && rect.bottom - i3 > g02;
        }

        private void v1(v vVar, int i2, View view) {
            d0 f02 = RecyclerView.f0(view);
            if (f02.J()) {
                return;
            }
            if (f02.t() && !f02.v() && !this.f2229b.f2140m.g()) {
                q1(i2);
                vVar.C(f02);
                return;
            }
            x(i2);
            vVar.D(view);
            this.f2229b.f2128g.k(f02);
        }

        private static boolean w0(int i2, int i3, int i4) {
            int mode = View.MeasureSpec.getMode(i3);
            int size = View.MeasureSpec.getSize(i3);
            if (i4 <= 0 || i2 == i4) {
                if (mode == Integer.MIN_VALUE) {
                    return size >= i2;
                } else if (mode != 0) {
                    return mode == 1073741824 && size == i2;
                } else {
                    return true;
                }
            }
            return false;
        }

        private void y(int i2, View view) {
            this.f2228a.d(i2);
        }

        void A(RecyclerView recyclerView, v vVar) {
            this.f2236i = false;
            I0(recyclerView, vVar);
        }

        public void A0(View view, int i2, int i3) {
            p pVar = (p) view.getLayoutParams();
            Rect j02 = this.f2229b.j0(view);
            int i4 = i2 + j02.left + j02.right;
            int i5 = i3 + j02.top + j02.bottom;
            int K = K(o0(), p0(), e0() + f0() + ((ViewGroup.MarginLayoutParams) pVar).leftMargin + ((ViewGroup.MarginLayoutParams) pVar).rightMargin + i4, ((ViewGroup.MarginLayoutParams) pVar).width, k());
            int K2 = K(W(), X(), g0() + d0() + ((ViewGroup.MarginLayoutParams) pVar).topMargin + ((ViewGroup.MarginLayoutParams) pVar).bottomMargin + i5, ((ViewGroup.MarginLayoutParams) pVar).height, l());
            if (F1(view, K, K2, pVar)) {
                view.measure(K, K2);
            }
        }

        void A1(int i2, int i3) {
            this.f2244q = View.MeasureSpec.getSize(i2);
            int mode = View.MeasureSpec.getMode(i2);
            this.f2242o = mode;
            if (mode == 0 && !RecyclerView.B0) {
                this.f2244q = 0;
            }
            this.f2245r = View.MeasureSpec.getSize(i3);
            int mode2 = View.MeasureSpec.getMode(i3);
            this.f2243p = mode2;
            if (mode2 != 0 || RecyclerView.B0) {
                return;
            }
            this.f2245r = 0;
        }

        public View B(View view) {
            View R;
            RecyclerView recyclerView = this.f2229b;
            if (recyclerView == null || (R = recyclerView.R(view)) == null || this.f2228a.n(R)) {
                return null;
            }
            return R;
        }

        public void B0(int i2, int i3) {
            View I = I(i2);
            if (I != null) {
                x(i2);
                h(I, i3);
                return;
            }
            throw new IllegalArgumentException("Cannot move a child from non-existing index:" + i2 + this.f2229b.toString());
        }

        public void B1(int i2, int i3) {
            this.f2229b.setMeasuredDimension(i2, i3);
        }

        public View C(int i2) {
            int J = J();
            for (int i3 = 0; i3 < J; i3++) {
                View I = I(i3);
                d0 f02 = RecyclerView.f0(I);
                if (f02 != null && f02.m() == i2 && !f02.J() && (this.f2229b.f2133i0.e() || !f02.v())) {
                    return I;
                }
            }
            return null;
        }

        public void C0(int i2) {
            RecyclerView recyclerView = this.f2229b;
            if (recyclerView != null) {
                recyclerView.y0(i2);
            }
        }

        public void C1(Rect rect, int i2, int i3) {
            B1(n(i2, rect.width() + e0() + f0(), c0()), n(i3, rect.height() + g0() + d0(), b0()));
        }

        public abstract p D();

        public void D0(int i2) {
            RecyclerView recyclerView = this.f2229b;
            if (recyclerView != null) {
                recyclerView.z0(i2);
            }
        }

        void D1(int i2, int i3) {
            int J = J();
            if (J == 0) {
                this.f2229b.w(i2, i3);
                return;
            }
            int i4 = Integer.MIN_VALUE;
            int i5 = Integer.MIN_VALUE;
            int i6 = Integer.MAX_VALUE;
            int i7 = Integer.MAX_VALUE;
            for (int i8 = 0; i8 < J; i8++) {
                View I = I(i8);
                Rect rect = this.f2229b.f2134j;
                P(I, rect);
                int i9 = rect.left;
                if (i9 < i6) {
                    i6 = i9;
                }
                int i10 = rect.right;
                if (i10 > i4) {
                    i4 = i10;
                }
                int i11 = rect.top;
                if (i11 < i7) {
                    i7 = i11;
                }
                int i12 = rect.bottom;
                if (i12 > i5) {
                    i5 = i12;
                }
            }
            this.f2229b.f2134j.set(i6, i7, i4, i5);
            C1(this.f2229b.f2134j, i2, i3);
        }

        public p E(Context context, AttributeSet attributeSet) {
            return new p(context, attributeSet);
        }

        public void E0(g gVar, g gVar2) {
        }

        void E1(RecyclerView recyclerView) {
            int height;
            if (recyclerView == null) {
                this.f2229b = null;
                this.f2228a = null;
                height = 0;
                this.f2244q = 0;
            } else {
                this.f2229b = recyclerView;
                this.f2228a = recyclerView.f2126f;
                this.f2244q = recyclerView.getWidth();
                height = recyclerView.getHeight();
            }
            this.f2245r = height;
            this.f2242o = 1073741824;
            this.f2243p = 1073741824;
        }

        public p F(ViewGroup.LayoutParams layoutParams) {
            return layoutParams instanceof p ? new p((p) layoutParams) : layoutParams instanceof ViewGroup.MarginLayoutParams ? new p((ViewGroup.MarginLayoutParams) layoutParams) : new p(layoutParams);
        }

        public boolean F0(RecyclerView recyclerView, ArrayList<View> arrayList, int i2, int i3) {
            return false;
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public boolean F1(View view, int i2, int i3, p pVar) {
            return (!view.isLayoutRequested() && this.f2238k && w0(view.getWidth(), i2, ((ViewGroup.MarginLayoutParams) pVar).width) && w0(view.getHeight(), i3, ((ViewGroup.MarginLayoutParams) pVar).height)) ? false : true;
        }

        public int G() {
            return -1;
        }

        public void G0(RecyclerView recyclerView) {
        }

        boolean G1() {
            return false;
        }

        public int H(View view) {
            return ((p) view.getLayoutParams()).f2253b.bottom;
        }

        @Deprecated
        public void H0(RecyclerView recyclerView) {
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public boolean H1(View view, int i2, int i3, p pVar) {
            return (this.f2238k && w0(view.getMeasuredWidth(), i2, ((ViewGroup.MarginLayoutParams) pVar).width) && w0(view.getMeasuredHeight(), i3, ((ViewGroup.MarginLayoutParams) pVar).height)) ? false : true;
        }

        public View I(int i2) {
            androidx.recyclerview.widget.b bVar = this.f2228a;
            if (bVar != null) {
                return bVar.f(i2);
            }
            return null;
        }

        public void I0(RecyclerView recyclerView, v vVar) {
            H0(recyclerView);
        }

        public void I1(RecyclerView recyclerView, a0 a0Var, int i2) {
            Log.e("RecyclerView", "You must override smoothScrollToPosition to support smooth scrolling");
        }

        public int J() {
            androidx.recyclerview.widget.b bVar = this.f2228a;
            if (bVar != null) {
                return bVar.g();
            }
            return 0;
        }

        public View J0(View view, int i2, v vVar, a0 a0Var) {
            return null;
        }

        public void J1(z zVar) {
            z zVar2 = this.f2234g;
            if (zVar2 != null && zVar != zVar2 && zVar2.h()) {
                this.f2234g.r();
            }
            this.f2234g = zVar;
            zVar.q(this.f2229b, this);
        }

        public void K0(AccessibilityEvent accessibilityEvent) {
            RecyclerView recyclerView = this.f2229b;
            L0(recyclerView.f2120c, recyclerView.f2133i0, accessibilityEvent);
        }

        void K1() {
            z zVar = this.f2234g;
            if (zVar != null) {
                zVar.r();
            }
        }

        public void L0(v vVar, a0 a0Var, AccessibilityEvent accessibilityEvent) {
            RecyclerView recyclerView = this.f2229b;
            if (recyclerView == null || accessibilityEvent == null) {
                return;
            }
            boolean z2 = true;
            if (!recyclerView.canScrollVertically(1) && !this.f2229b.canScrollVertically(-1) && !this.f2229b.canScrollHorizontally(-1) && !this.f2229b.canScrollHorizontally(1)) {
                z2 = false;
            }
            accessibilityEvent.setScrollable(z2);
            g gVar = this.f2229b.f2140m;
            if (gVar != null) {
                accessibilityEvent.setItemCount(gVar.c());
            }
        }

        public boolean L1() {
            return false;
        }

        public boolean M() {
            RecyclerView recyclerView = this.f2229b;
            return recyclerView != null && recyclerView.f2130h;
        }

        public void M0(v vVar, a0 a0Var, f0.c cVar) {
            if (this.f2229b.canScrollVertically(-1) || this.f2229b.canScrollHorizontally(-1)) {
                cVar.a(8192);
                cVar.o0(true);
            }
            if (this.f2229b.canScrollVertically(1) || this.f2229b.canScrollHorizontally(1)) {
                cVar.a(4096);
                cVar.o0(true);
            }
            cVar.Y(c.b.a(k0(vVar, a0Var), N(vVar, a0Var), v0(vVar, a0Var), l0(vVar, a0Var)));
        }

        public int N(v vVar, a0 a0Var) {
            RecyclerView recyclerView = this.f2229b;
            if (recyclerView == null || recyclerView.f2140m == null || !k()) {
                return 1;
            }
            return this.f2229b.f2140m.c();
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public void N0(f0.c cVar) {
            RecyclerView recyclerView = this.f2229b;
            M0(recyclerView.f2120c, recyclerView.f2133i0, cVar);
        }

        public int O(View view) {
            return view.getBottom() + H(view);
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public void O0(View view, f0.c cVar) {
            d0 f02 = RecyclerView.f0(view);
            if (f02 == null || f02.v() || this.f2228a.n(f02.f2195a)) {
                return;
            }
            RecyclerView recyclerView = this.f2229b;
            P0(recyclerView.f2120c, recyclerView.f2133i0, view, cVar);
        }

        public void P(View view, Rect rect) {
            RecyclerView.g0(view, rect);
        }

        public void P0(v vVar, a0 a0Var, View view, f0.c cVar) {
            cVar.Z(c.C0055c.a(l() ? h0(view) : 0, 1, k() ? h0(view) : 0, 1, false, false));
        }

        public int Q(View view) {
            return view.getLeft() - a0(view);
        }

        public View Q0(View view, int i2) {
            return null;
        }

        public int R(View view) {
            Rect rect = ((p) view.getLayoutParams()).f2253b;
            return view.getMeasuredHeight() + rect.top + rect.bottom;
        }

        public void R0(RecyclerView recyclerView, int i2, int i3) {
        }

        public int S(View view) {
            Rect rect = ((p) view.getLayoutParams()).f2253b;
            return view.getMeasuredWidth() + rect.left + rect.right;
        }

        public void S0(RecyclerView recyclerView) {
        }

        public int T(View view) {
            return view.getRight() + j0(view);
        }

        public void T0(RecyclerView recyclerView, int i2, int i3, int i4) {
        }

        public int U(View view) {
            return view.getTop() - m0(view);
        }

        public void U0(RecyclerView recyclerView, int i2, int i3) {
        }

        public View V() {
            View focusedChild;
            RecyclerView recyclerView = this.f2229b;
            if (recyclerView == null || (focusedChild = recyclerView.getFocusedChild()) == null || this.f2228a.n(focusedChild)) {
                return null;
            }
            return focusedChild;
        }

        public void V0(RecyclerView recyclerView, int i2, int i3) {
        }

        public int W() {
            return this.f2245r;
        }

        public void W0(RecyclerView recyclerView, int i2, int i3, Object obj) {
            V0(recyclerView, i2, i3);
        }

        public int X() {
            return this.f2243p;
        }

        public void X0(v vVar, a0 a0Var) {
            Log.e("RecyclerView", "You must override onLayoutChildren(Recycler recycler, State state) ");
        }

        public int Y() {
            RecyclerView recyclerView = this.f2229b;
            g adapter = recyclerView != null ? recyclerView.getAdapter() : null;
            if (adapter != null) {
                return adapter.c();
            }
            return 0;
        }

        public void Y0(a0 a0Var) {
        }

        public int Z() {
            return e0.q.B(this.f2229b);
        }

        public void Z0(v vVar, a0 a0Var, int i2, int i3) {
            this.f2229b.w(i2, i3);
        }

        public int a0(View view) {
            return ((p) view.getLayoutParams()).f2253b.left;
        }

        @Deprecated
        public boolean a1(RecyclerView recyclerView, View view, View view2) {
            return x0() || recyclerView.t0();
        }

        public void b(View view) {
            c(view, -1);
        }

        public int b0() {
            return e0.q.C(this.f2229b);
        }

        public boolean b1(RecyclerView recyclerView, a0 a0Var, View view, View view2) {
            return a1(recyclerView, view, view2);
        }

        public void c(View view, int i2) {
            f(view, i2, true);
        }

        public int c0() {
            return e0.q.D(this.f2229b);
        }

        public void c1(Parcelable parcelable) {
        }

        public void d(View view) {
            e(view, -1);
        }

        public int d0() {
            RecyclerView recyclerView = this.f2229b;
            if (recyclerView != null) {
                return recyclerView.getPaddingBottom();
            }
            return 0;
        }

        public Parcelable d1() {
            return null;
        }

        public void e(View view, int i2) {
            f(view, i2, false);
        }

        public int e0() {
            RecyclerView recyclerView = this.f2229b;
            if (recyclerView != null) {
                return recyclerView.getPaddingLeft();
            }
            return 0;
        }

        public void e1(int i2) {
        }

        public int f0() {
            RecyclerView recyclerView = this.f2229b;
            if (recyclerView != null) {
                return recyclerView.getPaddingRight();
            }
            return 0;
        }

        void f1(z zVar) {
            if (this.f2234g == zVar) {
                this.f2234g = null;
            }
        }

        public void g(String str) {
            RecyclerView recyclerView = this.f2229b;
            if (recyclerView != null) {
                recyclerView.o(str);
            }
        }

        public int g0() {
            RecyclerView recyclerView = this.f2229b;
            if (recyclerView != null) {
                return recyclerView.getPaddingTop();
            }
            return 0;
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public boolean g1(int i2, Bundle bundle) {
            RecyclerView recyclerView = this.f2229b;
            return h1(recyclerView.f2120c, recyclerView.f2133i0, i2, bundle);
        }

        public void h(View view, int i2) {
            i(view, i2, (p) view.getLayoutParams());
        }

        public int h0(View view) {
            return ((p) view.getLayoutParams()).a();
        }

        public boolean h1(v vVar, a0 a0Var, int i2, Bundle bundle) {
            int W;
            int o02;
            int i3;
            int i4;
            RecyclerView recyclerView = this.f2229b;
            if (recyclerView == null) {
                return false;
            }
            if (i2 == 4096) {
                W = recyclerView.canScrollVertically(1) ? (W() - g0()) - d0() : 0;
                if (this.f2229b.canScrollHorizontally(1)) {
                    o02 = (o0() - e0()) - f0();
                    i3 = W;
                    i4 = o02;
                }
                i3 = W;
                i4 = 0;
            } else if (i2 != 8192) {
                i4 = 0;
                i3 = 0;
            } else {
                W = recyclerView.canScrollVertically(-1) ? -((W() - g0()) - d0()) : 0;
                if (this.f2229b.canScrollHorizontally(-1)) {
                    o02 = -((o0() - e0()) - f0());
                    i3 = W;
                    i4 = o02;
                }
                i3 = W;
                i4 = 0;
            }
            if (i3 == 0 && i4 == 0) {
                return false;
            }
            this.f2229b.n1(i4, i3, null, Integer.MIN_VALUE, true);
            return true;
        }

        public void i(View view, int i2, p pVar) {
            d0 f02 = RecyclerView.f0(view);
            if (f02.v()) {
                this.f2229b.f2128g.b(f02);
            } else {
                this.f2229b.f2128g.p(f02);
            }
            this.f2228a.c(view, i2, pVar, f02.v());
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public boolean i1(View view, int i2, Bundle bundle) {
            RecyclerView recyclerView = this.f2229b;
            return j1(recyclerView.f2120c, recyclerView.f2133i0, view, i2, bundle);
        }

        public void j(View view, Rect rect) {
            RecyclerView recyclerView = this.f2229b;
            if (recyclerView == null) {
                rect.set(0, 0, 0, 0);
            } else {
                rect.set(recyclerView.j0(view));
            }
        }

        public int j0(View view) {
            return ((p) view.getLayoutParams()).f2253b.right;
        }

        public boolean j1(v vVar, a0 a0Var, View view, int i2, Bundle bundle) {
            return false;
        }

        public boolean k() {
            return false;
        }

        public int k0(v vVar, a0 a0Var) {
            RecyclerView recyclerView = this.f2229b;
            if (recyclerView == null || recyclerView.f2140m == null || !l()) {
                return 1;
            }
            return this.f2229b.f2140m.c();
        }

        public void k1(v vVar) {
            for (int J = J() - 1; J >= 0; J--) {
                if (!RecyclerView.f0(I(J)).J()) {
                    n1(J, vVar);
                }
            }
        }

        public boolean l() {
            return false;
        }

        public int l0(v vVar, a0 a0Var) {
            return 0;
        }

        void l1(v vVar) {
            int j2 = vVar.j();
            for (int i2 = j2 - 1; i2 >= 0; i2--) {
                View n2 = vVar.n(i2);
                d0 f02 = RecyclerView.f0(n2);
                if (!f02.J()) {
                    f02.G(false);
                    if (f02.x()) {
                        this.f2229b.removeDetachedView(n2, false);
                    }
                    l lVar = this.f2229b.N;
                    if (lVar != null) {
                        lVar.j(f02);
                    }
                    f02.G(true);
                    vVar.y(n2);
                }
            }
            vVar.e();
            if (j2 > 0) {
                this.f2229b.invalidate();
            }
        }

        public boolean m(p pVar) {
            return pVar != null;
        }

        public int m0(View view) {
            return ((p) view.getLayoutParams()).f2253b.top;
        }

        public void m1(View view, v vVar) {
            p1(view);
            vVar.B(view);
        }

        public void n0(View view, boolean z2, Rect rect) {
            Matrix matrix;
            if (z2) {
                Rect rect2 = ((p) view.getLayoutParams()).f2253b;
                rect.set(-rect2.left, -rect2.top, view.getWidth() + rect2.right, view.getHeight() + rect2.bottom);
            } else {
                rect.set(0, 0, view.getWidth(), view.getHeight());
            }
            if (this.f2229b != null && (matrix = view.getMatrix()) != null && !matrix.isIdentity()) {
                RectF rectF = this.f2229b.f2138l;
                rectF.set(rect);
                matrix.mapRect(rectF);
                rect.set((int) Math.floor(rectF.left), (int) Math.floor(rectF.top), (int) Math.ceil(rectF.right), (int) Math.ceil(rectF.bottom));
            }
            rect.offset(view.getLeft(), view.getTop());
        }

        public void n1(int i2, v vVar) {
            View I = I(i2);
            q1(i2);
            vVar.B(I);
        }

        public void o(int i2, int i3, a0 a0Var, c cVar) {
        }

        public int o0() {
            return this.f2244q;
        }

        public boolean o1(Runnable runnable) {
            RecyclerView recyclerView = this.f2229b;
            if (recyclerView != null) {
                return recyclerView.removeCallbacks(runnable);
            }
            return false;
        }

        public void p(int i2, c cVar) {
        }

        public int p0() {
            return this.f2242o;
        }

        public void p1(View view) {
            this.f2228a.p(view);
        }

        public int q(a0 a0Var) {
            return 0;
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public boolean q0() {
            int J = J();
            for (int i2 = 0; i2 < J; i2++) {
                ViewGroup.LayoutParams layoutParams = I(i2).getLayoutParams();
                if (layoutParams.width < 0 && layoutParams.height < 0) {
                    return true;
                }
            }
            return false;
        }

        public void q1(int i2) {
            if (I(i2) != null) {
                this.f2228a.q(i2);
            }
        }

        public int r(a0 a0Var) {
            return 0;
        }

        public boolean r0() {
            return this.f2236i;
        }

        public boolean r1(RecyclerView recyclerView, View view, Rect rect, boolean z2) {
            return s1(recyclerView, view, rect, z2, false);
        }

        public int s(a0 a0Var) {
            return 0;
        }

        public boolean s0() {
            return this.f2237j;
        }

        public boolean s1(RecyclerView recyclerView, View view, Rect rect, boolean z2, boolean z3) {
            int[] L = L(view, rect);
            int i2 = L[0];
            int i3 = L[1];
            if ((!z3 || t0(recyclerView, i2, i3)) && !(i2 == 0 && i3 == 0)) {
                if (z2) {
                    recyclerView.scrollBy(i2, i3);
                } else {
                    recyclerView.k1(i2, i3);
                }
                return true;
            }
            return false;
        }

        public int t(a0 a0Var) {
            return 0;
        }

        public void t1() {
            RecyclerView recyclerView = this.f2229b;
            if (recyclerView != null) {
                recyclerView.requestLayout();
            }
        }

        public int u(a0 a0Var) {
            return 0;
        }

        public final boolean u0() {
            return this.f2239l;
        }

        public void u1() {
            this.f2235h = true;
        }

        public int v(a0 a0Var) {
            return 0;
        }

        public boolean v0(v vVar, a0 a0Var) {
            return false;
        }

        public void w(v vVar) {
            for (int J = J() - 1; J >= 0; J--) {
                v1(vVar, J, I(J));
            }
        }

        public int w1(int i2, v vVar, a0 a0Var) {
            return 0;
        }

        public void x(int i2) {
            y(i2, I(i2));
        }

        public boolean x0() {
            z zVar = this.f2234g;
            return zVar != null && zVar.h();
        }

        public void x1(int i2) {
        }

        public boolean y0(View view, boolean z2, boolean z3) {
            boolean z4 = this.f2232e.b(view, 24579) && this.f2233f.b(view, 24579);
            return z2 ? z4 : !z4;
        }

        public int y1(int i2, v vVar, a0 a0Var) {
            return 0;
        }

        void z(RecyclerView recyclerView) {
            this.f2236i = true;
            G0(recyclerView);
        }

        public void z0(View view, int i2, int i3, int i4, int i5) {
            p pVar = (p) view.getLayoutParams();
            Rect rect = pVar.f2253b;
            view.layout(i2 + rect.left + ((ViewGroup.MarginLayoutParams) pVar).leftMargin, i3 + rect.top + ((ViewGroup.MarginLayoutParams) pVar).topMargin, (i4 - rect.right) - ((ViewGroup.MarginLayoutParams) pVar).rightMargin, (i5 - rect.bottom) - ((ViewGroup.MarginLayoutParams) pVar).bottomMargin);
        }

        void z1(RecyclerView recyclerView) {
            A1(View.MeasureSpec.makeMeasureSpec(recyclerView.getWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(recyclerView.getHeight(), 1073741824));
        }
    }

    /* loaded from: classes.dex */
    public static class p extends ViewGroup.MarginLayoutParams {

        /* renamed from: a  reason: collision with root package name */
        d0 f2252a;

        /* renamed from: b  reason: collision with root package name */
        final Rect f2253b;

        /* renamed from: c  reason: collision with root package name */
        boolean f2254c;

        /* renamed from: d  reason: collision with root package name */
        boolean f2255d;

        public p(int i2, int i3) {
            super(i2, i3);
            this.f2253b = new Rect();
            this.f2254c = true;
            this.f2255d = false;
        }

        public p(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.f2253b = new Rect();
            this.f2254c = true;
            this.f2255d = false;
        }

        public p(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
            this.f2253b = new Rect();
            this.f2254c = true;
            this.f2255d = false;
        }

        public p(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
            this.f2253b = new Rect();
            this.f2254c = true;
            this.f2255d = false;
        }

        public p(p pVar) {
            super((ViewGroup.LayoutParams) pVar);
            this.f2253b = new Rect();
            this.f2254c = true;
            this.f2255d = false;
        }

        public int a() {
            return this.f2252a.m();
        }

        public boolean b() {
            return this.f2252a.y();
        }

        public boolean c() {
            return this.f2252a.v();
        }

        public boolean d() {
            return this.f2252a.t();
        }
    }

    /* loaded from: classes.dex */
    public interface q {
        void a(View view);

        void b(View view);
    }

    /* loaded from: classes.dex */
    public static abstract class r {
        public abstract boolean a(int i2, int i3);
    }

    /* loaded from: classes.dex */
    public interface s {
        boolean a(RecyclerView recyclerView, MotionEvent motionEvent);

        void b(RecyclerView recyclerView, MotionEvent motionEvent);

        void c(boolean z2);
    }

    /* loaded from: classes.dex */
    public static abstract class t {
        public void a(RecyclerView recyclerView, int i2) {
        }

        public void b(RecyclerView recyclerView, int i2, int i3) {
        }
    }

    /* loaded from: classes.dex */
    public static class u {

        /* renamed from: a  reason: collision with root package name */
        SparseArray<a> f2256a = new SparseArray<>();

        /* renamed from: b  reason: collision with root package name */
        private int f2257b = 0;

        /* JADX INFO: Access modifiers changed from: package-private */
        /* loaded from: classes.dex */
        public static class a {

            /* renamed from: a  reason: collision with root package name */
            final ArrayList<d0> f2258a = new ArrayList<>();

            /* renamed from: b  reason: collision with root package name */
            int f2259b = 5;

            /* renamed from: c  reason: collision with root package name */
            long f2260c = 0;

            /* renamed from: d  reason: collision with root package name */
            long f2261d = 0;

            a() {
            }
        }

        private a g(int i2) {
            a aVar = this.f2256a.get(i2);
            if (aVar == null) {
                a aVar2 = new a();
                this.f2256a.put(i2, aVar2);
                return aVar2;
            }
            return aVar;
        }

        void a() {
            this.f2257b++;
        }

        public void b() {
            for (int i2 = 0; i2 < this.f2256a.size(); i2++) {
                this.f2256a.valueAt(i2).f2258a.clear();
            }
        }

        void c() {
            this.f2257b--;
        }

        void d(int i2, long j2) {
            a g2 = g(i2);
            g2.f2261d = j(g2.f2261d, j2);
        }

        void e(int i2, long j2) {
            a g2 = g(i2);
            g2.f2260c = j(g2.f2260c, j2);
        }

        public d0 f(int i2) {
            a aVar = this.f2256a.get(i2);
            if (aVar == null || aVar.f2258a.isEmpty()) {
                return null;
            }
            ArrayList<d0> arrayList = aVar.f2258a;
            for (int size = arrayList.size() - 1; size >= 0; size--) {
                if (!arrayList.get(size).r()) {
                    return arrayList.remove(size);
                }
            }
            return null;
        }

        void h(g gVar, g gVar2, boolean z2) {
            if (gVar != null) {
                c();
            }
            if (!z2 && this.f2257b == 0) {
                b();
            }
            if (gVar2 != null) {
                a();
            }
        }

        public void i(d0 d0Var) {
            int l2 = d0Var.l();
            ArrayList<d0> arrayList = g(l2).f2258a;
            if (this.f2256a.get(l2).f2259b <= arrayList.size()) {
                return;
            }
            d0Var.D();
            arrayList.add(d0Var);
        }

        long j(long j2, long j3) {
            return j2 == 0 ? j3 : ((j2 / 4) * 3) + (j3 / 4);
        }

        boolean k(int i2, long j2, long j3) {
            long j4 = g(i2).f2261d;
            return j4 == 0 || j2 + j4 < j3;
        }

        boolean l(int i2, long j2, long j3) {
            long j4 = g(i2).f2260c;
            return j4 == 0 || j2 + j4 < j3;
        }
    }

    /* loaded from: classes.dex */
    public final class v {

        /* renamed from: a  reason: collision with root package name */
        final ArrayList<d0> f2262a;

        /* renamed from: b  reason: collision with root package name */
        ArrayList<d0> f2263b;

        /* renamed from: c  reason: collision with root package name */
        final ArrayList<d0> f2264c;

        /* renamed from: d  reason: collision with root package name */
        private final List<d0> f2265d;

        /* renamed from: e  reason: collision with root package name */
        private int f2266e;

        /* renamed from: f  reason: collision with root package name */
        int f2267f;

        /* renamed from: g  reason: collision with root package name */
        u f2268g;

        public v() {
            ArrayList<d0> arrayList = new ArrayList<>();
            this.f2262a = arrayList;
            this.f2263b = null;
            this.f2264c = new ArrayList<>();
            this.f2265d = Collections.unmodifiableList(arrayList);
            this.f2266e = 2;
            this.f2267f = 2;
        }

        private boolean H(d0 d0Var, int i2, int i3, long j2) {
            d0Var.f2212r = RecyclerView.this;
            int l2 = d0Var.l();
            long nanoTime = RecyclerView.this.getNanoTime();
            if (j2 == Long.MAX_VALUE || this.f2268g.k(l2, nanoTime, j2)) {
                RecyclerView.this.f2140m.a(d0Var, i2);
                this.f2268g.d(d0Var.l(), RecyclerView.this.getNanoTime() - nanoTime);
                b(d0Var);
                if (RecyclerView.this.f2133i0.e()) {
                    d0Var.f2201g = i3;
                    return true;
                }
                return true;
            }
            return false;
        }

        private void b(d0 d0Var) {
            if (RecyclerView.this.s0()) {
                View view = d0Var.f2195a;
                if (e0.q.z(view) == 0) {
                    e0.q.u0(view, 1);
                }
                androidx.recyclerview.widget.k kVar = RecyclerView.this.f2147p0;
                if (kVar == null) {
                    return;
                }
                e0.a n2 = kVar.n();
                if (n2 instanceof k.a) {
                    ((k.a) n2).o(view);
                }
                e0.q.k0(view, n2);
            }
        }

        private void q(ViewGroup viewGroup, boolean z2) {
            for (int childCount = viewGroup.getChildCount() - 1; childCount >= 0; childCount--) {
                View childAt = viewGroup.getChildAt(childCount);
                if (childAt instanceof ViewGroup) {
                    q((ViewGroup) childAt, true);
                }
            }
            if (z2) {
                if (viewGroup.getVisibility() == 4) {
                    viewGroup.setVisibility(0);
                    viewGroup.setVisibility(4);
                    return;
                }
                int visibility = viewGroup.getVisibility();
                viewGroup.setVisibility(4);
                viewGroup.setVisibility(visibility);
            }
        }

        private void r(d0 d0Var) {
            View view = d0Var.f2195a;
            if (view instanceof ViewGroup) {
                q((ViewGroup) view, false);
            }
        }

        void A(int i2) {
            a(this.f2264c.get(i2), true);
            this.f2264c.remove(i2);
        }

        public void B(View view) {
            d0 f02 = RecyclerView.f0(view);
            if (f02.x()) {
                RecyclerView.this.removeDetachedView(view, false);
            }
            if (f02.w()) {
                f02.K();
            } else if (f02.L()) {
                f02.e();
            }
            C(f02);
            if (RecyclerView.this.N == null || f02.u()) {
                return;
            }
            RecyclerView.this.N.j(f02);
        }

        void C(d0 d0Var) {
            boolean z2;
            boolean z3 = true;
            if (d0Var.w() || d0Var.f2195a.getParent() != null) {
                StringBuilder sb = new StringBuilder();
                sb.append("Scrapped or attached views may not be recycled. isScrap:");
                sb.append(d0Var.w());
                sb.append(" isAttached:");
                sb.append(d0Var.f2195a.getParent() != null);
                sb.append(RecyclerView.this.P());
                throw new IllegalArgumentException(sb.toString());
            } else if (d0Var.x()) {
                throw new IllegalArgumentException("Tmp detached view should be removed from RecyclerView before it can be recycled: " + d0Var + RecyclerView.this.P());
            } else if (d0Var.J()) {
                throw new IllegalArgumentException("Trying to recycle an ignored view holder. You should first call stopIgnoringView(view) before calling recycle." + RecyclerView.this.P());
            } else {
                boolean h2 = d0Var.h();
                g gVar = RecyclerView.this.f2140m;
                if ((gVar != null && h2 && gVar.n(d0Var)) || d0Var.u()) {
                    if (this.f2267f <= 0 || d0Var.p(526)) {
                        z2 = false;
                    } else {
                        int size = this.f2264c.size();
                        if (size >= this.f2267f && size > 0) {
                            A(0);
                            size--;
                        }
                        if (RecyclerView.D0 && size > 0 && !RecyclerView.this.f2131h0.d(d0Var.f2197c)) {
                            int i2 = size - 1;
                            while (i2 >= 0) {
                                if (!RecyclerView.this.f2131h0.d(this.f2264c.get(i2).f2197c)) {
                                    break;
                                }
                                i2--;
                            }
                            size = i2 + 1;
                        }
                        this.f2264c.add(size, d0Var);
                        z2 = true;
                    }
                    if (!z2) {
                        a(d0Var, true);
                        r1 = z2;
                        RecyclerView.this.f2128g.q(d0Var);
                        if (r1 && !z3 && h2) {
                            d0Var.f2212r = null;
                            return;
                        }
                        return;
                    }
                    r1 = z2;
                }
                z3 = false;
                RecyclerView.this.f2128g.q(d0Var);
                if (r1) {
                }
            }
        }

        void D(View view) {
            ArrayList<d0> arrayList;
            d0 f02 = RecyclerView.f0(view);
            if (!f02.p(12) && f02.y() && !RecyclerView.this.p(f02)) {
                if (this.f2263b == null) {
                    this.f2263b = new ArrayList<>();
                }
                f02.H(this, true);
                arrayList = this.f2263b;
            } else if (f02.t() && !f02.v() && !RecyclerView.this.f2140m.g()) {
                throw new IllegalArgumentException("Called scrap view with an invalid view. Invalid views cannot be reused from scrap, they should rebound from recycler pool." + RecyclerView.this.P());
            } else {
                f02.H(this, false);
                arrayList = this.f2262a;
            }
            arrayList.add(f02);
        }

        void E(u uVar) {
            u uVar2 = this.f2268g;
            if (uVar2 != null) {
                uVar2.c();
            }
            this.f2268g = uVar;
            if (uVar == null || RecyclerView.this.getAdapter() == null) {
                return;
            }
            this.f2268g.a();
        }

        void F(b0 b0Var) {
        }

        public void G(int i2) {
            this.f2266e = i2;
            K();
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        /* JADX WARN: Removed duplicated region for block: B:18:0x0037  */
        /* JADX WARN: Removed duplicated region for block: B:27:0x005c  */
        /* JADX WARN: Removed duplicated region for block: B:29:0x005f  */
        /* JADX WARN: Removed duplicated region for block: B:62:0x0130  */
        /* JADX WARN: Removed duplicated region for block: B:68:0x014d  */
        /* JADX WARN: Removed duplicated region for block: B:71:0x0170  */
        /* JADX WARN: Removed duplicated region for block: B:76:0x017f  */
        /* JADX WARN: Removed duplicated region for block: B:85:0x01a9  */
        /* JADX WARN: Removed duplicated region for block: B:87:0x01b7  */
        /* JADX WARN: Removed duplicated region for block: B:93:0x01cc A[ADDED_TO_REGION] */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public androidx.recyclerview.widget.RecyclerView.d0 I(int r17, boolean r18, long r19) {
            /*
                Method dump skipped, instructions count: 523
                To view this dump add '--comments-level debug' option
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.RecyclerView.v.I(int, boolean, long):androidx.recyclerview.widget.RecyclerView$d0");
        }

        void J(d0 d0Var) {
            (d0Var.f2209o ? this.f2263b : this.f2262a).remove(d0Var);
            d0Var.f2208n = null;
            d0Var.f2209o = false;
            d0Var.e();
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public void K() {
            o oVar = RecyclerView.this.f2142n;
            this.f2267f = this.f2266e + (oVar != null ? oVar.f2240m : 0);
            for (int size = this.f2264c.size() - 1; size >= 0 && this.f2264c.size() > this.f2267f; size--) {
                A(size);
            }
        }

        boolean L(d0 d0Var) {
            if (d0Var.v()) {
                return RecyclerView.this.f2133i0.e();
            }
            int i2 = d0Var.f2197c;
            if (i2 >= 0 && i2 < RecyclerView.this.f2140m.c()) {
                if (RecyclerView.this.f2133i0.e() || RecyclerView.this.f2140m.e(d0Var.f2197c) == d0Var.l()) {
                    return !RecyclerView.this.f2140m.g() || d0Var.k() == RecyclerView.this.f2140m.d(d0Var.f2197c);
                }
                return false;
            }
            throw new IndexOutOfBoundsException("Inconsistency detected. Invalid view holder adapter position" + d0Var + RecyclerView.this.P());
        }

        void M(int i2, int i3) {
            int i4;
            int i5 = i3 + i2;
            for (int size = this.f2264c.size() - 1; size >= 0; size--) {
                d0 d0Var = this.f2264c.get(size);
                if (d0Var != null && (i4 = d0Var.f2197c) >= i2 && i4 < i5) {
                    d0Var.b(2);
                    A(size);
                }
            }
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public void a(d0 d0Var, boolean z2) {
            RecyclerView.r(d0Var);
            View view = d0Var.f2195a;
            androidx.recyclerview.widget.k kVar = RecyclerView.this.f2147p0;
            if (kVar != null) {
                e0.a n2 = kVar.n();
                e0.q.k0(view, n2 instanceof k.a ? ((k.a) n2).n(view) : null);
            }
            if (z2) {
                g(d0Var);
            }
            d0Var.f2212r = null;
            i().i(d0Var);
        }

        public void c() {
            this.f2262a.clear();
            z();
        }

        void d() {
            int size = this.f2264c.size();
            for (int i2 = 0; i2 < size; i2++) {
                this.f2264c.get(i2).c();
            }
            int size2 = this.f2262a.size();
            for (int i3 = 0; i3 < size2; i3++) {
                this.f2262a.get(i3).c();
            }
            ArrayList<d0> arrayList = this.f2263b;
            if (arrayList != null) {
                int size3 = arrayList.size();
                for (int i4 = 0; i4 < size3; i4++) {
                    this.f2263b.get(i4).c();
                }
            }
        }

        void e() {
            this.f2262a.clear();
            ArrayList<d0> arrayList = this.f2263b;
            if (arrayList != null) {
                arrayList.clear();
            }
        }

        public int f(int i2) {
            if (i2 >= 0 && i2 < RecyclerView.this.f2133i0.b()) {
                return !RecyclerView.this.f2133i0.e() ? i2 : RecyclerView.this.f2124e.m(i2);
            }
            throw new IndexOutOfBoundsException("invalid position " + i2 + ". State item count is " + RecyclerView.this.f2133i0.b() + RecyclerView.this.P());
        }

        void g(d0 d0Var) {
            w wVar = RecyclerView.this.f2144o;
            if (wVar != null) {
                wVar.a(d0Var);
            }
            g gVar = RecyclerView.this.f2140m;
            if (gVar != null) {
                gVar.q(d0Var);
            }
            RecyclerView recyclerView = RecyclerView.this;
            if (recyclerView.f2133i0 != null) {
                recyclerView.f2128g.q(d0Var);
            }
        }

        d0 h(int i2) {
            int size;
            int m2;
            ArrayList<d0> arrayList = this.f2263b;
            if (arrayList != null && (size = arrayList.size()) != 0) {
                for (int i3 = 0; i3 < size; i3++) {
                    d0 d0Var = this.f2263b.get(i3);
                    if (!d0Var.L() && d0Var.m() == i2) {
                        d0Var.b(32);
                        return d0Var;
                    }
                }
                if (RecyclerView.this.f2140m.g() && (m2 = RecyclerView.this.f2124e.m(i2)) > 0 && m2 < RecyclerView.this.f2140m.c()) {
                    long d2 = RecyclerView.this.f2140m.d(m2);
                    for (int i4 = 0; i4 < size; i4++) {
                        d0 d0Var2 = this.f2263b.get(i4);
                        if (!d0Var2.L() && d0Var2.k() == d2) {
                            d0Var2.b(32);
                            return d0Var2;
                        }
                    }
                }
            }
            return null;
        }

        u i() {
            if (this.f2268g == null) {
                this.f2268g = new u();
            }
            return this.f2268g;
        }

        int j() {
            return this.f2262a.size();
        }

        public List<d0> k() {
            return this.f2265d;
        }

        d0 l(long j2, int i2, boolean z2) {
            for (int size = this.f2262a.size() - 1; size >= 0; size--) {
                d0 d0Var = this.f2262a.get(size);
                if (d0Var.k() == j2 && !d0Var.L()) {
                    if (i2 == d0Var.l()) {
                        d0Var.b(32);
                        if (d0Var.v() && !RecyclerView.this.f2133i0.e()) {
                            d0Var.F(2, 14);
                        }
                        return d0Var;
                    } else if (!z2) {
                        this.f2262a.remove(size);
                        RecyclerView.this.removeDetachedView(d0Var.f2195a, false);
                        y(d0Var.f2195a);
                    }
                }
            }
            int size2 = this.f2264c.size();
            while (true) {
                size2--;
                if (size2 < 0) {
                    return null;
                }
                d0 d0Var2 = this.f2264c.get(size2);
                if (d0Var2.k() == j2 && !d0Var2.r()) {
                    if (i2 == d0Var2.l()) {
                        if (!z2) {
                            this.f2264c.remove(size2);
                        }
                        return d0Var2;
                    } else if (!z2) {
                        A(size2);
                        return null;
                    }
                }
            }
        }

        d0 m(int i2, boolean z2) {
            View e2;
            int size = this.f2262a.size();
            for (int i3 = 0; i3 < size; i3++) {
                d0 d0Var = this.f2262a.get(i3);
                if (!d0Var.L() && d0Var.m() == i2 && !d0Var.t() && (RecyclerView.this.f2133i0.f2175h || !d0Var.v())) {
                    d0Var.b(32);
                    return d0Var;
                }
            }
            if (z2 || (e2 = RecyclerView.this.f2126f.e(i2)) == null) {
                int size2 = this.f2264c.size();
                for (int i4 = 0; i4 < size2; i4++) {
                    d0 d0Var2 = this.f2264c.get(i4);
                    if (!d0Var2.t() && d0Var2.m() == i2 && !d0Var2.r()) {
                        if (!z2) {
                            this.f2264c.remove(i4);
                        }
                        return d0Var2;
                    }
                }
                return null;
            }
            d0 f02 = RecyclerView.f0(e2);
            RecyclerView.this.f2126f.s(e2);
            int m2 = RecyclerView.this.f2126f.m(e2);
            if (m2 != -1) {
                RecyclerView.this.f2126f.d(m2);
                D(e2);
                f02.b(8224);
                return f02;
            }
            throw new IllegalStateException("layout index should not be -1 after unhiding a view:" + f02 + RecyclerView.this.P());
        }

        View n(int i2) {
            return this.f2262a.get(i2).f2195a;
        }

        public View o(int i2) {
            return p(i2, false);
        }

        View p(int i2, boolean z2) {
            return I(i2, z2, Long.MAX_VALUE).f2195a;
        }

        void s() {
            int size = this.f2264c.size();
            for (int i2 = 0; i2 < size; i2++) {
                p pVar = (p) this.f2264c.get(i2).f2195a.getLayoutParams();
                if (pVar != null) {
                    pVar.f2254c = true;
                }
            }
        }

        void t() {
            int size = this.f2264c.size();
            for (int i2 = 0; i2 < size; i2++) {
                d0 d0Var = this.f2264c.get(i2);
                if (d0Var != null) {
                    d0Var.b(6);
                    d0Var.a(null);
                }
            }
            g gVar = RecyclerView.this.f2140m;
            if (gVar == null || !gVar.g()) {
                z();
            }
        }

        void u(int i2, int i3) {
            int size = this.f2264c.size();
            for (int i4 = 0; i4 < size; i4++) {
                d0 d0Var = this.f2264c.get(i4);
                if (d0Var != null && d0Var.f2197c >= i2) {
                    d0Var.A(i3, true);
                }
            }
        }

        void v(int i2, int i3) {
            int i4;
            int i5;
            int i6;
            int i7;
            if (i2 < i3) {
                i4 = -1;
                i6 = i2;
                i5 = i3;
            } else {
                i4 = 1;
                i5 = i2;
                i6 = i3;
            }
            int size = this.f2264c.size();
            for (int i8 = 0; i8 < size; i8++) {
                d0 d0Var = this.f2264c.get(i8);
                if (d0Var != null && (i7 = d0Var.f2197c) >= i6 && i7 <= i5) {
                    if (i7 == i2) {
                        d0Var.A(i3 - i2, false);
                    } else {
                        d0Var.A(i4, false);
                    }
                }
            }
        }

        void w(int i2, int i3, boolean z2) {
            int i4 = i2 + i3;
            for (int size = this.f2264c.size() - 1; size >= 0; size--) {
                d0 d0Var = this.f2264c.get(size);
                if (d0Var != null) {
                    int i5 = d0Var.f2197c;
                    if (i5 >= i4) {
                        d0Var.A(-i3, z2);
                    } else if (i5 >= i2) {
                        d0Var.b(8);
                        A(size);
                    }
                }
            }
        }

        void x(g gVar, g gVar2, boolean z2) {
            c();
            i().h(gVar, gVar2, z2);
        }

        void y(View view) {
            d0 f02 = RecyclerView.f0(view);
            f02.f2208n = null;
            f02.f2209o = false;
            f02.e();
            C(f02);
        }

        void z() {
            for (int size = this.f2264c.size() - 1; size >= 0; size--) {
                A(size);
            }
            this.f2264c.clear();
            if (RecyclerView.D0) {
                RecyclerView.this.f2131h0.b();
            }
        }
    }

    /* loaded from: classes.dex */
    public interface w {
        void a(d0 d0Var);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public class x extends i {
        x() {
        }

        @Override // androidx.recyclerview.widget.RecyclerView.i
        public void a() {
            RecyclerView.this.o(null);
            RecyclerView recyclerView = RecyclerView.this;
            recyclerView.f2133i0.f2174g = true;
            recyclerView.O0(true);
            if (RecyclerView.this.f2124e.p()) {
                return;
            }
            RecyclerView.this.requestLayout();
        }
    }

    /* loaded from: classes.dex */
    public static class y extends h0.a {
        public static final Parcelable.Creator<y> CREATOR = new a();

        /* renamed from: d  reason: collision with root package name */
        Parcelable f2271d;

        /* loaded from: classes.dex */
        static class a implements Parcelable.ClassLoaderCreator<y> {
            a() {
            }

            @Override // android.os.Parcelable.Creator
            /* renamed from: a  reason: merged with bridge method [inline-methods] */
            public y createFromParcel(Parcel parcel) {
                return new y(parcel, null);
            }

            @Override // android.os.Parcelable.ClassLoaderCreator
            /* renamed from: b  reason: merged with bridge method [inline-methods] */
            public y createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new y(parcel, classLoader);
            }

            @Override // android.os.Parcelable.Creator
            /* renamed from: c  reason: merged with bridge method [inline-methods] */
            public y[] newArray(int i2) {
                return new y[i2];
            }
        }

        y(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.f2271d = parcel.readParcelable(classLoader == null ? o.class.getClassLoader() : classLoader);
        }

        y(Parcelable parcelable) {
            super(parcelable);
        }

        void k(y yVar) {
            this.f2271d = yVar.f2271d;
        }

        @Override // h0.a, android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i2) {
            super.writeToParcel(parcel, i2);
            parcel.writeParcelable(this.f2271d, 0);
        }
    }

    /* loaded from: classes.dex */
    public static abstract class z {

        /* renamed from: b  reason: collision with root package name */
        private RecyclerView f2273b;

        /* renamed from: c  reason: collision with root package name */
        private o f2274c;

        /* renamed from: d  reason: collision with root package name */
        private boolean f2275d;

        /* renamed from: e  reason: collision with root package name */
        private boolean f2276e;

        /* renamed from: f  reason: collision with root package name */
        private View f2277f;

        /* renamed from: h  reason: collision with root package name */
        private boolean f2279h;

        /* renamed from: a  reason: collision with root package name */
        private int f2272a = -1;

        /* renamed from: g  reason: collision with root package name */
        private final a f2278g = new a(0, 0);

        /* loaded from: classes.dex */
        public static class a {

            /* renamed from: a  reason: collision with root package name */
            private int f2280a;

            /* renamed from: b  reason: collision with root package name */
            private int f2281b;

            /* renamed from: c  reason: collision with root package name */
            private int f2282c;

            /* renamed from: d  reason: collision with root package name */
            private int f2283d;

            /* renamed from: e  reason: collision with root package name */
            private Interpolator f2284e;

            /* renamed from: f  reason: collision with root package name */
            private boolean f2285f;

            /* renamed from: g  reason: collision with root package name */
            private int f2286g;

            public a(int i2, int i3) {
                this(i2, i3, Integer.MIN_VALUE, null);
            }

            public a(int i2, int i3, int i4, Interpolator interpolator) {
                this.f2283d = -1;
                this.f2285f = false;
                this.f2286g = 0;
                this.f2280a = i2;
                this.f2281b = i3;
                this.f2282c = i4;
                this.f2284e = interpolator;
            }

            private void e() {
                if (this.f2284e != null && this.f2282c < 1) {
                    throw new IllegalStateException("If you provide an interpolator, you must set a positive duration");
                }
                if (this.f2282c < 1) {
                    throw new IllegalStateException("Scroll duration must be a positive number");
                }
            }

            boolean a() {
                return this.f2283d >= 0;
            }

            public void b(int i2) {
                this.f2283d = i2;
            }

            void c(RecyclerView recyclerView) {
                int i2 = this.f2283d;
                if (i2 >= 0) {
                    this.f2283d = -1;
                    recyclerView.v0(i2);
                    this.f2285f = false;
                } else if (!this.f2285f) {
                    this.f2286g = 0;
                } else {
                    e();
                    recyclerView.f2127f0.f(this.f2280a, this.f2281b, this.f2282c, this.f2284e);
                    int i3 = this.f2286g + 1;
                    this.f2286g = i3;
                    if (i3 > 10) {
                        Log.e("RecyclerView", "Smooth Scroll action is being updated too frequently. Make sure you are not changing it unless necessary");
                    }
                    this.f2285f = false;
                }
            }

            public void d(int i2, int i3, int i4, Interpolator interpolator) {
                this.f2280a = i2;
                this.f2281b = i3;
                this.f2282c = i4;
                this.f2284e = interpolator;
                this.f2285f = true;
            }
        }

        /* loaded from: classes.dex */
        public interface b {
            PointF a(int i2);
        }

        public PointF a(int i2) {
            o e2 = e();
            if (e2 instanceof b) {
                return ((b) e2).a(i2);
            }
            Log.w("RecyclerView", "You should override computeScrollVectorForPosition when the LayoutManager does not implement " + b.class.getCanonicalName());
            return null;
        }

        public View b(int i2) {
            return this.f2273b.f2142n.C(i2);
        }

        public int c() {
            return this.f2273b.f2142n.J();
        }

        public int d(View view) {
            return this.f2273b.d0(view);
        }

        public o e() {
            return this.f2274c;
        }

        public int f() {
            return this.f2272a;
        }

        public boolean g() {
            return this.f2275d;
        }

        public boolean h() {
            return this.f2276e;
        }

        /* JADX INFO: Access modifiers changed from: protected */
        public void i(PointF pointF) {
            float f2 = pointF.x;
            float f3 = pointF.y;
            float sqrt = (float) Math.sqrt((f2 * f2) + (f3 * f3));
            pointF.x /= sqrt;
            pointF.y /= sqrt;
        }

        void j(int i2, int i3) {
            PointF a2;
            RecyclerView recyclerView = this.f2273b;
            if (this.f2272a == -1 || recyclerView == null) {
                r();
            }
            if (this.f2275d && this.f2277f == null && this.f2274c != null && (a2 = a(this.f2272a)) != null) {
                float f2 = a2.x;
                if (f2 != 0.0f || a2.y != 0.0f) {
                    recyclerView.f1((int) Math.signum(f2), (int) Math.signum(a2.y), null);
                }
            }
            this.f2275d = false;
            View view = this.f2277f;
            if (view != null) {
                if (d(view) == this.f2272a) {
                    o(this.f2277f, recyclerView.f2133i0, this.f2278g);
                    this.f2278g.c(recyclerView);
                    r();
                } else {
                    Log.e("RecyclerView", "Passed over target position while smooth scrolling.");
                    this.f2277f = null;
                }
            }
            if (this.f2276e) {
                l(i2, i3, recyclerView.f2133i0, this.f2278g);
                boolean a3 = this.f2278g.a();
                this.f2278g.c(recyclerView);
                if (a3 && this.f2276e) {
                    this.f2275d = true;
                    recyclerView.f2127f0.e();
                }
            }
        }

        protected void k(View view) {
            if (d(view) == f()) {
                this.f2277f = view;
            }
        }

        protected abstract void l(int i2, int i3, a0 a0Var, a aVar);

        protected abstract void m();

        protected abstract void n();

        protected abstract void o(View view, a0 a0Var, a aVar);

        public void p(int i2) {
            this.f2272a = i2;
        }

        void q(RecyclerView recyclerView, o oVar) {
            recyclerView.f2127f0.g();
            if (this.f2279h) {
                Log.w("RecyclerView", "An instance of " + getClass().getSimpleName() + " was started more than once. Each instance of" + getClass().getSimpleName() + " is intended to only be used once. You should create a new instance for each use.");
            }
            this.f2273b = recyclerView;
            this.f2274c = oVar;
            int i2 = this.f2272a;
            if (i2 == -1) {
                throw new IllegalArgumentException("Invalid target position");
            }
            recyclerView.f2133i0.f2168a = i2;
            this.f2276e = true;
            this.f2275d = true;
            this.f2277f = b(f());
            m();
            this.f2273b.f2127f0.e();
            this.f2279h = true;
        }

        /* JADX INFO: Access modifiers changed from: protected */
        public final void r() {
            if (this.f2276e) {
                this.f2276e = false;
                n();
                this.f2273b.f2133i0.f2168a = -1;
                this.f2277f = null;
                this.f2272a = -1;
                this.f2275d = false;
                this.f2274c.f1(this);
                this.f2274c = null;
                this.f2273b = null;
            }
        }
    }

    static {
        int i2 = Build.VERSION.SDK_INT;
        A0 = false;
        B0 = i2 >= 23;
        C0 = true;
        D0 = true;
        E0 = false;
        F0 = false;
        Class<?> cls = Integer.TYPE;
        G0 = new Class[]{Context.class, AttributeSet.class, cls, cls};
        H0 = new c();
    }

    public RecyclerView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, q0.a.recyclerViewStyle);
    }

    public RecyclerView(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.f2118b = new x();
        this.f2120c = new v();
        this.f2128g = new androidx.recyclerview.widget.p();
        this.f2132i = new a();
        this.f2134j = new Rect();
        this.f2136k = new Rect();
        this.f2138l = new RectF();
        this.f2146p = new ArrayList<>();
        this.f2148q = new ArrayList<>();
        this.f2160w = 0;
        this.E = false;
        this.F = false;
        this.G = 0;
        this.H = 0;
        this.I = new k();
        this.N = new androidx.recyclerview.widget.c();
        this.O = 0;
        this.P = -1;
        this.f2121c0 = Float.MIN_VALUE;
        this.f2123d0 = Float.MIN_VALUE;
        this.f2125e0 = true;
        this.f2127f0 = new c0();
        this.f2131h0 = D0 ? new e.b() : null;
        this.f2133i0 = new a0();
        this.f2139l0 = false;
        this.f2141m0 = false;
        this.f2143n0 = new m();
        this.f2145o0 = false;
        this.f2151r0 = new int[2];
        this.f2155t0 = new int[2];
        this.f2157u0 = new int[2];
        this.f2159v0 = new int[2];
        this.f2161w0 = new ArrayList();
        this.f2163x0 = new b();
        this.f2165y0 = new d();
        setScrollContainer(true);
        setFocusableInTouchMode(true);
        ViewConfiguration viewConfiguration = ViewConfiguration.get(context);
        this.V = viewConfiguration.getScaledTouchSlop();
        this.f2121c0 = e0.r.b(viewConfiguration, context);
        this.f2123d0 = e0.r.d(viewConfiguration, context);
        this.f2117a0 = viewConfiguration.getScaledMinimumFlingVelocity();
        this.f2119b0 = viewConfiguration.getScaledMaximumFlingVelocity();
        setWillNotDraw(getOverScrollMode() == 2);
        this.N.v(this.f2143n0);
        n0();
        p0();
        o0();
        if (e0.q.z(this) == 0) {
            e0.q.u0(this, 1);
        }
        this.C = (AccessibilityManager) getContext().getSystemService("accessibility");
        setAccessibilityDelegateCompat(new androidx.recyclerview.widget.k(this));
        int[] iArr = q0.c.f5079f;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, iArr, i2, 0);
        int i3 = Build.VERSION.SDK_INT;
        if (i3 >= 29) {
            saveAttributeDataForStyleable(context, iArr, attributeSet, obtainStyledAttributes, i2, 0);
        }
        String string = obtainStyledAttributes.getString(q0.c.f5088o);
        if (obtainStyledAttributes.getInt(q0.c.f5082i, -1) == -1) {
            setDescendantFocusability(262144);
        }
        this.f2130h = obtainStyledAttributes.getBoolean(q0.c.f5081h, true);
        boolean z2 = obtainStyledAttributes.getBoolean(q0.c.f5083j, false);
        this.f2156u = z2;
        if (z2) {
            q0((StateListDrawable) obtainStyledAttributes.getDrawable(q0.c.f5086m), obtainStyledAttributes.getDrawable(q0.c.f5087n), (StateListDrawable) obtainStyledAttributes.getDrawable(q0.c.f5084k), obtainStyledAttributes.getDrawable(q0.c.f5085l));
        }
        obtainStyledAttributes.recycle();
        v(context, string, attributeSet, i2, 0);
        int[] iArr2 = f2116z0;
        TypedArray obtainStyledAttributes2 = context.obtainStyledAttributes(attributeSet, iArr2, i2, 0);
        if (i3 >= 29) {
            saveAttributeDataForStyleable(context, iArr2, attributeSet, obtainStyledAttributes2, i2, 0);
        }
        boolean z3 = obtainStyledAttributes2.getBoolean(0, true);
        obtainStyledAttributes2.recycle();
        setNestedScrollingEnabled(z3);
    }

    private void A() {
        int i2 = this.A;
        this.A = 0;
        if (i2 == 0 || !s0()) {
            return;
        }
        AccessibilityEvent obtain = AccessibilityEvent.obtain();
        obtain.setEventType(2048);
        f0.b.b(obtain, i2);
        sendAccessibilityEventUnchecked(obtain);
    }

    private void C() {
        this.f2133i0.a(1);
        Q(this.f2133i0);
        this.f2133i0.f2177j = false;
        p1();
        this.f2128g.f();
        F0();
        N0();
        c1();
        a0 a0Var = this.f2133i0;
        a0Var.f2176i = a0Var.f2178k && this.f2141m0;
        this.f2141m0 = false;
        this.f2139l0 = false;
        a0Var.f2175h = a0Var.f2179l;
        a0Var.f2173f = this.f2140m.c();
        U(this.f2151r0);
        if (this.f2133i0.f2178k) {
            int g2 = this.f2126f.g();
            for (int i2 = 0; i2 < g2; i2++) {
                d0 f02 = f0(this.f2126f.f(i2));
                if (!f02.J() && (!f02.t() || this.f2140m.g())) {
                    this.f2128g.e(f02, this.N.t(this.f2133i0, f02, l.e(f02), f02.o()));
                    if (this.f2133i0.f2176i && f02.y() && !f02.v() && !f02.J() && !f02.t()) {
                        this.f2128g.c(c0(f02), f02);
                    }
                }
            }
        }
        if (this.f2133i0.f2179l) {
            d1();
            a0 a0Var2 = this.f2133i0;
            boolean z2 = a0Var2.f2174g;
            a0Var2.f2174g = false;
            this.f2142n.X0(this.f2120c, a0Var2);
            this.f2133i0.f2174g = z2;
            for (int i3 = 0; i3 < this.f2126f.g(); i3++) {
                d0 f03 = f0(this.f2126f.f(i3));
                if (!f03.J() && !this.f2128g.i(f03)) {
                    int e2 = l.e(f03);
                    boolean p2 = f03.p(8192);
                    if (!p2) {
                        e2 |= 4096;
                    }
                    l.c t2 = this.N.t(this.f2133i0, f03, e2, f03.o());
                    if (p2) {
                        Q0(f03, t2);
                    } else {
                        this.f2128g.a(f03, t2);
                    }
                }
            }
        }
        s();
        G0();
        r1(false);
        this.f2133i0.f2172e = 2;
    }

    private void D() {
        p1();
        F0();
        this.f2133i0.a(6);
        this.f2124e.j();
        this.f2133i0.f2173f = this.f2140m.c();
        a0 a0Var = this.f2133i0;
        a0Var.f2171d = 0;
        a0Var.f2175h = false;
        this.f2142n.X0(this.f2120c, a0Var);
        a0 a0Var2 = this.f2133i0;
        a0Var2.f2174g = false;
        this.f2122d = null;
        a0Var2.f2178k = a0Var2.f2178k && this.N != null;
        a0Var2.f2172e = 4;
        G0();
        r1(false);
    }

    private void E() {
        this.f2133i0.a(4);
        p1();
        F0();
        a0 a0Var = this.f2133i0;
        a0Var.f2172e = 1;
        if (a0Var.f2178k) {
            for (int g2 = this.f2126f.g() - 1; g2 >= 0; g2--) {
                d0 f02 = f0(this.f2126f.f(g2));
                if (!f02.J()) {
                    long c02 = c0(f02);
                    l.c s2 = this.N.s(this.f2133i0, f02);
                    d0 g3 = this.f2128g.g(c02);
                    if (g3 != null && !g3.J()) {
                        boolean h2 = this.f2128g.h(g3);
                        boolean h3 = this.f2128g.h(f02);
                        if (!h2 || g3 != f02) {
                            l.c n2 = this.f2128g.n(g3);
                            this.f2128g.d(f02, s2);
                            l.c m2 = this.f2128g.m(f02);
                            if (n2 == null) {
                                k0(c02, f02, g3);
                            } else {
                                m(g3, f02, n2, m2, h2, h3);
                            }
                        }
                    }
                    this.f2128g.d(f02, s2);
                }
            }
            this.f2128g.o(this.f2165y0);
        }
        this.f2142n.l1(this.f2120c);
        a0 a0Var2 = this.f2133i0;
        a0Var2.f2170c = a0Var2.f2173f;
        this.E = false;
        this.F = false;
        a0Var2.f2178k = false;
        a0Var2.f2179l = false;
        this.f2142n.f2235h = false;
        ArrayList<d0> arrayList = this.f2120c.f2263b;
        if (arrayList != null) {
            arrayList.clear();
        }
        o oVar = this.f2142n;
        if (oVar.f2241n) {
            oVar.f2240m = 0;
            oVar.f2241n = false;
            this.f2120c.K();
        }
        this.f2142n.Y0(this.f2133i0);
        G0();
        r1(false);
        this.f2128g.f();
        int[] iArr = this.f2151r0;
        if (x(iArr[0], iArr[1])) {
            I(0, 0);
        }
        R0();
        a1();
    }

    private void I0(MotionEvent motionEvent) {
        int actionIndex = motionEvent.getActionIndex();
        if (motionEvent.getPointerId(actionIndex) == this.P) {
            int i2 = actionIndex == 0 ? 1 : 0;
            this.P = motionEvent.getPointerId(i2);
            int x2 = (int) (motionEvent.getX(i2) + 0.5f);
            this.T = x2;
            this.R = x2;
            int y2 = (int) (motionEvent.getY(i2) + 0.5f);
            this.U = y2;
            this.S = y2;
        }
    }

    private boolean K(MotionEvent motionEvent) {
        s sVar = this.f2150r;
        if (sVar == null) {
            if (motionEvent.getAction() == 0) {
                return false;
            }
            return T(motionEvent);
        }
        sVar.b(this, motionEvent);
        int action = motionEvent.getAction();
        if (action == 3 || action == 1) {
            this.f2150r = null;
        }
        return true;
    }

    private boolean M0() {
        return this.N != null && this.f2142n.L1();
    }

    private void N0() {
        boolean z2;
        if (this.E) {
            this.f2124e.u();
            if (this.F) {
                this.f2142n.S0(this);
            }
        }
        if (M0()) {
            this.f2124e.s();
        } else {
            this.f2124e.j();
        }
        boolean z3 = false;
        boolean z4 = this.f2139l0 || this.f2141m0;
        this.f2133i0.f2178k = this.f2158v && this.N != null && ((z2 = this.E) || z4 || this.f2142n.f2235h) && (!z2 || this.f2140m.g());
        a0 a0Var = this.f2133i0;
        if (a0Var.f2178k && z4 && !this.E && M0()) {
            z3 = true;
        }
        a0Var.f2179l = z3;
    }

    /* JADX WARN: Removed duplicated region for block: B:12:0x003d  */
    /* JADX WARN: Removed duplicated region for block: B:13:0x0053  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private void P0(float r7, float r8, float r9, float r10) {
        /*
            r6 = this;
            r0 = 1065353216(0x3f800000, float:1.0)
            r1 = 1
            r2 = 0
            int r3 = (r8 > r2 ? 1 : (r8 == r2 ? 0 : -1))
            if (r3 >= 0) goto L21
            r6.M()
            android.widget.EdgeEffect r3 = r6.J
            float r4 = -r8
            int r5 = r6.getWidth()
            float r5 = (float) r5
            float r4 = r4 / r5
            int r5 = r6.getHeight()
            float r5 = (float) r5
            float r9 = r9 / r5
            float r9 = r0 - r9
        L1c:
            androidx.core.widget.d.a(r3, r4, r9)
            r9 = 1
            goto L39
        L21:
            int r3 = (r8 > r2 ? 1 : (r8 == r2 ? 0 : -1))
            if (r3 <= 0) goto L38
            r6.N()
            android.widget.EdgeEffect r3 = r6.L
            int r4 = r6.getWidth()
            float r4 = (float) r4
            float r4 = r8 / r4
            int r5 = r6.getHeight()
            float r5 = (float) r5
            float r9 = r9 / r5
            goto L1c
        L38:
            r9 = 0
        L39:
            int r3 = (r10 > r2 ? 1 : (r10 == r2 ? 0 : -1))
            if (r3 >= 0) goto L53
            r6.O()
            android.widget.EdgeEffect r9 = r6.K
            float r0 = -r10
            int r3 = r6.getHeight()
            float r3 = (float) r3
            float r0 = r0 / r3
            int r3 = r6.getWidth()
            float r3 = (float) r3
            float r7 = r7 / r3
            androidx.core.widget.d.a(r9, r0, r7)
            goto L6f
        L53:
            int r3 = (r10 > r2 ? 1 : (r10 == r2 ? 0 : -1))
            if (r3 <= 0) goto L6e
            r6.L()
            android.widget.EdgeEffect r9 = r6.M
            int r3 = r6.getHeight()
            float r3 = (float) r3
            float r3 = r10 / r3
            int r4 = r6.getWidth()
            float r4 = (float) r4
            float r7 = r7 / r4
            float r0 = r0 - r7
            androidx.core.widget.d.a(r9, r3, r0)
            goto L6f
        L6e:
            r1 = r9
        L6f:
            if (r1 != 0) goto L79
            int r7 = (r8 > r2 ? 1 : (r8 == r2 ? 0 : -1))
            if (r7 != 0) goto L79
            int r7 = (r10 > r2 ? 1 : (r10 == r2 ? 0 : -1))
            if (r7 == 0) goto L7c
        L79:
            e0.q.b0(r6)
        L7c:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.RecyclerView.P0(float, float, float, float):void");
    }

    private void R0() {
        View findViewById;
        if (!this.f2125e0 || this.f2140m == null || !hasFocus() || getDescendantFocusability() == 393216) {
            return;
        }
        if (getDescendantFocusability() == 131072 && isFocused()) {
            return;
        }
        if (!isFocused()) {
            View focusedChild = getFocusedChild();
            if (!F0 || (focusedChild.getParent() != null && focusedChild.hasFocus())) {
                if (!this.f2126f.n(focusedChild)) {
                    return;
                }
            } else if (this.f2126f.g() == 0) {
                requestFocus();
                return;
            }
        }
        View view = null;
        d0 Y = (this.f2133i0.f2181n == -1 || !this.f2140m.g()) ? null : Y(this.f2133i0.f2181n);
        if (Y != null && !this.f2126f.n(Y.f2195a) && Y.f2195a.hasFocusable()) {
            view = Y.f2195a;
        } else if (this.f2126f.g() > 0) {
            view = W();
        }
        if (view != null) {
            int i2 = this.f2133i0.f2182o;
            if (i2 != -1 && (findViewById = view.findViewById(i2)) != null && findViewById.isFocusable()) {
                view = findViewById;
            }
            view.requestFocus();
        }
    }

    private void S0() {
        boolean z2;
        EdgeEffect edgeEffect = this.J;
        if (edgeEffect != null) {
            edgeEffect.onRelease();
            z2 = this.J.isFinished();
        } else {
            z2 = false;
        }
        EdgeEffect edgeEffect2 = this.K;
        if (edgeEffect2 != null) {
            edgeEffect2.onRelease();
            z2 |= this.K.isFinished();
        }
        EdgeEffect edgeEffect3 = this.L;
        if (edgeEffect3 != null) {
            edgeEffect3.onRelease();
            z2 |= this.L.isFinished();
        }
        EdgeEffect edgeEffect4 = this.M;
        if (edgeEffect4 != null) {
            edgeEffect4.onRelease();
            z2 |= this.M.isFinished();
        }
        if (z2) {
            e0.q.b0(this);
        }
    }

    private boolean T(MotionEvent motionEvent) {
        int action = motionEvent.getAction();
        int size = this.f2148q.size();
        for (int i2 = 0; i2 < size; i2++) {
            s sVar = this.f2148q.get(i2);
            if (sVar.a(this, motionEvent) && action != 3) {
                this.f2150r = sVar;
                return true;
            }
        }
        return false;
    }

    private void U(int[] iArr) {
        int g2 = this.f2126f.g();
        if (g2 == 0) {
            iArr[0] = -1;
            iArr[1] = -1;
            return;
        }
        int i2 = Integer.MAX_VALUE;
        int i3 = Integer.MIN_VALUE;
        for (int i4 = 0; i4 < g2; i4++) {
            d0 f02 = f0(this.f2126f.f(i4));
            if (!f02.J()) {
                int m2 = f02.m();
                if (m2 < i2) {
                    i2 = m2;
                }
                if (m2 > i3) {
                    i3 = m2;
                }
            }
        }
        iArr[0] = i2;
        iArr[1] = i3;
    }

    static RecyclerView V(View view) {
        if (view instanceof ViewGroup) {
            if (view instanceof RecyclerView) {
                return (RecyclerView) view;
            }
            ViewGroup viewGroup = (ViewGroup) view;
            int childCount = viewGroup.getChildCount();
            for (int i2 = 0; i2 < childCount; i2++) {
                RecyclerView V = V(viewGroup.getChildAt(i2));
                if (V != null) {
                    return V;
                }
            }
            return null;
        }
        return null;
    }

    private View W() {
        d0 X;
        a0 a0Var = this.f2133i0;
        int i2 = a0Var.f2180m;
        if (i2 == -1) {
            i2 = 0;
        }
        int b2 = a0Var.b();
        for (int i3 = i2; i3 < b2; i3++) {
            d0 X2 = X(i3);
            if (X2 == null) {
                break;
            } else if (X2.f2195a.hasFocusable()) {
                return X2.f2195a;
            }
        }
        int min = Math.min(b2, i2);
        do {
            min--;
            if (min < 0 || (X = X(min)) == null) {
                return null;
            }
        } while (!X.f2195a.hasFocusable());
        return X.f2195a;
    }

    private void Z0(View view, View view2) {
        View view3 = view2 != null ? view2 : view;
        this.f2134j.set(0, 0, view3.getWidth(), view3.getHeight());
        ViewGroup.LayoutParams layoutParams = view3.getLayoutParams();
        if (layoutParams instanceof p) {
            p pVar = (p) layoutParams;
            if (!pVar.f2254c) {
                Rect rect = pVar.f2253b;
                Rect rect2 = this.f2134j;
                rect2.left -= rect.left;
                rect2.right += rect.right;
                rect2.top -= rect.top;
                rect2.bottom += rect.bottom;
            }
        }
        if (view2 != null) {
            offsetDescendantRectToMyCoords(view2, this.f2134j);
            offsetRectIntoDescendantCoords(view, this.f2134j);
        }
        this.f2142n.s1(this, view, this.f2134j, !this.f2158v, view2 == null);
    }

    private void a1() {
        a0 a0Var = this.f2133i0;
        a0Var.f2181n = -1L;
        a0Var.f2180m = -1;
        a0Var.f2182o = -1;
    }

    private void b1() {
        VelocityTracker velocityTracker = this.Q;
        if (velocityTracker != null) {
            velocityTracker.clear();
        }
        s1(0);
        S0();
    }

    private void c1() {
        View focusedChild = (this.f2125e0 && hasFocus() && this.f2140m != null) ? getFocusedChild() : null;
        d0 S = focusedChild != null ? S(focusedChild) : null;
        if (S == null) {
            a1();
            return;
        }
        this.f2133i0.f2181n = this.f2140m.g() ? S.k() : -1L;
        this.f2133i0.f2180m = this.E ? -1 : S.v() ? S.f2198d : S.j();
        this.f2133i0.f2182o = h0(S.f2195a);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static d0 f0(View view) {
        if (view == null) {
            return null;
        }
        return ((p) view.getLayoutParams()).f2252a;
    }

    private void g(d0 d0Var) {
        View view = d0Var.f2195a;
        boolean z2 = view.getParent() == this;
        this.f2120c.J(e0(view));
        if (d0Var.x()) {
            this.f2126f.c(view, -1, view.getLayoutParams(), true);
            return;
        }
        androidx.recyclerview.widget.b bVar = this.f2126f;
        if (z2) {
            bVar.k(view);
        } else {
            bVar.b(view, true);
        }
    }

    static void g0(View view, Rect rect) {
        p pVar = (p) view.getLayoutParams();
        Rect rect2 = pVar.f2253b;
        rect.set((view.getLeft() - rect2.left) - ((ViewGroup.MarginLayoutParams) pVar).leftMargin, (view.getTop() - rect2.top) - ((ViewGroup.MarginLayoutParams) pVar).topMargin, view.getRight() + rect2.right + ((ViewGroup.MarginLayoutParams) pVar).rightMargin, view.getBottom() + rect2.bottom + ((ViewGroup.MarginLayoutParams) pVar).bottomMargin);
    }

    private e0.k getScrollingChildHelper() {
        if (this.f2153s0 == null) {
            this.f2153s0 = new e0.k(this);
        }
        return this.f2153s0;
    }

    private int h0(View view) {
        int id;
        loop0: while (true) {
            id = view.getId();
            while (!view.isFocused() && (view instanceof ViewGroup) && view.hasFocus()) {
                view = ((ViewGroup) view).getFocusedChild();
                if (view.getId() != -1) {
                    break;
                }
            }
        }
        return id;
    }

    private void h1(g gVar, boolean z2, boolean z3) {
        g gVar2 = this.f2140m;
        if (gVar2 != null) {
            gVar2.t(this.f2118b);
            this.f2140m.m(this);
        }
        if (!z2 || z3) {
            T0();
        }
        this.f2124e.u();
        g gVar3 = this.f2140m;
        this.f2140m = gVar;
        if (gVar != null) {
            gVar.r(this.f2118b);
            gVar.i(this);
        }
        o oVar = this.f2142n;
        if (oVar != null) {
            oVar.E0(gVar3, this.f2140m);
        }
        this.f2120c.x(gVar3, this.f2140m, z2);
        this.f2133i0.f2174g = true;
    }

    private String i0(Context context, String str) {
        if (str.charAt(0) == '.') {
            return context.getPackageName() + str;
        } else if (str.contains(".")) {
            return str;
        } else {
            return RecyclerView.class.getPackage().getName() + '.' + str;
        }
    }

    private void k0(long j2, d0 d0Var, d0 d0Var2) {
        int g2 = this.f2126f.g();
        for (int i2 = 0; i2 < g2; i2++) {
            d0 f02 = f0(this.f2126f.f(i2));
            if (f02 != d0Var && c0(f02) == j2) {
                g gVar = this.f2140m;
                if (gVar == null || !gVar.g()) {
                    throw new IllegalStateException("Two different ViewHolders have the same change ID. This might happen due to inconsistent Adapter update events or if the LayoutManager lays out the same View multiple times.\n ViewHolder 1:" + f02 + " \n View Holder 2:" + d0Var + P());
                }
                throw new IllegalStateException("Two different ViewHolders have the same stable ID. Stable IDs in your adapter MUST BE unique and SHOULD NOT change.\n ViewHolder 1:" + f02 + " \n View Holder 2:" + d0Var + P());
            }
        }
        Log.e("RecyclerView", "Problem while matching changed view holders with the newones. The pre-layout information for the change holder " + d0Var2 + " cannot be found but it is necessary for " + d0Var + P());
    }

    private void m(d0 d0Var, d0 d0Var2, l.c cVar, l.c cVar2, boolean z2, boolean z3) {
        d0Var.G(false);
        if (z2) {
            g(d0Var);
        }
        if (d0Var != d0Var2) {
            if (z3) {
                g(d0Var2);
            }
            d0Var.f2202h = d0Var2;
            g(d0Var);
            this.f2120c.J(d0Var);
            d0Var2.G(false);
            d0Var2.f2203i = d0Var;
        }
        if (this.N.b(d0Var, d0Var2, cVar, cVar2)) {
            L0();
        }
    }

    private boolean m0() {
        int g2 = this.f2126f.g();
        for (int i2 = 0; i2 < g2; i2++) {
            d0 f02 = f0(this.f2126f.f(i2));
            if (f02 != null && !f02.J() && f02.y()) {
                return true;
            }
        }
        return false;
    }

    @SuppressLint({"InlinedApi"})
    private void o0() {
        if (e0.q.A(this) == 0) {
            e0.q.v0(this, 8);
        }
    }

    private void p0() {
        this.f2126f = new androidx.recyclerview.widget.b(new e());
    }

    private void q() {
        b1();
        setScrollState(0);
    }

    static void r(d0 d0Var) {
        WeakReference<RecyclerView> weakReference = d0Var.f2196b;
        if (weakReference != null) {
            ViewParent viewParent = weakReference.get();
            while (true) {
                for (View view = (View) viewParent; view != null; view = null) {
                    if (view == d0Var.f2195a) {
                        return;
                    }
                    viewParent = view.getParent();
                    if (viewParent instanceof View) {
                        break;
                    }
                }
                d0Var.f2196b = null;
                return;
            }
        }
    }

    private boolean u0(View view, View view2, int i2) {
        int i3;
        if (view2 == null || view2 == this || R(view2) == null) {
            return false;
        }
        if (view == null || R(view) == null) {
            return true;
        }
        this.f2134j.set(0, 0, view.getWidth(), view.getHeight());
        this.f2136k.set(0, 0, view2.getWidth(), view2.getHeight());
        offsetDescendantRectToMyCoords(view, this.f2134j);
        offsetDescendantRectToMyCoords(view2, this.f2136k);
        char c2 = 65535;
        int i4 = this.f2142n.Z() == 1 ? -1 : 1;
        Rect rect = this.f2134j;
        int i5 = rect.left;
        Rect rect2 = this.f2136k;
        int i6 = rect2.left;
        if ((i5 < i6 || rect.right <= i6) && rect.right < rect2.right) {
            i3 = 1;
        } else {
            int i7 = rect.right;
            int i8 = rect2.right;
            i3 = ((i7 > i8 || i5 >= i8) && i5 > i6) ? -1 : 0;
        }
        int i9 = rect.top;
        int i10 = rect2.top;
        if ((i9 < i10 || rect.bottom <= i10) && rect.bottom < rect2.bottom) {
            c2 = 1;
        } else {
            int i11 = rect.bottom;
            int i12 = rect2.bottom;
            if ((i11 <= i12 && i9 < i12) || i9 <= i10) {
                c2 = 0;
            }
        }
        if (i2 == 1) {
            return c2 < 0 || (c2 == 0 && i3 * i4 <= 0);
        } else if (i2 == 2) {
            return c2 > 0 || (c2 == 0 && i3 * i4 >= 0);
        } else if (i2 == 17) {
            return i3 < 0;
        } else if (i2 == 33) {
            return c2 < 0;
        } else if (i2 == 66) {
            return i3 > 0;
        } else if (i2 == 130) {
            return c2 > 0;
        } else {
            throw new IllegalArgumentException("Invalid direction: " + i2 + P());
        }
    }

    private void u1() {
        this.f2127f0.g();
        o oVar = this.f2142n;
        if (oVar != null) {
            oVar.K1();
        }
    }

    private void v(Context context, String str, AttributeSet attributeSet, int i2, int i3) {
        Constructor constructor;
        if (str != null) {
            String trim = str.trim();
            if (trim.isEmpty()) {
                return;
            }
            String i02 = i0(context, trim);
            try {
                Class<? extends U> asSubclass = Class.forName(i02, false, isInEditMode() ? getClass().getClassLoader() : context.getClassLoader()).asSubclass(o.class);
                Object[] objArr = null;
                try {
                    constructor = asSubclass.getConstructor(G0);
                    objArr = new Object[]{context, attributeSet, Integer.valueOf(i2), Integer.valueOf(i3)};
                } catch (NoSuchMethodException e2) {
                    try {
                        constructor = asSubclass.getConstructor(new Class[0]);
                    } catch (NoSuchMethodException e3) {
                        e3.initCause(e2);
                        throw new IllegalStateException(attributeSet.getPositionDescription() + ": Error creating LayoutManager " + i02, e3);
                    }
                }
                constructor.setAccessible(true);
                setLayoutManager((o) constructor.newInstance(objArr));
            } catch (ClassCastException e4) {
                throw new IllegalStateException(attributeSet.getPositionDescription() + ": Class is not a LayoutManager " + i02, e4);
            } catch (ClassNotFoundException e5) {
                throw new IllegalStateException(attributeSet.getPositionDescription() + ": Unable to find LayoutManager " + i02, e5);
            } catch (IllegalAccessException e6) {
                throw new IllegalStateException(attributeSet.getPositionDescription() + ": Cannot access non-public constructor " + i02, e6);
            } catch (InstantiationException e7) {
                throw new IllegalStateException(attributeSet.getPositionDescription() + ": Could not instantiate the LayoutManager: " + i02, e7);
            } catch (InvocationTargetException e8) {
                throw new IllegalStateException(attributeSet.getPositionDescription() + ": Could not instantiate the LayoutManager: " + i02, e8);
            }
        }
    }

    private boolean x(int i2, int i3) {
        U(this.f2151r0);
        int[] iArr = this.f2151r0;
        return (iArr[0] == i2 && iArr[1] == i3) ? false : true;
    }

    void A0(int i2, int i3) {
        int j2 = this.f2126f.j();
        for (int i4 = 0; i4 < j2; i4++) {
            d0 f02 = f0(this.f2126f.i(i4));
            if (f02 != null && !f02.J() && f02.f2197c >= i2) {
                f02.A(i3, false);
                this.f2133i0.f2174g = true;
            }
        }
        this.f2120c.u(i2, i3);
        requestLayout();
    }

    void B() {
        String str;
        if (this.f2140m == null) {
            str = "No adapter attached; skipping layout";
        } else if (this.f2142n != null) {
            a0 a0Var = this.f2133i0;
            a0Var.f2177j = false;
            if (a0Var.f2172e == 1) {
                C();
            } else if (!this.f2124e.q() && this.f2142n.o0() == getWidth() && this.f2142n.W() == getHeight()) {
                this.f2142n.z1(this);
                E();
                return;
            }
            this.f2142n.z1(this);
            D();
            E();
            return;
        } else {
            str = "No layout manager attached; skipping layout";
        }
        Log.e("RecyclerView", str);
    }

    void B0(int i2, int i3) {
        int i4;
        int i5;
        int i6;
        int i7;
        int j2 = this.f2126f.j();
        if (i2 < i3) {
            i6 = -1;
            i5 = i2;
            i4 = i3;
        } else {
            i4 = i2;
            i5 = i3;
            i6 = 1;
        }
        for (int i8 = 0; i8 < j2; i8++) {
            d0 f02 = f0(this.f2126f.i(i8));
            if (f02 != null && (i7 = f02.f2197c) >= i5 && i7 <= i4) {
                if (i7 == i2) {
                    f02.A(i3 - i2, false);
                } else {
                    f02.A(i6, false);
                }
                this.f2133i0.f2174g = true;
            }
        }
        this.f2120c.v(i2, i3);
        requestLayout();
    }

    void C0(int i2, int i3, boolean z2) {
        int i4 = i2 + i3;
        int j2 = this.f2126f.j();
        for (int i5 = 0; i5 < j2; i5++) {
            d0 f02 = f0(this.f2126f.i(i5));
            if (f02 != null && !f02.J()) {
                int i6 = f02.f2197c;
                if (i6 >= i4) {
                    f02.A(-i3, z2);
                } else if (i6 >= i2) {
                    f02.i(i2 - 1, -i3, z2);
                }
                this.f2133i0.f2174g = true;
            }
        }
        this.f2120c.w(i2, i3, z2);
        requestLayout();
    }

    public void D0(View view) {
    }

    public void E0(View view) {
    }

    public boolean F(int i2, int i3, int[] iArr, int[] iArr2, int i4) {
        return getScrollingChildHelper().d(i2, i3, iArr, iArr2, i4);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void F0() {
        this.G++;
    }

    public final void G(int i2, int i3, int i4, int i5, int[] iArr, int i6, int[] iArr2) {
        getScrollingChildHelper().e(i2, i3, i4, i5, iArr, i6, iArr2);
    }

    void G0() {
        H0(true);
    }

    void H(int i2) {
        o oVar = this.f2142n;
        if (oVar != null) {
            oVar.e1(i2);
        }
        J0(i2);
        t tVar = this.f2135j0;
        if (tVar != null) {
            tVar.a(this, i2);
        }
        List<t> list = this.f2137k0;
        if (list != null) {
            for (int size = list.size() - 1; size >= 0; size--) {
                this.f2137k0.get(size).a(this, i2);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void H0(boolean z2) {
        int i2 = this.G - 1;
        this.G = i2;
        if (i2 < 1) {
            this.G = 0;
            if (z2) {
                A();
                J();
            }
        }
    }

    void I(int i2, int i3) {
        this.H++;
        int scrollX = getScrollX();
        int scrollY = getScrollY();
        onScrollChanged(scrollX, scrollY, scrollX - i2, scrollY - i3);
        K0(i2, i3);
        t tVar = this.f2135j0;
        if (tVar != null) {
            tVar.b(this, i2, i3);
        }
        List<t> list = this.f2137k0;
        if (list != null) {
            for (int size = list.size() - 1; size >= 0; size--) {
                this.f2137k0.get(size).b(this, i2, i3);
            }
        }
        this.H--;
    }

    void J() {
        int i2;
        for (int size = this.f2161w0.size() - 1; size >= 0; size--) {
            d0 d0Var = this.f2161w0.get(size);
            if (d0Var.f2195a.getParent() == this && !d0Var.J() && (i2 = d0Var.f2211q) != -1) {
                e0.q.u0(d0Var.f2195a, i2);
                d0Var.f2211q = -1;
            }
        }
        this.f2161w0.clear();
    }

    public void J0(int i2) {
    }

    public void K0(int i2, int i3) {
    }

    void L() {
        int measuredWidth;
        int measuredHeight;
        if (this.M != null) {
            return;
        }
        EdgeEffect a2 = this.I.a(this, 3);
        this.M = a2;
        if (this.f2130h) {
            measuredWidth = (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight();
            measuredHeight = (getMeasuredHeight() - getPaddingTop()) - getPaddingBottom();
        } else {
            measuredWidth = getMeasuredWidth();
            measuredHeight = getMeasuredHeight();
        }
        a2.setSize(measuredWidth, measuredHeight);
    }

    void L0() {
        if (this.f2145o0 || !this.f2152s) {
            return;
        }
        e0.q.c0(this, this.f2163x0);
        this.f2145o0 = true;
    }

    void M() {
        int measuredHeight;
        int measuredWidth;
        if (this.J != null) {
            return;
        }
        EdgeEffect a2 = this.I.a(this, 0);
        this.J = a2;
        if (this.f2130h) {
            measuredHeight = (getMeasuredHeight() - getPaddingTop()) - getPaddingBottom();
            measuredWidth = (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight();
        } else {
            measuredHeight = getMeasuredHeight();
            measuredWidth = getMeasuredWidth();
        }
        a2.setSize(measuredHeight, measuredWidth);
    }

    void N() {
        int measuredHeight;
        int measuredWidth;
        if (this.L != null) {
            return;
        }
        EdgeEffect a2 = this.I.a(this, 2);
        this.L = a2;
        if (this.f2130h) {
            measuredHeight = (getMeasuredHeight() - getPaddingTop()) - getPaddingBottom();
            measuredWidth = (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight();
        } else {
            measuredHeight = getMeasuredHeight();
            measuredWidth = getMeasuredWidth();
        }
        a2.setSize(measuredHeight, measuredWidth);
    }

    void O() {
        int measuredWidth;
        int measuredHeight;
        if (this.K != null) {
            return;
        }
        EdgeEffect a2 = this.I.a(this, 1);
        this.K = a2;
        if (this.f2130h) {
            measuredWidth = (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight();
            measuredHeight = (getMeasuredHeight() - getPaddingTop()) - getPaddingBottom();
        } else {
            measuredWidth = getMeasuredWidth();
            measuredHeight = getMeasuredHeight();
        }
        a2.setSize(measuredWidth, measuredHeight);
    }

    void O0(boolean z2) {
        this.F = z2 | this.F;
        this.E = true;
        x0();
    }

    String P() {
        return " " + super.toString() + ", adapter:" + this.f2140m + ", layout:" + this.f2142n + ", context:" + getContext();
    }

    final void Q(a0 a0Var) {
        if (getScrollState() != 2) {
            a0Var.f2183p = 0;
            a0Var.f2184q = 0;
            return;
        }
        OverScroller overScroller = this.f2127f0.f2188d;
        a0Var.f2183p = overScroller.getFinalX() - overScroller.getCurrX();
        a0Var.f2184q = overScroller.getFinalY() - overScroller.getCurrY();
    }

    void Q0(d0 d0Var, l.c cVar) {
        d0Var.F(0, 8192);
        if (this.f2133i0.f2176i && d0Var.y() && !d0Var.v() && !d0Var.J()) {
            this.f2128g.c(c0(d0Var), d0Var);
        }
        this.f2128g.e(d0Var, cVar);
    }

    /* JADX WARN: Code restructure failed: missing block: B:15:?, code lost:
        return r3;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public android.view.View R(android.view.View r3) {
        /*
            r2 = this;
        L0:
            android.view.ViewParent r0 = r3.getParent()
            if (r0 == 0) goto L10
            if (r0 == r2) goto L10
            boolean r1 = r0 instanceof android.view.View
            if (r1 == 0) goto L10
            r3 = r0
            android.view.View r3 = (android.view.View) r3
            goto L0
        L10:
            if (r0 != r2) goto L13
            goto L14
        L13:
            r3 = 0
        L14:
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.RecyclerView.R(android.view.View):android.view.View");
    }

    public d0 S(View view) {
        View R = R(view);
        if (R == null) {
            return null;
        }
        return e0(R);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void T0() {
        l lVar = this.N;
        if (lVar != null) {
            lVar.k();
        }
        o oVar = this.f2142n;
        if (oVar != null) {
            oVar.k1(this.f2120c);
            this.f2142n.l1(this.f2120c);
        }
        this.f2120c.c();
    }

    boolean U0(View view) {
        p1();
        boolean r2 = this.f2126f.r(view);
        if (r2) {
            d0 f02 = f0(view);
            this.f2120c.J(f02);
            this.f2120c.C(f02);
        }
        r1(!r2);
        return r2;
    }

    public void V0(n nVar) {
        o oVar = this.f2142n;
        if (oVar != null) {
            oVar.g("Cannot remove item decoration during a scroll  or layout");
        }
        this.f2146p.remove(nVar);
        if (this.f2146p.isEmpty()) {
            setWillNotDraw(getOverScrollMode() == 2);
        }
        w0();
        requestLayout();
    }

    public void W0(s sVar) {
        this.f2148q.remove(sVar);
        if (this.f2150r == sVar) {
            this.f2150r = null;
        }
    }

    public d0 X(int i2) {
        d0 d0Var = null;
        if (this.E) {
            return null;
        }
        int j2 = this.f2126f.j();
        for (int i3 = 0; i3 < j2; i3++) {
            d0 f02 = f0(this.f2126f.i(i3));
            if (f02 != null && !f02.v() && b0(f02) == i2) {
                if (!this.f2126f.n(f02.f2195a)) {
                    return f02;
                }
                d0Var = f02;
            }
        }
        return d0Var;
    }

    public void X0(t tVar) {
        List<t> list = this.f2137k0;
        if (list != null) {
            list.remove(tVar);
        }
    }

    public d0 Y(long j2) {
        g gVar = this.f2140m;
        d0 d0Var = null;
        if (gVar != null && gVar.g()) {
            int j3 = this.f2126f.j();
            for (int i2 = 0; i2 < j3; i2++) {
                d0 f02 = f0(this.f2126f.i(i2));
                if (f02 != null && !f02.v() && f02.k() == j2) {
                    if (!this.f2126f.n(f02.f2195a)) {
                        return f02;
                    }
                    d0Var = f02;
                }
            }
        }
        return d0Var;
    }

    void Y0() {
        d0 d0Var;
        int g2 = this.f2126f.g();
        for (int i2 = 0; i2 < g2; i2++) {
            View f2 = this.f2126f.f(i2);
            d0 e02 = e0(f2);
            if (e02 != null && (d0Var = e02.f2203i) != null) {
                View view = d0Var.f2195a;
                int left = f2.getLeft();
                int top = f2.getTop();
                if (left != view.getLeft() || top != view.getTop()) {
                    view.layout(left, top, view.getWidth() + left, view.getHeight() + top);
                }
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:17:0x0034  */
    /* JADX WARN: Removed duplicated region for block: B:22:0x0036 A[SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    androidx.recyclerview.widget.RecyclerView.d0 Z(int r6, boolean r7) {
        /*
            r5 = this;
            androidx.recyclerview.widget.b r0 = r5.f2126f
            int r0 = r0.j()
            r1 = 0
            r2 = 0
        L8:
            if (r2 >= r0) goto L3a
            androidx.recyclerview.widget.b r3 = r5.f2126f
            android.view.View r3 = r3.i(r2)
            androidx.recyclerview.widget.RecyclerView$d0 r3 = f0(r3)
            if (r3 == 0) goto L37
            boolean r4 = r3.v()
            if (r4 != 0) goto L37
            if (r7 == 0) goto L23
            int r4 = r3.f2197c
            if (r4 == r6) goto L2a
            goto L37
        L23:
            int r4 = r3.m()
            if (r4 == r6) goto L2a
            goto L37
        L2a:
            androidx.recyclerview.widget.b r1 = r5.f2126f
            android.view.View r4 = r3.f2195a
            boolean r1 = r1.n(r4)
            if (r1 == 0) goto L36
            r1 = r3
            goto L37
        L36:
            return r3
        L37:
            int r2 = r2 + 1
            goto L8
        L3a:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.RecyclerView.Z(int, boolean):androidx.recyclerview.widget.RecyclerView$d0");
    }

    void a(int i2, int i3) {
        if (i2 < 0) {
            M();
            if (this.J.isFinished()) {
                this.J.onAbsorb(-i2);
            }
        } else if (i2 > 0) {
            N();
            if (this.L.isFinished()) {
                this.L.onAbsorb(i2);
            }
        }
        if (i3 < 0) {
            O();
            if (this.K.isFinished()) {
                this.K.onAbsorb(-i3);
            }
        } else if (i3 > 0) {
            L();
            if (this.M.isFinished()) {
                this.M.onAbsorb(i3);
            }
        }
        if (i2 == 0 && i3 == 0) {
            return;
        }
        e0.q.b0(this);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v1, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v6 */
    public boolean a0(int i2, int i3) {
        o oVar = this.f2142n;
        if (oVar == null) {
            Log.e("RecyclerView", "Cannot fling without a LayoutManager set. Call setLayoutManager with a non-null argument.");
            return false;
        } else if (this.f2164y) {
            return false;
        } else {
            int k2 = oVar.k();
            boolean l2 = this.f2142n.l();
            if (k2 == 0 || Math.abs(i2) < this.f2117a0) {
                i2 = 0;
            }
            if (!l2 || Math.abs(i3) < this.f2117a0) {
                i3 = 0;
            }
            if (i2 == 0 && i3 == 0) {
                return false;
            }
            float f2 = i2;
            float f3 = i3;
            if (!dispatchNestedPreFling(f2, f3)) {
                boolean z2 = k2 != 0 || l2;
                dispatchNestedFling(f2, f3, z2);
                r rVar = this.W;
                if (rVar != null && rVar.a(i2, i3)) {
                    return true;
                }
                if (z2) {
                    if (l2) {
                        k2 = (k2 == true ? 1 : 0) | 2;
                    }
                    q1(k2, 1);
                    int i4 = this.f2119b0;
                    int max = Math.max(-i4, Math.min(i2, i4));
                    int i5 = this.f2119b0;
                    this.f2127f0.c(max, Math.max(-i5, Math.min(i3, i5)));
                    return true;
                }
            }
            return false;
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public void addFocusables(ArrayList<View> arrayList, int i2, int i3) {
        o oVar = this.f2142n;
        if (oVar == null || !oVar.F0(this, arrayList, i2, i3)) {
            super.addFocusables(arrayList, i2, i3);
        }
    }

    int b0(d0 d0Var) {
        if (d0Var.p(524) || !d0Var.s()) {
            return -1;
        }
        return this.f2124e.e(d0Var.f2197c);
    }

    long c0(d0 d0Var) {
        return this.f2140m.g() ? d0Var.k() : d0Var.f2197c;
    }

    @Override // android.view.ViewGroup
    protected boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return (layoutParams instanceof p) && this.f2142n.m((p) layoutParams);
    }

    @Override // android.view.View
    public int computeHorizontalScrollExtent() {
        o oVar = this.f2142n;
        if (oVar != null && oVar.k()) {
            return this.f2142n.q(this.f2133i0);
        }
        return 0;
    }

    @Override // android.view.View
    public int computeHorizontalScrollOffset() {
        o oVar = this.f2142n;
        if (oVar != null && oVar.k()) {
            return this.f2142n.r(this.f2133i0);
        }
        return 0;
    }

    @Override // android.view.View
    public int computeHorizontalScrollRange() {
        o oVar = this.f2142n;
        if (oVar != null && oVar.k()) {
            return this.f2142n.s(this.f2133i0);
        }
        return 0;
    }

    @Override // android.view.View
    public int computeVerticalScrollExtent() {
        o oVar = this.f2142n;
        if (oVar != null && oVar.l()) {
            return this.f2142n.t(this.f2133i0);
        }
        return 0;
    }

    @Override // android.view.View
    public int computeVerticalScrollOffset() {
        o oVar = this.f2142n;
        if (oVar != null && oVar.l()) {
            return this.f2142n.u(this.f2133i0);
        }
        return 0;
    }

    @Override // android.view.View
    public int computeVerticalScrollRange() {
        o oVar = this.f2142n;
        if (oVar != null && oVar.l()) {
            return this.f2142n.v(this.f2133i0);
        }
        return 0;
    }

    public int d0(View view) {
        d0 f02 = f0(view);
        if (f02 != null) {
            return f02.m();
        }
        return -1;
    }

    void d1() {
        int j2 = this.f2126f.j();
        for (int i2 = 0; i2 < j2; i2++) {
            d0 f02 = f0(this.f2126f.i(i2));
            if (!f02.J()) {
                f02.E();
            }
        }
    }

    @Override // android.view.View
    public boolean dispatchNestedFling(float f2, float f3, boolean z2) {
        return getScrollingChildHelper().a(f2, f3, z2);
    }

    @Override // android.view.View
    public boolean dispatchNestedPreFling(float f2, float f3) {
        return getScrollingChildHelper().b(f2, f3);
    }

    @Override // android.view.View
    public boolean dispatchNestedPreScroll(int i2, int i3, int[] iArr, int[] iArr2) {
        return getScrollingChildHelper().c(i2, i3, iArr, iArr2);
    }

    @Override // android.view.View
    public boolean dispatchNestedScroll(int i2, int i3, int i4, int i5, int[] iArr) {
        return getScrollingChildHelper().f(i2, i3, i4, i5, iArr);
    }

    @Override // android.view.View
    public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        onPopulateAccessibilityEvent(accessibilityEvent);
        return true;
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void dispatchRestoreInstanceState(SparseArray<Parcelable> sparseArray) {
        dispatchThawSelfOnly(sparseArray);
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void dispatchSaveInstanceState(SparseArray<Parcelable> sparseArray) {
        dispatchFreezeSelfOnly(sparseArray);
    }

    @Override // android.view.View
    public void draw(Canvas canvas) {
        boolean z2;
        float f2;
        int i2;
        super.draw(canvas);
        int size = this.f2146p.size();
        boolean z3 = false;
        for (int i3 = 0; i3 < size; i3++) {
            this.f2146p.get(i3).i(canvas, this, this.f2133i0);
        }
        EdgeEffect edgeEffect = this.J;
        if (edgeEffect == null || edgeEffect.isFinished()) {
            z2 = false;
        } else {
            int save = canvas.save();
            int paddingBottom = this.f2130h ? getPaddingBottom() : 0;
            canvas.rotate(270.0f);
            canvas.translate((-getHeight()) + paddingBottom, 0.0f);
            EdgeEffect edgeEffect2 = this.J;
            z2 = edgeEffect2 != null && edgeEffect2.draw(canvas);
            canvas.restoreToCount(save);
        }
        EdgeEffect edgeEffect3 = this.K;
        if (edgeEffect3 != null && !edgeEffect3.isFinished()) {
            int save2 = canvas.save();
            if (this.f2130h) {
                canvas.translate(getPaddingLeft(), getPaddingTop());
            }
            EdgeEffect edgeEffect4 = this.K;
            z2 |= edgeEffect4 != null && edgeEffect4.draw(canvas);
            canvas.restoreToCount(save2);
        }
        EdgeEffect edgeEffect5 = this.L;
        if (edgeEffect5 != null && !edgeEffect5.isFinished()) {
            int save3 = canvas.save();
            int width = getWidth();
            int paddingTop = this.f2130h ? getPaddingTop() : 0;
            canvas.rotate(90.0f);
            canvas.translate(-paddingTop, -width);
            EdgeEffect edgeEffect6 = this.L;
            z2 |= edgeEffect6 != null && edgeEffect6.draw(canvas);
            canvas.restoreToCount(save3);
        }
        EdgeEffect edgeEffect7 = this.M;
        if (edgeEffect7 != null && !edgeEffect7.isFinished()) {
            int save4 = canvas.save();
            canvas.rotate(180.0f);
            if (this.f2130h) {
                f2 = (-getWidth()) + getPaddingRight();
                i2 = (-getHeight()) + getPaddingBottom();
            } else {
                f2 = -getWidth();
                i2 = -getHeight();
            }
            canvas.translate(f2, i2);
            EdgeEffect edgeEffect8 = this.M;
            if (edgeEffect8 != null && edgeEffect8.draw(canvas)) {
                z3 = true;
            }
            z2 |= z3;
            canvas.restoreToCount(save4);
        }
        if ((z2 || this.N == null || this.f2146p.size() <= 0 || !this.N.p()) ? z2 : true) {
            e0.q.b0(this);
        }
    }

    @Override // android.view.ViewGroup
    public boolean drawChild(Canvas canvas, View view, long j2) {
        return super.drawChild(canvas, view, j2);
    }

    public d0 e0(View view) {
        ViewParent parent = view.getParent();
        if (parent == null || parent == this) {
            return f0(view);
        }
        throw new IllegalArgumentException("View " + view + " is not a direct child of " + this);
    }

    boolean e1(int i2, int i3, MotionEvent motionEvent) {
        int i4;
        int i5;
        int i6;
        int i7;
        u();
        if (this.f2140m != null) {
            int[] iArr = this.f2159v0;
            iArr[0] = 0;
            iArr[1] = 0;
            f1(i2, i3, iArr);
            int[] iArr2 = this.f2159v0;
            int i8 = iArr2[0];
            int i9 = iArr2[1];
            i4 = i9;
            i5 = i8;
            i6 = i2 - i8;
            i7 = i3 - i9;
        } else {
            i4 = 0;
            i5 = 0;
            i6 = 0;
            i7 = 0;
        }
        if (!this.f2146p.isEmpty()) {
            invalidate();
        }
        int[] iArr3 = this.f2159v0;
        iArr3[0] = 0;
        iArr3[1] = 0;
        G(i5, i4, i6, i7, this.f2155t0, 0, iArr3);
        int[] iArr4 = this.f2159v0;
        int i10 = i6 - iArr4[0];
        int i11 = i7 - iArr4[1];
        boolean z2 = (iArr4[0] == 0 && iArr4[1] == 0) ? false : true;
        int i12 = this.T;
        int[] iArr5 = this.f2155t0;
        this.T = i12 - iArr5[0];
        this.U -= iArr5[1];
        int[] iArr6 = this.f2157u0;
        iArr6[0] = iArr6[0] + iArr5[0];
        iArr6[1] = iArr6[1] + iArr5[1];
        if (getOverScrollMode() != 2) {
            if (motionEvent != null && !e0.i.a(motionEvent, 8194)) {
                P0(motionEvent.getX(), i10, motionEvent.getY(), i11);
            }
            t(i2, i3);
        }
        if (i5 != 0 || i4 != 0) {
            I(i5, i4);
        }
        if (!awakenScrollBars()) {
            invalidate();
        }
        return (!z2 && i5 == 0 && i4 == 0) ? false : true;
    }

    void f1(int i2, int i3, int[] iArr) {
        p1();
        F0();
        a0.b.a("RV Scroll");
        Q(this.f2133i0);
        int w12 = i2 != 0 ? this.f2142n.w1(i2, this.f2120c, this.f2133i0) : 0;
        int y12 = i3 != 0 ? this.f2142n.y1(i3, this.f2120c, this.f2133i0) : 0;
        a0.b.b();
        Y0();
        G0();
        r1(false);
        if (iArr != null) {
            iArr[0] = w12;
            iArr[1] = y12;
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public View focusSearch(View view, int i2) {
        View view2;
        boolean z2;
        View Q0 = this.f2142n.Q0(view, i2);
        if (Q0 != null) {
            return Q0;
        }
        boolean z3 = (this.f2140m == null || this.f2142n == null || t0() || this.f2164y) ? false : true;
        FocusFinder focusFinder = FocusFinder.getInstance();
        if (z3 && (i2 == 2 || i2 == 1)) {
            if (this.f2142n.l()) {
                int i3 = i2 == 2 ? 130 : 33;
                z2 = focusFinder.findNextFocus(this, view, i3) == null;
                if (E0) {
                    i2 = i3;
                }
            } else {
                z2 = false;
            }
            if (!z2 && this.f2142n.k()) {
                int i4 = (this.f2142n.Z() == 1) ^ (i2 == 2) ? 66 : 17;
                boolean z4 = focusFinder.findNextFocus(this, view, i4) == null;
                if (E0) {
                    i2 = i4;
                }
                z2 = z4;
            }
            if (z2) {
                u();
                if (R(view) == null) {
                    return null;
                }
                p1();
                this.f2142n.J0(view, i2, this.f2120c, this.f2133i0);
                r1(false);
            }
            view2 = focusFinder.findNextFocus(this, view, i2);
        } else {
            View findNextFocus = focusFinder.findNextFocus(this, view, i2);
            if (findNextFocus == null && z3) {
                u();
                if (R(view) == null) {
                    return null;
                }
                p1();
                view2 = this.f2142n.J0(view, i2, this.f2120c, this.f2133i0);
                r1(false);
            } else {
                view2 = findNextFocus;
            }
        }
        if (view2 == null || view2.hasFocusable()) {
            return u0(view, view2, i2) ? view2 : super.focusSearch(view, i2);
        } else if (getFocusedChild() == null) {
            return super.focusSearch(view, i2);
        } else {
            Z0(view2, null);
            return view;
        }
    }

    public void g1(int i2) {
        if (this.f2164y) {
            return;
        }
        t1();
        o oVar = this.f2142n;
        if (oVar == null) {
            Log.e("RecyclerView", "Cannot scroll to position a LayoutManager set. Call setLayoutManager with a non-null argument.");
            return;
        }
        oVar.x1(i2);
        awakenScrollBars();
    }

    @Override // android.view.ViewGroup
    protected ViewGroup.LayoutParams generateDefaultLayoutParams() {
        o oVar = this.f2142n;
        if (oVar != null) {
            return oVar.D();
        }
        throw new IllegalStateException("RecyclerView has no LayoutManager" + P());
    }

    @Override // android.view.ViewGroup
    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        o oVar = this.f2142n;
        if (oVar != null) {
            return oVar.E(getContext(), attributeSet);
        }
        throw new IllegalStateException("RecyclerView has no LayoutManager" + P());
    }

    @Override // android.view.ViewGroup
    protected ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        o oVar = this.f2142n;
        if (oVar != null) {
            return oVar.F(layoutParams);
        }
        throw new IllegalStateException("RecyclerView has no LayoutManager" + P());
    }

    @Override // android.view.ViewGroup, android.view.View
    public CharSequence getAccessibilityClassName() {
        return "androidx.recyclerview.widget.RecyclerView";
    }

    public g getAdapter() {
        return this.f2140m;
    }

    @Override // android.view.View
    public int getBaseline() {
        o oVar = this.f2142n;
        return oVar != null ? oVar.G() : super.getBaseline();
    }

    @Override // android.view.ViewGroup
    protected int getChildDrawingOrder(int i2, int i3) {
        j jVar = this.f2149q0;
        return jVar == null ? super.getChildDrawingOrder(i2, i3) : jVar.a(i2, i3);
    }

    @Override // android.view.ViewGroup
    public boolean getClipToPadding() {
        return this.f2130h;
    }

    public androidx.recyclerview.widget.k getCompatAccessibilityDelegate() {
        return this.f2147p0;
    }

    public k getEdgeEffectFactory() {
        return this.I;
    }

    public l getItemAnimator() {
        return this.N;
    }

    public int getItemDecorationCount() {
        return this.f2146p.size();
    }

    public o getLayoutManager() {
        return this.f2142n;
    }

    public int getMaxFlingVelocity() {
        return this.f2119b0;
    }

    public int getMinFlingVelocity() {
        return this.f2117a0;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public long getNanoTime() {
        if (D0) {
            return System.nanoTime();
        }
        return 0L;
    }

    public r getOnFlingListener() {
        return this.W;
    }

    public boolean getPreserveFocusAfterLayout() {
        return this.f2125e0;
    }

    public u getRecycledViewPool() {
        return this.f2120c.i();
    }

    public int getScrollState() {
        return this.O;
    }

    public void h(n nVar) {
        i(nVar, -1);
    }

    @Override // android.view.View
    public boolean hasNestedScrollingParent() {
        return getScrollingChildHelper().j();
    }

    public void i(n nVar, int i2) {
        o oVar = this.f2142n;
        if (oVar != null) {
            oVar.g("Cannot add item decoration during a scroll  or layout");
        }
        if (this.f2146p.isEmpty()) {
            setWillNotDraw(false);
        }
        if (i2 < 0) {
            this.f2146p.add(nVar);
        } else {
            this.f2146p.add(i2, nVar);
        }
        w0();
        requestLayout();
    }

    boolean i1(d0 d0Var, int i2) {
        if (!t0()) {
            e0.q.u0(d0Var.f2195a, i2);
            return true;
        }
        d0Var.f2211q = i2;
        this.f2161w0.add(d0Var);
        return false;
    }

    @Override // android.view.View
    public boolean isAttachedToWindow() {
        return this.f2152s;
    }

    @Override // android.view.ViewGroup
    public final boolean isLayoutSuppressed() {
        return this.f2164y;
    }

    @Override // android.view.View
    public boolean isNestedScrollingEnabled() {
        return getScrollingChildHelper().l();
    }

    public void j(s sVar) {
        this.f2148q.add(sVar);
    }

    Rect j0(View view) {
        p pVar = (p) view.getLayoutParams();
        if (pVar.f2254c) {
            if (this.f2133i0.e() && (pVar.b() || pVar.d())) {
                return pVar.f2253b;
            }
            Rect rect = pVar.f2253b;
            rect.set(0, 0, 0, 0);
            int size = this.f2146p.size();
            for (int i2 = 0; i2 < size; i2++) {
                this.f2134j.set(0, 0, 0, 0);
                this.f2146p.get(i2).e(this.f2134j, view, this, this.f2133i0);
                int i3 = rect.left;
                Rect rect2 = this.f2134j;
                rect.left = i3 + rect2.left;
                rect.top += rect2.top;
                rect.right += rect2.right;
                rect.bottom += rect2.bottom;
            }
            pVar.f2254c = false;
            return rect;
        }
        return pVar.f2253b;
    }

    boolean j1(AccessibilityEvent accessibilityEvent) {
        if (t0()) {
            int a2 = accessibilityEvent != null ? f0.b.a(accessibilityEvent) : 0;
            this.A |= a2 != 0 ? a2 : 0;
            return true;
        }
        return false;
    }

    public void k(t tVar) {
        if (this.f2137k0 == null) {
            this.f2137k0 = new ArrayList();
        }
        this.f2137k0.add(tVar);
    }

    public void k1(int i2, int i3) {
        l1(i2, i3, null);
    }

    void l(d0 d0Var, l.c cVar, l.c cVar2) {
        d0Var.G(false);
        if (this.N.a(d0Var, cVar, cVar2)) {
            L0();
        }
    }

    public boolean l0() {
        return !this.f2158v || this.E || this.f2124e.p();
    }

    public void l1(int i2, int i3, Interpolator interpolator) {
        m1(i2, i3, interpolator, Integer.MIN_VALUE);
    }

    public void m1(int i2, int i3, Interpolator interpolator, int i4) {
        n1(i2, i3, interpolator, i4, false);
    }

    void n(d0 d0Var, l.c cVar, l.c cVar2) {
        g(d0Var);
        d0Var.G(false);
        if (this.N.c(d0Var, cVar, cVar2)) {
            L0();
        }
    }

    void n0() {
        this.f2124e = new androidx.recyclerview.widget.a(new f());
    }

    void n1(int i2, int i3, Interpolator interpolator, int i4, boolean z2) {
        o oVar = this.f2142n;
        if (oVar == null) {
            Log.e("RecyclerView", "Cannot smooth scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
        } else if (this.f2164y) {
        } else {
            if (!oVar.k()) {
                i2 = 0;
            }
            if (!this.f2142n.l()) {
                i3 = 0;
            }
            if (i2 == 0 && i3 == 0) {
                return;
            }
            if (!(i4 == Integer.MIN_VALUE || i4 > 0)) {
                scrollBy(i2, i3);
                return;
            }
            if (z2) {
                int i5 = i2 != 0 ? 1 : 0;
                if (i3 != 0) {
                    i5 |= 2;
                }
                q1(i5, 1);
            }
            this.f2127f0.f(i2, i3, i4, interpolator);
        }
    }

    void o(String str) {
        if (t0()) {
            if (str != null) {
                throw new IllegalStateException(str);
            }
            throw new IllegalStateException("Cannot call this method while RecyclerView is computing a layout or scrolling" + P());
        } else if (this.H > 0) {
            Log.w("RecyclerView", "Cannot call this method in a scroll callback. Scroll callbacks mightbe run during a measure & layout pass where you cannot change theRecyclerView data. Any method call that might change the structureof the RecyclerView or the adapter contents should be postponed tothe next frame.", new IllegalStateException("" + P()));
        }
    }

    public void o1(int i2) {
        if (this.f2164y) {
            return;
        }
        o oVar = this.f2142n;
        if (oVar == null) {
            Log.e("RecyclerView", "Cannot smooth scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
        } else {
            oVar.I1(this, this.f2133i0, i2);
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.G = 0;
        this.f2152s = true;
        this.f2158v = this.f2158v && !isLayoutRequested();
        o oVar = this.f2142n;
        if (oVar != null) {
            oVar.z(this);
        }
        this.f2145o0 = false;
        if (D0) {
            ThreadLocal<androidx.recyclerview.widget.e> threadLocal = androidx.recyclerview.widget.e.f2426f;
            androidx.recyclerview.widget.e eVar = threadLocal.get();
            this.f2129g0 = eVar;
            if (eVar == null) {
                this.f2129g0 = new androidx.recyclerview.widget.e();
                Display v2 = e0.q.v(this);
                float f2 = 60.0f;
                if (!isInEditMode() && v2 != null) {
                    float refreshRate = v2.getRefreshRate();
                    if (refreshRate >= 30.0f) {
                        f2 = refreshRate;
                    }
                }
                androidx.recyclerview.widget.e eVar2 = this.f2129g0;
                eVar2.f2430d = 1.0E9f / f2;
                threadLocal.set(eVar2);
            }
            this.f2129g0.a(this);
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onDetachedFromWindow() {
        androidx.recyclerview.widget.e eVar;
        super.onDetachedFromWindow();
        l lVar = this.N;
        if (lVar != null) {
            lVar.k();
        }
        t1();
        this.f2152s = false;
        o oVar = this.f2142n;
        if (oVar != null) {
            oVar.A(this, this.f2120c);
        }
        this.f2161w0.clear();
        removeCallbacks(this.f2163x0);
        this.f2128g.j();
        if (!D0 || (eVar = this.f2129g0) == null) {
            return;
        }
        eVar.j(this);
        this.f2129g0 = null;
    }

    @Override // android.view.View
    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int size = this.f2146p.size();
        for (int i2 = 0; i2 < size; i2++) {
            this.f2146p.get(i2).g(canvas, this, this.f2133i0);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:31:0x0066  */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public boolean onGenericMotionEvent(android.view.MotionEvent r6) {
        /*
            r5 = this;
            androidx.recyclerview.widget.RecyclerView$o r0 = r5.f2142n
            r1 = 0
            if (r0 != 0) goto L6
            return r1
        L6:
            boolean r0 = r5.f2164y
            if (r0 == 0) goto Lb
            return r1
        Lb:
            int r0 = r6.getAction()
            r2 = 8
            if (r0 != r2) goto L77
            int r0 = r6.getSource()
            r0 = r0 & 2
            r2 = 0
            if (r0 == 0) goto L3c
            androidx.recyclerview.widget.RecyclerView$o r0 = r5.f2142n
            boolean r0 = r0.l()
            if (r0 == 0) goto L2c
            r0 = 9
            float r0 = r6.getAxisValue(r0)
            float r0 = -r0
            goto L2d
        L2c:
            r0 = 0
        L2d:
            androidx.recyclerview.widget.RecyclerView$o r3 = r5.f2142n
            boolean r3 = r3.k()
            if (r3 == 0) goto L61
            r3 = 10
            float r3 = r6.getAxisValue(r3)
            goto L62
        L3c:
            int r0 = r6.getSource()
            r3 = 4194304(0x400000, float:5.877472E-39)
            r0 = r0 & r3
            if (r0 == 0) goto L60
            r0 = 26
            float r0 = r6.getAxisValue(r0)
            androidx.recyclerview.widget.RecyclerView$o r3 = r5.f2142n
            boolean r3 = r3.l()
            if (r3 == 0) goto L55
            float r0 = -r0
            goto L61
        L55:
            androidx.recyclerview.widget.RecyclerView$o r3 = r5.f2142n
            boolean r3 = r3.k()
            if (r3 == 0) goto L60
            r3 = r0
            r0 = 0
            goto L62
        L60:
            r0 = 0
        L61:
            r3 = 0
        L62:
            int r4 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1))
            if (r4 != 0) goto L6a
            int r2 = (r3 > r2 ? 1 : (r3 == r2 ? 0 : -1))
            if (r2 == 0) goto L77
        L6a:
            float r2 = r5.f2121c0
            float r3 = r3 * r2
            int r2 = (int) r3
            float r3 = r5.f2123d0
            float r0 = r0 * r3
            int r0 = (int) r0
            r5.e1(r2, r0, r6)
        L77:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.RecyclerView.onGenericMotionEvent(android.view.MotionEvent):boolean");
    }

    @Override // android.view.ViewGroup
    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        boolean z2;
        if (this.f2164y) {
            return false;
        }
        this.f2150r = null;
        if (T(motionEvent)) {
            q();
            return true;
        }
        o oVar = this.f2142n;
        if (oVar == null) {
            return false;
        }
        boolean k2 = oVar.k();
        boolean l2 = this.f2142n.l();
        if (this.Q == null) {
            this.Q = VelocityTracker.obtain();
        }
        this.Q.addMovement(motionEvent);
        int actionMasked = motionEvent.getActionMasked();
        int actionIndex = motionEvent.getActionIndex();
        if (actionMasked == 0) {
            if (this.f2166z) {
                this.f2166z = false;
            }
            this.P = motionEvent.getPointerId(0);
            int x2 = (int) (motionEvent.getX() + 0.5f);
            this.T = x2;
            this.R = x2;
            int y2 = (int) (motionEvent.getY() + 0.5f);
            this.U = y2;
            this.S = y2;
            if (this.O == 2) {
                getParent().requestDisallowInterceptTouchEvent(true);
                setScrollState(1);
                s1(1);
            }
            int[] iArr = this.f2157u0;
            iArr[1] = 0;
            iArr[0] = 0;
            int i2 = k2;
            if (l2) {
                i2 = (k2 ? 1 : 0) | 2;
            }
            q1(i2, 0);
        } else if (actionMasked == 1) {
            this.Q.clear();
            s1(0);
        } else if (actionMasked == 2) {
            int findPointerIndex = motionEvent.findPointerIndex(this.P);
            if (findPointerIndex < 0) {
                Log.e("RecyclerView", "Error processing scroll; pointer index for id " + this.P + " not found. Did any MotionEvents get skipped?");
                return false;
            }
            int x3 = (int) (motionEvent.getX(findPointerIndex) + 0.5f);
            int y3 = (int) (motionEvent.getY(findPointerIndex) + 0.5f);
            if (this.O != 1) {
                int i3 = x3 - this.R;
                int i4 = y3 - this.S;
                if (!k2 || Math.abs(i3) <= this.V) {
                    z2 = false;
                } else {
                    this.T = x3;
                    z2 = true;
                }
                if (l2 && Math.abs(i4) > this.V) {
                    this.U = y3;
                    z2 = true;
                }
                if (z2) {
                    setScrollState(1);
                }
            }
        } else if (actionMasked == 3) {
            q();
        } else if (actionMasked == 5) {
            this.P = motionEvent.getPointerId(actionIndex);
            int x4 = (int) (motionEvent.getX(actionIndex) + 0.5f);
            this.T = x4;
            this.R = x4;
            int y4 = (int) (motionEvent.getY(actionIndex) + 0.5f);
            this.U = y4;
            this.S = y4;
        } else if (actionMasked == 6) {
            I0(motionEvent);
        }
        return this.O == 1;
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        a0.b.a("RV OnLayout");
        B();
        a0.b.b();
        this.f2158v = true;
    }

    @Override // android.view.View
    protected void onMeasure(int i2, int i3) {
        o oVar = this.f2142n;
        if (oVar == null) {
            w(i2, i3);
            return;
        }
        boolean z2 = false;
        if (oVar.s0()) {
            int mode = View.MeasureSpec.getMode(i2);
            int mode2 = View.MeasureSpec.getMode(i3);
            this.f2142n.Z0(this.f2120c, this.f2133i0, i2, i3);
            if (mode == 1073741824 && mode2 == 1073741824) {
                z2 = true;
            }
            if (z2 || this.f2140m == null) {
                return;
            }
            if (this.f2133i0.f2172e == 1) {
                C();
            }
            this.f2142n.A1(i2, i3);
            this.f2133i0.f2177j = true;
            D();
            this.f2142n.D1(i2, i3);
            if (this.f2142n.G1()) {
                this.f2142n.A1(View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 1073741824));
                this.f2133i0.f2177j = true;
                D();
                this.f2142n.D1(i2, i3);
            }
        } else if (this.f2154t) {
            this.f2142n.Z0(this.f2120c, this.f2133i0, i2, i3);
        } else {
            if (this.B) {
                p1();
                F0();
                N0();
                G0();
                a0 a0Var = this.f2133i0;
                if (a0Var.f2179l) {
                    a0Var.f2175h = true;
                } else {
                    this.f2124e.j();
                    this.f2133i0.f2175h = false;
                }
                this.B = false;
                r1(false);
            } else if (this.f2133i0.f2179l) {
                setMeasuredDimension(getMeasuredWidth(), getMeasuredHeight());
                return;
            }
            g gVar = this.f2140m;
            if (gVar != null) {
                this.f2133i0.f2173f = gVar.c();
            } else {
                this.f2133i0.f2173f = 0;
            }
            p1();
            this.f2142n.Z0(this.f2120c, this.f2133i0, i2, i3);
            r1(false);
            this.f2133i0.f2175h = false;
        }
    }

    @Override // android.view.ViewGroup
    protected boolean onRequestFocusInDescendants(int i2, Rect rect) {
        if (t0()) {
            return false;
        }
        return super.onRequestFocusInDescendants(i2, rect);
    }

    @Override // android.view.View
    protected void onRestoreInstanceState(Parcelable parcelable) {
        Parcelable parcelable2;
        if (!(parcelable instanceof y)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        y yVar = (y) parcelable;
        this.f2122d = yVar;
        super.onRestoreInstanceState(yVar.j());
        o oVar = this.f2142n;
        if (oVar == null || (parcelable2 = this.f2122d.f2271d) == null) {
            return;
        }
        oVar.c1(parcelable2);
    }

    @Override // android.view.View
    protected Parcelable onSaveInstanceState() {
        y yVar = new y(super.onSaveInstanceState());
        y yVar2 = this.f2122d;
        if (yVar2 != null) {
            yVar.k(yVar2);
        } else {
            o oVar = this.f2142n;
            yVar.f2271d = oVar != null ? oVar.d1() : null;
        }
        return yVar;
    }

    @Override // android.view.View
    protected void onSizeChanged(int i2, int i3, int i4, int i5) {
        super.onSizeChanged(i2, i3, i4, i5);
        if (i2 == i4 && i3 == i5) {
            return;
        }
        r0();
    }

    /* JADX WARN: Removed duplicated region for block: B:50:0x00e0  */
    /* JADX WARN: Removed duplicated region for block: B:57:0x00f4  */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public boolean onTouchEvent(android.view.MotionEvent r18) {
        /*
            Method dump skipped, instructions count: 476
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.RecyclerView.onTouchEvent(android.view.MotionEvent):boolean");
    }

    boolean p(d0 d0Var) {
        l lVar = this.N;
        return lVar == null || lVar.g(d0Var, d0Var.o());
    }

    void p1() {
        int i2 = this.f2160w + 1;
        this.f2160w = i2;
        if (i2 != 1 || this.f2164y) {
            return;
        }
        this.f2162x = false;
    }

    void q0(StateListDrawable stateListDrawable, Drawable drawable, StateListDrawable stateListDrawable2, Drawable drawable2) {
        if (stateListDrawable != null && drawable != null && stateListDrawable2 != null && drawable2 != null) {
            Resources resources = getContext().getResources();
            new androidx.recyclerview.widget.d(this, stateListDrawable, drawable, stateListDrawable2, drawable2, resources.getDimensionPixelSize(q0.b.fastscroll_default_thickness), resources.getDimensionPixelSize(q0.b.fastscroll_minimum_range), resources.getDimensionPixelOffset(q0.b.fastscroll_margin));
            return;
        }
        throw new IllegalArgumentException("Trying to set fast scroller without both required drawables." + P());
    }

    public boolean q1(int i2, int i3) {
        return getScrollingChildHelper().p(i2, i3);
    }

    void r0() {
        this.M = null;
        this.K = null;
        this.L = null;
        this.J = null;
    }

    void r1(boolean z2) {
        if (this.f2160w < 1) {
            this.f2160w = 1;
        }
        if (!z2 && !this.f2164y) {
            this.f2162x = false;
        }
        if (this.f2160w == 1) {
            if (z2 && this.f2162x && !this.f2164y && this.f2142n != null && this.f2140m != null) {
                B();
            }
            if (!this.f2164y) {
                this.f2162x = false;
            }
        }
        this.f2160w--;
    }

    @Override // android.view.ViewGroup
    protected void removeDetachedView(View view, boolean z2) {
        d0 f02 = f0(view);
        if (f02 != null) {
            if (f02.x()) {
                f02.f();
            } else if (!f02.J()) {
                throw new IllegalArgumentException("Called removeDetachedView with a view which is not flagged as tmp detached." + f02 + P());
            }
        }
        view.clearAnimation();
        z(view);
        super.removeDetachedView(view, z2);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void requestChildFocus(View view, View view2) {
        if (!this.f2142n.b1(this, this.f2133i0, view, view2) && view2 != null) {
            Z0(view, view2);
        }
        super.requestChildFocus(view, view2);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z2) {
        return this.f2142n.r1(this, view, rect, z2);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void requestDisallowInterceptTouchEvent(boolean z2) {
        int size = this.f2148q.size();
        for (int i2 = 0; i2 < size; i2++) {
            this.f2148q.get(i2).c(z2);
        }
        super.requestDisallowInterceptTouchEvent(z2);
    }

    @Override // android.view.View, android.view.ViewParent
    public void requestLayout() {
        if (this.f2160w != 0 || this.f2164y) {
            this.f2162x = true;
        } else {
            super.requestLayout();
        }
    }

    void s() {
        int j2 = this.f2126f.j();
        for (int i2 = 0; i2 < j2; i2++) {
            d0 f02 = f0(this.f2126f.i(i2));
            if (!f02.J()) {
                f02.c();
            }
        }
        this.f2120c.d();
    }

    boolean s0() {
        AccessibilityManager accessibilityManager = this.C;
        return accessibilityManager != null && accessibilityManager.isEnabled();
    }

    public void s1(int i2) {
        getScrollingChildHelper().r(i2);
    }

    @Override // android.view.View
    public void scrollBy(int i2, int i3) {
        o oVar = this.f2142n;
        if (oVar == null) {
            Log.e("RecyclerView", "Cannot scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
        } else if (this.f2164y) {
        } else {
            boolean k2 = oVar.k();
            boolean l2 = this.f2142n.l();
            if (k2 || l2) {
                if (!k2) {
                    i2 = 0;
                }
                if (!l2) {
                    i3 = 0;
                }
                e1(i2, i3, null);
            }
        }
    }

    @Override // android.view.View
    public void scrollTo(int i2, int i3) {
        Log.w("RecyclerView", "RecyclerView does not support scrolling to an absolute position. Use scrollToPosition instead");
    }

    @Override // android.view.View, android.view.accessibility.AccessibilityEventSource
    public void sendAccessibilityEventUnchecked(AccessibilityEvent accessibilityEvent) {
        if (j1(accessibilityEvent)) {
            return;
        }
        super.sendAccessibilityEventUnchecked(accessibilityEvent);
    }

    public void setAccessibilityDelegateCompat(androidx.recyclerview.widget.k kVar) {
        this.f2147p0 = kVar;
        e0.q.k0(this, kVar);
    }

    public void setAdapter(g gVar) {
        setLayoutFrozen(false);
        h1(gVar, false, true);
        O0(false);
        requestLayout();
    }

    public void setChildDrawingOrderCallback(j jVar) {
        if (jVar == this.f2149q0) {
            return;
        }
        this.f2149q0 = jVar;
        setChildrenDrawingOrderEnabled(jVar != null);
    }

    @Override // android.view.ViewGroup
    public void setClipToPadding(boolean z2) {
        if (z2 != this.f2130h) {
            r0();
        }
        this.f2130h = z2;
        super.setClipToPadding(z2);
        if (this.f2158v) {
            requestLayout();
        }
    }

    public void setEdgeEffectFactory(k kVar) {
        d0.h.c(kVar);
        this.I = kVar;
        r0();
    }

    public void setHasFixedSize(boolean z2) {
        this.f2154t = z2;
    }

    public void setItemAnimator(l lVar) {
        l lVar2 = this.N;
        if (lVar2 != null) {
            lVar2.k();
            this.N.v(null);
        }
        this.N = lVar;
        if (lVar != null) {
            lVar.v(this.f2143n0);
        }
    }

    public void setItemViewCacheSize(int i2) {
        this.f2120c.G(i2);
    }

    @Deprecated
    public void setLayoutFrozen(boolean z2) {
        suppressLayout(z2);
    }

    public void setLayoutManager(o oVar) {
        if (oVar == this.f2142n) {
            return;
        }
        t1();
        if (this.f2142n != null) {
            l lVar = this.N;
            if (lVar != null) {
                lVar.k();
            }
            this.f2142n.k1(this.f2120c);
            this.f2142n.l1(this.f2120c);
            this.f2120c.c();
            if (this.f2152s) {
                this.f2142n.A(this, this.f2120c);
            }
            this.f2142n.E1(null);
            this.f2142n = null;
        } else {
            this.f2120c.c();
        }
        this.f2126f.o();
        this.f2142n = oVar;
        if (oVar != null) {
            if (oVar.f2229b != null) {
                throw new IllegalArgumentException("LayoutManager " + oVar + " is already attached to a RecyclerView:" + oVar.f2229b.P());
            }
            oVar.E1(this);
            if (this.f2152s) {
                this.f2142n.z(this);
            }
        }
        this.f2120c.K();
        requestLayout();
    }

    @Override // android.view.ViewGroup
    @Deprecated
    public void setLayoutTransition(LayoutTransition layoutTransition) {
        if (layoutTransition != null) {
            throw new IllegalArgumentException("Providing a LayoutTransition into RecyclerView is not supported. Please use setItemAnimator() instead for animating changes to the items in this RecyclerView");
        }
        super.setLayoutTransition(null);
    }

    @Override // android.view.View
    public void setNestedScrollingEnabled(boolean z2) {
        getScrollingChildHelper().m(z2);
    }

    public void setOnFlingListener(r rVar) {
        this.W = rVar;
    }

    @Deprecated
    public void setOnScrollListener(t tVar) {
        this.f2135j0 = tVar;
    }

    public void setPreserveFocusAfterLayout(boolean z2) {
        this.f2125e0 = z2;
    }

    public void setRecycledViewPool(u uVar) {
        this.f2120c.E(uVar);
    }

    public void setRecyclerListener(w wVar) {
        this.f2144o = wVar;
    }

    void setScrollState(int i2) {
        if (i2 == this.O) {
            return;
        }
        this.O = i2;
        if (i2 != 2) {
            u1();
        }
        H(i2);
    }

    public void setScrollingTouchSlop(int i2) {
        int scaledTouchSlop;
        ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
        if (i2 != 0) {
            if (i2 == 1) {
                scaledTouchSlop = viewConfiguration.getScaledPagingTouchSlop();
                this.V = scaledTouchSlop;
            }
            Log.w("RecyclerView", "setScrollingTouchSlop(): bad argument constant " + i2 + "; using default value");
        }
        scaledTouchSlop = viewConfiguration.getScaledTouchSlop();
        this.V = scaledTouchSlop;
    }

    public void setViewCacheExtension(b0 b0Var) {
        this.f2120c.F(b0Var);
    }

    @Override // android.view.View
    public boolean startNestedScroll(int i2) {
        return getScrollingChildHelper().o(i2);
    }

    @Override // android.view.View
    public void stopNestedScroll() {
        getScrollingChildHelper().q();
    }

    @Override // android.view.ViewGroup
    public final void suppressLayout(boolean z2) {
        if (z2 != this.f2164y) {
            o("Do not suppressLayout in layout or scroll");
            if (z2) {
                long uptimeMillis = SystemClock.uptimeMillis();
                onTouchEvent(MotionEvent.obtain(uptimeMillis, uptimeMillis, 3, 0.0f, 0.0f, 0));
                this.f2164y = true;
                this.f2166z = true;
                t1();
                return;
            }
            this.f2164y = false;
            if (this.f2162x && this.f2142n != null && this.f2140m != null) {
                requestLayout();
            }
            this.f2162x = false;
        }
    }

    void t(int i2, int i3) {
        boolean z2;
        EdgeEffect edgeEffect = this.J;
        if (edgeEffect == null || edgeEffect.isFinished() || i2 <= 0) {
            z2 = false;
        } else {
            this.J.onRelease();
            z2 = this.J.isFinished();
        }
        EdgeEffect edgeEffect2 = this.L;
        if (edgeEffect2 != null && !edgeEffect2.isFinished() && i2 < 0) {
            this.L.onRelease();
            z2 |= this.L.isFinished();
        }
        EdgeEffect edgeEffect3 = this.K;
        if (edgeEffect3 != null && !edgeEffect3.isFinished() && i3 > 0) {
            this.K.onRelease();
            z2 |= this.K.isFinished();
        }
        EdgeEffect edgeEffect4 = this.M;
        if (edgeEffect4 != null && !edgeEffect4.isFinished() && i3 < 0) {
            this.M.onRelease();
            z2 |= this.M.isFinished();
        }
        if (z2) {
            e0.q.b0(this);
        }
    }

    public boolean t0() {
        return this.G > 0;
    }

    public void t1() {
        setScrollState(0);
        u1();
    }

    void u() {
        if (!this.f2158v || this.E) {
            a0.b.a("RV FullInvalidate");
            B();
            a0.b.b();
        } else if (this.f2124e.p()) {
            if (this.f2124e.o(4) && !this.f2124e.o(11)) {
                a0.b.a("RV PartialInvalidate");
                p1();
                F0();
                this.f2124e.s();
                if (!this.f2162x) {
                    if (m0()) {
                        B();
                    } else {
                        this.f2124e.i();
                    }
                }
                r1(true);
                G0();
            } else if (!this.f2124e.p()) {
                return;
            } else {
                a0.b.a("RV FullInvalidate");
                B();
            }
            a0.b.b();
        }
    }

    void v0(int i2) {
        if (this.f2142n == null) {
            return;
        }
        setScrollState(2);
        this.f2142n.x1(i2);
        awakenScrollBars();
    }

    void v1(int i2, int i3, Object obj) {
        int i4;
        int j2 = this.f2126f.j();
        int i5 = i2 + i3;
        for (int i6 = 0; i6 < j2; i6++) {
            View i7 = this.f2126f.i(i6);
            d0 f02 = f0(i7);
            if (f02 != null && !f02.J() && (i4 = f02.f2197c) >= i2 && i4 < i5) {
                f02.b(2);
                f02.a(obj);
                ((p) i7.getLayoutParams()).f2254c = true;
            }
        }
        this.f2120c.M(i2, i3);
    }

    void w(int i2, int i3) {
        setMeasuredDimension(o.n(i2, getPaddingLeft() + getPaddingRight(), e0.q.D(this)), o.n(i3, getPaddingTop() + getPaddingBottom(), e0.q.C(this)));
    }

    void w0() {
        int j2 = this.f2126f.j();
        for (int i2 = 0; i2 < j2; i2++) {
            ((p) this.f2126f.i(i2).getLayoutParams()).f2254c = true;
        }
        this.f2120c.s();
    }

    void x0() {
        int j2 = this.f2126f.j();
        for (int i2 = 0; i2 < j2; i2++) {
            d0 f02 = f0(this.f2126f.i(i2));
            if (f02 != null && !f02.J()) {
                f02.b(6);
            }
        }
        w0();
        this.f2120c.t();
    }

    void y(View view) {
        d0 f02 = f0(view);
        D0(view);
        g gVar = this.f2140m;
        if (gVar != null && f02 != null) {
            gVar.o(f02);
        }
        List<q> list = this.D;
        if (list != null) {
            for (int size = list.size() - 1; size >= 0; size--) {
                this.D.get(size).a(view);
            }
        }
    }

    public void y0(int i2) {
        int g2 = this.f2126f.g();
        for (int i3 = 0; i3 < g2; i3++) {
            this.f2126f.f(i3).offsetLeftAndRight(i2);
        }
    }

    void z(View view) {
        d0 f02 = f0(view);
        E0(view);
        g gVar = this.f2140m;
        if (gVar != null && f02 != null) {
            gVar.p(f02);
        }
        List<q> list = this.D;
        if (list != null) {
            for (int size = list.size() - 1; size >= 0; size--) {
                this.D.get(size).b(view);
            }
        }
    }

    public void z0(int i2) {
        int g2 = this.f2126f.g();
        for (int i3 = 0; i3 < g2; i3++) {
            this.f2126f.f(i3).offsetTopAndBottom(i2);
        }
    }
}
