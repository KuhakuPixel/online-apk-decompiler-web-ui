package z0;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.d;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.json.JSONException;
/* loaded from: classes.dex */
public final class k {

    /* renamed from: a  reason: collision with root package name */
    public static final int f5701a = Runtime.getRuntime().availableProcessors();

    public static int a(Intent intent, String str) {
        if (intent == null) {
            m("ProxyBillingActivity", "Got null intent!");
            return 0;
        }
        return o(intent.getExtras(), "ProxyBillingActivity");
    }

    public static int b(Bundle bundle, String str) {
        String concat;
        if (bundle == null) {
            concat = "Unexpected null bundle received!";
        } else {
            Object obj = bundle.get("RESPONSE_CODE");
            if (obj == null) {
                l(str, "getResponseCodeFromBundle() got null response code, assuming OK");
                return 0;
            } else if (obj instanceof Integer) {
                return ((Integer) obj).intValue();
            } else {
                concat = "Unexpected type for bundle response code: ".concat(obj.getClass().getName());
            }
        }
        m(str, concat);
        return 6;
    }

    public static Bundle c(y0.a aVar, String str) {
        Bundle bundle = new Bundle();
        bundle.putString("playBillingLibraryVersion", str);
        return bundle;
    }

    public static Bundle d(y0.d dVar, boolean z2, String str) {
        Bundle bundle = new Bundle();
        if (z2) {
            bundle.putString("playBillingLibraryVersion", str);
        }
        return bundle;
    }

    public static Bundle e(int i2, boolean z2, String str, String str2, ArrayList arrayList) {
        Bundle bundle = new Bundle();
        if (i2 >= 9) {
            bundle.putString("playBillingLibraryVersion", str);
        }
        if (i2 >= 9 && z2) {
            bundle.putBoolean("enablePendingPurchases", true);
        }
        if (i2 >= 14) {
            ArrayList<String> arrayList2 = new ArrayList<>();
            ArrayList<String> arrayList3 = new ArrayList<>();
            ArrayList arrayList4 = new ArrayList();
            int size = arrayList.size();
            boolean z3 = false;
            boolean z4 = false;
            for (int i3 = 0; i3 < size; i3++) {
                com.android.billingclient.api.s sVar = (com.android.billingclient.api.s) arrayList.get(i3);
                arrayList2.add(null);
                z3 |= !TextUtils.isEmpty(null);
                arrayList3.add(null);
                z4 |= !TextUtils.isEmpty(null);
                arrayList4.add(0);
            }
            if (z3) {
                bundle.putStringArrayList("SKU_OFFER_ID_TOKEN_LIST", arrayList2);
            }
            if (z4) {
                bundle.putStringArrayList("SKU_OFFER_ID_LIST", arrayList3);
            }
        }
        return bundle;
    }

    public static Bundle f(com.android.billingclient.api.c cVar, boolean z2, boolean z3, boolean z4, String str) {
        Bundle bundle = new Bundle();
        bundle.putString("playBillingLibraryVersion", str);
        if (cVar.b() != 0) {
            bundle.putInt("prorationMode", cVar.b());
        }
        if (!TextUtils.isEmpty(cVar.c())) {
            bundle.putString("accountId", cVar.c());
        }
        if (!TextUtils.isEmpty(cVar.d())) {
            bundle.putString("obfuscatedProfileId", cVar.d());
        }
        if (cVar.o()) {
            bundle.putBoolean("isOfferPersonalizedByDeveloper", true);
        }
        if (!TextUtils.isEmpty(null)) {
            bundle.putStringArrayList("skusToReplace", new ArrayList<>(Arrays.asList(null)));
        }
        if (!TextUtils.isEmpty(cVar.e())) {
            bundle.putString("oldSkuPurchaseToken", cVar.e());
        }
        if (!TextUtils.isEmpty(null)) {
            bundle.putString("oldSkuPurchaseId", null);
        }
        if (!TextUtils.isEmpty(null)) {
            bundle.putString("originalExternalTransactionId", null);
        }
        if (!TextUtils.isEmpty(null)) {
            bundle.putString("paymentsPurchaseParams", null);
        }
        if (z2 && z3) {
            bundle.putBoolean("enablePendingPurchases", true);
        }
        if (z4) {
            bundle.putBoolean("enableAlternativeBilling", true);
        }
        return bundle;
    }

    public static Bundle g(boolean z2, boolean z3, String str) {
        Bundle bundle = new Bundle();
        bundle.putString("playBillingLibraryVersion", str);
        if (z2 && z3) {
            bundle.putBoolean("enablePendingPurchases", true);
        }
        return bundle;
    }

    public static com.android.billingclient.api.d h(Intent intent, String str) {
        if (intent != null) {
            d.a c2 = com.android.billingclient.api.d.c();
            c2.c(b(intent.getExtras(), str));
            c2.b(i(intent.getExtras(), str));
            return c2.a();
        }
        m("BillingHelper", "Got null intent!");
        d.a c3 = com.android.billingclient.api.d.c();
        c3.c(6);
        c3.b("An internal error occurred.");
        return c3.a();
    }

    public static String i(Bundle bundle, String str) {
        if (bundle == null) {
            m(str, "Unexpected null bundle received!");
            return "";
        }
        Object obj = bundle.get("DEBUG_MESSAGE");
        if (obj == null) {
            l(str, "getDebugMessageFromBundle() got null response code, assuming OK");
            return "";
        } else if (obj instanceof String) {
            return (String) obj;
        } else {
            m(str, "Unexpected type for debug message: ".concat(obj.getClass().getName()));
            return "";
        }
    }

    public static String j(int i2) {
        return a.a(i2).toString();
    }

    public static List k(Bundle bundle) {
        if (bundle == null) {
            return null;
        }
        ArrayList<String> stringArrayList = bundle.getStringArrayList("INAPP_PURCHASE_DATA_LIST");
        ArrayList<String> stringArrayList2 = bundle.getStringArrayList("INAPP_DATA_SIGNATURE_LIST");
        ArrayList arrayList = new ArrayList();
        if (stringArrayList == null || stringArrayList2 == null) {
            Purchase p2 = p(bundle.getString("INAPP_PURCHASE_DATA"), bundle.getString("INAPP_DATA_SIGNATURE"));
            if (p2 == null) {
                l("BillingHelper", "Couldn't find single purchase data as well.");
                return null;
            }
            arrayList.add(p2);
        } else {
            l("BillingHelper", "Found purchase list of " + stringArrayList.size() + " items");
            for (int i2 = 0; i2 < stringArrayList.size() && i2 < stringArrayList2.size(); i2++) {
                Purchase p3 = p(stringArrayList.get(i2), stringArrayList2.get(i2));
                if (p3 != null) {
                    arrayList.add(p3);
                }
            }
        }
        return arrayList;
    }

    public static void l(String str, String str2) {
        if (Log.isLoggable(str, 2)) {
            if (str2.isEmpty()) {
                Log.v(str, str2);
                return;
            }
            int i2 = 40000;
            while (!str2.isEmpty() && i2 > 0) {
                int min = Math.min(str2.length(), Math.min(4000, i2));
                Log.v(str, str2.substring(0, min));
                str2 = str2.substring(min);
                i2 -= min;
            }
        }
    }

    public static void m(String str, String str2) {
        if (Log.isLoggable(str, 5)) {
            Log.w(str, str2);
        }
    }

    public static void n(String str, String str2, Throwable th) {
        if (Log.isLoggable(str, 5)) {
            Log.w(str, str2, th);
        }
    }

    private static int o(Bundle bundle, String str) {
        if (bundle == null) {
            m(str, "Unexpected null bundle received!");
            return 0;
        }
        return bundle.getInt("IN_APP_MESSAGE_RESPONSE_CODE", 0);
    }

    private static Purchase p(String str, String str2) {
        if (str == null || str2 == null) {
            l("BillingHelper", "Received a null purchase data.");
            return null;
        }
        try {
            return new Purchase(str, str2);
        } catch (JSONException e2) {
            m("BillingHelper", "Got JSONException while parsing purchase data: ".concat(e2.toString()));
            return null;
        }
    }
}
