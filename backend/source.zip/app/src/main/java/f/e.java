package f;

import android.content.Context;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import androidx.appcompat.view.menu.e;
import androidx.appcompat.widget.ActionBarContextView;
import f.b;
import java.lang.ref.WeakReference;
/* loaded from: classes.dex */
public class e extends b implements e.a {

    /* renamed from: d  reason: collision with root package name */
    private Context f4363d;

    /* renamed from: e  reason: collision with root package name */
    private ActionBarContextView f4364e;

    /* renamed from: f  reason: collision with root package name */
    private b.a f4365f;

    /* renamed from: g  reason: collision with root package name */
    private WeakReference<View> f4366g;

    /* renamed from: h  reason: collision with root package name */
    private boolean f4367h;

    /* renamed from: i  reason: collision with root package name */
    private boolean f4368i;

    /* renamed from: j  reason: collision with root package name */
    private androidx.appcompat.view.menu.e f4369j;

    public e(Context context, ActionBarContextView actionBarContextView, b.a aVar, boolean z2) {
        this.f4363d = context;
        this.f4364e = actionBarContextView;
        this.f4365f = aVar;
        androidx.appcompat.view.menu.e S = new androidx.appcompat.view.menu.e(actionBarContextView.getContext()).S(1);
        this.f4369j = S;
        S.R(this);
        this.f4368i = z2;
    }

    @Override // androidx.appcompat.view.menu.e.a
    public boolean a(androidx.appcompat.view.menu.e eVar, MenuItem menuItem) {
        return this.f4365f.a(this, menuItem);
    }

    @Override // androidx.appcompat.view.menu.e.a
    public void b(androidx.appcompat.view.menu.e eVar) {
        k();
        this.f4364e.l();
    }

    @Override // f.b
    public void c() {
        if (this.f4367h) {
            return;
        }
        this.f4367h = true;
        this.f4364e.sendAccessibilityEvent(32);
        this.f4365f.c(this);
    }

    @Override // f.b
    public View d() {
        WeakReference<View> weakReference = this.f4366g;
        if (weakReference != null) {
            return weakReference.get();
        }
        return null;
    }

    @Override // f.b
    public Menu e() {
        return this.f4369j;
    }

    @Override // f.b
    public MenuInflater f() {
        return new g(this.f4364e.getContext());
    }

    @Override // f.b
    public CharSequence g() {
        return this.f4364e.getSubtitle();
    }

    @Override // f.b
    public CharSequence i() {
        return this.f4364e.getTitle();
    }

    @Override // f.b
    public void k() {
        this.f4365f.d(this, this.f4369j);
    }

    @Override // f.b
    public boolean l() {
        return this.f4364e.j();
    }

    @Override // f.b
    public void m(View view) {
        this.f4364e.setCustomView(view);
        this.f4366g = view != null ? new WeakReference<>(view) : null;
    }

    @Override // f.b
    public void n(int i2) {
        o(this.f4363d.getString(i2));
    }

    @Override // f.b
    public void o(CharSequence charSequence) {
        this.f4364e.setSubtitle(charSequence);
    }

    @Override // f.b
    public void q(int i2) {
        r(this.f4363d.getString(i2));
    }

    @Override // f.b
    public void r(CharSequence charSequence) {
        this.f4364e.setTitle(charSequence);
    }

    @Override // f.b
    public void s(boolean z2) {
        super.s(z2);
        this.f4364e.setTitleOptional(z2);
    }
}
