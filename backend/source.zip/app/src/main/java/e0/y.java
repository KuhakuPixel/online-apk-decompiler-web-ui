package e0;

import android.graphics.Rect;
import android.os.Build;
import android.util.Log;
import android.view.WindowInsets;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.util.Objects;
/* loaded from: classes.dex */
public class y {

    /* renamed from: b  reason: collision with root package name */
    public static final y f4329b = new a().a().a().b().c();

    /* renamed from: a  reason: collision with root package name */
    private final i f4330a;

    /* loaded from: classes.dex */
    public static final class a {

        /* renamed from: a  reason: collision with root package name */
        private final d f4331a;

        public a() {
            this.f4331a = Build.VERSION.SDK_INT >= 29 ? new c() : new b();
        }

        public a(y yVar) {
            this.f4331a = Build.VERSION.SDK_INT >= 29 ? new c(yVar) : new b(yVar);
        }

        public y a() {
            return this.f4331a.a();
        }

        public a b(w.b bVar) {
            this.f4331a.b(bVar);
            return this;
        }

        public a c(w.b bVar) {
            this.f4331a.c(bVar);
            return this;
        }
    }

    /* loaded from: classes.dex */
    private static class b extends d {

        /* renamed from: c  reason: collision with root package name */
        private static Field f4332c = null;

        /* renamed from: d  reason: collision with root package name */
        private static boolean f4333d = false;

        /* renamed from: e  reason: collision with root package name */
        private static Constructor<WindowInsets> f4334e = null;

        /* renamed from: f  reason: collision with root package name */
        private static boolean f4335f = false;

        /* renamed from: b  reason: collision with root package name */
        private WindowInsets f4336b;

        b() {
            this.f4336b = d();
        }

        b(y yVar) {
            this.f4336b = yVar.n();
        }

        private static WindowInsets d() {
            if (!f4333d) {
                try {
                    f4332c = WindowInsets.class.getDeclaredField("CONSUMED");
                } catch (ReflectiveOperationException e2) {
                    Log.i("WindowInsetsCompat", "Could not retrieve WindowInsets.CONSUMED field", e2);
                }
                f4333d = true;
            }
            Field field = f4332c;
            if (field != null) {
                try {
                    WindowInsets windowInsets = (WindowInsets) field.get(null);
                    if (windowInsets != null) {
                        return new WindowInsets(windowInsets);
                    }
                } catch (ReflectiveOperationException e3) {
                    Log.i("WindowInsetsCompat", "Could not get value from WindowInsets.CONSUMED field", e3);
                }
            }
            if (!f4335f) {
                try {
                    f4334e = WindowInsets.class.getConstructor(Rect.class);
                } catch (ReflectiveOperationException e4) {
                    Log.i("WindowInsetsCompat", "Could not retrieve WindowInsets(Rect) constructor", e4);
                }
                f4335f = true;
            }
            Constructor<WindowInsets> constructor = f4334e;
            if (constructor != null) {
                try {
                    return constructor.newInstance(new Rect());
                } catch (ReflectiveOperationException e5) {
                    Log.i("WindowInsetsCompat", "Could not invoke WindowInsets(Rect) constructor", e5);
                }
            }
            return null;
        }

        @Override // e0.y.d
        y a() {
            return y.o(this.f4336b);
        }

        @Override // e0.y.d
        void c(w.b bVar) {
            WindowInsets windowInsets = this.f4336b;
            if (windowInsets != null) {
                this.f4336b = windowInsets.replaceSystemWindowInsets(bVar.f5448a, bVar.f5449b, bVar.f5450c, bVar.f5451d);
            }
        }
    }

    /* loaded from: classes.dex */
    private static class c extends d {

        /* renamed from: b  reason: collision with root package name */
        final WindowInsets.Builder f4337b;

        c() {
            this.f4337b = new WindowInsets.Builder();
        }

        c(y yVar) {
            WindowInsets n2 = yVar.n();
            this.f4337b = n2 != null ? new WindowInsets.Builder(n2) : new WindowInsets.Builder();
        }

        @Override // e0.y.d
        y a() {
            return y.o(this.f4337b.build());
        }

        @Override // e0.y.d
        void b(w.b bVar) {
            this.f4337b.setStableInsets(bVar.c());
        }

        @Override // e0.y.d
        void c(w.b bVar) {
            this.f4337b.setSystemWindowInsets(bVar.c());
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public static class d {

        /* renamed from: a  reason: collision with root package name */
        private final y f4338a;

        d() {
            this(new y((y) null));
        }

        d(y yVar) {
            this.f4338a = yVar;
        }

        y a() {
            throw null;
        }

        void b(w.b bVar) {
        }

        void c(w.b bVar) {
            throw null;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public static class e extends i {

        /* renamed from: b  reason: collision with root package name */
        final WindowInsets f4339b;

        /* renamed from: c  reason: collision with root package name */
        private w.b f4340c;

        e(y yVar, WindowInsets windowInsets) {
            super(yVar);
            this.f4340c = null;
            this.f4339b = windowInsets;
        }

        e(y yVar, e eVar) {
            this(yVar, new WindowInsets(eVar.f4339b));
        }

        @Override // e0.y.i
        final w.b g() {
            if (this.f4340c == null) {
                this.f4340c = w.b.a(this.f4339b.getSystemWindowInsetLeft(), this.f4339b.getSystemWindowInsetTop(), this.f4339b.getSystemWindowInsetRight(), this.f4339b.getSystemWindowInsetBottom());
            }
            return this.f4340c;
        }

        @Override // e0.y.i
        y h(int i2, int i3, int i4, int i5) {
            a aVar = new a(y.o(this.f4339b));
            aVar.c(y.k(g(), i2, i3, i4, i5));
            aVar.b(y.k(f(), i2, i3, i4, i5));
            return aVar.a();
        }

        @Override // e0.y.i
        boolean j() {
            return this.f4339b.isRound();
        }
    }

    /* loaded from: classes.dex */
    private static class f extends e {

        /* renamed from: d  reason: collision with root package name */
        private w.b f4341d;

        f(y yVar, WindowInsets windowInsets) {
            super(yVar, windowInsets);
            this.f4341d = null;
        }

        f(y yVar, f fVar) {
            super(yVar, fVar);
            this.f4341d = null;
        }

        @Override // e0.y.i
        y b() {
            return y.o(this.f4339b.consumeStableInsets());
        }

        @Override // e0.y.i
        y c() {
            return y.o(this.f4339b.consumeSystemWindowInsets());
        }

        @Override // e0.y.i
        final w.b f() {
            if (this.f4341d == null) {
                this.f4341d = w.b.a(this.f4339b.getStableInsetLeft(), this.f4339b.getStableInsetTop(), this.f4339b.getStableInsetRight(), this.f4339b.getStableInsetBottom());
            }
            return this.f4341d;
        }

        @Override // e0.y.i
        boolean i() {
            return this.f4339b.isConsumed();
        }
    }

    /* loaded from: classes.dex */
    private static class g extends f {
        g(y yVar, WindowInsets windowInsets) {
            super(yVar, windowInsets);
        }

        g(y yVar, g gVar) {
            super(yVar, gVar);
        }

        @Override // e0.y.i
        y a() {
            return y.o(this.f4339b.consumeDisplayCutout());
        }

        @Override // e0.y.i
        e0.c d() {
            return e0.c.a(this.f4339b.getDisplayCutout());
        }

        @Override // e0.y.i
        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj instanceof g) {
                return Objects.equals(this.f4339b, ((g) obj).f4339b);
            }
            return false;
        }

        @Override // e0.y.i
        public int hashCode() {
            return this.f4339b.hashCode();
        }
    }

    /* loaded from: classes.dex */
    private static class h extends g {

        /* renamed from: e  reason: collision with root package name */
        private w.b f4342e;

        /* renamed from: f  reason: collision with root package name */
        private w.b f4343f;

        /* renamed from: g  reason: collision with root package name */
        private w.b f4344g;

        h(y yVar, WindowInsets windowInsets) {
            super(yVar, windowInsets);
            this.f4342e = null;
            this.f4343f = null;
            this.f4344g = null;
        }

        h(y yVar, h hVar) {
            super(yVar, hVar);
            this.f4342e = null;
            this.f4343f = null;
            this.f4344g = null;
        }

        @Override // e0.y.i
        w.b e() {
            if (this.f4343f == null) {
                this.f4343f = w.b.b(this.f4339b.getMandatorySystemGestureInsets());
            }
            return this.f4343f;
        }

        @Override // e0.y.e, e0.y.i
        y h(int i2, int i3, int i4, int i5) {
            return y.o(this.f4339b.inset(i2, i3, i4, i5));
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public static class i {

        /* renamed from: a  reason: collision with root package name */
        final y f4345a;

        i(y yVar) {
            this.f4345a = yVar;
        }

        y a() {
            return this.f4345a;
        }

        y b() {
            return this.f4345a;
        }

        y c() {
            return this.f4345a;
        }

        e0.c d() {
            return null;
        }

        w.b e() {
            return g();
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj instanceof i) {
                i iVar = (i) obj;
                return j() == iVar.j() && i() == iVar.i() && d0.c.a(g(), iVar.g()) && d0.c.a(f(), iVar.f()) && d0.c.a(d(), iVar.d());
            }
            return false;
        }

        w.b f() {
            return w.b.f5447e;
        }

        w.b g() {
            return w.b.f5447e;
        }

        y h(int i2, int i3, int i4, int i5) {
            return y.f4329b;
        }

        public int hashCode() {
            return d0.c.b(Boolean.valueOf(j()), Boolean.valueOf(i()), g(), f(), d());
        }

        boolean i() {
            return false;
        }

        boolean j() {
            return false;
        }
    }

    private y(WindowInsets windowInsets) {
        int i2 = Build.VERSION.SDK_INT;
        this.f4330a = i2 >= 29 ? new h(this, windowInsets) : i2 >= 28 ? new g(this, windowInsets) : new f(this, windowInsets);
    }

    public y(y yVar) {
        i iVar;
        i eVar;
        if (yVar != null) {
            i iVar2 = yVar.f4330a;
            int i2 = Build.VERSION.SDK_INT;
            if (i2 >= 29 && (iVar2 instanceof h)) {
                eVar = new h(this, (h) iVar2);
            } else if (i2 >= 28 && (iVar2 instanceof g)) {
                eVar = new g(this, (g) iVar2);
            } else if (iVar2 instanceof f) {
                eVar = new f(this, (f) iVar2);
            } else if (iVar2 instanceof e) {
                eVar = new e(this, (e) iVar2);
            } else {
                iVar = new i(this);
            }
            this.f4330a = eVar;
            return;
        }
        iVar = new i(this);
        this.f4330a = iVar;
    }

    static w.b k(w.b bVar, int i2, int i3, int i4, int i5) {
        int max = Math.max(0, bVar.f5448a - i2);
        int max2 = Math.max(0, bVar.f5449b - i3);
        int max3 = Math.max(0, bVar.f5450c - i4);
        int max4 = Math.max(0, bVar.f5451d - i5);
        return (max == i2 && max2 == i3 && max3 == i4 && max4 == i5) ? bVar : w.b.a(max, max2, max3, max4);
    }

    public static y o(WindowInsets windowInsets) {
        return new y((WindowInsets) d0.h.c(windowInsets));
    }

    public y a() {
        return this.f4330a.a();
    }

    public y b() {
        return this.f4330a.b();
    }

    public y c() {
        return this.f4330a.c();
    }

    public w.b d() {
        return this.f4330a.e();
    }

    public int e() {
        return i().f5451d;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof y) {
            return d0.c.a(this.f4330a, ((y) obj).f4330a);
        }
        return false;
    }

    public int f() {
        return i().f5448a;
    }

    public int g() {
        return i().f5450c;
    }

    public int h() {
        return i().f5449b;
    }

    public int hashCode() {
        i iVar = this.f4330a;
        if (iVar == null) {
            return 0;
        }
        return iVar.hashCode();
    }

    public w.b i() {
        return this.f4330a.g();
    }

    public y j(int i2, int i3, int i4, int i5) {
        return this.f4330a.h(i2, i3, i4, i5);
    }

    public boolean l() {
        return this.f4330a.i();
    }

    @Deprecated
    public y m(int i2, int i3, int i4, int i5) {
        return new a(this).c(w.b.a(i2, i3, i4, i5)).a();
    }

    public WindowInsets n() {
        i iVar = this.f4330a;
        if (iVar instanceof e) {
            return ((e) iVar).f4339b;
        }
        return null;
    }
}
