package a1;
/* loaded from: classes.dex */
public final class g {

    /* renamed from: a */
    public static final int app_bar_elevation_anim_duration = 2131427330;

    /* renamed from: b */
    public static final int mtrl_calendar_year_selector_span = 2131427343;
}
