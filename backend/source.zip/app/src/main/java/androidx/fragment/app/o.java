package androidx.fragment.app;

import android.util.Log;
import androidx.lifecycle.s;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes.dex */
public final class o extends androidx.lifecycle.r {

    /* renamed from: i  reason: collision with root package name */
    private static final s.a f1686i = new a();

    /* renamed from: f  reason: collision with root package name */
    private final boolean f1690f;

    /* renamed from: c  reason: collision with root package name */
    private final HashMap<String, Fragment> f1687c = new HashMap<>();

    /* renamed from: d  reason: collision with root package name */
    private final HashMap<String, o> f1688d = new HashMap<>();

    /* renamed from: e  reason: collision with root package name */
    private final HashMap<String, androidx.lifecycle.t> f1689e = new HashMap<>();

    /* renamed from: g  reason: collision with root package name */
    private boolean f1691g = false;

    /* renamed from: h  reason: collision with root package name */
    private boolean f1692h = false;

    /* loaded from: classes.dex */
    static class a implements s.a {
        a() {
        }

        @Override // androidx.lifecycle.s.a
        public <T extends androidx.lifecycle.r> T a(Class<T> cls) {
            return new o(true);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public o(boolean z2) {
        this.f1690f = z2;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static o i(androidx.lifecycle.t tVar) {
        return (o) new androidx.lifecycle.s(tVar, f1686i).a(o.class);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.lifecycle.r
    public void d() {
        if (l.p0(3)) {
            Log.d("FragmentManager", "onCleared called for " + this);
        }
        this.f1691g = true;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public boolean e(Fragment fragment) {
        if (this.f1687c.containsKey(fragment.f1525f)) {
            return false;
        }
        this.f1687c.put(fragment.f1525f, fragment);
        return true;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || o.class != obj.getClass()) {
            return false;
        }
        o oVar = (o) obj;
        return this.f1687c.equals(oVar.f1687c) && this.f1688d.equals(oVar.f1688d) && this.f1689e.equals(oVar.f1689e);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void f(Fragment fragment) {
        if (l.p0(3)) {
            Log.d("FragmentManager", "Clearing non-config state for " + fragment);
        }
        o oVar = this.f1688d.get(fragment.f1525f);
        if (oVar != null) {
            oVar.d();
            this.f1688d.remove(fragment.f1525f);
        }
        androidx.lifecycle.t tVar = this.f1689e.get(fragment.f1525f);
        if (tVar != null) {
            tVar.a();
            this.f1689e.remove(fragment.f1525f);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public Fragment g(String str) {
        return this.f1687c.get(str);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public o h(Fragment fragment) {
        o oVar = this.f1688d.get(fragment.f1525f);
        if (oVar == null) {
            o oVar2 = new o(this.f1690f);
            this.f1688d.put(fragment.f1525f, oVar2);
            return oVar2;
        }
        return oVar;
    }

    public int hashCode() {
        return (((this.f1687c.hashCode() * 31) + this.f1688d.hashCode()) * 31) + this.f1689e.hashCode();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public Collection<Fragment> j() {
        return this.f1687c.values();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public androidx.lifecycle.t k(Fragment fragment) {
        androidx.lifecycle.t tVar = this.f1689e.get(fragment.f1525f);
        if (tVar == null) {
            androidx.lifecycle.t tVar2 = new androidx.lifecycle.t();
            this.f1689e.put(fragment.f1525f, tVar2);
            return tVar2;
        }
        return tVar;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public boolean l() {
        return this.f1691g;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public boolean m(Fragment fragment) {
        return this.f1687c.remove(fragment.f1525f) != null;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public boolean n(Fragment fragment) {
        if (this.f1687c.containsKey(fragment.f1525f)) {
            return this.f1690f ? this.f1691g : !this.f1692h;
        }
        return true;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder("FragmentManagerViewModel{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        sb.append("} Fragments (");
        Iterator<Fragment> it = this.f1687c.values().iterator();
        while (it.hasNext()) {
            sb.append(it.next());
            if (it.hasNext()) {
                sb.append(", ");
            }
        }
        sb.append(") Child Non Config (");
        Iterator<String> it2 = this.f1688d.keySet().iterator();
        while (it2.hasNext()) {
            sb.append(it2.next());
            if (it2.hasNext()) {
                sb.append(", ");
            }
        }
        sb.append(") ViewModelStores (");
        Iterator<String> it3 = this.f1689e.keySet().iterator();
        while (it3.hasNext()) {
            sb.append(it3.next());
            if (it3.hasNext()) {
                sb.append(", ");
            }
        }
        sb.append(')');
        return sb.toString();
    }
}
