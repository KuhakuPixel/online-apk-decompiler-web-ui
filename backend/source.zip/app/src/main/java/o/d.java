package o;

import java.util.Arrays;
import java.util.HashMap;
import o.i;
import p.d;
/* loaded from: classes.dex */
public class d {

    /* renamed from: r  reason: collision with root package name */
    public static boolean f4728r = false;

    /* renamed from: s  reason: collision with root package name */
    public static boolean f4729s = true;

    /* renamed from: t  reason: collision with root package name */
    public static boolean f4730t = true;

    /* renamed from: u  reason: collision with root package name */
    public static boolean f4731u = true;

    /* renamed from: v  reason: collision with root package name */
    public static boolean f4732v = false;

    /* renamed from: w  reason: collision with root package name */
    private static int f4733w = 1000;

    /* renamed from: x  reason: collision with root package name */
    public static long f4734x;

    /* renamed from: y  reason: collision with root package name */
    public static long f4735y;

    /* renamed from: d  reason: collision with root package name */
    private a f4739d;

    /* renamed from: g  reason: collision with root package name */
    o.b[] f4742g;

    /* renamed from: n  reason: collision with root package name */
    final c f4749n;

    /* renamed from: q  reason: collision with root package name */
    private a f4752q;

    /* renamed from: a  reason: collision with root package name */
    public boolean f4736a = false;

    /* renamed from: b  reason: collision with root package name */
    int f4737b = 0;

    /* renamed from: c  reason: collision with root package name */
    private HashMap<String, i> f4738c = null;

    /* renamed from: e  reason: collision with root package name */
    private int f4740e = 32;

    /* renamed from: f  reason: collision with root package name */
    private int f4741f = 32;

    /* renamed from: h  reason: collision with root package name */
    public boolean f4743h = false;

    /* renamed from: i  reason: collision with root package name */
    public boolean f4744i = false;

    /* renamed from: j  reason: collision with root package name */
    private boolean[] f4745j = new boolean[32];

    /* renamed from: k  reason: collision with root package name */
    int f4746k = 1;

    /* renamed from: l  reason: collision with root package name */
    int f4747l = 0;

    /* renamed from: m  reason: collision with root package name */
    private int f4748m = 32;

    /* renamed from: o  reason: collision with root package name */
    private i[] f4750o = new i[f4733w];

    /* renamed from: p  reason: collision with root package name */
    private int f4751p = 0;

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public interface a {
        void a(i iVar);

        i b(d dVar, boolean[] zArr);

        void c(a aVar);

        void clear();

        i getKey();

        boolean isEmpty();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public class b extends o.b {
        public b(c cVar) {
            this.f4722e = new j(this, cVar);
        }
    }

    public d() {
        this.f4742g = null;
        this.f4742g = new o.b[32];
        C();
        c cVar = new c();
        this.f4749n = cVar;
        this.f4739d = new h(cVar);
        this.f4752q = f4732v ? new b(cVar) : new o.b(cVar);
    }

    private final int B(a aVar, boolean z2) {
        for (int i2 = 0; i2 < this.f4746k; i2++) {
            this.f4745j[i2] = false;
        }
        boolean z3 = false;
        int i3 = 0;
        while (!z3) {
            i3++;
            if (i3 >= this.f4746k * 2) {
                return i3;
            }
            if (aVar.getKey() != null) {
                this.f4745j[aVar.getKey().f4769c] = true;
            }
            i b2 = aVar.b(this, this.f4745j);
            if (b2 != null) {
                boolean[] zArr = this.f4745j;
                int i4 = b2.f4769c;
                if (zArr[i4]) {
                    return i3;
                }
                zArr[i4] = true;
            }
            if (b2 != null) {
                float f2 = Float.MAX_VALUE;
                int i5 = -1;
                for (int i6 = 0; i6 < this.f4747l; i6++) {
                    o.b bVar = this.f4742g[i6];
                    if (bVar.f4718a.f4776j != i.a.UNRESTRICTED && !bVar.f4723f && bVar.t(b2)) {
                        float f3 = bVar.f4722e.f(b2);
                        if (f3 < 0.0f) {
                            float f4 = (-bVar.f4719b) / f3;
                            if (f4 < f2) {
                                i5 = i6;
                                f2 = f4;
                            }
                        }
                    }
                }
                if (i5 > -1) {
                    o.b bVar2 = this.f4742g[i5];
                    bVar2.f4718a.f4770d = -1;
                    bVar2.x(b2);
                    i iVar = bVar2.f4718a;
                    iVar.f4770d = i5;
                    iVar.g(this, bVar2);
                }
            } else {
                z3 = true;
            }
        }
        return i3;
    }

    private void C() {
        int i2 = 0;
        if (f4732v) {
            while (i2 < this.f4747l) {
                o.b bVar = this.f4742g[i2];
                if (bVar != null) {
                    this.f4749n.f4724a.a(bVar);
                }
                this.f4742g[i2] = null;
                i2++;
            }
            return;
        }
        while (i2 < this.f4747l) {
            o.b bVar2 = this.f4742g[i2];
            if (bVar2 != null) {
                this.f4749n.f4725b.a(bVar2);
            }
            this.f4742g[i2] = null;
            i2++;
        }
    }

    private i a(i.a aVar, String str) {
        i b2 = this.f4749n.f4726c.b();
        if (b2 == null) {
            b2 = new i(aVar, str);
        } else {
            b2.d();
        }
        b2.f(aVar, str);
        int i2 = this.f4751p;
        int i3 = f4733w;
        if (i2 >= i3) {
            int i4 = i3 * 2;
            f4733w = i4;
            this.f4750o = (i[]) Arrays.copyOf(this.f4750o, i4);
        }
        i[] iVarArr = this.f4750o;
        int i5 = this.f4751p;
        this.f4751p = i5 + 1;
        iVarArr[i5] = b2;
        return b2;
    }

    private final void l(o.b bVar) {
        int i2;
        if (f4730t && bVar.f4723f) {
            bVar.f4718a.e(this, bVar.f4719b);
        } else {
            o.b[] bVarArr = this.f4742g;
            int i3 = this.f4747l;
            bVarArr[i3] = bVar;
            i iVar = bVar.f4718a;
            iVar.f4770d = i3;
            this.f4747l = i3 + 1;
            iVar.g(this, bVar);
        }
        if (f4730t && this.f4736a) {
            int i4 = 0;
            while (i4 < this.f4747l) {
                if (this.f4742g[i4] == null) {
                    System.out.println("WTF");
                }
                o.b[] bVarArr2 = this.f4742g;
                if (bVarArr2[i4] != null && bVarArr2[i4].f4723f) {
                    o.b bVar2 = bVarArr2[i4];
                    bVar2.f4718a.e(this, bVar2.f4719b);
                    (f4732v ? this.f4749n.f4724a : this.f4749n.f4725b).a(bVar2);
                    this.f4742g[i4] = null;
                    int i5 = i4 + 1;
                    int i6 = i5;
                    while (true) {
                        i2 = this.f4747l;
                        if (i5 >= i2) {
                            break;
                        }
                        o.b[] bVarArr3 = this.f4742g;
                        int i7 = i5 - 1;
                        bVarArr3[i7] = bVarArr3[i5];
                        if (bVarArr3[i7].f4718a.f4770d == i5) {
                            bVarArr3[i7].f4718a.f4770d = i7;
                        }
                        i6 = i5;
                        i5++;
                    }
                    if (i6 < i2) {
                        this.f4742g[i6] = null;
                    }
                    this.f4747l = i2 - 1;
                    i4--;
                }
                i4++;
            }
            this.f4736a = false;
        }
    }

    private void n() {
        for (int i2 = 0; i2 < this.f4747l; i2++) {
            o.b bVar = this.f4742g[i2];
            bVar.f4718a.f4772f = bVar.f4719b;
        }
    }

    public static o.b s(d dVar, i iVar, i iVar2, float f2) {
        return dVar.r().j(iVar, iVar2, f2);
    }

    private int u(a aVar) {
        boolean z2;
        int i2 = 0;
        while (true) {
            if (i2 >= this.f4747l) {
                z2 = false;
                break;
            }
            o.b[] bVarArr = this.f4742g;
            if (bVarArr[i2].f4718a.f4776j != i.a.UNRESTRICTED && bVarArr[i2].f4719b < 0.0f) {
                z2 = true;
                break;
            }
            i2++;
        }
        if (z2) {
            boolean z3 = false;
            int i3 = 0;
            while (!z3) {
                i3++;
                float f2 = Float.MAX_VALUE;
                int i4 = -1;
                int i5 = -1;
                int i6 = 0;
                for (int i7 = 0; i7 < this.f4747l; i7++) {
                    o.b bVar = this.f4742g[i7];
                    if (bVar.f4718a.f4776j != i.a.UNRESTRICTED && !bVar.f4723f && bVar.f4719b < 0.0f) {
                        int i8 = 9;
                        if (f4731u) {
                            int k2 = bVar.f4722e.k();
                            int i9 = 0;
                            while (i9 < k2) {
                                i g2 = bVar.f4722e.g(i9);
                                float f3 = bVar.f4722e.f(g2);
                                if (f3 > 0.0f) {
                                    int i10 = 0;
                                    while (i10 < i8) {
                                        float f4 = g2.f4774h[i10] / f3;
                                        if ((f4 < f2 && i10 == i6) || i10 > i6) {
                                            i5 = g2.f4769c;
                                            i6 = i10;
                                            i4 = i7;
                                            f2 = f4;
                                        }
                                        i10++;
                                        i8 = 9;
                                    }
                                }
                                i9++;
                                i8 = 9;
                            }
                        } else {
                            for (int i11 = 1; i11 < this.f4746k; i11++) {
                                i iVar = this.f4749n.f4727d[i11];
                                float f5 = bVar.f4722e.f(iVar);
                                if (f5 > 0.0f) {
                                    for (int i12 = 0; i12 < 9; i12++) {
                                        float f6 = iVar.f4774h[i12] / f5;
                                        if ((f6 < f2 && i12 == i6) || i12 > i6) {
                                            i5 = i11;
                                            i4 = i7;
                                            i6 = i12;
                                            f2 = f6;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                if (i4 != -1) {
                    o.b bVar2 = this.f4742g[i4];
                    bVar2.f4718a.f4770d = -1;
                    bVar2.x(this.f4749n.f4727d[i5]);
                    i iVar2 = bVar2.f4718a;
                    iVar2.f4770d = i4;
                    iVar2.g(this, bVar2);
                } else {
                    z3 = true;
                }
                if (i3 > this.f4746k / 2) {
                    z3 = true;
                }
            }
            return i3;
        }
        return 0;
    }

    public static e w() {
        return null;
    }

    private void y() {
        int i2 = this.f4740e * 2;
        this.f4740e = i2;
        this.f4742g = (o.b[]) Arrays.copyOf(this.f4742g, i2);
        c cVar = this.f4749n;
        cVar.f4727d = (i[]) Arrays.copyOf(cVar.f4727d, this.f4740e);
        int i3 = this.f4740e;
        this.f4745j = new boolean[i3];
        this.f4741f = i3;
        this.f4748m = i3;
    }

    void A(a aVar) {
        u(aVar);
        B(aVar, false);
        n();
    }

    public void D() {
        c cVar;
        int i2 = 0;
        while (true) {
            cVar = this.f4749n;
            i[] iVarArr = cVar.f4727d;
            if (i2 >= iVarArr.length) {
                break;
            }
            i iVar = iVarArr[i2];
            if (iVar != null) {
                iVar.d();
            }
            i2++;
        }
        cVar.f4726c.c(this.f4750o, this.f4751p);
        this.f4751p = 0;
        Arrays.fill(this.f4749n.f4727d, (Object) null);
        HashMap<String, i> hashMap = this.f4738c;
        if (hashMap != null) {
            hashMap.clear();
        }
        this.f4737b = 0;
        this.f4739d.clear();
        this.f4746k = 1;
        for (int i3 = 0; i3 < this.f4747l; i3++) {
            o.b[] bVarArr = this.f4742g;
            if (bVarArr[i3] != null) {
                bVarArr[i3].f4720c = false;
            }
        }
        C();
        this.f4747l = 0;
        this.f4752q = f4732v ? new b(this.f4749n) : new o.b(this.f4749n);
    }

    public void b(p.e eVar, p.e eVar2, float f2, int i2) {
        d.b bVar = d.b.LEFT;
        i q2 = q(eVar.m(bVar));
        d.b bVar2 = d.b.TOP;
        i q3 = q(eVar.m(bVar2));
        d.b bVar3 = d.b.RIGHT;
        i q4 = q(eVar.m(bVar3));
        d.b bVar4 = d.b.BOTTOM;
        i q5 = q(eVar.m(bVar4));
        i q6 = q(eVar2.m(bVar));
        i q7 = q(eVar2.m(bVar2));
        i q8 = q(eVar2.m(bVar3));
        i q9 = q(eVar2.m(bVar4));
        o.b r2 = r();
        double d2 = f2;
        double d3 = i2;
        r2.q(q3, q5, q7, q9, (float) (Math.sin(d2) * d3));
        d(r2);
        o.b r3 = r();
        r3.q(q2, q4, q6, q8, (float) (Math.cos(d2) * d3));
        d(r3);
    }

    public void c(i iVar, i iVar2, int i2, float f2, i iVar3, i iVar4, int i3, int i4) {
        o.b r2 = r();
        r2.h(iVar, iVar2, i2, f2, iVar3, iVar4, i3);
        if (i4 != 8) {
            r2.d(this, i4);
        }
        d(r2);
    }

    /* JADX WARN: Removed duplicated region for block: B:36:0x007f A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:37:0x0080  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void d(o.b r6) {
        /*
            r5 = this;
            if (r6 != 0) goto L3
            return
        L3:
            int r0 = r5.f4747l
            r1 = 1
            int r0 = r0 + r1
            int r2 = r5.f4748m
            if (r0 >= r2) goto L12
            int r0 = r5.f4746k
            int r0 = r0 + r1
            int r2 = r5.f4741f
            if (r0 < r2) goto L15
        L12:
            r5.y()
        L15:
            r0 = 0
            boolean r2 = r6.f4723f
            if (r2 != 0) goto L81
            r6.D(r5)
            boolean r2 = r6.isEmpty()
            if (r2 == 0) goto L24
            return
        L24:
            r6.r()
            boolean r2 = r6.f(r5)
            if (r2 == 0) goto L78
            o.i r2 = r5.p()
            r6.f4718a = r2
            int r3 = r5.f4747l
            r5.l(r6)
            int r4 = r5.f4747l
            int r3 = r3 + r1
            if (r4 != r3) goto L78
            o.d$a r0 = r5.f4752q
            r0.c(r6)
            o.d$a r0 = r5.f4752q
            r5.B(r0, r1)
            int r0 = r2.f4770d
            r3 = -1
            if (r0 != r3) goto L79
            o.i r0 = r6.f4718a
            if (r0 != r2) goto L59
            o.i r0 = r6.v(r2)
            if (r0 == 0) goto L59
            r6.x(r0)
        L59:
            boolean r0 = r6.f4723f
            if (r0 != 0) goto L62
            o.i r0 = r6.f4718a
            r0.g(r5, r6)
        L62:
            boolean r0 = o.d.f4732v
            if (r0 == 0) goto L6b
            o.c r0 = r5.f4749n
            o.f<o.b> r0 = r0.f4724a
            goto L6f
        L6b:
            o.c r0 = r5.f4749n
            o.f<o.b> r0 = r0.f4725b
        L6f:
            r0.a(r6)
            int r0 = r5.f4747l
            int r0 = r0 - r1
            r5.f4747l = r0
            goto L79
        L78:
            r1 = 0
        L79:
            boolean r0 = r6.s()
            if (r0 != 0) goto L80
            return
        L80:
            r0 = r1
        L81:
            if (r0 != 0) goto L86
            r5.l(r6)
        L86:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: o.d.d(o.b):void");
    }

    public o.b e(i iVar, i iVar2, int i2, int i3) {
        if (f4729s && i3 == 8 && iVar2.f4773g && iVar.f4770d == -1) {
            iVar.e(this, iVar2.f4772f + i2);
            return null;
        }
        o.b r2 = r();
        r2.n(iVar, iVar2, i2);
        if (i3 != 8) {
            r2.d(this, i3);
        }
        d(r2);
        return r2;
    }

    public void f(i iVar, int i2) {
        o.b r2;
        if (f4729s && iVar.f4770d == -1) {
            float f2 = i2;
            iVar.e(this, f2);
            for (int i3 = 0; i3 < this.f4737b + 1; i3++) {
                i iVar2 = this.f4749n.f4727d[i3];
                if (iVar2 != null && iVar2.f4780n && iVar2.f4781o == iVar.f4769c) {
                    iVar2.e(this, iVar2.f4782p + f2);
                }
            }
            return;
        }
        int i4 = iVar.f4770d;
        if (i4 != -1) {
            o.b bVar = this.f4742g[i4];
            if (!bVar.f4723f) {
                if (bVar.f4722e.k() == 0) {
                    bVar.f4723f = true;
                } else {
                    r2 = r();
                    r2.m(iVar, i2);
                }
            }
            bVar.f4719b = i2;
            return;
        }
        r2 = r();
        r2.i(iVar, i2);
        d(r2);
    }

    public void g(i iVar, i iVar2, int i2, boolean z2) {
        o.b r2 = r();
        i t2 = t();
        t2.f4771e = 0;
        r2.o(iVar, iVar2, t2, i2);
        d(r2);
    }

    public void h(i iVar, i iVar2, int i2, int i3) {
        o.b r2 = r();
        i t2 = t();
        t2.f4771e = 0;
        r2.o(iVar, iVar2, t2, i2);
        if (i3 != 8) {
            m(r2, (int) (r2.f4722e.f(t2) * (-1.0f)), i3);
        }
        d(r2);
    }

    public void i(i iVar, i iVar2, int i2, boolean z2) {
        o.b r2 = r();
        i t2 = t();
        t2.f4771e = 0;
        r2.p(iVar, iVar2, t2, i2);
        d(r2);
    }

    public void j(i iVar, i iVar2, int i2, int i3) {
        o.b r2 = r();
        i t2 = t();
        t2.f4771e = 0;
        r2.p(iVar, iVar2, t2, i2);
        if (i3 != 8) {
            m(r2, (int) (r2.f4722e.f(t2) * (-1.0f)), i3);
        }
        d(r2);
    }

    public void k(i iVar, i iVar2, i iVar3, i iVar4, float f2, int i2) {
        o.b r2 = r();
        r2.k(iVar, iVar2, iVar3, iVar4, f2);
        if (i2 != 8) {
            r2.d(this, i2);
        }
        d(r2);
    }

    void m(o.b bVar, int i2, int i3) {
        bVar.e(o(i3, null), i2);
    }

    public i o(int i2, String str) {
        if (this.f4746k + 1 >= this.f4741f) {
            y();
        }
        i a2 = a(i.a.ERROR, str);
        int i3 = this.f4737b + 1;
        this.f4737b = i3;
        this.f4746k++;
        a2.f4769c = i3;
        a2.f4771e = i2;
        this.f4749n.f4727d[i3] = a2;
        this.f4739d.a(a2);
        return a2;
    }

    public i p() {
        if (this.f4746k + 1 >= this.f4741f) {
            y();
        }
        i a2 = a(i.a.SLACK, null);
        int i2 = this.f4737b + 1;
        this.f4737b = i2;
        this.f4746k++;
        a2.f4769c = i2;
        this.f4749n.f4727d[i2] = a2;
        return a2;
    }

    public i q(Object obj) {
        i iVar = null;
        if (obj == null) {
            return null;
        }
        if (this.f4746k + 1 >= this.f4741f) {
            y();
        }
        if (obj instanceof p.d) {
            p.d dVar = (p.d) obj;
            iVar = dVar.h();
            if (iVar == null) {
                dVar.r(this.f4749n);
                iVar = dVar.h();
            }
            int i2 = iVar.f4769c;
            if (i2 == -1 || i2 > this.f4737b || this.f4749n.f4727d[i2] == null) {
                if (i2 != -1) {
                    iVar.d();
                }
                int i3 = this.f4737b + 1;
                this.f4737b = i3;
                this.f4746k++;
                iVar.f4769c = i3;
                iVar.f4776j = i.a.UNRESTRICTED;
                this.f4749n.f4727d[i3] = iVar;
            }
        }
        return iVar;
    }

    public o.b r() {
        o.b b2;
        if (f4732v) {
            b2 = this.f4749n.f4724a.b();
            if (b2 == null) {
                b2 = new b(this.f4749n);
                f4735y++;
            }
            b2.y();
        } else {
            b2 = this.f4749n.f4725b.b();
            if (b2 == null) {
                b2 = new o.b(this.f4749n);
                f4734x++;
            }
            b2.y();
        }
        i.b();
        return b2;
    }

    public i t() {
        if (this.f4746k + 1 >= this.f4741f) {
            y();
        }
        i a2 = a(i.a.SLACK, null);
        int i2 = this.f4737b + 1;
        this.f4737b = i2;
        this.f4746k++;
        a2.f4769c = i2;
        this.f4749n.f4727d[i2] = a2;
        return a2;
    }

    public c v() {
        return this.f4749n;
    }

    public int x(Object obj) {
        i h2 = ((p.d) obj).h();
        if (h2 != null) {
            return (int) (h2.f4772f + 0.5f);
        }
        return 0;
    }

    public void z() {
        if (this.f4739d.isEmpty()) {
            n();
            return;
        }
        if (this.f4743h || this.f4744i) {
            boolean z2 = false;
            int i2 = 0;
            while (true) {
                if (i2 >= this.f4747l) {
                    z2 = true;
                    break;
                } else if (!this.f4742g[i2].f4723f) {
                    break;
                } else {
                    i2++;
                }
            }
            if (z2) {
                n();
                return;
            }
        }
        A(this.f4739d);
    }
}
