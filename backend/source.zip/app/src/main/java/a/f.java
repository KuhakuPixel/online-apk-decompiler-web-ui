package a;
/* loaded from: classes.dex */
public final class f {

    /* renamed from: A */
    public static final int search_go_btn = 2131362124;

    /* renamed from: B */
    public static final int search_mag_icon = 2131362125;

    /* renamed from: C */
    public static final int search_plate = 2131362126;

    /* renamed from: D */
    public static final int search_src_text = 2131362127;

    /* renamed from: E */
    public static final int search_voice_btn = 2131362128;

    /* renamed from: F */
    public static final int shortcut = 2131362132;

    /* renamed from: G */
    public static final int spacer = 2131362148;

    /* renamed from: H */
    public static final int split_action_bar = 2131362150;

    /* renamed from: I */
    public static final int submenuarrow = 2131362166;

    /* renamed from: J */
    public static final int submit_area = 2131362167;

    /* renamed from: K */
    public static final int textSpacerNoButtons = 2131362184;

    /* renamed from: L */
    public static final int textSpacerNoTitle = 2131362185;

    /* renamed from: M */
    public static final int title = 2131362199;

    /* renamed from: N */
    public static final int titleDividerNoCustom = 2131362200;

    /* renamed from: O */
    public static final int title_template = 2131362201;

    /* renamed from: P */
    public static final int topPanel = 2131362206;

    /* renamed from: a */
    public static final int action_bar = 2131361840;

    /* renamed from: b */
    public static final int action_bar_activity_content = 2131361841;

    /* renamed from: c */
    public static final int action_bar_container = 2131361842;

    /* renamed from: d */
    public static final int action_bar_subtitle = 2131361845;

    /* renamed from: e */
    public static final int action_bar_title = 2131361846;

    /* renamed from: f */
    public static final int action_context_bar = 2131361848;

    /* renamed from: g */
    public static final int action_menu_presenter = 2131361853;

    /* renamed from: h */
    public static final int action_mode_bar_stub = 2131361855;

    /* renamed from: i */
    public static final int action_mode_close_button = 2131361856;

    /* renamed from: j */
    public static final int alertTitle = 2131361861;

    /* renamed from: k */
    public static final int buttonPanel = 2131361880;

    /* renamed from: l */
    public static final int content = 2131361906;

    /* renamed from: m */
    public static final int contentPanel = 2131361907;

    /* renamed from: n */
    public static final int custom = 2131361912;

    /* renamed from: o */
    public static final int customPanel = 2131361913;

    /* renamed from: p */
    public static final int decor_content_parent = 2131361919;

    /* renamed from: q */
    public static final int edit_query = 2131361946;

    /* renamed from: r */
    public static final int group_divider = 2131361974;

    /* renamed from: s */
    public static final int message = 2131362031;

    /* renamed from: t */
    public static final int parentPanel = 2131362086;

    /* renamed from: u */
    public static final int scrollIndicatorDown = 2131362115;

    /* renamed from: v */
    public static final int scrollIndicatorUp = 2131362116;

    /* renamed from: w */
    public static final int scrollView = 2131362117;

    /* renamed from: x */
    public static final int search_button = 2131362121;

    /* renamed from: y */
    public static final int search_close_btn = 2131362122;

    /* renamed from: z */
    public static final int search_edit_frame = 2131362123;
}
