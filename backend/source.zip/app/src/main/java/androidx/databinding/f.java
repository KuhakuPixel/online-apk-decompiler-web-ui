package androidx.databinding;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
/* loaded from: classes.dex */
public class f {

    /* renamed from: a  reason: collision with root package name */
    private static d f1514a = new DataBinderMapperImpl();

    /* renamed from: b  reason: collision with root package name */
    private static e f1515b = null;

    static <T extends ViewDataBinding> T a(e eVar, View view, int i2) {
        return (T) f1514a.b(eVar, view, i2);
    }

    static <T extends ViewDataBinding> T b(e eVar, View[] viewArr, int i2) {
        return (T) f1514a.c(eVar, viewArr, i2);
    }

    private static <T extends ViewDataBinding> T c(e eVar, ViewGroup viewGroup, int i2, int i3) {
        int childCount = viewGroup.getChildCount();
        int i4 = childCount - i2;
        if (i4 == 1) {
            return (T) a(eVar, viewGroup.getChildAt(childCount - 1), i3);
        }
        View[] viewArr = new View[i4];
        for (int i5 = 0; i5 < i4; i5++) {
            viewArr[i5] = viewGroup.getChildAt(i5 + i2);
        }
        return (T) b(eVar, viewArr, i3);
    }

    public static <T extends ViewDataBinding> T d(LayoutInflater layoutInflater, int i2, ViewGroup viewGroup, boolean z2) {
        return (T) e(layoutInflater, i2, viewGroup, z2, f1515b);
    }

    public static <T extends ViewDataBinding> T e(LayoutInflater layoutInflater, int i2, ViewGroup viewGroup, boolean z2, e eVar) {
        boolean z3 = viewGroup != null && z2;
        return z3 ? (T) c(eVar, viewGroup, z3 ? viewGroup.getChildCount() : 0, i2) : (T) a(eVar, layoutInflater.inflate(i2, viewGroup, z2), i2);
    }

    public static <T extends ViewDataBinding> T f(Activity activity, int i2) {
        return (T) g(activity, i2, f1515b);
    }

    public static <T extends ViewDataBinding> T g(Activity activity, int i2, e eVar) {
        activity.setContentView(i2);
        return (T) c(eVar, (ViewGroup) activity.getWindow().getDecorView().findViewById(16908290), 0, i2);
    }
}
