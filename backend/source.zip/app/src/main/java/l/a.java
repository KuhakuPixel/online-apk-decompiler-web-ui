package l;

import java.util.Collection;
import java.util.Map;
import java.util.Set;
/* loaded from: classes.dex */
public class a<K, V> extends g<K, V> implements Map<K, V> {

    /* renamed from: i  reason: collision with root package name */
    f<K, V> f4600i;

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: l.a$a  reason: collision with other inner class name */
    /* loaded from: classes.dex */
    public class C0064a extends f<K, V> {
        C0064a() {
        }

        @Override // l.f
        protected void a() {
            a.this.clear();
        }

        @Override // l.f
        protected Object b(int i2, int i3) {
            return a.this.f4649c[(i2 << 1) + i3];
        }

        @Override // l.f
        protected Map<K, V> c() {
            return a.this;
        }

        @Override // l.f
        protected int d() {
            return a.this.f4650d;
        }

        @Override // l.f
        protected int e(Object obj) {
            return a.this.h(obj);
        }

        @Override // l.f
        protected int f(Object obj) {
            return a.this.j(obj);
        }

        @Override // l.f
        protected void g(K k2, V v2) {
            a.this.put(k2, v2);
        }

        @Override // l.f
        protected void h(int i2) {
            a.this.m(i2);
        }

        @Override // l.f
        protected V i(int i2, V v2) {
            return a.this.n(i2, v2);
        }
    }

    public a() {
    }

    public a(int i2) {
        super(i2);
    }

    public a(g gVar) {
        super(gVar);
    }

    private f<K, V> p() {
        if (this.f4600i == null) {
            this.f4600i = new C0064a();
        }
        return this.f4600i;
    }

    @Override // java.util.Map
    public Set<Map.Entry<K, V>> entrySet() {
        return p().l();
    }

    @Override // java.util.Map
    public Set<K> keySet() {
        return p().m();
    }

    @Override // java.util.Map
    public void putAll(Map<? extends K, ? extends V> map) {
        e(this.f4650d + map.size());
        for (Map.Entry<? extends K, ? extends V> entry : map.entrySet()) {
            put(entry.getKey(), entry.getValue());
        }
    }

    public boolean q(Collection<?> collection) {
        return f.p(this, collection);
    }

    @Override // java.util.Map
    public Collection<V> values() {
        return p().n();
    }
}
