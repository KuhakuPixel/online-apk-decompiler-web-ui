package w1;

import android.util.SparseIntArray;
import android.view.View;
import android.widget.FrameLayout;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.databinding.ViewDataBinding;
import com.sample.android.kuhakupixelinapppurchase.R;
/* loaded from: classes.dex */
public class h extends g {
    private static final SparseIntArray E;
    private final FrameLayout C;
    private long D;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        E = sparseIntArray;
        sparseIntArray.put(R.id.header_title, 1);
    }

    public h(androidx.databinding.e eVar, View view) {
        this(eVar, view, ViewDataBinding.u(eVar, view, 2, null, E));
    }

    private h(androidx.databinding.e eVar, View view, Object[] objArr) {
        super(eVar, view, 0, (AppCompatTextView) objArr[1]);
        this.D = -1L;
        FrameLayout frameLayout = (FrameLayout) objArr[0];
        this.C = frameLayout;
        frameLayout.setTag(null);
        D(view);
        H();
    }

    public void H() {
        synchronized (this) {
            this.D = 1L;
        }
        z();
    }

    @Override // androidx.databinding.ViewDataBinding
    protected void l() {
        synchronized (this) {
            this.D = 0L;
        }
    }

    @Override // androidx.databinding.ViewDataBinding
    public boolean r() {
        synchronized (this) {
            return this.D != 0;
        }
    }

    @Override // androidx.databinding.ViewDataBinding
    protected boolean v(int i2, Object obj, int i3) {
        return false;
    }
}
