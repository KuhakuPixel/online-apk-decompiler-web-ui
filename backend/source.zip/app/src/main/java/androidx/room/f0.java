package androidx.room;

import android.database.Cursor;
import java.util.Iterator;
import java.util.List;
import u0.c;
/* loaded from: classes.dex */
public class f0 extends c.a {

    /* renamed from: b  reason: collision with root package name */
    private h f2570b;

    /* renamed from: c  reason: collision with root package name */
    private final a f2571c;

    /* renamed from: d  reason: collision with root package name */
    private final String f2572d;

    /* renamed from: e  reason: collision with root package name */
    private final String f2573e;

    /* loaded from: classes.dex */
    public static abstract class a {

        /* renamed from: a  reason: collision with root package name */
        public final int f2574a;

        public a(int i2) {
            this.f2574a = i2;
        }

        protected abstract void a(u0.b bVar);

        protected abstract void b(u0.b bVar);

        protected abstract void c(u0.b bVar);

        protected abstract void d(u0.b bVar);

        protected abstract void e(u0.b bVar);

        protected abstract void f(u0.b bVar);

        protected abstract b g(u0.b bVar);
    }

    /* loaded from: classes.dex */
    public static class b {

        /* renamed from: a  reason: collision with root package name */
        public final boolean f2575a;

        /* renamed from: b  reason: collision with root package name */
        public final String f2576b;

        public b(boolean z2, String str) {
            this.f2575a = z2;
            this.f2576b = str;
        }
    }

    public f0(h hVar, a aVar, String str, String str2) {
        super(aVar.f2574a);
        this.f2570b = hVar;
        this.f2571c = aVar;
        this.f2572d = str;
        this.f2573e = str2;
    }

    private void h(u0.b bVar) {
        if (!k(bVar)) {
            b g2 = this.f2571c.g(bVar);
            if (g2.f2575a) {
                this.f2571c.e(bVar);
                l(bVar);
                return;
            }
            throw new IllegalStateException("Pre-packaged database has an invalid schema: " + g2.f2576b);
        }
        Cursor j2 = bVar.j(new u0.a("SELECT identity_hash FROM room_master_table WHERE id = 42 LIMIT 1"));
        try {
            String string = j2.moveToFirst() ? j2.getString(0) : null;
            j2.close();
            if (!this.f2572d.equals(string) && !this.f2573e.equals(string)) {
                throw new IllegalStateException("Room cannot verify the data integrity. Looks like you've changed schema but forgot to update the version number. You can simply fix this by increasing the version number.");
            }
        } catch (Throwable th) {
            j2.close();
            throw th;
        }
    }

    private void i(u0.b bVar) {
        bVar.g("CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)");
    }

    private static boolean j(u0.b bVar) {
        Cursor s2 = bVar.s("SELECT count(*) FROM sqlite_master WHERE name != 'android_metadata'");
        try {
            boolean z2 = false;
            if (s2.moveToFirst()) {
                if (s2.getInt(0) == 0) {
                    z2 = true;
                }
            }
            return z2;
        } finally {
            s2.close();
        }
    }

    private static boolean k(u0.b bVar) {
        Cursor s2 = bVar.s("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name='room_master_table'");
        try {
            boolean z2 = false;
            if (s2.moveToFirst()) {
                if (s2.getInt(0) != 0) {
                    z2 = true;
                }
            }
            return z2;
        } finally {
            s2.close();
        }
    }

    private void l(u0.b bVar) {
        i(bVar);
        bVar.g(r0.g.a(this.f2572d));
    }

    @Override // u0.c.a
    public void b(u0.b bVar) {
        super.b(bVar);
    }

    @Override // u0.c.a
    public void d(u0.b bVar) {
        boolean j2 = j(bVar);
        this.f2571c.a(bVar);
        if (!j2) {
            b g2 = this.f2571c.g(bVar);
            if (!g2.f2575a) {
                throw new IllegalStateException("Pre-packaged database has an invalid schema: " + g2.f2576b);
            }
        }
        l(bVar);
        this.f2571c.c(bVar);
    }

    @Override // u0.c.a
    public void e(u0.b bVar, int i2, int i3) {
        g(bVar, i2, i3);
    }

    @Override // u0.c.a
    public void f(u0.b bVar) {
        super.f(bVar);
        h(bVar);
        this.f2571c.d(bVar);
        this.f2570b = null;
    }

    @Override // u0.c.a
    public void g(u0.b bVar, int i2, int i3) {
        boolean z2;
        List<s0.a> a2;
        h hVar = this.f2570b;
        if (hVar == null || (a2 = hVar.f2595d.a(i2, i3)) == null) {
            z2 = false;
        } else {
            this.f2571c.f(bVar);
            Iterator<s0.a> it = a2.iterator();
            while (it.hasNext()) {
                it.next().a(bVar);
            }
            b g2 = this.f2571c.g(bVar);
            if (!g2.f2575a) {
                throw new IllegalStateException("Migration didn't properly handle: " + g2.f2576b);
            }
            this.f2571c.e(bVar);
            l(bVar);
            z2 = true;
        }
        if (z2) {
            return;
        }
        h hVar2 = this.f2570b;
        if (hVar2 != null && !hVar2.a(i2, i3)) {
            this.f2571c.b(bVar);
            this.f2571c.a(bVar);
            return;
        }
        throw new IllegalStateException("A migration from " + i2 + " to " + i3 + " was required but not found. Please provide the necessary Migration path via RoomDatabase.Builder.addMigration(Migration ...) or allow for destructive migrations via one of the RoomDatabase.Builder.fallbackToDestructiveMigration* methods.");
    }
}
