package a;
/* loaded from: classes.dex */
public final class d {

    /* renamed from: a */
    public static final int abc_action_bar_stacked_max_height = 2131165193;

    /* renamed from: b */
    public static final int abc_action_bar_stacked_tab_max_width = 2131165194;

    /* renamed from: c */
    public static final int abc_cascading_menus_min_smallest_width = 2131165206;

    /* renamed from: d */
    public static final int abc_config_prefDialogWidth = 2131165207;

    /* renamed from: e */
    public static final int abc_dropdownitem_icon_width = 2131165225;

    /* renamed from: f */
    public static final int abc_dropdownitem_text_padding_left = 2131165226;

    /* renamed from: g */
    public static final int abc_search_view_preferred_height = 2131165238;

    /* renamed from: h */
    public static final int abc_search_view_preferred_width = 2131165239;

    /* renamed from: i */
    public static final int tooltip_precise_anchor_extra_offset = 2131165575;

    /* renamed from: j */
    public static final int tooltip_precise_anchor_threshold = 2131165576;

    /* renamed from: k */
    public static final int tooltip_y_offset_non_touch = 2131165578;

    /* renamed from: l */
    public static final int tooltip_y_offset_touch = 2131165579;
}
