package androidx.lifecycle;
/* loaded from: classes.dex */
public class q {

    /* JADX INFO: Add missing generic type declarations: [X] */
    /* loaded from: classes.dex */
    static class a<X> implements n<X> {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ k f1873a;

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ j.a f1874b;

        a(k kVar, j.a aVar) {
            this.f1873a = kVar;
            this.f1874b = aVar;
        }

        @Override // androidx.lifecycle.n
        public void c(X x2) {
            this.f1873a.m(this.f1874b.a(x2));
        }
    }

    public static <X, Y> LiveData<Y> a(LiveData<X> liveData, j.a<X, Y> aVar) {
        k kVar = new k();
        kVar.n(liveData, new a(kVar, aVar));
        return kVar;
    }
}
