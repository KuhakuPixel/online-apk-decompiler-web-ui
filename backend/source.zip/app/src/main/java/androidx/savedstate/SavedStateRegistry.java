package androidx.savedstate;

import android.annotation.SuppressLint;
import android.os.Bundle;
import androidx.lifecycle.d;
import androidx.lifecycle.e;
import androidx.lifecycle.g;
import androidx.savedstate.Recreator;
import java.util.Map;
@SuppressLint({"RestrictedApi"})
/* loaded from: classes.dex */
public final class SavedStateRegistry {

    /* renamed from: b  reason: collision with root package name */
    private Bundle f2705b;

    /* renamed from: c  reason: collision with root package name */
    private boolean f2706c;

    /* renamed from: d  reason: collision with root package name */
    private Recreator.a f2707d;

    /* renamed from: a  reason: collision with root package name */
    private i.b<String, b> f2704a = new i.b<>();

    /* renamed from: e  reason: collision with root package name */
    boolean f2708e = true;

    /* loaded from: classes.dex */
    public interface a {
        void a(androidx.savedstate.b bVar);
    }

    /* loaded from: classes.dex */
    public interface b {
        Bundle a();
    }

    public Bundle a(String str) {
        if (this.f2706c) {
            Bundle bundle = this.f2705b;
            if (bundle != null) {
                Bundle bundle2 = bundle.getBundle(str);
                this.f2705b.remove(str);
                if (this.f2705b.isEmpty()) {
                    this.f2705b = null;
                }
                return bundle2;
            }
            return null;
        }
        throw new IllegalStateException("You can consumeRestoredStateForKey only after super.onCreate of corresponding component");
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void b(d dVar, Bundle bundle) {
        if (this.f2706c) {
            throw new IllegalStateException("SavedStateRegistry was already restored.");
        }
        if (bundle != null) {
            this.f2705b = bundle.getBundle("androidx.lifecycle.BundlableSavedStateRegistry.key");
        }
        dVar.a(new e() { // from class: androidx.savedstate.SavedStateRegistry.1
            @Override // androidx.lifecycle.e
            public void f(g gVar, d.a aVar) {
                SavedStateRegistry savedStateRegistry;
                boolean z2;
                if (aVar == d.a.ON_START) {
                    savedStateRegistry = SavedStateRegistry.this;
                    z2 = true;
                } else if (aVar != d.a.ON_STOP) {
                    return;
                } else {
                    savedStateRegistry = SavedStateRegistry.this;
                    z2 = false;
                }
                savedStateRegistry.f2708e = z2;
            }
        });
        this.f2706c = true;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void c(Bundle bundle) {
        Bundle bundle2 = new Bundle();
        Bundle bundle3 = this.f2705b;
        if (bundle3 != null) {
            bundle2.putAll(bundle3);
        }
        i.b<String, b>.d f2 = this.f2704a.f();
        while (f2.hasNext()) {
            Map.Entry next = f2.next();
            bundle2.putBundle((String) next.getKey(), ((b) next.getValue()).a());
        }
        bundle.putBundle("androidx.lifecycle.BundlableSavedStateRegistry.key", bundle2);
    }

    public void d(String str, b bVar) {
        if (this.f2704a.i(str, bVar) != null) {
            throw new IllegalArgumentException("SavedStateProvider with the given key is already registered");
        }
    }

    public void e(Class<? extends a> cls) {
        if (!this.f2708e) {
            throw new IllegalStateException("Can not perform this action after onSaveInstanceState");
        }
        if (this.f2707d == null) {
            this.f2707d = new Recreator.a(this);
        }
        try {
            cls.getDeclaredConstructor(new Class[0]);
            this.f2707d.b(cls.getName());
        } catch (NoSuchMethodException e2) {
            throw new IllegalArgumentException("Class" + cls.getSimpleName() + " must have default constructor in order to be automatically recreated", e2);
        }
    }
}
