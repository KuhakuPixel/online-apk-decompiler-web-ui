package androidx.appcompat.view.menu;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import androidx.appcompat.view.menu.k;
import java.util.ArrayList;
/* loaded from: classes.dex */
public class d extends BaseAdapter {

    /* renamed from: b  reason: collision with root package name */
    e f381b;

    /* renamed from: c  reason: collision with root package name */
    private int f382c = -1;

    /* renamed from: d  reason: collision with root package name */
    private boolean f383d;

    /* renamed from: e  reason: collision with root package name */
    private final boolean f384e;

    /* renamed from: f  reason: collision with root package name */
    private final LayoutInflater f385f;

    /* renamed from: g  reason: collision with root package name */
    private final int f386g;

    public d(e eVar, LayoutInflater layoutInflater, boolean z2, int i2) {
        this.f384e = z2;
        this.f385f = layoutInflater;
        this.f381b = eVar;
        this.f386g = i2;
        a();
    }

    void a() {
        g v2 = this.f381b.v();
        if (v2 != null) {
            ArrayList<g> z2 = this.f381b.z();
            int size = z2.size();
            for (int i2 = 0; i2 < size; i2++) {
                if (z2.get(i2) == v2) {
                    this.f382c = i2;
                    return;
                }
            }
        }
        this.f382c = -1;
    }

    public e b() {
        return this.f381b;
    }

    @Override // android.widget.Adapter
    /* renamed from: c  reason: merged with bridge method [inline-methods] */
    public g getItem(int i2) {
        ArrayList<g> z2 = this.f384e ? this.f381b.z() : this.f381b.E();
        int i3 = this.f382c;
        if (i3 >= 0 && i2 >= i3) {
            i2++;
        }
        return z2.get(i2);
    }

    public void d(boolean z2) {
        this.f383d = z2;
    }

    @Override // android.widget.Adapter
    public int getCount() {
        ArrayList<g> z2 = this.f384e ? this.f381b.z() : this.f381b.E();
        int i2 = this.f382c;
        int size = z2.size();
        return i2 < 0 ? size : size - 1;
    }

    @Override // android.widget.Adapter
    public long getItemId(int i2) {
        return i2;
    }

    @Override // android.widget.Adapter
    public View getView(int i2, View view, ViewGroup viewGroup) {
        if (view == null) {
            view = this.f385f.inflate(this.f386g, viewGroup, false);
        }
        int groupId = getItem(i2).getGroupId();
        int i3 = i2 - 1;
        ListMenuItemView listMenuItemView = (ListMenuItemView) view;
        listMenuItemView.setGroupDividerEnabled(this.f381b.F() && groupId != (i3 >= 0 ? getItem(i3).getGroupId() : groupId));
        k.a aVar = (k.a) view;
        if (this.f383d) {
            listMenuItemView.setForceShowIcon(true);
        }
        aVar.e(getItem(i2), 0);
        return view;
    }

    @Override // android.widget.BaseAdapter
    public void notifyDataSetChanged() {
        a();
        super.notifyDataSetChanged();
    }
}
