package androidx.print;
/* loaded from: classes.dex */
public final class R {
    private R() {
    }
}
