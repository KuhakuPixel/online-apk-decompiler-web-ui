package androidx.constraintlayout.widget;

import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewParent;
import p.k;
/* loaded from: classes.dex */
public abstract class j extends b {

    /* renamed from: k  reason: collision with root package name */
    private boolean f1331k;

    /* renamed from: l  reason: collision with root package name */
    private boolean f1332l;

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.constraintlayout.widget.b
    public void h(AttributeSet attributeSet) {
        super.h(attributeSet);
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, i.f1255a1);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i2 = 0; i2 < indexCount; i2++) {
                int index = obtainStyledAttributes.getIndex(i2);
                if (index == i.f1261c1) {
                    this.f1331k = true;
                } else if (index == i.f1276h1) {
                    this.f1332l = true;
                }
            }
            obtainStyledAttributes.recycle();
        }
    }

    public void o(k kVar, int i2, int i3) {
    }

    @Override // androidx.constraintlayout.widget.b, android.view.View
    public void onAttachedToWindow() {
        ViewParent parent;
        super.onAttachedToWindow();
        if ((this.f1331k || this.f1332l) && (parent = getParent()) != null && (parent instanceof ConstraintLayout)) {
            ConstraintLayout constraintLayout = (ConstraintLayout) parent;
            int visibility = getVisibility();
            float elevation = getElevation();
            for (int i2 = 0; i2 < this.f1140c; i2++) {
                View i3 = constraintLayout.i(this.f1139b[i2]);
                if (i3 != null) {
                    if (this.f1331k) {
                        i3.setVisibility(visibility);
                    }
                    if (this.f1332l && elevation > 0.0f) {
                        i3.setTranslationZ(i3.getTranslationZ() + elevation);
                    }
                }
            }
        }
    }

    @Override // android.view.View
    public void setElevation(float f2) {
        super.setElevation(f2);
        d();
    }

    @Override // android.view.View
    public void setVisibility(int i2) {
        super.setVisibility(i2);
        d();
    }
}
