package androidx.navigation;

import android.content.Context;
import android.os.Bundle;
import androidx.lifecycle.d;
import androidx.savedstate.SavedStateRegistry;
import java.util.UUID;
/* loaded from: classes.dex */
public final class e implements androidx.lifecycle.g, androidx.lifecycle.u, androidx.savedstate.b {

    /* renamed from: b  reason: collision with root package name */
    private final Context f1922b;

    /* renamed from: c  reason: collision with root package name */
    private final k f1923c;

    /* renamed from: d  reason: collision with root package name */
    private Bundle f1924d;

    /* renamed from: e  reason: collision with root package name */
    private final androidx.lifecycle.h f1925e;

    /* renamed from: f  reason: collision with root package name */
    private final androidx.savedstate.a f1926f;

    /* renamed from: g  reason: collision with root package name */
    final UUID f1927g;

    /* renamed from: h  reason: collision with root package name */
    private d.b f1928h;

    /* renamed from: i  reason: collision with root package name */
    private d.b f1929i;

    /* renamed from: j  reason: collision with root package name */
    private g f1930j;

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public static /* synthetic */ class a {

        /* renamed from: a  reason: collision with root package name */
        static final /* synthetic */ int[] f1931a;

        static {
            int[] iArr = new int[d.a.values().length];
            f1931a = iArr;
            try {
                iArr[d.a.ON_CREATE.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                f1931a[d.a.ON_STOP.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                f1931a[d.a.ON_START.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                f1931a[d.a.ON_PAUSE.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                f1931a[d.a.ON_RESUME.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                f1931a[d.a.ON_DESTROY.ordinal()] = 6;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                f1931a[d.a.ON_ANY.ordinal()] = 7;
            } catch (NoSuchFieldError unused7) {
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public e(Context context, k kVar, Bundle bundle, androidx.lifecycle.g gVar, g gVar2) {
        this(context, kVar, bundle, gVar, gVar2, UUID.randomUUID(), null);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public e(Context context, k kVar, Bundle bundle, androidx.lifecycle.g gVar, g gVar2, UUID uuid, Bundle bundle2) {
        this.f1925e = new androidx.lifecycle.h(this);
        androidx.savedstate.a a2 = androidx.savedstate.a.a(this);
        this.f1926f = a2;
        this.f1928h = d.b.CREATED;
        this.f1929i = d.b.RESUMED;
        this.f1922b = context;
        this.f1927g = uuid;
        this.f1923c = kVar;
        this.f1924d = bundle;
        this.f1930j = gVar2;
        a2.c(bundle2);
        if (gVar != null) {
            this.f1928h = gVar.a().b();
        }
    }

    private static d.b h(d.a aVar) {
        switch (a.f1931a[aVar.ordinal()]) {
            case 1:
            case 2:
                return d.b.CREATED;
            case 3:
            case 4:
                return d.b.STARTED;
            case 5:
                return d.b.RESUMED;
            case 6:
                return d.b.DESTROYED;
            default:
                throw new IllegalArgumentException("Unexpected event value " + aVar);
        }
    }

    @Override // androidx.lifecycle.g
    public androidx.lifecycle.d a() {
        return this.f1925e;
    }

    @Override // androidx.savedstate.b
    public SavedStateRegistry c() {
        return this.f1926f.b();
    }

    public Bundle d() {
        return this.f1924d;
    }

    public k e() {
        return this.f1923c;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public d.b f() {
        return this.f1929i;
    }

    @Override // androidx.lifecycle.u
    public androidx.lifecycle.t g() {
        g gVar = this.f1930j;
        if (gVar != null) {
            return gVar.g(this.f1927g);
        }
        throw new IllegalStateException("You must call setViewModelStore() on your NavHostController before accessing the ViewModelStore of a navigation graph.");
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void i(d.a aVar) {
        this.f1928h = h(aVar);
        m();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void j(Bundle bundle) {
        this.f1924d = bundle;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void k(Bundle bundle) {
        this.f1926f.d(bundle);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void l(d.b bVar) {
        this.f1929i = bVar;
        m();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void m() {
        androidx.lifecycle.h hVar;
        d.b bVar;
        if (this.f1928h.ordinal() < this.f1929i.ordinal()) {
            hVar = this.f1925e;
            bVar = this.f1928h;
        } else {
            hVar = this.f1925e;
            bVar = this.f1929i;
        }
        hVar.p(bVar);
    }
}
