package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.Menu;
import android.view.ViewGroup;
import android.view.Window;
import androidx.appcompat.view.menu.e;
import androidx.appcompat.view.menu.j;
/* loaded from: classes.dex */
public interface b0 {
    void a(Menu menu, j.a aVar);

    boolean b();

    boolean c();

    void collapseActionView();

    boolean d();

    boolean e();

    void f();

    boolean g();

    CharSequence getTitle();

    void h();

    void i(j.a aVar, e.a aVar2);

    int j();

    void k(int i2);

    Menu l();

    void m(int i2);

    void n(m0 m0Var);

    ViewGroup o();

    void p(boolean z2);

    Context q();

    int r();

    e0.u s(int i2, long j2);

    void setIcon(int i2);

    void setIcon(Drawable drawable);

    void setWindowCallback(Window.Callback callback);

    void setWindowTitle(CharSequence charSequence);

    void t();

    boolean u();

    void v();

    void w(boolean z2);

    void x(int i2);
}
