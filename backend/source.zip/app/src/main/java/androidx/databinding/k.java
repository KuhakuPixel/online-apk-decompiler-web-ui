package androidx.databinding;

import androidx.databinding.ViewDataBinding;
/* loaded from: classes.dex */
public abstract class k<T extends ViewDataBinding> {
    public void a(T t2) {
    }

    public void b(T t2) {
    }

    public boolean c(T t2) {
        return true;
    }
}
