package androidx.constraintlayout.widget;

import com.sample.android.kuhakupixelinapppurchase.R;
/* loaded from: classes.dex */
public final class i {
    public static final int A = 8;
    public static final int A0 = 83;
    public static final int A1 = 51;
    public static final int A2 = 27;
    public static final int A3 = 34;
    public static final int A4 = 3;
    public static final int B = 13;
    public static final int B0 = 84;
    public static final int B1 = 52;
    public static final int B2 = 28;
    public static final int B3 = 35;
    public static final int B4 = 4;
    public static final int C = 14;
    public static final int C0 = 85;
    public static final int C1 = 53;
    public static final int C3 = 36;
    public static final int D = 15;
    public static final int D0 = 86;
    public static final int D1 = 54;
    public static final int D2 = 0;
    public static final int D3 = 37;
    public static final int E = 16;
    public static final int E0 = 87;
    public static final int E1 = 55;
    public static final int E2 = 1;
    public static final int E3 = 38;
    public static final int F = 17;
    public static final int F0 = 88;
    public static final int F1 = 56;
    public static final int F2 = 2;
    public static final int F3 = 39;
    public static final int G = 18;
    public static final int G0 = 89;
    public static final int G1 = 57;
    public static final int G2 = 3;
    public static final int G3 = 40;
    public static final int G4 = 0;
    public static final int H = 19;
    public static final int H0 = 90;
    public static final int H1 = 58;
    public static final int H2 = 4;
    public static final int H3 = 41;
    public static final int H4 = 1;
    public static final int I = 20;
    public static final int I0 = 91;
    public static final int I1 = 59;
    public static final int I2 = 5;
    public static final int I3 = 42;
    public static final int J = 21;
    public static final int J0 = 92;
    public static final int J1 = 60;
    public static final int J2 = 6;
    public static final int J3 = 43;
    public static final int K = 22;
    public static final int K0 = 93;
    public static final int K1 = 61;
    public static final int K2 = 7;
    public static final int K3 = 44;
    public static final int L = 23;
    public static final int L0 = 94;
    public static final int L1 = 62;
    public static final int L2 = 8;
    public static final int L3 = 45;
    public static final int M = 24;
    public static final int M0 = 95;
    public static final int M1 = 63;
    public static final int M3 = 46;
    public static final int N = 25;
    public static final int N0 = 96;
    public static final int N1 = 64;
    public static final int N3 = 47;
    public static final int O = 26;
    public static final int O0 = 97;
    public static final int O1 = 65;
    public static final int O3 = 48;
    public static final int P = 27;
    public static final int P0 = 98;
    public static final int P1 = 66;
    public static final int P3 = 49;
    public static final int P4 = 0;
    public static final int Q = 28;
    public static final int Q0 = 99;
    public static final int Q1 = 67;
    public static final int Q3 = 50;
    public static final int Q4 = 1;
    public static final int R = 29;
    public static final int R0 = 100;
    public static final int R1 = 68;
    public static final int R3 = 51;
    public static final int R4 = 2;
    public static final int S = 30;
    public static final int S0 = 101;
    public static final int S1 = 69;
    public static final int S3 = 55;
    public static final int S4 = 3;
    public static final int T = 31;
    public static final int T0 = 102;
    public static final int T1 = 70;
    public static final int T3 = 56;
    public static final int T4 = 4;
    public static final int U = 32;
    public static final int U0 = 103;
    public static final int U1 = 71;
    public static final int U3 = 57;
    public static final int U4 = 5;
    public static final int V = 34;
    public static final int V0 = 104;
    public static final int V1 = 72;
    public static final int V3 = 58;
    public static final int V4 = 6;
    public static final int W = 53;
    public static final int W0 = 105;
    public static final int W1 = 73;
    public static final int W3 = 59;
    public static final int W4 = 7;
    public static final int X = 54;
    public static final int X0 = 107;
    public static final int X1 = 74;
    public static final int X3 = 60;
    public static final int X4 = 8;
    public static final int Y = 55;
    public static final int Y0 = 108;
    public static final int Y1 = 75;
    public static final int Y2 = 0;
    public static final int Y3 = 61;
    public static final int Y4 = 9;
    public static final int Z = 56;
    public static final int Z0 = 109;
    public static final int Z1 = 76;
    public static final int Z2 = 1;
    public static final int Z3 = 62;
    public static final int Z4 = 10;

    /* renamed from: a0  reason: collision with root package name */
    public static final int f1254a0 = 57;
    public static final int a2 = 77;
    public static final int a3 = 2;
    public static final int a4 = 63;

    /* renamed from: b0  reason: collision with root package name */
    public static final int f1257b0 = 58;

    /* renamed from: b1  reason: collision with root package name */
    public static final int f1258b1 = 0;
    public static final int b2 = 78;
    public static final int b3 = 3;

    /* renamed from: c0  reason: collision with root package name */
    public static final int f1260c0 = 59;

    /* renamed from: c1  reason: collision with root package name */
    public static final int f1261c1 = 6;
    public static final int c2 = 79;
    public static final int c3 = 4;
    public static final int c5 = 0;

    /* renamed from: d0  reason: collision with root package name */
    public static final int f1263d0 = 60;

    /* renamed from: d1  reason: collision with root package name */
    public static final int f1264d1 = 7;
    public static final int d2 = 80;
    public static final int d3 = 5;
    public static final int d5 = 1;

    /* renamed from: e0  reason: collision with root package name */
    public static final int f1266e0 = 61;

    /* renamed from: e1  reason: collision with root package name */
    public static final int f1267e1 = 8;
    public static final int e2 = 81;
    public static final int e3 = 6;
    public static final int e5 = 2;

    /* renamed from: f0  reason: collision with root package name */
    public static final int f1269f0 = 62;

    /* renamed from: f1  reason: collision with root package name */
    public static final int f1270f1 = 9;
    public static final int f2 = 82;
    public static final int f3 = 7;
    public static final int f5 = 3;

    /* renamed from: g0  reason: collision with root package name */
    public static final int f1272g0 = 63;

    /* renamed from: g1  reason: collision with root package name */
    public static final int f1273g1 = 10;
    public static final int g2 = 83;
    public static final int g3 = 8;
    public static final int g5 = 4;

    /* renamed from: h0  reason: collision with root package name */
    public static final int f1275h0 = 64;

    /* renamed from: h1  reason: collision with root package name */
    public static final int f1276h1 = 13;
    public static final int h2 = 84;
    public static final int h3 = 9;

    /* renamed from: i0  reason: collision with root package name */
    public static final int f1278i0 = 65;

    /* renamed from: i1  reason: collision with root package name */
    public static final int f1279i1 = 14;
    public static final int i2 = 85;
    public static final int i3 = 10;

    /* renamed from: j0  reason: collision with root package name */
    public static final int f1281j0 = 66;

    /* renamed from: j1  reason: collision with root package name */
    public static final int f1282j1 = 15;
    public static final int j2 = 86;
    public static final int j3 = 11;
    public static final int j4 = 0;

    /* renamed from: k0  reason: collision with root package name */
    public static final int f1284k0 = 67;

    /* renamed from: k1  reason: collision with root package name */
    public static final int f1285k1 = 16;
    public static final int k2 = 87;
    public static final int k3 = 12;
    public static final int k4 = 1;

    /* renamed from: l0  reason: collision with root package name */
    public static final int f1287l0 = 68;

    /* renamed from: l1  reason: collision with root package name */
    public static final int f1288l1 = 18;
    public static final int l2 = 88;
    public static final int l3 = 13;
    public static final int l4 = 2;

    /* renamed from: m0  reason: collision with root package name */
    public static final int f1290m0 = 69;

    /* renamed from: m1  reason: collision with root package name */
    public static final int f1291m1 = 19;
    public static final int m2 = 89;
    public static final int m3 = 17;
    public static final int m4 = 3;

    /* renamed from: n0  reason: collision with root package name */
    public static final int f1293n0 = 70;

    /* renamed from: n1  reason: collision with root package name */
    public static final int f1294n1 = 20;
    public static final int n2 = 90;
    public static final int n3 = 18;
    public static final int n4 = 4;

    /* renamed from: o0  reason: collision with root package name */
    public static final int f1296o0 = 71;

    /* renamed from: o1  reason: collision with root package name */
    public static final int f1297o1 = 39;
    public static final int o3 = 19;
    public static final int o4 = 5;

    /* renamed from: p0  reason: collision with root package name */
    public static final int f1299p0 = 72;

    /* renamed from: p1  reason: collision with root package name */
    public static final int f1300p1 = 40;
    public static final int p3 = 20;

    /* renamed from: q0  reason: collision with root package name */
    public static final int f1302q0 = 73;

    /* renamed from: q1  reason: collision with root package name */
    public static final int f1303q1 = 41;
    public static final int q2 = 15;
    public static final int q3 = 21;

    /* renamed from: r0  reason: collision with root package name */
    public static final int f1305r0 = 74;

    /* renamed from: r1  reason: collision with root package name */
    public static final int f1306r1 = 42;
    public static final int r2 = 16;
    public static final int r3 = 22;

    /* renamed from: s  reason: collision with root package name */
    public static final int f1307s = 0;

    /* renamed from: s0  reason: collision with root package name */
    public static final int f1308s0 = 75;

    /* renamed from: s1  reason: collision with root package name */
    public static final int f1309s1 = 43;
    public static final int s2 = 17;
    public static final int s3 = 23;

    /* renamed from: t  reason: collision with root package name */
    public static final int f1310t = 1;

    /* renamed from: t0  reason: collision with root package name */
    public static final int f1311t0 = 76;

    /* renamed from: t1  reason: collision with root package name */
    public static final int f1312t1 = 44;
    public static final int t2 = 18;
    public static final int t3 = 24;

    /* renamed from: u  reason: collision with root package name */
    public static final int f1313u = 2;

    /* renamed from: u0  reason: collision with root package name */
    public static final int f1314u0 = 77;

    /* renamed from: u1  reason: collision with root package name */
    public static final int f1315u1 = 45;
    public static final int u2 = 19;
    public static final int u3 = 25;

    /* renamed from: v  reason: collision with root package name */
    public static final int f1316v = 3;

    /* renamed from: v0  reason: collision with root package name */
    public static final int f1317v0 = 78;

    /* renamed from: v1  reason: collision with root package name */
    public static final int f1318v1 = 46;
    public static final int v2 = 20;
    public static final int v3 = 26;

    /* renamed from: w  reason: collision with root package name */
    public static final int f1319w = 4;

    /* renamed from: w0  reason: collision with root package name */
    public static final int f1320w0 = 79;

    /* renamed from: w1  reason: collision with root package name */
    public static final int f1321w1 = 47;
    public static final int w2 = 21;
    public static final int w3 = 27;

    /* renamed from: x  reason: collision with root package name */
    public static final int f1322x = 5;

    /* renamed from: x0  reason: collision with root package name */
    public static final int f1323x0 = 80;

    /* renamed from: x1  reason: collision with root package name */
    public static final int f1324x1 = 48;
    public static final int x2 = 22;
    public static final int x3 = 28;

    /* renamed from: y  reason: collision with root package name */
    public static final int f1325y = 6;

    /* renamed from: y0  reason: collision with root package name */
    public static final int f1326y0 = 81;

    /* renamed from: y1  reason: collision with root package name */
    public static final int f1327y1 = 49;
    public static final int y2 = 23;
    public static final int y3 = 29;
    public static final int y4 = 0;

    /* renamed from: z  reason: collision with root package name */
    public static final int f1328z = 7;

    /* renamed from: z0  reason: collision with root package name */
    public static final int f1329z0 = 82;

    /* renamed from: z1  reason: collision with root package name */
    public static final int f1330z1 = 50;
    public static final int z2 = 24;
    public static final int z3 = 30;
    public static final int z4 = 1;

    /* renamed from: a  reason: collision with root package name */
    public static final int[] f1253a = {R.attr.background, R.attr.backgroundSplit, R.attr.backgroundStacked, R.attr.contentInsetEnd, R.attr.contentInsetEndWithActions, R.attr.contentInsetLeft, R.attr.contentInsetRight, R.attr.contentInsetStart, R.attr.contentInsetStartWithNavigation, R.attr.customNavigationLayout, R.attr.displayOptions, R.attr.divider, R.attr.elevation, R.attr.height, R.attr.hideOnContentScroll, R.attr.homeAsUpIndicator, R.attr.homeLayout, R.attr.icon, R.attr.indeterminateProgressStyle, R.attr.itemPadding, R.attr.logo, R.attr.navigationMode, R.attr.popupTheme, R.attr.progressBarPadding, R.attr.progressBarStyle, R.attr.subtitle, R.attr.subtitleTextStyle, R.attr.title, R.attr.titleTextStyle};

    /* renamed from: b  reason: collision with root package name */
    public static final int[] f1256b = {16842931};

    /* renamed from: c  reason: collision with root package name */
    public static final int[] f1259c = {16843071};

    /* renamed from: d  reason: collision with root package name */
    public static final int[] f1262d = {R.attr.background, R.attr.backgroundSplit, R.attr.closeItemLayout, R.attr.height, R.attr.subtitleTextStyle, R.attr.titleTextStyle};

    /* renamed from: e  reason: collision with root package name */
    public static final int[] f1265e = {R.attr.expandActivityOverflowButtonDrawable, R.attr.initialActivityCount};

    /* renamed from: f  reason: collision with root package name */
    public static final int[] f1268f = {16842994, R.attr.buttonIconDimen, R.attr.buttonPanelSideLayout, R.attr.listItemLayout, R.attr.listLayout, R.attr.multiChoiceItemLayout, R.attr.showTitle, R.attr.singleChoiceItemLayout};

    /* renamed from: g  reason: collision with root package name */
    public static final int[] f1271g = {16843036, 16843156, 16843157, 16843158, 16843532, 16843533};

    /* renamed from: h  reason: collision with root package name */
    public static final int[] f1274h = {16842960, 16843161};

    /* renamed from: i  reason: collision with root package name */
    public static final int[] f1277i = {16843161, 16843849, 16843850, 16843851};

    /* renamed from: j  reason: collision with root package name */
    public static final int[] f1280j = {16843033, R.attr.srcCompat, R.attr.tint, R.attr.tintMode};

    /* renamed from: k  reason: collision with root package name */
    public static final int[] f1283k = {16843074, R.attr.tickMark, R.attr.tickMarkTint, R.attr.tickMarkTintMode};

    /* renamed from: l  reason: collision with root package name */
    public static final int[] f1286l = {16842804, 16843117, 16843118, 16843119, 16843120, 16843666, 16843667};

    /* renamed from: m  reason: collision with root package name */
    public static final int[] f1289m = {16842804, R.attr.autoSizeMaxTextSize, R.attr.autoSizeMinTextSize, R.attr.autoSizePresetSizes, R.attr.autoSizeStepGranularity, R.attr.autoSizeTextType, R.attr.drawableBottomCompat, R.attr.drawableEndCompat, R.attr.drawableLeftCompat, R.attr.drawableRightCompat, R.attr.drawableStartCompat, R.attr.drawableTint, R.attr.drawableTintMode, R.attr.drawableTopCompat, R.attr.firstBaselineToTopHeight, R.attr.fontFamily, R.attr.fontVariationSettings, R.attr.lastBaselineToBottomHeight, R.attr.lineHeight, R.attr.textAllCaps, R.attr.textLocale};

    /* renamed from: n  reason: collision with root package name */
    public static final int[] f1292n = {16842839, 16842926, R.attr.actionBarDivider, R.attr.actionBarItemBackground, R.attr.actionBarPopupTheme, R.attr.actionBarSize, R.attr.actionBarSplitStyle, R.attr.actionBarStyle, R.attr.actionBarTabBarStyle, R.attr.actionBarTabStyle, R.attr.actionBarTabTextStyle, R.attr.actionBarTheme, R.attr.actionBarWidgetTheme, R.attr.actionButtonStyle, R.attr.actionDropDownStyle, R.attr.actionMenuTextAppearance, R.attr.actionMenuTextColor, R.attr.actionModeBackground, R.attr.actionModeCloseButtonStyle, R.attr.actionModeCloseDrawable, R.attr.actionModeCopyDrawable, R.attr.actionModeCutDrawable, R.attr.actionModeFindDrawable, R.attr.actionModePasteDrawable, R.attr.actionModePopupWindowStyle, R.attr.actionModeSelectAllDrawable, R.attr.actionModeShareDrawable, R.attr.actionModeSplitBackground, R.attr.actionModeStyle, R.attr.actionModeWebSearchDrawable, R.attr.actionOverflowButtonStyle, R.attr.actionOverflowMenuStyle, R.attr.activityChooserViewStyle, R.attr.alertDialogButtonGroupStyle, R.attr.alertDialogCenterButtons, R.attr.alertDialogStyle, R.attr.alertDialogTheme, R.attr.autoCompleteTextViewStyle, R.attr.borderlessButtonStyle, R.attr.buttonBarButtonStyle, R.attr.buttonBarNegativeButtonStyle, R.attr.buttonBarNeutralButtonStyle, R.attr.buttonBarPositiveButtonStyle, R.attr.buttonBarStyle, R.attr.buttonStyle, R.attr.buttonStyleSmall, R.attr.checkboxStyle, R.attr.checkedTextViewStyle, R.attr.colorAccent, R.attr.colorBackgroundFloating, R.attr.colorButtonNormal, R.attr.colorControlActivated, R.attr.colorControlHighlight, R.attr.colorControlNormal, R.attr.colorError, R.attr.colorPrimary, R.attr.colorPrimaryDark, R.attr.colorSwitchThumbNormal, R.attr.controlBackground, R.attr.dialogCornerRadius, R.attr.dialogPreferredPadding, R.attr.dialogTheme, R.attr.dividerHorizontal, R.attr.dividerVertical, R.attr.dropDownListViewStyle, R.attr.dropdownListPreferredItemHeight, R.attr.editTextBackground, R.attr.editTextColor, R.attr.editTextStyle, R.attr.homeAsUpIndicator, R.attr.imageButtonStyle, R.attr.listChoiceBackgroundIndicator, R.attr.listChoiceIndicatorMultipleAnimated, R.attr.listChoiceIndicatorSingleAnimated, R.attr.listDividerAlertDialog, R.attr.listMenuViewStyle, R.attr.listPopupWindowStyle, R.attr.listPreferredItemHeight, R.attr.listPreferredItemHeightLarge, R.attr.listPreferredItemHeightSmall, R.attr.listPreferredItemPaddingEnd, R.attr.listPreferredItemPaddingLeft, R.attr.listPreferredItemPaddingRight, R.attr.listPreferredItemPaddingStart, R.attr.panelBackground, R.attr.panelMenuListTheme, R.attr.panelMenuListWidth, R.attr.popupMenuStyle, R.attr.popupWindowStyle, R.attr.radioButtonStyle, R.attr.ratingBarStyle, R.attr.ratingBarStyleIndicator, R.attr.ratingBarStyleSmall, R.attr.searchViewStyle, R.attr.seekBarStyle, R.attr.selectableItemBackground, R.attr.selectableItemBackgroundBorderless, R.attr.spinnerDropDownItemStyle, R.attr.spinnerStyle, R.attr.switchStyle, R.attr.textAppearanceLargePopupMenu, R.attr.textAppearanceListItem, R.attr.textAppearanceListItemSecondary, R.attr.textAppearanceListItemSmall, R.attr.textAppearancePopupMenuHeader, R.attr.textAppearanceSearchResultSubtitle, R.attr.textAppearanceSearchResultTitle, R.attr.textAppearanceSmallPopupMenu, R.attr.textColorAlertDialogListItem, R.attr.textColorSearchUrl, R.attr.toolbarNavigationButtonStyle, R.attr.toolbarStyle, R.attr.tooltipForegroundColor, R.attr.tooltipFrameBackground, R.attr.viewInflaterClass, R.attr.windowActionBar, R.attr.windowActionBarOverlay, R.attr.windowActionModeOverlay, R.attr.windowFixedHeightMajor, R.attr.windowFixedHeightMinor, R.attr.windowFixedWidthMajor, R.attr.windowFixedWidthMinor, R.attr.windowMinWidthMajor, R.attr.windowMinWidthMinor, R.attr.windowNoTitle};

    /* renamed from: o  reason: collision with root package name */
    public static final int[] f1295o = {R.attr.allowStacking};

    /* renamed from: p  reason: collision with root package name */
    public static final int[] f1298p = {16843173, 16843551, R.attr.alpha};

    /* renamed from: q  reason: collision with root package name */
    public static final int[] f1301q = {16843015, R.attr.buttonCompat, R.attr.buttonTint, R.attr.buttonTintMode};

    /* renamed from: r  reason: collision with root package name */
    public static final int[] f1304r = {16842948, 16842960, 16842972, 16842996, 16842997, 16842999, 16843000, 16843001, 16843002, 16843039, 16843040, 16843071, 16843072, 16843551, 16843552, 16843553, 16843554, 16843555, 16843556, 16843557, 16843558, 16843559, 16843560, 16843701, 16843702, 16843770, 16843840, R.attr.animate_relativeTo, R.attr.barrierAllowsGoneWidgets, R.attr.barrierDirection, R.attr.barrierMargin, R.attr.chainUseRtl, R.attr.constraint_referenced_ids, R.attr.constraint_referenced_tags, R.attr.drawPath, R.attr.flow_firstHorizontalBias, R.attr.flow_firstHorizontalStyle, R.attr.flow_firstVerticalBias, R.attr.flow_firstVerticalStyle, R.attr.flow_horizontalAlign, R.attr.flow_horizontalBias, R.attr.flow_horizontalGap, R.attr.flow_horizontalStyle, R.attr.flow_lastHorizontalBias, R.attr.flow_lastHorizontalStyle, R.attr.flow_lastVerticalBias, R.attr.flow_lastVerticalStyle, R.attr.flow_maxElementsWrap, R.attr.flow_verticalAlign, R.attr.flow_verticalBias, R.attr.flow_verticalGap, R.attr.flow_verticalStyle, R.attr.flow_wrapMode, R.attr.layout_constrainedHeight, R.attr.layout_constrainedWidth, R.attr.layout_constraintBaseline_creator, R.attr.layout_constraintBaseline_toBaselineOf, R.attr.layout_constraintBottom_creator, R.attr.layout_constraintBottom_toBottomOf, R.attr.layout_constraintBottom_toTopOf, R.attr.layout_constraintCircle, R.attr.layout_constraintCircleAngle, R.attr.layout_constraintCircleRadius, R.attr.layout_constraintDimensionRatio, R.attr.layout_constraintEnd_toEndOf, R.attr.layout_constraintEnd_toStartOf, R.attr.layout_constraintGuide_begin, R.attr.layout_constraintGuide_end, R.attr.layout_constraintGuide_percent, R.attr.layout_constraintHeight_default, R.attr.layout_constraintHeight_max, R.attr.layout_constraintHeight_min, R.attr.layout_constraintHeight_percent, R.attr.layout_constraintHorizontal_bias, R.attr.layout_constraintHorizontal_chainStyle, R.attr.layout_constraintHorizontal_weight, R.attr.layout_constraintLeft_creator, R.attr.layout_constraintLeft_toLeftOf, R.attr.layout_constraintLeft_toRightOf, R.attr.layout_constraintRight_creator, R.attr.layout_constraintRight_toLeftOf, R.attr.layout_constraintRight_toRightOf, R.attr.layout_constraintStart_toEndOf, R.attr.layout_constraintStart_toStartOf, R.attr.layout_constraintTag, R.attr.layout_constraintTop_creator, R.attr.layout_constraintTop_toBottomOf, R.attr.layout_constraintTop_toTopOf, R.attr.layout_constraintVertical_bias, R.attr.layout_constraintVertical_chainStyle, R.attr.layout_constraintVertical_weight, R.attr.layout_constraintWidth_default, R.attr.layout_constraintWidth_max, R.attr.layout_constraintWidth_min, R.attr.layout_constraintWidth_percent, R.attr.layout_editor_absoluteX, R.attr.layout_editor_absoluteY, R.attr.layout_goneMarginBottom, R.attr.layout_goneMarginEnd, R.attr.layout_goneMarginLeft, R.attr.layout_goneMarginRight, R.attr.layout_goneMarginStart, R.attr.layout_goneMarginTop, R.attr.motionProgress, R.attr.motionStagger, R.attr.pathMotionArc, R.attr.pivotAnchor, R.attr.transitionEasing, R.attr.transitionPathRotate, R.attr.visibilityMode};

    /* renamed from: a1  reason: collision with root package name */
    public static final int[] f1255a1 = {16842948, 16842965, 16842966, 16842967, 16842968, 16842969, 16842972, 16843039, 16843040, 16843071, 16843072, 16843699, 16843700, 16843840, R.attr.barrierAllowsGoneWidgets, R.attr.barrierDirection, R.attr.barrierMargin, R.attr.chainUseRtl, R.attr.constraintSet, R.attr.constraint_referenced_ids, R.attr.constraint_referenced_tags, R.attr.flow_firstHorizontalBias, R.attr.flow_firstHorizontalStyle, R.attr.flow_firstVerticalBias, R.attr.flow_firstVerticalStyle, R.attr.flow_horizontalAlign, R.attr.flow_horizontalBias, R.attr.flow_horizontalGap, R.attr.flow_horizontalStyle, R.attr.flow_lastHorizontalBias, R.attr.flow_lastHorizontalStyle, R.attr.flow_lastVerticalBias, R.attr.flow_lastVerticalStyle, R.attr.flow_maxElementsWrap, R.attr.flow_verticalAlign, R.attr.flow_verticalBias, R.attr.flow_verticalGap, R.attr.flow_verticalStyle, R.attr.flow_wrapMode, R.attr.layoutDescription, R.attr.layout_constrainedHeight, R.attr.layout_constrainedWidth, R.attr.layout_constraintBaseline_creator, R.attr.layout_constraintBaseline_toBaselineOf, R.attr.layout_constraintBottom_creator, R.attr.layout_constraintBottom_toBottomOf, R.attr.layout_constraintBottom_toTopOf, R.attr.layout_constraintCircle, R.attr.layout_constraintCircleAngle, R.attr.layout_constraintCircleRadius, R.attr.layout_constraintDimensionRatio, R.attr.layout_constraintEnd_toEndOf, R.attr.layout_constraintEnd_toStartOf, R.attr.layout_constraintGuide_begin, R.attr.layout_constraintGuide_end, R.attr.layout_constraintGuide_percent, R.attr.layout_constraintHeight_default, R.attr.layout_constraintHeight_max, R.attr.layout_constraintHeight_min, R.attr.layout_constraintHeight_percent, R.attr.layout_constraintHorizontal_bias, R.attr.layout_constraintHorizontal_chainStyle, R.attr.layout_constraintHorizontal_weight, R.attr.layout_constraintLeft_creator, R.attr.layout_constraintLeft_toLeftOf, R.attr.layout_constraintLeft_toRightOf, R.attr.layout_constraintRight_creator, R.attr.layout_constraintRight_toLeftOf, R.attr.layout_constraintRight_toRightOf, R.attr.layout_constraintStart_toEndOf, R.attr.layout_constraintStart_toStartOf, R.attr.layout_constraintTag, R.attr.layout_constraintTop_creator, R.attr.layout_constraintTop_toBottomOf, R.attr.layout_constraintTop_toTopOf, R.attr.layout_constraintVertical_bias, R.attr.layout_constraintVertical_chainStyle, R.attr.layout_constraintVertical_weight, R.attr.layout_constraintWidth_default, R.attr.layout_constraintWidth_max, R.attr.layout_constraintWidth_min, R.attr.layout_constraintWidth_percent, R.attr.layout_editor_absoluteX, R.attr.layout_editor_absoluteY, R.attr.layout_goneMarginBottom, R.attr.layout_goneMarginEnd, R.attr.layout_goneMarginLeft, R.attr.layout_goneMarginRight, R.attr.layout_goneMarginStart, R.attr.layout_goneMarginTop, R.attr.layout_optimizationLevel};
    public static final int[] o2 = {R.attr.content, R.attr.placeholder_emptyVisibility};
    public static final int[] p2 = {16842948, 16842960, 16842972, 16842996, 16842997, 16842999, 16843000, 16843001, 16843002, 16843039, 16843040, 16843071, 16843072, 16843189, 16843190, 16843551, 16843552, 16843553, 16843554, 16843555, 16843556, 16843557, 16843558, 16843559, 16843560, 16843701, 16843702, 16843770, 16843840, R.attr.animate_relativeTo, R.attr.barrierAllowsGoneWidgets, R.attr.barrierDirection, R.attr.barrierMargin, R.attr.chainUseRtl, R.attr.constraint_referenced_ids, R.attr.constraint_referenced_tags, R.attr.deriveConstraintsFrom, R.attr.drawPath, R.attr.flow_firstHorizontalBias, R.attr.flow_firstHorizontalStyle, R.attr.flow_firstVerticalBias, R.attr.flow_firstVerticalStyle, R.attr.flow_horizontalAlign, R.attr.flow_horizontalBias, R.attr.flow_horizontalGap, R.attr.flow_horizontalStyle, R.attr.flow_lastHorizontalBias, R.attr.flow_lastHorizontalStyle, R.attr.flow_lastVerticalBias, R.attr.flow_lastVerticalStyle, R.attr.flow_maxElementsWrap, R.attr.flow_verticalAlign, R.attr.flow_verticalBias, R.attr.flow_verticalGap, R.attr.flow_verticalStyle, R.attr.flow_wrapMode, R.attr.layout_constrainedHeight, R.attr.layout_constrainedWidth, R.attr.layout_constraintBaseline_creator, R.attr.layout_constraintBaseline_toBaselineOf, R.attr.layout_constraintBottom_creator, R.attr.layout_constraintBottom_toBottomOf, R.attr.layout_constraintBottom_toTopOf, R.attr.layout_constraintCircle, R.attr.layout_constraintCircleAngle, R.attr.layout_constraintCircleRadius, R.attr.layout_constraintDimensionRatio, R.attr.layout_constraintEnd_toEndOf, R.attr.layout_constraintEnd_toStartOf, R.attr.layout_constraintGuide_begin, R.attr.layout_constraintGuide_end, R.attr.layout_constraintGuide_percent, R.attr.layout_constraintHeight_default, R.attr.layout_constraintHeight_max, R.attr.layout_constraintHeight_min, R.attr.layout_constraintHeight_percent, R.attr.layout_constraintHorizontal_bias, R.attr.layout_constraintHorizontal_chainStyle, R.attr.layout_constraintHorizontal_weight, R.attr.layout_constraintLeft_creator, R.attr.layout_constraintLeft_toLeftOf, R.attr.layout_constraintLeft_toRightOf, R.attr.layout_constraintRight_creator, R.attr.layout_constraintRight_toLeftOf, R.attr.layout_constraintRight_toRightOf, R.attr.layout_constraintStart_toEndOf, R.attr.layout_constraintStart_toStartOf, R.attr.layout_constraintTag, R.attr.layout_constraintTop_creator, R.attr.layout_constraintTop_toBottomOf, R.attr.layout_constraintTop_toTopOf, R.attr.layout_constraintVertical_bias, R.attr.layout_constraintVertical_chainStyle, R.attr.layout_constraintVertical_weight, R.attr.layout_constraintWidth_default, R.attr.layout_constraintWidth_max, R.attr.layout_constraintWidth_min, R.attr.layout_constraintWidth_percent, R.attr.layout_editor_absoluteX, R.attr.layout_editor_absoluteY, R.attr.layout_goneMarginBottom, R.attr.layout_goneMarginEnd, R.attr.layout_goneMarginLeft, R.attr.layout_goneMarginRight, R.attr.layout_goneMarginStart, R.attr.layout_goneMarginTop, R.attr.motionProgress, R.attr.motionStagger, R.attr.pathMotionArc, R.attr.pivotAnchor, R.attr.transitionEasing, R.attr.transitionPathRotate};
    public static final int[] C2 = {R.attr.attributeName, R.attr.customBoolean, R.attr.customColorDrawableValue, R.attr.customColorValue, R.attr.customDimension, R.attr.customFloatValue, R.attr.customIntegerValue, R.attr.customPixelDimension, R.attr.customStringValue};
    public static final int[] M2 = {R.attr.arrowHeadLength, R.attr.arrowShaftLength, R.attr.barLength, R.attr.color, R.attr.drawableSize, R.attr.gapBetweenBars, R.attr.spinBars, R.attr.thickness};
    public static final int[] N2 = {R.attr.fontProviderAuthority, R.attr.fontProviderCerts, R.attr.fontProviderFetchStrategy, R.attr.fontProviderFetchTimeout, R.attr.fontProviderPackage, R.attr.fontProviderQuery};
    public static final int[] O2 = {16844082, 16844083, 16844095, 16844143, 16844144, R.attr.font, R.attr.fontStyle, R.attr.fontVariationSettings, R.attr.fontWeight, R.attr.ttcIndex};
    public static final int[] P2 = {16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 16844050, 16844051};
    public static final int[] Q2 = {16843173, 16844052};
    public static final int[] R2 = {R.attr.altSrc, R.attr.brightness, R.attr.contrast, R.attr.crossfade, R.attr.overlay, R.attr.round, R.attr.roundPercent, R.attr.saturation, R.attr.warmth};
    public static final int[] S2 = {16843551, 16843552, 16843553, 16843554, 16843555, 16843556, 16843557, 16843558, 16843559, 16843560, 16843770, 16843840, R.attr.curveFit, R.attr.framePosition, R.attr.motionProgress, R.attr.motionTarget, R.attr.transitionEasing, R.attr.transitionPathRotate};
    public static final int[] T2 = {16843551, 16843554, 16843555, 16843556, 16843557, 16843558, 16843559, 16843560, 16843770, 16843840, R.attr.curveFit, R.attr.framePosition, R.attr.motionProgress, R.attr.motionTarget, R.attr.transitionEasing, R.attr.transitionPathRotate, R.attr.waveOffset, R.attr.wavePeriod, R.attr.waveShape, R.attr.waveVariesBy};
    public static final int[] U2 = {R.attr.curveFit, R.attr.drawPath, R.attr.framePosition, R.attr.keyPositionType, R.attr.motionTarget, R.attr.pathMotionArc, R.attr.percentHeight, R.attr.percentWidth, R.attr.percentX, R.attr.percentY, R.attr.sizePercent, R.attr.transitionEasing};
    public static final int[] V2 = {16843551, 16843554, 16843555, 16843556, 16843557, 16843558, 16843559, 16843560, 16843770, 16843840, R.attr.curveFit, R.attr.framePosition, R.attr.motionProgress, R.attr.motionTarget, R.attr.transitionEasing, R.attr.transitionPathRotate, R.attr.waveDecay, R.attr.waveOffset, R.attr.wavePeriod, R.attr.waveShape};
    public static final int[] W2 = {R.attr.framePosition, R.attr.motionTarget, R.attr.motion_postLayoutCollision, R.attr.motion_triggerOnCollision, R.attr.onCross, R.attr.onNegativeCross, R.attr.onPositiveCross, R.attr.triggerId, R.attr.triggerReceiver, R.attr.triggerSlack};
    public static final int[] X2 = {16842948, 16842996, 16842997, 16842999, 16843000, 16843001, 16843002, 16843701, 16843702, R.attr.barrierAllowsGoneWidgets, R.attr.barrierDirection, R.attr.barrierMargin, R.attr.chainUseRtl, R.attr.constraint_referenced_ids, R.attr.constraint_referenced_tags, R.attr.layout_constrainedHeight, R.attr.layout_constrainedWidth, R.attr.layout_constraintBaseline_creator, R.attr.layout_constraintBaseline_toBaselineOf, R.attr.layout_constraintBottom_creator, R.attr.layout_constraintBottom_toBottomOf, R.attr.layout_constraintBottom_toTopOf, R.attr.layout_constraintCircle, R.attr.layout_constraintCircleAngle, R.attr.layout_constraintCircleRadius, R.attr.layout_constraintDimensionRatio, R.attr.layout_constraintEnd_toEndOf, R.attr.layout_constraintEnd_toStartOf, R.attr.layout_constraintGuide_begin, R.attr.layout_constraintGuide_end, R.attr.layout_constraintGuide_percent, R.attr.layout_constraintHeight_default, R.attr.layout_constraintHeight_max, R.attr.layout_constraintHeight_min, R.attr.layout_constraintHeight_percent, R.attr.layout_constraintHorizontal_bias, R.attr.layout_constraintHorizontal_chainStyle, R.attr.layout_constraintHorizontal_weight, R.attr.layout_constraintLeft_creator, R.attr.layout_constraintLeft_toLeftOf, R.attr.layout_constraintLeft_toRightOf, R.attr.layout_constraintRight_creator, R.attr.layout_constraintRight_toLeftOf, R.attr.layout_constraintRight_toRightOf, R.attr.layout_constraintStart_toEndOf, R.attr.layout_constraintStart_toStartOf, R.attr.layout_constraintTop_creator, R.attr.layout_constraintTop_toBottomOf, R.attr.layout_constraintTop_toTopOf, R.attr.layout_constraintVertical_bias, R.attr.layout_constraintVertical_chainStyle, R.attr.layout_constraintVertical_weight, R.attr.layout_constraintWidth_default, R.attr.layout_constraintWidth_max, R.attr.layout_constraintWidth_min, R.attr.layout_constraintWidth_percent, R.attr.layout_editor_absoluteX, R.attr.layout_editor_absoluteY, R.attr.layout_goneMarginBottom, R.attr.layout_goneMarginEnd, R.attr.layout_goneMarginLeft, R.attr.layout_goneMarginRight, R.attr.layout_goneMarginStart, R.attr.layout_goneMarginTop, R.attr.maxHeight, R.attr.maxWidth, R.attr.minHeight, R.attr.minWidth};
    public static final int[] b4 = {16842927, 16842948, 16843046, 16843047, 16843048, R.attr.divider, R.attr.dividerPadding, R.attr.measureWithLargestChild, R.attr.showDividers};
    public static final int[] c4 = {16842931, 16842996, 16842997, 16843137};
    public static final int[] d4 = {16843436, 16843437};
    public static final int[] e4 = {16842766, 16842960, 16843156, 16843230, 16843231, 16843232};
    public static final int[] f4 = {16842754, 16842766, 16842960, 16843014, 16843156, 16843230, 16843231, 16843233, 16843234, 16843235, 16843236, 16843237, 16843375, R.attr.actionLayout, R.attr.actionProviderClass, R.attr.actionViewClass, R.attr.alphabeticModifiers, R.attr.contentDescription, R.attr.iconTint, R.attr.iconTintMode, R.attr.numericModifiers, R.attr.showAsAction, R.attr.tooltipText};
    public static final int[] g4 = {16842926, 16843052, 16843053, 16843054, 16843055, 16843056, 16843057, R.attr.preserveIconSpacing, R.attr.subMenuArrow};
    public static final int[] h4 = {R.attr.mock_diagonalsColor, R.attr.mock_label, R.attr.mock_labelBackgroundColor, R.attr.mock_labelColor, R.attr.mock_showDiagonals, R.attr.mock_showLabel};
    public static final int[] i4 = {R.attr.animate_relativeTo, R.attr.drawPath, R.attr.motionPathRotate, R.attr.motionStagger, R.attr.pathMotionArc, R.attr.transitionEasing};
    public static final int[] p4 = {R.attr.onHide, R.attr.onShow};
    public static final int[] q4 = {R.attr.applyMotionScene, R.attr.currentState, R.attr.layoutDescription, R.attr.motionDebug, R.attr.motionProgress, R.attr.showPaths};
    public static final int[] r4 = {R.attr.defaultDuration, R.attr.layoutDuringTransition};
    public static final int[] s4 = {R.attr.telltales_tailColor, R.attr.telltales_tailScale, R.attr.telltales_velocityMode};
    public static final int[] t4 = {R.attr.clickAction, R.attr.targetId};
    public static final int[] u4 = {R.attr.dragDirection, R.attr.dragScale, R.attr.dragThreshold, R.attr.limitBoundsTo, R.attr.maxAcceleration, R.attr.maxVelocity, R.attr.moveWhenScrollAtTop, R.attr.nestedScrollFlags, R.attr.onTouchUp, R.attr.touchAnchorId, R.attr.touchAnchorSide, R.attr.touchRegionId};
    public static final int[] v4 = {16843126, 16843465, R.attr.overlapAnchor};
    public static final int[] w4 = {R.attr.state_above_anchor};
    public static final int[] x4 = {16842972, 16843551, R.attr.layout_constraintTag, R.attr.motionProgress, R.attr.visibilityMode};
    public static final int[] C4 = {R.attr.paddingBottomNoButtons, R.attr.paddingTopNoTitle};
    public static final int[] D4 = {16842970, 16843039, 16843296, 16843364, R.attr.closeIcon, R.attr.commitIcon, R.attr.defaultQueryHint, R.attr.goIcon, R.attr.iconifiedByDefault, R.attr.layout, R.attr.queryBackground, R.attr.queryHint, R.attr.searchHintIcon, R.attr.searchIcon, R.attr.submitBackground, R.attr.suggestionRowLayout, R.attr.voiceIcon};
    public static final int[] E4 = {16842930, 16843126, 16843131, 16843362, R.attr.popupTheme};
    public static final int[] F4 = {16842960, R.attr.constraints};
    public static final int[] I4 = {16843036, 16843156, 16843157, 16843158, 16843532, 16843533};
    public static final int[] J4 = {16843161};
    public static final int[] K4 = {R.attr.defaultState};
    public static final int[] L4 = {16843044, 16843045, 16843074, R.attr.showText, R.attr.splitTrack, R.attr.switchMinWidth, R.attr.switchPadding, R.attr.switchTextAppearance, R.attr.thumbTextPadding, R.attr.thumbTint, R.attr.thumbTintMode, R.attr.track, R.attr.trackTint, R.attr.trackTintMode};
    public static final int[] M4 = {16842901, 16842902, 16842903, 16842904, 16842906, 16842907, 16843105, 16843106, 16843107, 16843108, 16843692, 16844165, R.attr.fontFamily, R.attr.fontVariationSettings, R.attr.textAllCaps, R.attr.textLocale};
    public static final int[] N4 = {16842927, 16843072, R.attr.buttonGravity, R.attr.collapseContentDescription, R.attr.collapseIcon, R.attr.contentInsetEnd, R.attr.contentInsetEndWithActions, R.attr.contentInsetLeft, R.attr.contentInsetRight, R.attr.contentInsetStart, R.attr.contentInsetStartWithNavigation, R.attr.logo, R.attr.logoDescription, R.attr.maxButtonHeight, R.attr.menu, R.attr.navigationContentDescription, R.attr.navigationIcon, R.attr.popupTheme, R.attr.subtitle, R.attr.subtitleTextAppearance, R.attr.subtitleTextColor, R.attr.title, R.attr.titleMargin, R.attr.titleMarginBottom, R.attr.titleMarginEnd, R.attr.titleMarginStart, R.attr.titleMarginTop, R.attr.titleMargins, R.attr.titleTextAppearance, R.attr.titleTextColor};
    public static final int[] O4 = {16843552, 16843553, 16843554, 16843555, 16843556, 16843557, 16843558, 16843559, 16843560, 16843770, 16843840};
    public static final int[] a5 = {16842960, R.attr.autoTransition, R.attr.constraintSetEnd, R.attr.constraintSetStart, R.attr.duration, R.attr.layoutDuringTransition, R.attr.motionInterpolator, R.attr.pathMotionArc, R.attr.staggered, R.attr.transitionDisable, R.attr.transitionFlags};
    public static final int[] b5 = {R.attr.constraints, R.attr.region_heightLessThan, R.attr.region_heightMoreThan, R.attr.region_widthLessThan, R.attr.region_widthMoreThan};
    public static final int[] h5 = {16842752, 16842970, R.attr.paddingEnd, R.attr.paddingStart, R.attr.theme};
    public static final int[] i5 = {16842964, R.attr.backgroundTint, R.attr.backgroundTintMode};
    public static final int[] j5 = {16842960, 16842994, 16842995};
}
