package f;

import android.view.View;
import android.view.animation.Interpolator;
import e0.u;
import e0.v;
import e0.w;
import java.util.ArrayList;
import java.util.Iterator;
/* loaded from: classes.dex */
public class h {

    /* renamed from: c  reason: collision with root package name */
    private Interpolator f4413c;

    /* renamed from: d  reason: collision with root package name */
    v f4414d;

    /* renamed from: e  reason: collision with root package name */
    private boolean f4415e;

    /* renamed from: b  reason: collision with root package name */
    private long f4412b = -1;

    /* renamed from: f  reason: collision with root package name */
    private final w f4416f = new a();

    /* renamed from: a  reason: collision with root package name */
    final ArrayList<u> f4411a = new ArrayList<>();

    /* loaded from: classes.dex */
    class a extends w {

        /* renamed from: a  reason: collision with root package name */
        private boolean f4417a = false;

        /* renamed from: b  reason: collision with root package name */
        private int f4418b = 0;

        a() {
        }

        @Override // e0.v
        public void a(View view) {
            int i2 = this.f4418b + 1;
            this.f4418b = i2;
            if (i2 == h.this.f4411a.size()) {
                v vVar = h.this.f4414d;
                if (vVar != null) {
                    vVar.a(null);
                }
                d();
            }
        }

        @Override // e0.w, e0.v
        public void b(View view) {
            if (this.f4417a) {
                return;
            }
            this.f4417a = true;
            v vVar = h.this.f4414d;
            if (vVar != null) {
                vVar.b(null);
            }
        }

        void d() {
            this.f4418b = 0;
            this.f4417a = false;
            h.this.b();
        }
    }

    public void a() {
        if (this.f4415e) {
            Iterator<u> it = this.f4411a.iterator();
            while (it.hasNext()) {
                it.next().b();
            }
            this.f4415e = false;
        }
    }

    void b() {
        this.f4415e = false;
    }

    public h c(u uVar) {
        if (!this.f4415e) {
            this.f4411a.add(uVar);
        }
        return this;
    }

    public h d(u uVar, u uVar2) {
        this.f4411a.add(uVar);
        uVar2.h(uVar.c());
        this.f4411a.add(uVar2);
        return this;
    }

    public h e(long j2) {
        if (!this.f4415e) {
            this.f4412b = j2;
        }
        return this;
    }

    public h f(Interpolator interpolator) {
        if (!this.f4415e) {
            this.f4413c = interpolator;
        }
        return this;
    }

    public h g(v vVar) {
        if (!this.f4415e) {
            this.f4414d = vVar;
        }
        return this;
    }

    public void h() {
        if (this.f4415e) {
            return;
        }
        Iterator<u> it = this.f4411a.iterator();
        while (it.hasNext()) {
            u next = it.next();
            long j2 = this.f4412b;
            if (j2 >= 0) {
                next.d(j2);
            }
            Interpolator interpolator = this.f4413c;
            if (interpolator != null) {
                next.e(interpolator);
            }
            if (this.f4414d != null) {
                next.f(this.f4416f);
            }
            next.j();
        }
        this.f4415e = true;
    }
}
