package androidx.coordinatorlayout.widget;

import d0.e;
import d0.f;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import l.g;
/* loaded from: classes.dex */
public final class a<T> {

    /* renamed from: a  reason: collision with root package name */
    private final e<ArrayList<T>> f1380a = new f(10);

    /* renamed from: b  reason: collision with root package name */
    private final g<T, ArrayList<T>> f1381b = new g<>();

    /* renamed from: c  reason: collision with root package name */
    private final ArrayList<T> f1382c = new ArrayList<>();

    /* renamed from: d  reason: collision with root package name */
    private final HashSet<T> f1383d = new HashSet<>();

    private void e(T t2, ArrayList<T> arrayList, HashSet<T> hashSet) {
        if (arrayList.contains(t2)) {
            return;
        }
        if (hashSet.contains(t2)) {
            throw new RuntimeException("This graph contains cyclic dependencies");
        }
        hashSet.add(t2);
        ArrayList<T> arrayList2 = this.f1381b.get(t2);
        if (arrayList2 != null) {
            int size = arrayList2.size();
            for (int i2 = 0; i2 < size; i2++) {
                e(arrayList2.get(i2), arrayList, hashSet);
            }
        }
        hashSet.remove(t2);
        arrayList.add(t2);
    }

    private ArrayList<T> f() {
        ArrayList<T> b2 = this.f1380a.b();
        return b2 == null ? new ArrayList<>() : b2;
    }

    private void k(ArrayList<T> arrayList) {
        arrayList.clear();
        this.f1380a.a(arrayList);
    }

    public void a(T t2, T t3) {
        if (!this.f1381b.containsKey(t2) || !this.f1381b.containsKey(t3)) {
            throw new IllegalArgumentException("All nodes must be present in the graph before being added as an edge");
        }
        ArrayList<T> arrayList = this.f1381b.get(t2);
        if (arrayList == null) {
            arrayList = f();
            this.f1381b.put(t2, arrayList);
        }
        arrayList.add(t3);
    }

    public void b(T t2) {
        if (this.f1381b.containsKey(t2)) {
            return;
        }
        this.f1381b.put(t2, null);
    }

    public void c() {
        int size = this.f1381b.size();
        for (int i2 = 0; i2 < size; i2++) {
            ArrayList<T> o2 = this.f1381b.o(i2);
            if (o2 != null) {
                k(o2);
            }
        }
        this.f1381b.clear();
    }

    public boolean d(T t2) {
        return this.f1381b.containsKey(t2);
    }

    public List g(T t2) {
        return this.f1381b.get(t2);
    }

    public List<T> h(T t2) {
        int size = this.f1381b.size();
        ArrayList arrayList = null;
        for (int i2 = 0; i2 < size; i2++) {
            ArrayList<T> o2 = this.f1381b.o(i2);
            if (o2 != null && o2.contains(t2)) {
                if (arrayList == null) {
                    arrayList = new ArrayList();
                }
                arrayList.add(this.f1381b.k(i2));
            }
        }
        return arrayList;
    }

    public ArrayList<T> i() {
        this.f1382c.clear();
        this.f1383d.clear();
        int size = this.f1381b.size();
        for (int i2 = 0; i2 < size; i2++) {
            e(this.f1381b.k(i2), this.f1382c, this.f1383d);
        }
        return this.f1382c;
    }

    public boolean j(T t2) {
        int size = this.f1381b.size();
        for (int i2 = 0; i2 < size; i2++) {
            ArrayList<T> o2 = this.f1381b.o(i2);
            if (o2 != null && o2.contains(t2)) {
                return true;
            }
        }
        return false;
    }
}
