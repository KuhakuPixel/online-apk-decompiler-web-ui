package b0;

import android.content.ContentUris;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.pm.ProviderInfo;
import android.content.pm.Signature;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.CancellationSignal;
import android.os.Handler;
import b0.c;
import d0.h;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import v.f;
import w.k;
/* loaded from: classes.dex */
public class b {

    /* renamed from: a  reason: collision with root package name */
    static final l.e<String, Typeface> f2984a = new l.e<>(16);

    /* renamed from: b  reason: collision with root package name */
    private static final b0.c f2985b = new b0.c("fonts", 10, 10000);

    /* renamed from: c  reason: collision with root package name */
    static final Object f2986c = new Object();

    /* renamed from: d  reason: collision with root package name */
    static final l.g<String, ArrayList<c.d<g>>> f2987d = new l.g<>();

    /* renamed from: e  reason: collision with root package name */
    private static final Comparator<byte[]> f2988e = new d();

    /* loaded from: classes.dex */
    class a implements Callable<g> {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ Context f2989a;

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ b0.a f2990b;

        /* renamed from: c  reason: collision with root package name */
        final /* synthetic */ int f2991c;

        /* renamed from: d  reason: collision with root package name */
        final /* synthetic */ String f2992d;

        a(Context context, b0.a aVar, int i2, String str) {
            this.f2989a = context;
            this.f2990b = aVar;
            this.f2991c = i2;
            this.f2992d = str;
        }

        @Override // java.util.concurrent.Callable
        /* renamed from: a  reason: merged with bridge method [inline-methods] */
        public g call() {
            g f2 = b.f(this.f2989a, this.f2990b, this.f2991c);
            Typeface typeface = f2.f3003a;
            if (typeface != null) {
                b.f2984a.d(this.f2992d, typeface);
            }
            return f2;
        }
    }

    /* renamed from: b0.b$b  reason: collision with other inner class name */
    /* loaded from: classes.dex */
    class C0027b implements c.d<g> {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ f.a f2993a;

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ Handler f2994b;

        C0027b(f.a aVar, Handler handler) {
            this.f2993a = aVar;
            this.f2994b = handler;
        }

        @Override // b0.c.d
        /* renamed from: b  reason: merged with bridge method [inline-methods] */
        public void a(g gVar) {
            int i2;
            f.a aVar;
            if (gVar == null) {
                aVar = this.f2993a;
                i2 = 1;
            } else {
                i2 = gVar.f3004b;
                if (i2 == 0) {
                    this.f2993a.b(gVar.f3003a, this.f2994b);
                    return;
                }
                aVar = this.f2993a;
            }
            aVar.a(i2, this.f2994b);
        }
    }

    /* loaded from: classes.dex */
    class c implements c.d<g> {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ String f2995a;

        c(String str) {
            this.f2995a = str;
        }

        @Override // b0.c.d
        /* renamed from: b  reason: merged with bridge method [inline-methods] */
        public void a(g gVar) {
            synchronized (b.f2986c) {
                l.g<String, ArrayList<c.d<g>>> gVar2 = b.f2987d;
                ArrayList<c.d<g>> arrayList = gVar2.get(this.f2995a);
                if (arrayList == null) {
                    return;
                }
                gVar2.remove(this.f2995a);
                for (int i2 = 0; i2 < arrayList.size(); i2++) {
                    arrayList.get(i2).a(gVar);
                }
            }
        }
    }

    /* loaded from: classes.dex */
    class d implements Comparator<byte[]> {
        d() {
        }

        /* JADX WARN: Multi-variable type inference failed */
        @Override // java.util.Comparator
        /* renamed from: a  reason: merged with bridge method [inline-methods] */
        public int compare(byte[] bArr, byte[] bArr2) {
            int i2;
            int i3;
            if (bArr.length == bArr2.length) {
                for (int i4 = 0; i4 < bArr.length; i4++) {
                    if (bArr[i4] != bArr2[i4]) {
                        i2 = bArr[i4];
                        i3 = bArr2[i4];
                    }
                }
                return 0;
            }
            i2 = bArr.length;
            i3 = bArr2.length;
            return i2 - i3;
        }
    }

    /* loaded from: classes.dex */
    public static class e {

        /* renamed from: a  reason: collision with root package name */
        private final int f2996a;

        /* renamed from: b  reason: collision with root package name */
        private final f[] f2997b;

        public e(int i2, f[] fVarArr) {
            this.f2996a = i2;
            this.f2997b = fVarArr;
        }

        public f[] a() {
            return this.f2997b;
        }

        public int b() {
            return this.f2996a;
        }
    }

    /* loaded from: classes.dex */
    public static class f {

        /* renamed from: a  reason: collision with root package name */
        private final Uri f2998a;

        /* renamed from: b  reason: collision with root package name */
        private final int f2999b;

        /* renamed from: c  reason: collision with root package name */
        private final int f3000c;

        /* renamed from: d  reason: collision with root package name */
        private final boolean f3001d;

        /* renamed from: e  reason: collision with root package name */
        private final int f3002e;

        public f(Uri uri, int i2, int i3, boolean z2, int i4) {
            this.f2998a = (Uri) h.c(uri);
            this.f2999b = i2;
            this.f3000c = i3;
            this.f3001d = z2;
            this.f3002e = i4;
        }

        public int a() {
            return this.f3002e;
        }

        public int b() {
            return this.f2999b;
        }

        public Uri c() {
            return this.f2998a;
        }

        public int d() {
            return this.f3000c;
        }

        public boolean e() {
            return this.f3001d;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public static final class g {

        /* renamed from: a  reason: collision with root package name */
        final Typeface f3003a;

        /* renamed from: b  reason: collision with root package name */
        final int f3004b;

        g(Typeface typeface, int i2) {
            this.f3003a = typeface;
            this.f3004b = i2;
        }
    }

    private static List<byte[]> a(Signature[] signatureArr) {
        ArrayList arrayList = new ArrayList();
        for (Signature signature : signatureArr) {
            arrayList.add(signature.toByteArray());
        }
        return arrayList;
    }

    private static boolean b(List<byte[]> list, List<byte[]> list2) {
        if (list.size() != list2.size()) {
            return false;
        }
        for (int i2 = 0; i2 < list.size(); i2++) {
            if (!Arrays.equals(list.get(i2), list2.get(i2))) {
                return false;
            }
        }
        return true;
    }

    public static e c(Context context, CancellationSignal cancellationSignal, b0.a aVar) {
        ProviderInfo h2 = h(context.getPackageManager(), aVar, context.getResources());
        return h2 == null ? new e(1, null) : new e(0, e(context, aVar, h2.authority, cancellationSignal));
    }

    private static List<List<byte[]>> d(b0.a aVar, Resources resources) {
        return aVar.a() != null ? aVar.a() : v.c.c(resources, aVar.b());
    }

    static f[] e(Context context, b0.a aVar, String str, CancellationSignal cancellationSignal) {
        ArrayList arrayList = new ArrayList();
        Uri build = new Uri.Builder().scheme("content").authority(str).build();
        Uri build2 = new Uri.Builder().scheme("content").authority(str).appendPath("file").build();
        Cursor cursor = null;
        try {
            cursor = context.getContentResolver().query(build, new String[]{"_id", "file_id", "font_ttc_index", "font_variation_settings", "font_weight", "font_italic", "result_code"}, "query = ?", new String[]{aVar.f()}, null, cancellationSignal);
            if (cursor != null && cursor.getCount() > 0) {
                int columnIndex = cursor.getColumnIndex("result_code");
                ArrayList arrayList2 = new ArrayList();
                int columnIndex2 = cursor.getColumnIndex("_id");
                int columnIndex3 = cursor.getColumnIndex("file_id");
                int columnIndex4 = cursor.getColumnIndex("font_ttc_index");
                int columnIndex5 = cursor.getColumnIndex("font_weight");
                int columnIndex6 = cursor.getColumnIndex("font_italic");
                while (cursor.moveToNext()) {
                    int i2 = columnIndex != -1 ? cursor.getInt(columnIndex) : 0;
                    arrayList2.add(new f(columnIndex3 == -1 ? ContentUris.withAppendedId(build, cursor.getLong(columnIndex2)) : ContentUris.withAppendedId(build2, cursor.getLong(columnIndex3)), columnIndex4 != -1 ? cursor.getInt(columnIndex4) : 0, columnIndex5 != -1 ? cursor.getInt(columnIndex5) : 400, columnIndex6 != -1 && cursor.getInt(columnIndex6) == 1, i2));
                }
                arrayList = arrayList2;
            }
            return (f[]) arrayList.toArray(new f[0]);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    static g f(Context context, b0.a aVar, int i2) {
        try {
            e c2 = c(context, null, aVar);
            if (c2.b() != 0) {
                return new g(null, c2.b() == 1 ? -2 : -3);
            }
            Typeface b2 = w.d.b(context, null, c2.a(), i2);
            return new g(b2, b2 != null ? 0 : -3);
        } catch (PackageManager.NameNotFoundException unused) {
            return new g(null, -1);
        }
    }

    public static Typeface g(Context context, b0.a aVar, f.a aVar2, Handler handler, boolean z2, int i2, int i3) {
        String str = aVar.c() + "-" + i3;
        Typeface c2 = f2984a.c(str);
        if (c2 != null) {
            if (aVar2 != null) {
                aVar2.d(c2);
            }
            return c2;
        } else if (z2 && i2 == -1) {
            g f2 = f(context, aVar, i3);
            if (aVar2 != null) {
                int i4 = f2.f3004b;
                if (i4 == 0) {
                    aVar2.b(f2.f3003a, handler);
                } else {
                    aVar2.a(i4, handler);
                }
            }
            return f2.f3003a;
        } else {
            a aVar3 = new a(context, aVar, i3, str);
            if (z2) {
                try {
                    return ((g) f2985b.e(aVar3, i2)).f3003a;
                } catch (InterruptedException unused) {
                    return null;
                }
            }
            C0027b c0027b = aVar2 == null ? null : new C0027b(aVar2, handler);
            synchronized (f2986c) {
                l.g<String, ArrayList<c.d<g>>> gVar = f2987d;
                ArrayList<c.d<g>> arrayList = gVar.get(str);
                if (arrayList != null) {
                    if (c0027b != null) {
                        arrayList.add(c0027b);
                    }
                    return null;
                }
                if (c0027b != null) {
                    ArrayList<c.d<g>> arrayList2 = new ArrayList<>();
                    arrayList2.add(c0027b);
                    gVar.put(str, arrayList2);
                }
                f2985b.d(aVar3, new c(str));
                return null;
            }
        }
    }

    public static ProviderInfo h(PackageManager packageManager, b0.a aVar, Resources resources) {
        String d2 = aVar.d();
        ProviderInfo resolveContentProvider = packageManager.resolveContentProvider(d2, 0);
        if (resolveContentProvider == null) {
            throw new PackageManager.NameNotFoundException("No package found for authority: " + d2);
        } else if (!resolveContentProvider.packageName.equals(aVar.e())) {
            throw new PackageManager.NameNotFoundException("Found content provider " + d2 + ", but package was not " + aVar.e());
        } else {
            List<byte[]> a2 = a(packageManager.getPackageInfo(resolveContentProvider.packageName, 64).signatures);
            Collections.sort(a2, f2988e);
            List<List<byte[]>> d3 = d(aVar, resources);
            for (int i2 = 0; i2 < d3.size(); i2++) {
                ArrayList arrayList = new ArrayList(d3.get(i2));
                Collections.sort(arrayList, f2988e);
                if (b(a2, arrayList)) {
                    return resolveContentProvider;
                }
            }
            return null;
        }
    }

    public static Map<Uri, ByteBuffer> i(Context context, f[] fVarArr, CancellationSignal cancellationSignal) {
        HashMap hashMap = new HashMap();
        for (f fVar : fVarArr) {
            if (fVar.a() == 0) {
                Uri c2 = fVar.c();
                if (!hashMap.containsKey(c2)) {
                    hashMap.put(c2, k.f(context, cancellationSignal, c2));
                }
            }
        }
        return Collections.unmodifiableMap(hashMap);
    }
}
