package b1;

import android.animation.TimeInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
/* loaded from: classes.dex */
public class a {

    /* renamed from: a  reason: collision with root package name */
    public static final TimeInterpolator f3026a = new LinearInterpolator();

    /* renamed from: b  reason: collision with root package name */
    public static final TimeInterpolator f3027b = new m0.b();

    /* renamed from: c  reason: collision with root package name */
    public static final TimeInterpolator f3028c = new m0.a();

    /* renamed from: d  reason: collision with root package name */
    public static final TimeInterpolator f3029d = new m0.c();

    /* renamed from: e  reason: collision with root package name */
    public static final TimeInterpolator f3030e = new DecelerateInterpolator();

    public static float a(float f2, float f3, float f4) {
        return f2 + (f4 * (f3 - f2));
    }
}
