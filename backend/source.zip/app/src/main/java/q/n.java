package q;

import p.e;
import q.f;
import q.p;
/* loaded from: classes.dex */
public class n extends p {

    /* renamed from: k  reason: collision with root package name */
    public f f5040k;

    /* renamed from: l  reason: collision with root package name */
    g f5041l;

    /* loaded from: classes.dex */
    static /* synthetic */ class a {

        /* renamed from: a  reason: collision with root package name */
        static final /* synthetic */ int[] f5042a;

        static {
            int[] iArr = new int[p.b.values().length];
            f5042a = iArr;
            try {
                iArr[p.b.START.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                f5042a[p.b.END.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                f5042a[p.b.CENTER.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
        }
    }

    public n(p.e eVar) {
        super(eVar);
        f fVar = new f(this);
        this.f5040k = fVar;
        this.f5041l = null;
        this.f5065h.f5011e = f.a.TOP;
        this.f5066i.f5011e = f.a.BOTTOM;
        fVar.f5011e = f.a.BASELINE;
        this.f5063f = 1;
    }

    @Override // q.p, q.d
    public void a(d dVar) {
        int i2;
        float t2;
        int i3 = a.f5042a[this.f5067j.ordinal()];
        if (i3 == 1) {
            p(dVar);
        } else if (i3 == 2) {
            o(dVar);
        } else if (i3 == 3) {
            p.e eVar = this.f5059b;
            n(dVar, eVar.I, eVar.K, 1);
            return;
        }
        g gVar = this.f5062e;
        if (gVar.f5009c && !gVar.f5016j && this.f5061d == e.b.MATCH_CONSTRAINT) {
            p.e eVar2 = this.f5059b;
            int i4 = eVar2.f4919q;
            if (i4 == 2) {
                p.e I = eVar2.I();
                if (I != null) {
                    if (I.f4897f.f5062e.f5016j) {
                        i2 = (int) ((r7.f5013g * this.f5059b.f4933x) + 0.5f);
                        this.f5062e.d(i2);
                    }
                }
            } else if (i4 == 3 && eVar2.f4895e.f5062e.f5016j) {
                int u2 = eVar2.u();
                if (u2 != -1) {
                    if (u2 == 0) {
                        t2 = r7.f4895e.f5062e.f5013g * this.f5059b.t();
                        i2 = (int) (t2 + 0.5f);
                        this.f5062e.d(i2);
                    } else if (u2 != 1) {
                        i2 = 0;
                        this.f5062e.d(i2);
                    }
                }
                t2 = r7.f4895e.f5062e.f5013g / this.f5059b.t();
                i2 = (int) (t2 + 0.5f);
                this.f5062e.d(i2);
            }
        }
        f fVar = this.f5065h;
        if (fVar.f5009c) {
            f fVar2 = this.f5066i;
            if (fVar2.f5009c) {
                if (fVar.f5016j && fVar2.f5016j && this.f5062e.f5016j) {
                    return;
                }
                if (!this.f5062e.f5016j && this.f5061d == e.b.MATCH_CONSTRAINT) {
                    p.e eVar3 = this.f5059b;
                    if (eVar3.f4917p == 0 && !eVar3.b0()) {
                        f fVar3 = this.f5065h.f5018l.get(0);
                        f fVar4 = this.f5066i.f5018l.get(0);
                        int i5 = fVar3.f5013g;
                        f fVar5 = this.f5065h;
                        int i6 = i5 + fVar5.f5012f;
                        int i7 = fVar4.f5013g + this.f5066i.f5012f;
                        fVar5.d(i6);
                        this.f5066i.d(i7);
                        this.f5062e.d(i7 - i6);
                        return;
                    }
                }
                if (!this.f5062e.f5016j && this.f5061d == e.b.MATCH_CONSTRAINT && this.f5058a == 1 && this.f5065h.f5018l.size() > 0 && this.f5066i.f5018l.size() > 0) {
                    f fVar6 = this.f5065h.f5018l.get(0);
                    int i8 = (this.f5066i.f5018l.get(0).f5013g + this.f5066i.f5012f) - (fVar6.f5013g + this.f5065h.f5012f);
                    g gVar2 = this.f5062e;
                    int i9 = gVar2.f5028m;
                    if (i8 < i9) {
                        gVar2.d(i8);
                    } else {
                        gVar2.d(i9);
                    }
                }
                if (this.f5062e.f5016j && this.f5065h.f5018l.size() > 0 && this.f5066i.f5018l.size() > 0) {
                    f fVar7 = this.f5065h.f5018l.get(0);
                    f fVar8 = this.f5066i.f5018l.get(0);
                    int i10 = fVar7.f5013g + this.f5065h.f5012f;
                    int i11 = fVar8.f5013g + this.f5066i.f5012f;
                    float M = this.f5059b.M();
                    if (fVar7 == fVar8) {
                        i10 = fVar7.f5013g;
                        i11 = fVar8.f5013g;
                        M = 0.5f;
                    }
                    this.f5065h.d((int) (i10 + 0.5f + (((i11 - i10) - this.f5062e.f5013g) * M)));
                    this.f5066i.d(this.f5065h.f5013g + this.f5062e.f5013g);
                }
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* JADX WARN: Code restructure failed: missing block: B:110:0x02e3, code lost:
        if (r9.f5059b.U() != false) goto L111;
     */
    /* JADX WARN: Code restructure failed: missing block: B:111:0x02e5, code lost:
        r0 = r9.f5040k;
        r1 = r9.f5065h;
        r2 = r9.f5041l;
     */
    /* JADX WARN: Code restructure failed: missing block: B:125:0x033e, code lost:
        if (r0.f5061d == r1) goto L152;
     */
    /* JADX WARN: Code restructure failed: missing block: B:132:0x0370, code lost:
        if (r9.f5059b.U() != false) goto L111;
     */
    /* JADX WARN: Code restructure failed: missing block: B:151:0x03e7, code lost:
        if (r0.f5061d == r1) goto L152;
     */
    /* JADX WARN: Code restructure failed: missing block: B:152:0x03e9, code lost:
        r0.f5062e.f5017k.add(r9.f5062e);
        r9.f5062e.f5018l.add(r9.f5059b.f4895e.f5062e);
        r9.f5062e.f5007a = r9;
     */
    /* JADX WARN: Removed duplicated region for block: B:155:0x040d  */
    /* JADX WARN: Removed duplicated region for block: B:167:? A[RETURN, SYNTHETIC] */
    @Override // q.p
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void d() {
        /*
            Method dump skipped, instructions count: 1042
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: q.n.d():void");
    }

    @Override // q.p
    public void e() {
        f fVar = this.f5065h;
        if (fVar.f5016j) {
            this.f5059b.W0(fVar.f5013g);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    @Override // q.p
    public void f() {
        this.f5060c = null;
        this.f5065h.c();
        this.f5066i.c();
        this.f5040k.c();
        this.f5062e.c();
        this.f5064g = false;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    @Override // q.p
    public boolean m() {
        return this.f5061d != e.b.MATCH_CONSTRAINT || this.f5059b.f4919q == 0;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void q() {
        this.f5064g = false;
        this.f5065h.c();
        this.f5065h.f5016j = false;
        this.f5066i.c();
        this.f5066i.f5016j = false;
        this.f5040k.c();
        this.f5040k.f5016j = false;
        this.f5062e.f5016j = false;
    }

    public String toString() {
        return "VerticalRun " + this.f5059b.r();
    }
}
