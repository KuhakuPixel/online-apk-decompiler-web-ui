package androidx.lifecycle;

import androidx.lifecycle.d;
/* loaded from: classes.dex */
public abstract class LiveData<T> {

    /* renamed from: j  reason: collision with root package name */
    static final Object f1816j = new Object();

    /* renamed from: a  reason: collision with root package name */
    final Object f1817a = new Object();

    /* renamed from: b  reason: collision with root package name */
    private i.b<n<? super T>, LiveData<T>.c> f1818b = new i.b<>();

    /* renamed from: c  reason: collision with root package name */
    int f1819c = 0;

    /* renamed from: d  reason: collision with root package name */
    private volatile Object f1820d;

    /* renamed from: e  reason: collision with root package name */
    volatile Object f1821e;

    /* renamed from: f  reason: collision with root package name */
    private int f1822f;

    /* renamed from: g  reason: collision with root package name */
    private boolean f1823g;

    /* renamed from: h  reason: collision with root package name */
    private boolean f1824h;

    /* renamed from: i  reason: collision with root package name */
    private final Runnable f1825i;

    /* loaded from: classes.dex */
    class LifecycleBoundObserver extends LiveData<T>.c implements e {

        /* renamed from: e  reason: collision with root package name */
        final g f1826e;

        LifecycleBoundObserver(g gVar, n<? super T> nVar) {
            super(nVar);
            this.f1826e = gVar;
        }

        @Override // androidx.lifecycle.LiveData.c
        void e() {
            this.f1826e.a().c(this);
        }

        @Override // androidx.lifecycle.e
        public void f(g gVar, d.a aVar) {
            if (this.f1826e.a().b() == d.b.DESTROYED) {
                LiveData.this.l(this.f1830a);
            } else {
                d(k());
            }
        }

        @Override // androidx.lifecycle.LiveData.c
        boolean i(g gVar) {
            return this.f1826e == gVar;
        }

        @Override // androidx.lifecycle.LiveData.c
        boolean k() {
            return this.f1826e.a().b().a(d.b.STARTED);
        }
    }

    /* loaded from: classes.dex */
    class a implements Runnable {
        a() {
        }

        /* JADX WARN: Multi-variable type inference failed */
        @Override // java.lang.Runnable
        public void run() {
            Object obj;
            synchronized (LiveData.this.f1817a) {
                obj = LiveData.this.f1821e;
                LiveData.this.f1821e = LiveData.f1816j;
            }
            LiveData.this.m(obj);
        }
    }

    /* loaded from: classes.dex */
    private class b extends LiveData<T>.c {
        b(n<? super T> nVar) {
            super(nVar);
        }

        @Override // androidx.lifecycle.LiveData.c
        boolean k() {
            return true;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public abstract class c {

        /* renamed from: a  reason: collision with root package name */
        final n<? super T> f1830a;

        /* renamed from: b  reason: collision with root package name */
        boolean f1831b;

        /* renamed from: c  reason: collision with root package name */
        int f1832c = -1;

        c(n<? super T> nVar) {
            this.f1830a = nVar;
        }

        void d(boolean z2) {
            if (z2 == this.f1831b) {
                return;
            }
            this.f1831b = z2;
            LiveData liveData = LiveData.this;
            int i2 = liveData.f1819c;
            boolean z3 = i2 == 0;
            liveData.f1819c = i2 + (z2 ? 1 : -1);
            if (z3 && z2) {
                liveData.i();
            }
            LiveData liveData2 = LiveData.this;
            if (liveData2.f1819c == 0 && !this.f1831b) {
                liveData2.j();
            }
            if (this.f1831b) {
                LiveData.this.c(this);
            }
        }

        void e() {
        }

        boolean i(g gVar) {
            return false;
        }

        abstract boolean k();
    }

    public LiveData() {
        Object obj = f1816j;
        this.f1821e = obj;
        this.f1825i = new a();
        this.f1820d = obj;
        this.f1822f = -1;
    }

    static void a(String str) {
        if (h.a.f().c()) {
            return;
        }
        throw new IllegalStateException("Cannot invoke " + str + " on a background thread");
    }

    private void b(LiveData<T>.c cVar) {
        if (cVar.f1831b) {
            if (!cVar.k()) {
                cVar.d(false);
                return;
            }
            int i2 = cVar.f1832c;
            int i3 = this.f1822f;
            if (i2 >= i3) {
                return;
            }
            cVar.f1832c = i3;
            cVar.f1830a.c((Object) this.f1820d);
        }
    }

    void c(LiveData<T>.c cVar) {
        if (this.f1823g) {
            this.f1824h = true;
            return;
        }
        this.f1823g = true;
        do {
            this.f1824h = false;
            if (cVar != null) {
                b(cVar);
                cVar = null;
            } else {
                i.b<n<? super T>, LiveData<T>.c>.d f2 = this.f1818b.f();
                while (f2.hasNext()) {
                    b((c) f2.next().getValue());
                    if (this.f1824h) {
                        break;
                    }
                }
            }
        } while (this.f1824h);
        this.f1823g = false;
    }

    public T d() {
        T t2 = (T) this.f1820d;
        if (t2 != f1816j) {
            return t2;
        }
        return null;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public int e() {
        return this.f1822f;
    }

    public boolean f() {
        return this.f1819c > 0;
    }

    public void g(g gVar, n<? super T> nVar) {
        a("observe");
        if (gVar.a().b() == d.b.DESTROYED) {
            return;
        }
        LifecycleBoundObserver lifecycleBoundObserver = new LifecycleBoundObserver(gVar, nVar);
        LiveData<T>.c i2 = this.f1818b.i(nVar, lifecycleBoundObserver);
        if (i2 != null && !i2.i(gVar)) {
            throw new IllegalArgumentException("Cannot add the same observer with different lifecycles");
        }
        if (i2 != null) {
            return;
        }
        gVar.a().a(lifecycleBoundObserver);
    }

    public void h(n<? super T> nVar) {
        a("observeForever");
        b bVar = new b(nVar);
        LiveData<T>.c i2 = this.f1818b.i(nVar, bVar);
        if (i2 instanceof LifecycleBoundObserver) {
            throw new IllegalArgumentException("Cannot add the same observer with different lifecycles");
        }
        if (i2 != null) {
            return;
        }
        bVar.d(true);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public void i() {
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public void j() {
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public void k(T t2) {
        boolean z2;
        synchronized (this.f1817a) {
            z2 = this.f1821e == f1816j;
            this.f1821e = t2;
        }
        if (z2) {
            h.a.f().d(this.f1825i);
        }
    }

    public void l(n<? super T> nVar) {
        a("removeObserver");
        LiveData<T>.c j2 = this.f1818b.j(nVar);
        if (j2 == null) {
            return;
        }
        j2.e();
        j2.d(false);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public void m(T t2) {
        a("setValue");
        this.f1822f++;
        this.f1820d = t2;
        c(null);
    }
}
