package androidx.lifecycle;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
/* loaded from: classes.dex */
public class t {

    /* renamed from: a  reason: collision with root package name */
    private final HashMap<String, r> f1879a = new HashMap<>();

    public final void a() {
        Iterator<r> it = this.f1879a.values().iterator();
        while (it.hasNext()) {
            it.next().a();
        }
        this.f1879a.clear();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final r b(String str) {
        return this.f1879a.get(str);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public Set<String> c() {
        return new HashSet(this.f1879a.keySet());
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final void d(String str, r rVar) {
        r put = this.f1879a.put(str, rVar);
        if (put != null) {
            put.d();
        }
    }
}
