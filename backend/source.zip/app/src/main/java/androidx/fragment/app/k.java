package androidx.fragment.app;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import java.util.Iterator;
import java.util.Objects;
import java.util.concurrent.CopyOnWriteArrayList;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes.dex */
public class k {

    /* renamed from: a  reason: collision with root package name */
    private final CopyOnWriteArrayList<a> f1637a = new CopyOnWriteArrayList<>();

    /* renamed from: b  reason: collision with root package name */
    private final l f1638b;

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public static final class a {

        /* renamed from: a  reason: collision with root package name */
        final boolean f1639a;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public k(l lVar) {
        this.f1638b = lVar;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void a(Fragment fragment, Bundle bundle, boolean z2) {
        Fragment i02 = this.f1638b.i0();
        if (i02 != null) {
            i02.A().h0().a(fragment, bundle, true);
        }
        Iterator<a> it = this.f1637a.iterator();
        while (it.hasNext()) {
            a next = it.next();
            if (!z2 || next.f1639a) {
                Objects.requireNonNull(next);
                throw null;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void b(Fragment fragment, Context context, boolean z2) {
        Fragment i02 = this.f1638b.i0();
        if (i02 != null) {
            i02.A().h0().b(fragment, context, true);
        }
        Iterator<a> it = this.f1637a.iterator();
        while (it.hasNext()) {
            a next = it.next();
            if (!z2 || next.f1639a) {
                Objects.requireNonNull(next);
                throw null;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void c(Fragment fragment, Bundle bundle, boolean z2) {
        Fragment i02 = this.f1638b.i0();
        if (i02 != null) {
            i02.A().h0().c(fragment, bundle, true);
        }
        Iterator<a> it = this.f1637a.iterator();
        while (it.hasNext()) {
            a next = it.next();
            if (!z2 || next.f1639a) {
                Objects.requireNonNull(next);
                throw null;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void d(Fragment fragment, boolean z2) {
        Fragment i02 = this.f1638b.i0();
        if (i02 != null) {
            i02.A().h0().d(fragment, true);
        }
        Iterator<a> it = this.f1637a.iterator();
        while (it.hasNext()) {
            a next = it.next();
            if (!z2 || next.f1639a) {
                Objects.requireNonNull(next);
                throw null;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void e(Fragment fragment, boolean z2) {
        Fragment i02 = this.f1638b.i0();
        if (i02 != null) {
            i02.A().h0().e(fragment, true);
        }
        Iterator<a> it = this.f1637a.iterator();
        while (it.hasNext()) {
            a next = it.next();
            if (!z2 || next.f1639a) {
                Objects.requireNonNull(next);
                throw null;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void f(Fragment fragment, boolean z2) {
        Fragment i02 = this.f1638b.i0();
        if (i02 != null) {
            i02.A().h0().f(fragment, true);
        }
        Iterator<a> it = this.f1637a.iterator();
        while (it.hasNext()) {
            a next = it.next();
            if (!z2 || next.f1639a) {
                Objects.requireNonNull(next);
                throw null;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void g(Fragment fragment, Context context, boolean z2) {
        Fragment i02 = this.f1638b.i0();
        if (i02 != null) {
            i02.A().h0().g(fragment, context, true);
        }
        Iterator<a> it = this.f1637a.iterator();
        while (it.hasNext()) {
            a next = it.next();
            if (!z2 || next.f1639a) {
                Objects.requireNonNull(next);
                throw null;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void h(Fragment fragment, Bundle bundle, boolean z2) {
        Fragment i02 = this.f1638b.i0();
        if (i02 != null) {
            i02.A().h0().h(fragment, bundle, true);
        }
        Iterator<a> it = this.f1637a.iterator();
        while (it.hasNext()) {
            a next = it.next();
            if (!z2 || next.f1639a) {
                Objects.requireNonNull(next);
                throw null;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void i(Fragment fragment, boolean z2) {
        Fragment i02 = this.f1638b.i0();
        if (i02 != null) {
            i02.A().h0().i(fragment, true);
        }
        Iterator<a> it = this.f1637a.iterator();
        while (it.hasNext()) {
            a next = it.next();
            if (!z2 || next.f1639a) {
                Objects.requireNonNull(next);
                throw null;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void j(Fragment fragment, Bundle bundle, boolean z2) {
        Fragment i02 = this.f1638b.i0();
        if (i02 != null) {
            i02.A().h0().j(fragment, bundle, true);
        }
        Iterator<a> it = this.f1637a.iterator();
        while (it.hasNext()) {
            a next = it.next();
            if (!z2 || next.f1639a) {
                Objects.requireNonNull(next);
                throw null;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void k(Fragment fragment, boolean z2) {
        Fragment i02 = this.f1638b.i0();
        if (i02 != null) {
            i02.A().h0().k(fragment, true);
        }
        Iterator<a> it = this.f1637a.iterator();
        while (it.hasNext()) {
            a next = it.next();
            if (!z2 || next.f1639a) {
                Objects.requireNonNull(next);
                throw null;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void l(Fragment fragment, boolean z2) {
        Fragment i02 = this.f1638b.i0();
        if (i02 != null) {
            i02.A().h0().l(fragment, true);
        }
        Iterator<a> it = this.f1637a.iterator();
        while (it.hasNext()) {
            a next = it.next();
            if (!z2 || next.f1639a) {
                Objects.requireNonNull(next);
                throw null;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void m(Fragment fragment, View view, Bundle bundle, boolean z2) {
        Fragment i02 = this.f1638b.i0();
        if (i02 != null) {
            i02.A().h0().m(fragment, view, bundle, true);
        }
        Iterator<a> it = this.f1637a.iterator();
        while (it.hasNext()) {
            a next = it.next();
            if (!z2 || next.f1639a) {
                Objects.requireNonNull(next);
                throw null;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void n(Fragment fragment, boolean z2) {
        Fragment i02 = this.f1638b.i0();
        if (i02 != null) {
            i02.A().h0().n(fragment, true);
        }
        Iterator<a> it = this.f1637a.iterator();
        while (it.hasNext()) {
            a next = it.next();
            if (!z2 || next.f1639a) {
                Objects.requireNonNull(next);
                throw null;
            }
        }
    }
}
