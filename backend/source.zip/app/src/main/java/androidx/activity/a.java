package androidx.activity;
/* loaded from: classes.dex */
interface a {
    void cancel();
}
