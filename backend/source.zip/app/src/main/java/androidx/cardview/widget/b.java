package androidx.cardview.widget;

import android.graphics.drawable.Drawable;
import android.view.View;
/* loaded from: classes.dex */
interface b {
    void a(int i2, int i3, int i4, int i5);

    View b();

    boolean c();

    Drawable d();

    void e(Drawable drawable);

    boolean f();
}
