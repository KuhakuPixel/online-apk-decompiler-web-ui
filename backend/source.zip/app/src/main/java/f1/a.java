package f1;

import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import e1.d;
/* loaded from: classes.dex */
public class a extends com.google.android.material.card.a implements d {
    @Override // e1.d
    public void a() {
        throw null;
    }

    @Override // e1.d
    public void b() {
        throw null;
    }

    @Override // android.view.View
    public void draw(Canvas canvas) {
        super.draw(canvas);
    }

    public Drawable getCircularRevealOverlayDrawable() {
        throw null;
    }

    @Override // e1.d
    public int getCircularRevealScrimColor() {
        throw null;
    }

    @Override // e1.d
    public d.e getRevealInfo() {
        throw null;
    }

    @Override // android.view.View
    public boolean isOpaque() {
        return super.isOpaque();
    }

    @Override // e1.d
    public void setCircularRevealOverlayDrawable(Drawable drawable) {
        throw null;
    }

    @Override // e1.d
    public void setCircularRevealScrimColor(int i2) {
        throw null;
    }

    @Override // e1.d
    public void setRevealInfo(d.e eVar) {
        throw null;
    }
}
