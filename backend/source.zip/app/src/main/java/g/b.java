package g;

import android.content.Context;
import android.view.MenuItem;
import android.view.SubMenu;
import l.g;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes.dex */
public abstract class b {

    /* renamed from: a  reason: collision with root package name */
    final Context f4479a;

    /* renamed from: b  reason: collision with root package name */
    private g<y.b, MenuItem> f4480b;

    /* renamed from: c  reason: collision with root package name */
    private g<y.c, SubMenu> f4481c;

    /* JADX INFO: Access modifiers changed from: package-private */
    public b(Context context) {
        this.f4479a = context;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final MenuItem c(MenuItem menuItem) {
        if (menuItem instanceof y.b) {
            y.b bVar = (y.b) menuItem;
            if (this.f4480b == null) {
                this.f4480b = new g<>();
            }
            MenuItem menuItem2 = this.f4480b.get(menuItem);
            if (menuItem2 == null) {
                c cVar = new c(this.f4479a, bVar);
                this.f4480b.put(bVar, cVar);
                return cVar;
            }
            return menuItem2;
        }
        return menuItem;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final SubMenu d(SubMenu subMenu) {
        if (subMenu instanceof y.c) {
            y.c cVar = (y.c) subMenu;
            if (this.f4481c == null) {
                this.f4481c = new g<>();
            }
            SubMenu subMenu2 = this.f4481c.get(cVar);
            if (subMenu2 == null) {
                f fVar = new f(this.f4479a, cVar);
                this.f4481c.put(cVar, fVar);
                return fVar;
            }
            return subMenu2;
        }
        return subMenu;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final void e() {
        g<y.b, MenuItem> gVar = this.f4480b;
        if (gVar != null) {
            gVar.clear();
        }
        g<y.c, SubMenu> gVar2 = this.f4481c;
        if (gVar2 != null) {
            gVar2.clear();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final void f(int i2) {
        if (this.f4480b == null) {
            return;
        }
        int i3 = 0;
        while (i3 < this.f4480b.size()) {
            if (this.f4480b.k(i3).getGroupId() == i2) {
                this.f4480b.m(i3);
                i3--;
            }
            i3++;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final void g(int i2) {
        if (this.f4480b == null) {
            return;
        }
        for (int i3 = 0; i3 < this.f4480b.size(); i3++) {
            if (this.f4480b.k(i3).getItemId() == i2) {
                this.f4480b.m(i3);
                return;
            }
        }
    }
}
