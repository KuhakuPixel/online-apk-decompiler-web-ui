package e0;

import android.view.View;
/* loaded from: classes.dex */
public class w implements v {
    @Override // e0.v
    public void b(View view) {
    }

    @Override // e0.v
    public void c(View view) {
    }
}
