package androidx.core.internal.view;

import android.view.SubMenu;
/* loaded from: classes.dex */
public interface SupportSubMenu extends SupportMenu, SubMenu {
}
