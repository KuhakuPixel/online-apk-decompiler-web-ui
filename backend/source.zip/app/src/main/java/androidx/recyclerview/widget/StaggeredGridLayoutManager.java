package androidx.recyclerview.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.PointF;
import android.graphics.Rect;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import androidx.recyclerview.widget.RecyclerView;
import f0.c;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.List;
/* loaded from: classes.dex */
public class StaggeredGridLayoutManager extends RecyclerView.o implements RecyclerView.z.b {
    private BitSet B;
    private boolean G;
    private boolean H;
    private e I;
    private int J;
    private int[] O;

    /* renamed from: t  reason: collision with root package name */
    f[] f2288t;

    /* renamed from: u  reason: collision with root package name */
    i f2289u;

    /* renamed from: v  reason: collision with root package name */
    i f2290v;

    /* renamed from: w  reason: collision with root package name */
    private int f2291w;

    /* renamed from: x  reason: collision with root package name */
    private int f2292x;

    /* renamed from: y  reason: collision with root package name */
    private final androidx.recyclerview.widget.f f2293y;

    /* renamed from: s  reason: collision with root package name */
    private int f2287s = -1;

    /* renamed from: z  reason: collision with root package name */
    boolean f2294z = false;
    boolean A = false;
    int C = -1;
    int D = Integer.MIN_VALUE;
    d E = new d();
    private int F = 2;
    private final Rect K = new Rect();
    private final b L = new b();
    private boolean M = false;
    private boolean N = true;
    private final Runnable P = new a();

    /* loaded from: classes.dex */
    class a implements Runnable {
        a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            StaggeredGridLayoutManager.this.S1();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public class b {

        /* renamed from: a  reason: collision with root package name */
        int f2296a;

        /* renamed from: b  reason: collision with root package name */
        int f2297b;

        /* renamed from: c  reason: collision with root package name */
        boolean f2298c;

        /* renamed from: d  reason: collision with root package name */
        boolean f2299d;

        /* renamed from: e  reason: collision with root package name */
        boolean f2300e;

        /* renamed from: f  reason: collision with root package name */
        int[] f2301f;

        b() {
            c();
        }

        void a() {
            this.f2297b = this.f2298c ? StaggeredGridLayoutManager.this.f2289u.i() : StaggeredGridLayoutManager.this.f2289u.m();
        }

        void b(int i2) {
            this.f2297b = this.f2298c ? StaggeredGridLayoutManager.this.f2289u.i() - i2 : StaggeredGridLayoutManager.this.f2289u.m() + i2;
        }

        void c() {
            this.f2296a = -1;
            this.f2297b = Integer.MIN_VALUE;
            this.f2298c = false;
            this.f2299d = false;
            this.f2300e = false;
            int[] iArr = this.f2301f;
            if (iArr != null) {
                Arrays.fill(iArr, -1);
            }
        }

        void d(f[] fVarArr) {
            int length = fVarArr.length;
            int[] iArr = this.f2301f;
            if (iArr == null || iArr.length < length) {
                this.f2301f = new int[StaggeredGridLayoutManager.this.f2288t.length];
            }
            for (int i2 = 0; i2 < length; i2++) {
                this.f2301f[i2] = fVarArr[i2].p(Integer.MIN_VALUE);
            }
        }
    }

    /* loaded from: classes.dex */
    public static class c extends RecyclerView.p {

        /* renamed from: e  reason: collision with root package name */
        f f2303e;

        /* renamed from: f  reason: collision with root package name */
        boolean f2304f;

        public c(int i2, int i3) {
            super(i2, i3);
        }

        public c(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public c(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }

        public c(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
        }

        public final int e() {
            f fVar = this.f2303e;
            if (fVar == null) {
                return -1;
            }
            return fVar.f2325e;
        }

        public boolean f() {
            return this.f2304f;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public static class d {

        /* renamed from: a  reason: collision with root package name */
        int[] f2305a;

        /* renamed from: b  reason: collision with root package name */
        List<a> f2306b;

        /* JADX INFO: Access modifiers changed from: package-private */
        @SuppressLint({"BanParcelableUsage"})
        /* loaded from: classes.dex */
        public static class a implements Parcelable {
            public static final Parcelable.Creator<a> CREATOR = new C0014a();

            /* renamed from: b  reason: collision with root package name */
            int f2307b;

            /* renamed from: c  reason: collision with root package name */
            int f2308c;

            /* renamed from: d  reason: collision with root package name */
            int[] f2309d;

            /* renamed from: e  reason: collision with root package name */
            boolean f2310e;

            /* renamed from: androidx.recyclerview.widget.StaggeredGridLayoutManager$d$a$a  reason: collision with other inner class name */
            /* loaded from: classes.dex */
            static class C0014a implements Parcelable.Creator<a> {
                C0014a() {
                }

                @Override // android.os.Parcelable.Creator
                /* renamed from: a  reason: merged with bridge method [inline-methods] */
                public a createFromParcel(Parcel parcel) {
                    return new a(parcel);
                }

                @Override // android.os.Parcelable.Creator
                /* renamed from: b  reason: merged with bridge method [inline-methods] */
                public a[] newArray(int i2) {
                    return new a[i2];
                }
            }

            a() {
            }

            a(Parcel parcel) {
                this.f2307b = parcel.readInt();
                this.f2308c = parcel.readInt();
                this.f2310e = parcel.readInt() == 1;
                int readInt = parcel.readInt();
                if (readInt > 0) {
                    int[] iArr = new int[readInt];
                    this.f2309d = iArr;
                    parcel.readIntArray(iArr);
                }
            }

            @Override // android.os.Parcelable
            public int describeContents() {
                return 0;
            }

            int j(int i2) {
                int[] iArr = this.f2309d;
                if (iArr == null) {
                    return 0;
                }
                return iArr[i2];
            }

            public String toString() {
                return "FullSpanItem{mPosition=" + this.f2307b + ", mGapDir=" + this.f2308c + ", mHasUnwantedGapAfter=" + this.f2310e + ", mGapPerSpan=" + Arrays.toString(this.f2309d) + '}';
            }

            @Override // android.os.Parcelable
            public void writeToParcel(Parcel parcel, int i2) {
                parcel.writeInt(this.f2307b);
                parcel.writeInt(this.f2308c);
                parcel.writeInt(this.f2310e ? 1 : 0);
                int[] iArr = this.f2309d;
                if (iArr == null || iArr.length <= 0) {
                    parcel.writeInt(0);
                    return;
                }
                parcel.writeInt(iArr.length);
                parcel.writeIntArray(this.f2309d);
            }
        }

        d() {
        }

        private int i(int i2) {
            if (this.f2306b == null) {
                return -1;
            }
            a f2 = f(i2);
            if (f2 != null) {
                this.f2306b.remove(f2);
            }
            int size = this.f2306b.size();
            int i3 = 0;
            while (true) {
                if (i3 >= size) {
                    i3 = -1;
                    break;
                } else if (this.f2306b.get(i3).f2307b >= i2) {
                    break;
                } else {
                    i3++;
                }
            }
            if (i3 != -1) {
                a aVar = this.f2306b.get(i3);
                this.f2306b.remove(i3);
                return aVar.f2307b;
            }
            return -1;
        }

        private void l(int i2, int i3) {
            List<a> list = this.f2306b;
            if (list == null) {
                return;
            }
            for (int size = list.size() - 1; size >= 0; size--) {
                a aVar = this.f2306b.get(size);
                int i4 = aVar.f2307b;
                if (i4 >= i2) {
                    aVar.f2307b = i4 + i3;
                }
            }
        }

        private void m(int i2, int i3) {
            List<a> list = this.f2306b;
            if (list == null) {
                return;
            }
            int i4 = i2 + i3;
            for (int size = list.size() - 1; size >= 0; size--) {
                a aVar = this.f2306b.get(size);
                int i5 = aVar.f2307b;
                if (i5 >= i2) {
                    if (i5 < i4) {
                        this.f2306b.remove(size);
                    } else {
                        aVar.f2307b = i5 - i3;
                    }
                }
            }
        }

        public void a(a aVar) {
            if (this.f2306b == null) {
                this.f2306b = new ArrayList();
            }
            int size = this.f2306b.size();
            for (int i2 = 0; i2 < size; i2++) {
                a aVar2 = this.f2306b.get(i2);
                if (aVar2.f2307b == aVar.f2307b) {
                    this.f2306b.remove(i2);
                }
                if (aVar2.f2307b >= aVar.f2307b) {
                    this.f2306b.add(i2, aVar);
                    return;
                }
            }
            this.f2306b.add(aVar);
        }

        void b() {
            int[] iArr = this.f2305a;
            if (iArr != null) {
                Arrays.fill(iArr, -1);
            }
            this.f2306b = null;
        }

        void c(int i2) {
            int[] iArr = this.f2305a;
            if (iArr == null) {
                int[] iArr2 = new int[Math.max(i2, 10) + 1];
                this.f2305a = iArr2;
                Arrays.fill(iArr2, -1);
            } else if (i2 >= iArr.length) {
                int[] iArr3 = new int[o(i2)];
                this.f2305a = iArr3;
                System.arraycopy(iArr, 0, iArr3, 0, iArr.length);
                int[] iArr4 = this.f2305a;
                Arrays.fill(iArr4, iArr.length, iArr4.length, -1);
            }
        }

        int d(int i2) {
            List<a> list = this.f2306b;
            if (list != null) {
                for (int size = list.size() - 1; size >= 0; size--) {
                    if (this.f2306b.get(size).f2307b >= i2) {
                        this.f2306b.remove(size);
                    }
                }
            }
            return h(i2);
        }

        public a e(int i2, int i3, int i4, boolean z2) {
            List<a> list = this.f2306b;
            if (list == null) {
                return null;
            }
            int size = list.size();
            for (int i5 = 0; i5 < size; i5++) {
                a aVar = this.f2306b.get(i5);
                int i6 = aVar.f2307b;
                if (i6 >= i3) {
                    return null;
                }
                if (i6 >= i2 && (i4 == 0 || aVar.f2308c == i4 || (z2 && aVar.f2310e))) {
                    return aVar;
                }
            }
            return null;
        }

        public a f(int i2) {
            List<a> list = this.f2306b;
            if (list == null) {
                return null;
            }
            for (int size = list.size() - 1; size >= 0; size--) {
                a aVar = this.f2306b.get(size);
                if (aVar.f2307b == i2) {
                    return aVar;
                }
            }
            return null;
        }

        int g(int i2) {
            int[] iArr = this.f2305a;
            if (iArr == null || i2 >= iArr.length) {
                return -1;
            }
            return iArr[i2];
        }

        int h(int i2) {
            int[] iArr = this.f2305a;
            if (iArr != null && i2 < iArr.length) {
                int i3 = i(i2);
                if (i3 == -1) {
                    int[] iArr2 = this.f2305a;
                    Arrays.fill(iArr2, i2, iArr2.length, -1);
                    return this.f2305a.length;
                }
                int i4 = i3 + 1;
                Arrays.fill(this.f2305a, i2, i4, -1);
                return i4;
            }
            return -1;
        }

        void j(int i2, int i3) {
            int[] iArr = this.f2305a;
            if (iArr == null || i2 >= iArr.length) {
                return;
            }
            int i4 = i2 + i3;
            c(i4);
            int[] iArr2 = this.f2305a;
            System.arraycopy(iArr2, i2, iArr2, i4, (iArr2.length - i2) - i3);
            Arrays.fill(this.f2305a, i2, i4, -1);
            l(i2, i3);
        }

        void k(int i2, int i3) {
            int[] iArr = this.f2305a;
            if (iArr == null || i2 >= iArr.length) {
                return;
            }
            int i4 = i2 + i3;
            c(i4);
            int[] iArr2 = this.f2305a;
            System.arraycopy(iArr2, i4, iArr2, i2, (iArr2.length - i2) - i3);
            int[] iArr3 = this.f2305a;
            Arrays.fill(iArr3, iArr3.length - i3, iArr3.length, -1);
            m(i2, i3);
        }

        void n(int i2, f fVar) {
            c(i2);
            this.f2305a[i2] = fVar.f2325e;
        }

        int o(int i2) {
            int length = this.f2305a.length;
            while (length <= i2) {
                length *= 2;
            }
            return length;
        }
    }

    @SuppressLint({"BanParcelableUsage"})
    /* loaded from: classes.dex */
    public static class e implements Parcelable {
        public static final Parcelable.Creator<e> CREATOR = new a();

        /* renamed from: b  reason: collision with root package name */
        int f2311b;

        /* renamed from: c  reason: collision with root package name */
        int f2312c;

        /* renamed from: d  reason: collision with root package name */
        int f2313d;

        /* renamed from: e  reason: collision with root package name */
        int[] f2314e;

        /* renamed from: f  reason: collision with root package name */
        int f2315f;

        /* renamed from: g  reason: collision with root package name */
        int[] f2316g;

        /* renamed from: h  reason: collision with root package name */
        List<d.a> f2317h;

        /* renamed from: i  reason: collision with root package name */
        boolean f2318i;

        /* renamed from: j  reason: collision with root package name */
        boolean f2319j;

        /* renamed from: k  reason: collision with root package name */
        boolean f2320k;

        /* loaded from: classes.dex */
        static class a implements Parcelable.Creator<e> {
            a() {
            }

            @Override // android.os.Parcelable.Creator
            /* renamed from: a  reason: merged with bridge method [inline-methods] */
            public e createFromParcel(Parcel parcel) {
                return new e(parcel);
            }

            @Override // android.os.Parcelable.Creator
            /* renamed from: b  reason: merged with bridge method [inline-methods] */
            public e[] newArray(int i2) {
                return new e[i2];
            }
        }

        public e() {
        }

        e(Parcel parcel) {
            this.f2311b = parcel.readInt();
            this.f2312c = parcel.readInt();
            int readInt = parcel.readInt();
            this.f2313d = readInt;
            if (readInt > 0) {
                int[] iArr = new int[readInt];
                this.f2314e = iArr;
                parcel.readIntArray(iArr);
            }
            int readInt2 = parcel.readInt();
            this.f2315f = readInt2;
            if (readInt2 > 0) {
                int[] iArr2 = new int[readInt2];
                this.f2316g = iArr2;
                parcel.readIntArray(iArr2);
            }
            this.f2318i = parcel.readInt() == 1;
            this.f2319j = parcel.readInt() == 1;
            this.f2320k = parcel.readInt() == 1;
            this.f2317h = parcel.readArrayList(d.a.class.getClassLoader());
        }

        public e(e eVar) {
            this.f2313d = eVar.f2313d;
            this.f2311b = eVar.f2311b;
            this.f2312c = eVar.f2312c;
            this.f2314e = eVar.f2314e;
            this.f2315f = eVar.f2315f;
            this.f2316g = eVar.f2316g;
            this.f2318i = eVar.f2318i;
            this.f2319j = eVar.f2319j;
            this.f2320k = eVar.f2320k;
            this.f2317h = eVar.f2317h;
        }

        @Override // android.os.Parcelable
        public int describeContents() {
            return 0;
        }

        void j() {
            this.f2314e = null;
            this.f2313d = 0;
            this.f2311b = -1;
            this.f2312c = -1;
        }

        void k() {
            this.f2314e = null;
            this.f2313d = 0;
            this.f2315f = 0;
            this.f2316g = null;
            this.f2317h = null;
        }

        @Override // android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i2) {
            parcel.writeInt(this.f2311b);
            parcel.writeInt(this.f2312c);
            parcel.writeInt(this.f2313d);
            if (this.f2313d > 0) {
                parcel.writeIntArray(this.f2314e);
            }
            parcel.writeInt(this.f2315f);
            if (this.f2315f > 0) {
                parcel.writeIntArray(this.f2316g);
            }
            parcel.writeInt(this.f2318i ? 1 : 0);
            parcel.writeInt(this.f2319j ? 1 : 0);
            parcel.writeInt(this.f2320k ? 1 : 0);
            parcel.writeList(this.f2317h);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public class f {

        /* renamed from: a  reason: collision with root package name */
        ArrayList<View> f2321a = new ArrayList<>();

        /* renamed from: b  reason: collision with root package name */
        int f2322b = Integer.MIN_VALUE;

        /* renamed from: c  reason: collision with root package name */
        int f2323c = Integer.MIN_VALUE;

        /* renamed from: d  reason: collision with root package name */
        int f2324d = 0;

        /* renamed from: e  reason: collision with root package name */
        final int f2325e;

        f(int i2) {
            this.f2325e = i2;
        }

        void a(View view) {
            c n2 = n(view);
            n2.f2303e = this;
            this.f2321a.add(view);
            this.f2323c = Integer.MIN_VALUE;
            if (this.f2321a.size() == 1) {
                this.f2322b = Integer.MIN_VALUE;
            }
            if (n2.c() || n2.b()) {
                this.f2324d += StaggeredGridLayoutManager.this.f2289u.e(view);
            }
        }

        void b(boolean z2, int i2) {
            int l2 = z2 ? l(Integer.MIN_VALUE) : p(Integer.MIN_VALUE);
            e();
            if (l2 == Integer.MIN_VALUE) {
                return;
            }
            if (!z2 || l2 >= StaggeredGridLayoutManager.this.f2289u.i()) {
                if (z2 || l2 <= StaggeredGridLayoutManager.this.f2289u.m()) {
                    if (i2 != Integer.MIN_VALUE) {
                        l2 += i2;
                    }
                    this.f2323c = l2;
                    this.f2322b = l2;
                }
            }
        }

        void c() {
            d.a f2;
            ArrayList<View> arrayList = this.f2321a;
            View view = arrayList.get(arrayList.size() - 1);
            c n2 = n(view);
            this.f2323c = StaggeredGridLayoutManager.this.f2289u.d(view);
            if (n2.f2304f && (f2 = StaggeredGridLayoutManager.this.E.f(n2.a())) != null && f2.f2308c == 1) {
                this.f2323c += f2.j(this.f2325e);
            }
        }

        void d() {
            d.a f2;
            View view = this.f2321a.get(0);
            c n2 = n(view);
            this.f2322b = StaggeredGridLayoutManager.this.f2289u.g(view);
            if (n2.f2304f && (f2 = StaggeredGridLayoutManager.this.E.f(n2.a())) != null && f2.f2308c == -1) {
                this.f2322b -= f2.j(this.f2325e);
            }
        }

        void e() {
            this.f2321a.clear();
            q();
            this.f2324d = 0;
        }

        public int f() {
            int i2;
            int size;
            if (StaggeredGridLayoutManager.this.f2294z) {
                i2 = this.f2321a.size() - 1;
                size = -1;
            } else {
                i2 = 0;
                size = this.f2321a.size();
            }
            return i(i2, size, true);
        }

        public int g() {
            int size;
            int i2;
            if (StaggeredGridLayoutManager.this.f2294z) {
                size = 0;
                i2 = this.f2321a.size();
            } else {
                size = this.f2321a.size() - 1;
                i2 = -1;
            }
            return i(size, i2, true);
        }

        int h(int i2, int i3, boolean z2, boolean z3, boolean z4) {
            int m2 = StaggeredGridLayoutManager.this.f2289u.m();
            int i4 = StaggeredGridLayoutManager.this.f2289u.i();
            int i5 = i3 > i2 ? 1 : -1;
            while (i2 != i3) {
                View view = this.f2321a.get(i2);
                int g2 = StaggeredGridLayoutManager.this.f2289u.g(view);
                int d2 = StaggeredGridLayoutManager.this.f2289u.d(view);
                boolean z5 = false;
                boolean z6 = !z4 ? g2 >= i4 : g2 > i4;
                if (!z4 ? d2 > m2 : d2 >= m2) {
                    z5 = true;
                }
                if (z6 && z5) {
                    if (!z2 || !z3) {
                        if (!z3 && g2 >= m2 && d2 <= i4) {
                        }
                        return StaggeredGridLayoutManager.this.h0(view);
                    } else if (g2 >= m2 && d2 <= i4) {
                        return StaggeredGridLayoutManager.this.h0(view);
                    }
                }
                i2 += i5;
            }
            return -1;
        }

        int i(int i2, int i3, boolean z2) {
            return h(i2, i3, false, false, z2);
        }

        public int j() {
            return this.f2324d;
        }

        int k() {
            int i2 = this.f2323c;
            if (i2 != Integer.MIN_VALUE) {
                return i2;
            }
            c();
            return this.f2323c;
        }

        int l(int i2) {
            int i3 = this.f2323c;
            if (i3 != Integer.MIN_VALUE) {
                return i3;
            }
            if (this.f2321a.size() == 0) {
                return i2;
            }
            c();
            return this.f2323c;
        }

        public View m(int i2, int i3) {
            View view = null;
            if (i3 != -1) {
                int size = this.f2321a.size() - 1;
                while (size >= 0) {
                    View view2 = this.f2321a.get(size);
                    StaggeredGridLayoutManager staggeredGridLayoutManager = StaggeredGridLayoutManager.this;
                    if (staggeredGridLayoutManager.f2294z && staggeredGridLayoutManager.h0(view2) >= i2) {
                        break;
                    }
                    StaggeredGridLayoutManager staggeredGridLayoutManager2 = StaggeredGridLayoutManager.this;
                    if ((!staggeredGridLayoutManager2.f2294z && staggeredGridLayoutManager2.h0(view2) <= i2) || !view2.hasFocusable()) {
                        break;
                    }
                    size--;
                    view = view2;
                }
            } else {
                int size2 = this.f2321a.size();
                int i4 = 0;
                while (i4 < size2) {
                    View view3 = this.f2321a.get(i4);
                    StaggeredGridLayoutManager staggeredGridLayoutManager3 = StaggeredGridLayoutManager.this;
                    if (staggeredGridLayoutManager3.f2294z && staggeredGridLayoutManager3.h0(view3) <= i2) {
                        break;
                    }
                    StaggeredGridLayoutManager staggeredGridLayoutManager4 = StaggeredGridLayoutManager.this;
                    if ((!staggeredGridLayoutManager4.f2294z && staggeredGridLayoutManager4.h0(view3) >= i2) || !view3.hasFocusable()) {
                        break;
                    }
                    i4++;
                    view = view3;
                }
            }
            return view;
        }

        c n(View view) {
            return (c) view.getLayoutParams();
        }

        int o() {
            int i2 = this.f2322b;
            if (i2 != Integer.MIN_VALUE) {
                return i2;
            }
            d();
            return this.f2322b;
        }

        int p(int i2) {
            int i3 = this.f2322b;
            if (i3 != Integer.MIN_VALUE) {
                return i3;
            }
            if (this.f2321a.size() == 0) {
                return i2;
            }
            d();
            return this.f2322b;
        }

        void q() {
            this.f2322b = Integer.MIN_VALUE;
            this.f2323c = Integer.MIN_VALUE;
        }

        void r(int i2) {
            int i3 = this.f2322b;
            if (i3 != Integer.MIN_VALUE) {
                this.f2322b = i3 + i2;
            }
            int i4 = this.f2323c;
            if (i4 != Integer.MIN_VALUE) {
                this.f2323c = i4 + i2;
            }
        }

        void s() {
            int size = this.f2321a.size();
            View remove = this.f2321a.remove(size - 1);
            c n2 = n(remove);
            n2.f2303e = null;
            if (n2.c() || n2.b()) {
                this.f2324d -= StaggeredGridLayoutManager.this.f2289u.e(remove);
            }
            if (size == 1) {
                this.f2322b = Integer.MIN_VALUE;
            }
            this.f2323c = Integer.MIN_VALUE;
        }

        void t() {
            View remove = this.f2321a.remove(0);
            c n2 = n(remove);
            n2.f2303e = null;
            if (this.f2321a.size() == 0) {
                this.f2323c = Integer.MIN_VALUE;
            }
            if (n2.c() || n2.b()) {
                this.f2324d -= StaggeredGridLayoutManager.this.f2289u.e(remove);
            }
            this.f2322b = Integer.MIN_VALUE;
        }

        void u(View view) {
            c n2 = n(view);
            n2.f2303e = this;
            this.f2321a.add(0, view);
            this.f2322b = Integer.MIN_VALUE;
            if (this.f2321a.size() == 1) {
                this.f2323c = Integer.MIN_VALUE;
            }
            if (n2.c() || n2.b()) {
                this.f2324d += StaggeredGridLayoutManager.this.f2289u.e(view);
            }
        }

        void v(int i2) {
            this.f2322b = i2;
            this.f2323c = i2;
        }
    }

    public StaggeredGridLayoutManager(Context context, AttributeSet attributeSet, int i2, int i3) {
        RecyclerView.o.d i02 = RecyclerView.o.i0(context, attributeSet, i2, i3);
        H2(i02.f2248a);
        J2(i02.f2249b);
        I2(i02.f2250c);
        this.f2293y = new androidx.recyclerview.widget.f();
        a2();
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0010, code lost:
        if (r4.f2445e == (-1)) goto L11;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private void A2(androidx.recyclerview.widget.RecyclerView.v r3, androidx.recyclerview.widget.f r4) {
        /*
            r2 = this;
            boolean r0 = r4.f2441a
            if (r0 == 0) goto L4d
            boolean r0 = r4.f2449i
            if (r0 == 0) goto L9
            goto L4d
        L9:
            int r0 = r4.f2442b
            r1 = -1
            if (r0 != 0) goto L1e
            int r0 = r4.f2445e
            if (r0 != r1) goto L18
        L12:
            int r4 = r4.f2447g
        L14:
            r2.B2(r3, r4)
            goto L4d
        L18:
            int r4 = r4.f2446f
        L1a:
            r2.C2(r3, r4)
            goto L4d
        L1e:
            int r0 = r4.f2445e
            if (r0 != r1) goto L37
            int r0 = r4.f2446f
            int r1 = r2.m2(r0)
            int r0 = r0 - r1
            if (r0 >= 0) goto L2c
            goto L12
        L2c:
            int r1 = r4.f2447g
            int r4 = r4.f2442b
            int r4 = java.lang.Math.min(r0, r4)
            int r4 = r1 - r4
            goto L14
        L37:
            int r0 = r4.f2447g
            int r0 = r2.n2(r0)
            int r1 = r4.f2447g
            int r0 = r0 - r1
            if (r0 >= 0) goto L43
            goto L18
        L43:
            int r1 = r4.f2446f
            int r4 = r4.f2442b
            int r4 = java.lang.Math.min(r0, r4)
            int r4 = r4 + r1
            goto L1a
        L4d:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.StaggeredGridLayoutManager.A2(androidx.recyclerview.widget.RecyclerView$v, androidx.recyclerview.widget.f):void");
    }

    private void B2(RecyclerView.v vVar, int i2) {
        for (int J = J() - 1; J >= 0; J--) {
            View I = I(J);
            if (this.f2289u.g(I) < i2 || this.f2289u.q(I) < i2) {
                return;
            }
            c cVar = (c) I.getLayoutParams();
            if (cVar.f2304f) {
                for (int i3 = 0; i3 < this.f2287s; i3++) {
                    if (this.f2288t[i3].f2321a.size() == 1) {
                        return;
                    }
                }
                for (int i4 = 0; i4 < this.f2287s; i4++) {
                    this.f2288t[i4].s();
                }
            } else if (cVar.f2303e.f2321a.size() == 1) {
                return;
            } else {
                cVar.f2303e.s();
            }
            m1(I, vVar);
        }
    }

    private void C2(RecyclerView.v vVar, int i2) {
        while (J() > 0) {
            View I = I(0);
            if (this.f2289u.d(I) > i2 || this.f2289u.p(I) > i2) {
                return;
            }
            c cVar = (c) I.getLayoutParams();
            if (cVar.f2304f) {
                for (int i3 = 0; i3 < this.f2287s; i3++) {
                    if (this.f2288t[i3].f2321a.size() == 1) {
                        return;
                    }
                }
                for (int i4 = 0; i4 < this.f2287s; i4++) {
                    this.f2288t[i4].t();
                }
            } else if (cVar.f2303e.f2321a.size() == 1) {
                return;
            } else {
                cVar.f2303e.t();
            }
            m1(I, vVar);
        }
    }

    private void D2() {
        if (this.f2290v.k() == 1073741824) {
            return;
        }
        float f2 = 0.0f;
        int J = J();
        for (int i2 = 0; i2 < J; i2++) {
            View I = I(i2);
            float e2 = this.f2290v.e(I);
            if (e2 >= f2) {
                if (((c) I.getLayoutParams()).f()) {
                    e2 = (e2 * 1.0f) / this.f2287s;
                }
                f2 = Math.max(f2, e2);
            }
        }
        int i3 = this.f2292x;
        int round = Math.round(f2 * this.f2287s);
        if (this.f2290v.k() == Integer.MIN_VALUE) {
            round = Math.min(round, this.f2290v.n());
        }
        P2(round);
        if (this.f2292x == i3) {
            return;
        }
        for (int i4 = 0; i4 < J; i4++) {
            View I2 = I(i4);
            c cVar = (c) I2.getLayoutParams();
            if (!cVar.f2304f) {
                if (t2() && this.f2291w == 1) {
                    int i5 = this.f2287s;
                    int i6 = cVar.f2303e.f2325e;
                    I2.offsetLeftAndRight(((-((i5 - 1) - i6)) * this.f2292x) - ((-((i5 - 1) - i6)) * i3));
                } else {
                    int i7 = cVar.f2303e.f2325e;
                    int i8 = this.f2291w;
                    int i9 = (this.f2292x * i7) - (i7 * i3);
                    if (i8 == 1) {
                        I2.offsetLeftAndRight(i9);
                    } else {
                        I2.offsetTopAndBottom(i9);
                    }
                }
            }
        }
    }

    private void E2() {
        this.A = (this.f2291w == 1 || !t2()) ? this.f2294z : !this.f2294z;
    }

    private void G2(int i2) {
        androidx.recyclerview.widget.f fVar = this.f2293y;
        fVar.f2445e = i2;
        fVar.f2444d = this.A != (i2 == -1) ? -1 : 1;
    }

    private void K2(int i2, int i3) {
        for (int i4 = 0; i4 < this.f2287s; i4++) {
            if (!this.f2288t[i4].f2321a.isEmpty()) {
                Q2(this.f2288t[i4], i2, i3);
            }
        }
    }

    private boolean L2(RecyclerView.a0 a0Var, b bVar) {
        boolean z2 = this.G;
        int b2 = a0Var.b();
        bVar.f2296a = z2 ? g2(b2) : c2(b2);
        bVar.f2297b = Integer.MIN_VALUE;
        return true;
    }

    private void M1(View view) {
        for (int i2 = this.f2287s - 1; i2 >= 0; i2--) {
            this.f2288t[i2].a(view);
        }
    }

    private void N1(b bVar) {
        boolean z2;
        e eVar = this.I;
        int i2 = eVar.f2313d;
        if (i2 > 0) {
            if (i2 == this.f2287s) {
                for (int i3 = 0; i3 < this.f2287s; i3++) {
                    this.f2288t[i3].e();
                    e eVar2 = this.I;
                    int i4 = eVar2.f2314e[i3];
                    if (i4 != Integer.MIN_VALUE) {
                        i4 += eVar2.f2319j ? this.f2289u.i() : this.f2289u.m();
                    }
                    this.f2288t[i3].v(i4);
                }
            } else {
                eVar.k();
                e eVar3 = this.I;
                eVar3.f2311b = eVar3.f2312c;
            }
        }
        e eVar4 = this.I;
        this.H = eVar4.f2320k;
        I2(eVar4.f2318i);
        E2();
        e eVar5 = this.I;
        int i5 = eVar5.f2311b;
        if (i5 != -1) {
            this.C = i5;
            z2 = eVar5.f2319j;
        } else {
            z2 = this.A;
        }
        bVar.f2298c = z2;
        if (eVar5.f2315f > 1) {
            d dVar = this.E;
            dVar.f2305a = eVar5.f2316g;
            dVar.f2306b = eVar5.f2317h;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:17:0x0036  */
    /* JADX WARN: Removed duplicated region for block: B:18:0x004d  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private void O2(int r5, androidx.recyclerview.widget.RecyclerView.a0 r6) {
        /*
            r4 = this;
            androidx.recyclerview.widget.f r0 = r4.f2293y
            r1 = 0
            r0.f2442b = r1
            r0.f2443c = r5
            boolean r0 = r4.x0()
            r2 = 1
            if (r0 == 0) goto L2e
            int r6 = r6.c()
            r0 = -1
            if (r6 == r0) goto L2e
            boolean r0 = r4.A
            if (r6 >= r5) goto L1b
            r5 = 1
            goto L1c
        L1b:
            r5 = 0
        L1c:
            if (r0 != r5) goto L25
            androidx.recyclerview.widget.i r5 = r4.f2289u
            int r5 = r5.n()
            goto L2f
        L25:
            androidx.recyclerview.widget.i r5 = r4.f2289u
            int r5 = r5.n()
            r6 = r5
            r5 = 0
            goto L30
        L2e:
            r5 = 0
        L2f:
            r6 = 0
        L30:
            boolean r0 = r4.M()
            if (r0 == 0) goto L4d
            androidx.recyclerview.widget.f r0 = r4.f2293y
            androidx.recyclerview.widget.i r3 = r4.f2289u
            int r3 = r3.m()
            int r3 = r3 - r6
            r0.f2446f = r3
            androidx.recyclerview.widget.f r6 = r4.f2293y
            androidx.recyclerview.widget.i r0 = r4.f2289u
            int r0 = r0.i()
            int r0 = r0 + r5
            r6.f2447g = r0
            goto L5d
        L4d:
            androidx.recyclerview.widget.f r0 = r4.f2293y
            androidx.recyclerview.widget.i r3 = r4.f2289u
            int r3 = r3.h()
            int r3 = r3 + r5
            r0.f2447g = r3
            androidx.recyclerview.widget.f r5 = r4.f2293y
            int r6 = -r6
            r5.f2446f = r6
        L5d:
            androidx.recyclerview.widget.f r5 = r4.f2293y
            r5.f2448h = r1
            r5.f2441a = r2
            androidx.recyclerview.widget.i r6 = r4.f2289u
            int r6 = r6.k()
            if (r6 != 0) goto L74
            androidx.recyclerview.widget.i r6 = r4.f2289u
            int r6 = r6.h()
            if (r6 != 0) goto L74
            r1 = 1
        L74:
            r5.f2449i = r1
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.StaggeredGridLayoutManager.O2(int, androidx.recyclerview.widget.RecyclerView$a0):void");
    }

    private void Q1(View view, c cVar, androidx.recyclerview.widget.f fVar) {
        if (fVar.f2445e == 1) {
            if (cVar.f2304f) {
                M1(view);
            } else {
                cVar.f2303e.a(view);
            }
        } else if (cVar.f2304f) {
            z2(view);
        } else {
            cVar.f2303e.u(view);
        }
    }

    private void Q2(f fVar, int i2, int i3) {
        int j2 = fVar.j();
        if (i2 == -1) {
            if (fVar.o() + j2 > i3) {
                return;
            }
        } else if (fVar.k() - j2 < i3) {
            return;
        }
        this.B.set(fVar.f2325e, false);
    }

    private int R1(int i2) {
        if (J() == 0) {
            return this.A ? 1 : -1;
        }
        return (i2 < j2()) != this.A ? -1 : 1;
    }

    private int R2(int i2, int i3, int i4) {
        if (i3 == 0 && i4 == 0) {
            return i2;
        }
        int mode = View.MeasureSpec.getMode(i2);
        return (mode == Integer.MIN_VALUE || mode == 1073741824) ? View.MeasureSpec.makeMeasureSpec(Math.max(0, (View.MeasureSpec.getSize(i2) - i3) - i4), mode) : i2;
    }

    private boolean T1(f fVar) {
        if (this.A) {
            if (fVar.k() < this.f2289u.i()) {
                ArrayList<View> arrayList = fVar.f2321a;
                return !fVar.n(arrayList.get(arrayList.size() - 1)).f2304f;
            }
        } else if (fVar.o() > this.f2289u.m()) {
            return !fVar.n(fVar.f2321a.get(0)).f2304f;
        }
        return false;
    }

    private int U1(RecyclerView.a0 a0Var) {
        if (J() == 0) {
            return 0;
        }
        return l.a(a0Var, this.f2289u, e2(!this.N), d2(!this.N), this, this.N);
    }

    private int V1(RecyclerView.a0 a0Var) {
        if (J() == 0) {
            return 0;
        }
        return l.b(a0Var, this.f2289u, e2(!this.N), d2(!this.N), this, this.N, this.A);
    }

    private int W1(RecyclerView.a0 a0Var) {
        if (J() == 0) {
            return 0;
        }
        return l.c(a0Var, this.f2289u, e2(!this.N), d2(!this.N), this, this.N);
    }

    private int X1(int i2) {
        return i2 != 1 ? i2 != 2 ? i2 != 17 ? i2 != 33 ? i2 != 66 ? (i2 == 130 && this.f2291w == 1) ? 1 : Integer.MIN_VALUE : this.f2291w == 0 ? 1 : Integer.MIN_VALUE : this.f2291w == 1 ? -1 : Integer.MIN_VALUE : this.f2291w == 0 ? -1 : Integer.MIN_VALUE : (this.f2291w != 1 && t2()) ? -1 : 1 : (this.f2291w != 1 && t2()) ? 1 : -1;
    }

    private d.a Y1(int i2) {
        d.a aVar = new d.a();
        aVar.f2309d = new int[this.f2287s];
        for (int i3 = 0; i3 < this.f2287s; i3++) {
            aVar.f2309d[i3] = i2 - this.f2288t[i3].l(i2);
        }
        return aVar;
    }

    private d.a Z1(int i2) {
        d.a aVar = new d.a();
        aVar.f2309d = new int[this.f2287s];
        for (int i3 = 0; i3 < this.f2287s; i3++) {
            aVar.f2309d[i3] = this.f2288t[i3].p(i2) - i2;
        }
        return aVar;
    }

    private void a2() {
        this.f2289u = i.b(this, this.f2291w);
        this.f2290v = i.b(this, 1 - this.f2291w);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r9v0 */
    /* JADX WARN: Type inference failed for: r9v1, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r9v7 */
    private int b2(RecyclerView.v vVar, androidx.recyclerview.widget.f fVar, RecyclerView.a0 a0Var) {
        int i2;
        f fVar2;
        int e2;
        int i3;
        int i4;
        int e3;
        RecyclerView.o oVar;
        View view;
        int i5;
        int i6;
        ?? r9 = 0;
        this.B.set(0, this.f2287s, true);
        if (this.f2293y.f2449i) {
            i2 = fVar.f2445e == 1 ? Integer.MAX_VALUE : Integer.MIN_VALUE;
        } else {
            i2 = fVar.f2445e == 1 ? fVar.f2447g + fVar.f2442b : fVar.f2446f - fVar.f2442b;
        }
        K2(fVar.f2445e, i2);
        int i7 = this.A ? this.f2289u.i() : this.f2289u.m();
        boolean z2 = false;
        while (fVar.a(a0Var) && (this.f2293y.f2449i || !this.B.isEmpty())) {
            View b2 = fVar.b(vVar);
            c cVar = (c) b2.getLayoutParams();
            int a2 = cVar.a();
            int g2 = this.E.g(a2);
            boolean z3 = g2 == -1;
            if (z3) {
                fVar2 = cVar.f2304f ? this.f2288t[r9] : p2(fVar);
                this.E.n(a2, fVar2);
            } else {
                fVar2 = this.f2288t[g2];
            }
            f fVar3 = fVar2;
            cVar.f2303e = fVar3;
            if (fVar.f2445e == 1) {
                d(b2);
            } else {
                e(b2, r9);
            }
            v2(b2, cVar, r9);
            if (fVar.f2445e == 1) {
                int l2 = cVar.f2304f ? l2(i7) : fVar3.l(i7);
                int e4 = this.f2289u.e(b2) + l2;
                if (z3 && cVar.f2304f) {
                    d.a Y1 = Y1(l2);
                    Y1.f2308c = -1;
                    Y1.f2307b = a2;
                    this.E.a(Y1);
                }
                i3 = e4;
                e2 = l2;
            } else {
                int o2 = cVar.f2304f ? o2(i7) : fVar3.p(i7);
                e2 = o2 - this.f2289u.e(b2);
                if (z3 && cVar.f2304f) {
                    d.a Z1 = Z1(o2);
                    Z1.f2308c = 1;
                    Z1.f2307b = a2;
                    this.E.a(Z1);
                }
                i3 = o2;
            }
            if (cVar.f2304f && fVar.f2444d == -1) {
                if (!z3) {
                    if ((!(fVar.f2445e == 1 ? O1() : P1())) != false) {
                        d.a f2 = this.E.f(a2);
                        if (f2 != null) {
                            f2.f2310e = true;
                        }
                    }
                }
                this.M = true;
            }
            Q1(b2, cVar, fVar);
            if (t2() && this.f2291w == 1) {
                int i8 = cVar.f2304f ? this.f2290v.i() : this.f2290v.i() - (((this.f2287s - 1) - fVar3.f2325e) * this.f2292x);
                e3 = i8;
                i4 = i8 - this.f2290v.e(b2);
            } else {
                int m2 = cVar.f2304f ? this.f2290v.m() : (fVar3.f2325e * this.f2292x) + this.f2290v.m();
                i4 = m2;
                e3 = this.f2290v.e(b2) + m2;
            }
            if (this.f2291w == 1) {
                oVar = this;
                view = b2;
                i5 = i4;
                i4 = e2;
                i6 = e3;
            } else {
                oVar = this;
                view = b2;
                i5 = e2;
                i6 = i3;
                i3 = e3;
            }
            oVar.z0(view, i5, i4, i6, i3);
            if (cVar.f2304f) {
                K2(this.f2293y.f2445e, i2);
            } else {
                Q2(fVar3, this.f2293y.f2445e, i2);
            }
            A2(vVar, this.f2293y);
            if (this.f2293y.f2448h && b2.hasFocusable()) {
                if (cVar.f2304f) {
                    this.B.clear();
                } else {
                    this.B.set(fVar3.f2325e, false);
                    z2 = true;
                    r9 = 0;
                }
            }
            z2 = true;
            r9 = 0;
        }
        if (!z2) {
            A2(vVar, this.f2293y);
        }
        int m3 = this.f2293y.f2445e == -1 ? this.f2289u.m() - o2(this.f2289u.m()) : l2(this.f2289u.i()) - this.f2289u.i();
        if (m3 > 0) {
            return Math.min(fVar.f2442b, m3);
        }
        return 0;
    }

    private int c2(int i2) {
        int J = J();
        for (int i3 = 0; i3 < J; i3++) {
            int h02 = h0(I(i3));
            if (h02 >= 0 && h02 < i2) {
                return h02;
            }
        }
        return 0;
    }

    private int g2(int i2) {
        for (int J = J() - 1; J >= 0; J--) {
            int h02 = h0(I(J));
            if (h02 >= 0 && h02 < i2) {
                return h02;
            }
        }
        return 0;
    }

    private void h2(RecyclerView.v vVar, RecyclerView.a0 a0Var, boolean z2) {
        int i2;
        int l2 = l2(Integer.MIN_VALUE);
        if (l2 != Integer.MIN_VALUE && (i2 = this.f2289u.i() - l2) > 0) {
            int i3 = i2 - (-F2(-i2, vVar, a0Var));
            if (!z2 || i3 <= 0) {
                return;
            }
            this.f2289u.r(i3);
        }
    }

    private void i2(RecyclerView.v vVar, RecyclerView.a0 a0Var, boolean z2) {
        int m2;
        int o2 = o2(Integer.MAX_VALUE);
        if (o2 != Integer.MAX_VALUE && (m2 = o2 - this.f2289u.m()) > 0) {
            int F2 = m2 - F2(m2, vVar, a0Var);
            if (!z2 || F2 <= 0) {
                return;
            }
            this.f2289u.r(-F2);
        }
    }

    private int l2(int i2) {
        int l2 = this.f2288t[0].l(i2);
        for (int i3 = 1; i3 < this.f2287s; i3++) {
            int l3 = this.f2288t[i3].l(i2);
            if (l3 > l2) {
                l2 = l3;
            }
        }
        return l2;
    }

    private int m2(int i2) {
        int p2 = this.f2288t[0].p(i2);
        for (int i3 = 1; i3 < this.f2287s; i3++) {
            int p3 = this.f2288t[i3].p(i2);
            if (p3 > p2) {
                p2 = p3;
            }
        }
        return p2;
    }

    private int n2(int i2) {
        int l2 = this.f2288t[0].l(i2);
        for (int i3 = 1; i3 < this.f2287s; i3++) {
            int l3 = this.f2288t[i3].l(i2);
            if (l3 < l2) {
                l2 = l3;
            }
        }
        return l2;
    }

    private int o2(int i2) {
        int p2 = this.f2288t[0].p(i2);
        for (int i3 = 1; i3 < this.f2287s; i3++) {
            int p3 = this.f2288t[i3].p(i2);
            if (p3 < p2) {
                p2 = p3;
            }
        }
        return p2;
    }

    private f p2(androidx.recyclerview.widget.f fVar) {
        int i2;
        int i3;
        int i4 = -1;
        if (x2(fVar.f2445e)) {
            i2 = this.f2287s - 1;
            i3 = -1;
        } else {
            i2 = 0;
            i4 = this.f2287s;
            i3 = 1;
        }
        f fVar2 = null;
        if (fVar.f2445e == 1) {
            int i5 = Integer.MAX_VALUE;
            int m2 = this.f2289u.m();
            while (i2 != i4) {
                f fVar3 = this.f2288t[i2];
                int l2 = fVar3.l(m2);
                if (l2 < i5) {
                    fVar2 = fVar3;
                    i5 = l2;
                }
                i2 += i3;
            }
            return fVar2;
        }
        int i6 = Integer.MIN_VALUE;
        int i7 = this.f2289u.i();
        while (i2 != i4) {
            f fVar4 = this.f2288t[i2];
            int p2 = fVar4.p(i7);
            if (p2 > i6) {
                fVar2 = fVar4;
                i6 = p2;
            }
            i2 += i3;
        }
        return fVar2;
    }

    /* JADX WARN: Removed duplicated region for block: B:15:0x0025  */
    /* JADX WARN: Removed duplicated region for block: B:21:0x003c  */
    /* JADX WARN: Removed duplicated region for block: B:23:0x0043 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:24:0x0044  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private void q2(int r7, int r8, int r9) {
        /*
            r6 = this;
            boolean r0 = r6.A
            if (r0 == 0) goto L9
            int r0 = r6.k2()
            goto Ld
        L9:
            int r0 = r6.j2()
        Ld:
            r1 = 8
            if (r9 != r1) goto L1a
            if (r7 >= r8) goto L16
            int r2 = r8 + 1
            goto L1c
        L16:
            int r2 = r7 + 1
            r3 = r8
            goto L1d
        L1a:
            int r2 = r7 + r8
        L1c:
            r3 = r7
        L1d:
            androidx.recyclerview.widget.StaggeredGridLayoutManager$d r4 = r6.E
            r4.h(r3)
            r4 = 1
            if (r9 == r4) goto L3c
            r5 = 2
            if (r9 == r5) goto L36
            if (r9 == r1) goto L2b
            goto L41
        L2b:
            androidx.recyclerview.widget.StaggeredGridLayoutManager$d r9 = r6.E
            r9.k(r7, r4)
            androidx.recyclerview.widget.StaggeredGridLayoutManager$d r7 = r6.E
            r7.j(r8, r4)
            goto L41
        L36:
            androidx.recyclerview.widget.StaggeredGridLayoutManager$d r9 = r6.E
            r9.k(r7, r8)
            goto L41
        L3c:
            androidx.recyclerview.widget.StaggeredGridLayoutManager$d r9 = r6.E
            r9.j(r7, r8)
        L41:
            if (r2 > r0) goto L44
            return
        L44:
            boolean r7 = r6.A
            if (r7 == 0) goto L4d
            int r7 = r6.j2()
            goto L51
        L4d:
            int r7 = r6.k2()
        L51:
            if (r3 > r7) goto L56
            r6.t1()
        L56:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.StaggeredGridLayoutManager.q2(int, int, int):void");
    }

    private void u2(View view, int i2, int i3, boolean z2) {
        j(view, this.K);
        c cVar = (c) view.getLayoutParams();
        int i4 = ((ViewGroup.MarginLayoutParams) cVar).leftMargin;
        Rect rect = this.K;
        int R2 = R2(i2, i4 + rect.left, ((ViewGroup.MarginLayoutParams) cVar).rightMargin + rect.right);
        int i5 = ((ViewGroup.MarginLayoutParams) cVar).topMargin;
        Rect rect2 = this.K;
        int R22 = R2(i3, i5 + rect2.top, ((ViewGroup.MarginLayoutParams) cVar).bottomMargin + rect2.bottom);
        if (z2 ? H1(view, R2, R22, cVar) : F1(view, R2, R22, cVar)) {
            view.measure(R2, R22);
        }
    }

    private void v2(View view, c cVar, boolean z2) {
        int K;
        int K2;
        if (cVar.f2304f) {
            if (this.f2291w != 1) {
                u2(view, RecyclerView.o.K(o0(), p0(), e0() + f0(), ((ViewGroup.MarginLayoutParams) cVar).width, true), this.J, z2);
                return;
            }
            K = this.J;
        } else if (this.f2291w != 1) {
            K = RecyclerView.o.K(o0(), p0(), e0() + f0(), ((ViewGroup.MarginLayoutParams) cVar).width, true);
            K2 = RecyclerView.o.K(this.f2292x, X(), 0, ((ViewGroup.MarginLayoutParams) cVar).height, false);
            u2(view, K, K2, z2);
        } else {
            K = RecyclerView.o.K(this.f2292x, p0(), 0, ((ViewGroup.MarginLayoutParams) cVar).width, false);
        }
        K2 = RecyclerView.o.K(W(), X(), g0() + d0(), ((ViewGroup.MarginLayoutParams) cVar).height, true);
        u2(view, K, K2, z2);
    }

    /* JADX WARN: Code restructure failed: missing block: B:87:0x014b, code lost:
        if (S1() != false) goto L90;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private void w2(androidx.recyclerview.widget.RecyclerView.v r9, androidx.recyclerview.widget.RecyclerView.a0 r10, boolean r11) {
        /*
            Method dump skipped, instructions count: 367
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.StaggeredGridLayoutManager.w2(androidx.recyclerview.widget.RecyclerView$v, androidx.recyclerview.widget.RecyclerView$a0, boolean):void");
    }

    private boolean x2(int i2) {
        if (this.f2291w == 0) {
            return (i2 == -1) != this.A;
        }
        return ((i2 == -1) == this.A) == t2();
    }

    private void z2(View view) {
        for (int i2 = this.f2287s - 1; i2 >= 0; i2--) {
            this.f2288t[i2].u(view);
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public void C0(int i2) {
        super.C0(i2);
        for (int i3 = 0; i3 < this.f2287s; i3++) {
            this.f2288t[i3].r(i2);
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public void C1(Rect rect, int i2, int i3) {
        int n2;
        int n3;
        int e02 = e0() + f0();
        int g02 = g0() + d0();
        if (this.f2291w == 1) {
            n3 = RecyclerView.o.n(i3, rect.height() + g02, b0());
            n2 = RecyclerView.o.n(i2, (this.f2292x * this.f2287s) + e02, c0());
        } else {
            n2 = RecyclerView.o.n(i2, rect.width() + e02, c0());
            n3 = RecyclerView.o.n(i3, (this.f2292x * this.f2287s) + g02, b0());
        }
        B1(n2, n3);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public RecyclerView.p D() {
        return this.f2291w == 0 ? new c(-2, -1) : new c(-1, -2);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public void D0(int i2) {
        super.D0(i2);
        for (int i3 = 0; i3 < this.f2287s; i3++) {
            this.f2288t[i3].r(i2);
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public RecyclerView.p E(Context context, AttributeSet attributeSet) {
        return new c(context, attributeSet);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public RecyclerView.p F(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof ViewGroup.MarginLayoutParams ? new c((ViewGroup.MarginLayoutParams) layoutParams) : new c(layoutParams);
    }

    int F2(int i2, RecyclerView.v vVar, RecyclerView.a0 a0Var) {
        if (J() == 0 || i2 == 0) {
            return 0;
        }
        y2(i2, a0Var);
        int b2 = b2(vVar, this.f2293y, a0Var);
        if (this.f2293y.f2442b >= b2) {
            i2 = i2 < 0 ? -b2 : b2;
        }
        this.f2289u.r(-i2);
        this.G = this.A;
        androidx.recyclerview.widget.f fVar = this.f2293y;
        fVar.f2442b = 0;
        A2(vVar, fVar);
        return i2;
    }

    public void H2(int i2) {
        if (i2 != 0 && i2 != 1) {
            throw new IllegalArgumentException("invalid orientation.");
        }
        g(null);
        if (i2 == this.f2291w) {
            return;
        }
        this.f2291w = i2;
        i iVar = this.f2289u;
        this.f2289u = this.f2290v;
        this.f2290v = iVar;
        t1();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public void I0(RecyclerView recyclerView, RecyclerView.v vVar) {
        super.I0(recyclerView, vVar);
        o1(this.P);
        for (int i2 = 0; i2 < this.f2287s; i2++) {
            this.f2288t[i2].e();
        }
        recyclerView.requestLayout();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public void I1(RecyclerView recyclerView, RecyclerView.a0 a0Var, int i2) {
        g gVar = new g(recyclerView.getContext());
        gVar.p(i2);
        J1(gVar);
    }

    public void I2(boolean z2) {
        g(null);
        e eVar = this.I;
        if (eVar != null && eVar.f2318i != z2) {
            eVar.f2318i = z2;
        }
        this.f2294z = z2;
        t1();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public View J0(View view, int i2, RecyclerView.v vVar, RecyclerView.a0 a0Var) {
        View B;
        View m2;
        if (J() == 0 || (B = B(view)) == null) {
            return null;
        }
        E2();
        int X1 = X1(i2);
        if (X1 == Integer.MIN_VALUE) {
            return null;
        }
        c cVar = (c) B.getLayoutParams();
        boolean z2 = cVar.f2304f;
        f fVar = cVar.f2303e;
        int k2 = X1 == 1 ? k2() : j2();
        O2(k2, a0Var);
        G2(X1);
        androidx.recyclerview.widget.f fVar2 = this.f2293y;
        fVar2.f2443c = fVar2.f2444d + k2;
        fVar2.f2442b = (int) (this.f2289u.n() * 0.33333334f);
        androidx.recyclerview.widget.f fVar3 = this.f2293y;
        fVar3.f2448h = true;
        fVar3.f2441a = false;
        b2(vVar, fVar3, a0Var);
        this.G = this.A;
        if (z2 || (m2 = fVar.m(k2, X1)) == null || m2 == B) {
            if (x2(X1)) {
                for (int i3 = this.f2287s - 1; i3 >= 0; i3--) {
                    View m3 = this.f2288t[i3].m(k2, X1);
                    if (m3 != null && m3 != B) {
                        return m3;
                    }
                }
            } else {
                for (int i4 = 0; i4 < this.f2287s; i4++) {
                    View m4 = this.f2288t[i4].m(k2, X1);
                    if (m4 != null && m4 != B) {
                        return m4;
                    }
                }
            }
            boolean z3 = (this.f2294z ^ true) == (X1 == -1);
            if (!z2) {
                View C = C(z3 ? fVar.f() : fVar.g());
                if (C != null && C != B) {
                    return C;
                }
            }
            if (x2(X1)) {
                for (int i5 = this.f2287s - 1; i5 >= 0; i5--) {
                    if (i5 != fVar.f2325e) {
                        f[] fVarArr = this.f2288t;
                        View C2 = C(z3 ? fVarArr[i5].f() : fVarArr[i5].g());
                        if (C2 != null && C2 != B) {
                            return C2;
                        }
                    }
                }
            } else {
                for (int i6 = 0; i6 < this.f2287s; i6++) {
                    f[] fVarArr2 = this.f2288t;
                    View C3 = C(z3 ? fVarArr2[i6].f() : fVarArr2[i6].g());
                    if (C3 != null && C3 != B) {
                        return C3;
                    }
                }
            }
            return null;
        }
        return m2;
    }

    public void J2(int i2) {
        g(null);
        if (i2 != this.f2287s) {
            s2();
            this.f2287s = i2;
            this.B = new BitSet(this.f2287s);
            this.f2288t = new f[this.f2287s];
            for (int i3 = 0; i3 < this.f2287s; i3++) {
                this.f2288t[i3] = new f(i3);
            }
            t1();
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public void K0(AccessibilityEvent accessibilityEvent) {
        super.K0(accessibilityEvent);
        if (J() > 0) {
            View e2 = e2(false);
            View d2 = d2(false);
            if (e2 == null || d2 == null) {
                return;
            }
            int h02 = h0(e2);
            int h03 = h0(d2);
            if (h02 < h03) {
                accessibilityEvent.setFromIndex(h02);
                accessibilityEvent.setToIndex(h03);
                return;
            }
            accessibilityEvent.setFromIndex(h03);
            accessibilityEvent.setToIndex(h02);
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public boolean L1() {
        return this.I == null;
    }

    boolean M2(RecyclerView.a0 a0Var, b bVar) {
        int i2;
        int m2;
        int g2;
        if (!a0Var.e() && (i2 = this.C) != -1) {
            if (i2 >= 0 && i2 < a0Var.b()) {
                e eVar = this.I;
                if (eVar == null || eVar.f2311b == -1 || eVar.f2313d < 1) {
                    View C = C(this.C);
                    if (C != null) {
                        bVar.f2296a = this.A ? k2() : j2();
                        if (this.D != Integer.MIN_VALUE) {
                            if (bVar.f2298c) {
                                m2 = this.f2289u.i() - this.D;
                                g2 = this.f2289u.d(C);
                            } else {
                                m2 = this.f2289u.m() + this.D;
                                g2 = this.f2289u.g(C);
                            }
                            bVar.f2297b = m2 - g2;
                            return true;
                        } else if (this.f2289u.e(C) > this.f2289u.n()) {
                            bVar.f2297b = bVar.f2298c ? this.f2289u.i() : this.f2289u.m();
                            return true;
                        } else {
                            int g3 = this.f2289u.g(C) - this.f2289u.m();
                            if (g3 < 0) {
                                bVar.f2297b = -g3;
                                return true;
                            }
                            int i3 = this.f2289u.i() - this.f2289u.d(C);
                            if (i3 < 0) {
                                bVar.f2297b = i3;
                                return true;
                            }
                            bVar.f2297b = Integer.MIN_VALUE;
                        }
                    } else {
                        int i4 = this.C;
                        bVar.f2296a = i4;
                        int i5 = this.D;
                        if (i5 == Integer.MIN_VALUE) {
                            bVar.f2298c = R1(i4) == 1;
                            bVar.a();
                        } else {
                            bVar.b(i5);
                        }
                        bVar.f2299d = true;
                    }
                } else {
                    bVar.f2297b = Integer.MIN_VALUE;
                    bVar.f2296a = this.C;
                }
                return true;
            }
            this.C = -1;
            this.D = Integer.MIN_VALUE;
        }
        return false;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public int N(RecyclerView.v vVar, RecyclerView.a0 a0Var) {
        return this.f2291w == 1 ? this.f2287s : super.N(vVar, a0Var);
    }

    void N2(RecyclerView.a0 a0Var, b bVar) {
        if (M2(a0Var, bVar) || L2(a0Var, bVar)) {
            return;
        }
        bVar.a();
        bVar.f2296a = 0;
    }

    boolean O1() {
        int l2 = this.f2288t[0].l(Integer.MIN_VALUE);
        for (int i2 = 1; i2 < this.f2287s; i2++) {
            if (this.f2288t[i2].l(Integer.MIN_VALUE) != l2) {
                return false;
            }
        }
        return true;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public void P0(RecyclerView.v vVar, RecyclerView.a0 a0Var, View view, f0.c cVar) {
        int i2;
        int i3;
        int e2;
        int i4;
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (!(layoutParams instanceof c)) {
            super.O0(view, cVar);
            return;
        }
        c cVar2 = (c) layoutParams;
        if (this.f2291w == 0) {
            i2 = cVar2.e();
            i3 = cVar2.f2304f ? this.f2287s : 1;
            e2 = -1;
            i4 = -1;
        } else {
            i2 = -1;
            i3 = -1;
            e2 = cVar2.e();
            i4 = cVar2.f2304f ? this.f2287s : 1;
        }
        cVar.Z(c.C0055c.a(i2, i3, e2, i4, false, false));
    }

    boolean P1() {
        int p2 = this.f2288t[0].p(Integer.MIN_VALUE);
        for (int i2 = 1; i2 < this.f2287s; i2++) {
            if (this.f2288t[i2].p(Integer.MIN_VALUE) != p2) {
                return false;
            }
        }
        return true;
    }

    void P2(int i2) {
        this.f2292x = i2 / this.f2287s;
        this.J = View.MeasureSpec.makeMeasureSpec(i2, this.f2290v.k());
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public void R0(RecyclerView recyclerView, int i2, int i3) {
        q2(i2, i3, 1);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public void S0(RecyclerView recyclerView) {
        this.E.b();
        t1();
    }

    boolean S1() {
        int j2;
        int k2;
        if (J() == 0 || this.F == 0 || !r0()) {
            return false;
        }
        if (this.A) {
            j2 = k2();
            k2 = j2();
        } else {
            j2 = j2();
            k2 = k2();
        }
        if (j2 == 0 && r2() != null) {
            this.E.b();
        } else if (!this.M) {
            return false;
        } else {
            int i2 = this.A ? -1 : 1;
            int i3 = k2 + 1;
            d.a e2 = this.E.e(j2, i3, i2, true);
            if (e2 == null) {
                this.M = false;
                this.E.d(i3);
                return false;
            }
            d.a e3 = this.E.e(j2, e2.f2307b, i2 * (-1), true);
            if (e3 == null) {
                this.E.d(e2.f2307b);
            } else {
                this.E.d(e3.f2307b + 1);
            }
        }
        u1();
        t1();
        return true;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public void T0(RecyclerView recyclerView, int i2, int i3, int i4) {
        q2(i2, i3, 8);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public void U0(RecyclerView recyclerView, int i2, int i3) {
        q2(i2, i3, 2);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public void W0(RecyclerView recyclerView, int i2, int i3, Object obj) {
        q2(i2, i3, 4);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public void X0(RecyclerView.v vVar, RecyclerView.a0 a0Var) {
        w2(vVar, a0Var, true);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public void Y0(RecyclerView.a0 a0Var) {
        super.Y0(a0Var);
        this.C = -1;
        this.D = Integer.MIN_VALUE;
        this.I = null;
        this.L.c();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.z.b
    public PointF a(int i2) {
        int R1 = R1(i2);
        PointF pointF = new PointF();
        if (R1 == 0) {
            return null;
        }
        if (this.f2291w == 0) {
            pointF.x = R1;
            pointF.y = 0.0f;
        } else {
            pointF.x = 0.0f;
            pointF.y = R1;
        }
        return pointF;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public void c1(Parcelable parcelable) {
        if (parcelable instanceof e) {
            this.I = (e) parcelable;
            t1();
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public Parcelable d1() {
        int p2;
        int m2;
        int[] iArr;
        if (this.I != null) {
            return new e(this.I);
        }
        e eVar = new e();
        eVar.f2318i = this.f2294z;
        eVar.f2319j = this.G;
        eVar.f2320k = this.H;
        d dVar = this.E;
        if (dVar == null || (iArr = dVar.f2305a) == null) {
            eVar.f2315f = 0;
        } else {
            eVar.f2316g = iArr;
            eVar.f2315f = iArr.length;
            eVar.f2317h = dVar.f2306b;
        }
        if (J() > 0) {
            eVar.f2311b = this.G ? k2() : j2();
            eVar.f2312c = f2();
            int i2 = this.f2287s;
            eVar.f2313d = i2;
            eVar.f2314e = new int[i2];
            for (int i3 = 0; i3 < this.f2287s; i3++) {
                if (this.G) {
                    p2 = this.f2288t[i3].l(Integer.MIN_VALUE);
                    if (p2 != Integer.MIN_VALUE) {
                        m2 = this.f2289u.i();
                        p2 -= m2;
                        eVar.f2314e[i3] = p2;
                    } else {
                        eVar.f2314e[i3] = p2;
                    }
                } else {
                    p2 = this.f2288t[i3].p(Integer.MIN_VALUE);
                    if (p2 != Integer.MIN_VALUE) {
                        m2 = this.f2289u.m();
                        p2 -= m2;
                        eVar.f2314e[i3] = p2;
                    } else {
                        eVar.f2314e[i3] = p2;
                    }
                }
            }
        } else {
            eVar.f2311b = -1;
            eVar.f2312c = -1;
            eVar.f2313d = 0;
        }
        return eVar;
    }

    View d2(boolean z2) {
        int m2 = this.f2289u.m();
        int i2 = this.f2289u.i();
        View view = null;
        for (int J = J() - 1; J >= 0; J--) {
            View I = I(J);
            int g2 = this.f2289u.g(I);
            int d2 = this.f2289u.d(I);
            if (d2 > m2 && g2 < i2) {
                if (d2 <= i2 || !z2) {
                    return I;
                }
                if (view == null) {
                    view = I;
                }
            }
        }
        return view;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public void e1(int i2) {
        if (i2 == 0) {
            S1();
        }
    }

    View e2(boolean z2) {
        int m2 = this.f2289u.m();
        int i2 = this.f2289u.i();
        int J = J();
        View view = null;
        for (int i3 = 0; i3 < J; i3++) {
            View I = I(i3);
            int g2 = this.f2289u.g(I);
            if (this.f2289u.d(I) > m2 && g2 < i2) {
                if (g2 >= m2 || !z2) {
                    return I;
                }
                if (view == null) {
                    view = I;
                }
            }
        }
        return view;
    }

    int f2() {
        View d2 = this.A ? d2(true) : e2(true);
        if (d2 == null) {
            return -1;
        }
        return h0(d2);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public void g(String str) {
        if (this.I == null) {
            super.g(str);
        }
    }

    int j2() {
        if (J() == 0) {
            return 0;
        }
        return h0(I(0));
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public boolean k() {
        return this.f2291w == 0;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public int k0(RecyclerView.v vVar, RecyclerView.a0 a0Var) {
        return this.f2291w == 0 ? this.f2287s : super.k0(vVar, a0Var);
    }

    int k2() {
        int J = J();
        if (J == 0) {
            return 0;
        }
        return h0(I(J - 1));
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public boolean l() {
        return this.f2291w == 1;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public boolean m(RecyclerView.p pVar) {
        return pVar instanceof c;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public void o(int i2, int i3, RecyclerView.a0 a0Var, RecyclerView.o.c cVar) {
        int l2;
        int i4;
        if (this.f2291w != 0) {
            i2 = i3;
        }
        if (J() == 0 || i2 == 0) {
            return;
        }
        y2(i2, a0Var);
        int[] iArr = this.O;
        if (iArr == null || iArr.length < this.f2287s) {
            this.O = new int[this.f2287s];
        }
        int i5 = 0;
        for (int i6 = 0; i6 < this.f2287s; i6++) {
            androidx.recyclerview.widget.f fVar = this.f2293y;
            if (fVar.f2444d == -1) {
                l2 = fVar.f2446f;
                i4 = this.f2288t[i6].p(l2);
            } else {
                l2 = this.f2288t[i6].l(fVar.f2447g);
                i4 = this.f2293y.f2447g;
            }
            int i7 = l2 - i4;
            if (i7 >= 0) {
                this.O[i5] = i7;
                i5++;
            }
        }
        Arrays.sort(this.O, 0, i5);
        for (int i8 = 0; i8 < i5 && this.f2293y.a(a0Var); i8++) {
            cVar.a(this.f2293y.f2443c, this.O[i8]);
            androidx.recyclerview.widget.f fVar2 = this.f2293y;
            fVar2.f2443c += fVar2.f2444d;
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public int q(RecyclerView.a0 a0Var) {
        return U1(a0Var);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public int r(RecyclerView.a0 a0Var) {
        return V1(a0Var);
    }

    /* JADX WARN: Code restructure failed: missing block: B:31:0x0074, code lost:
        if (r10 == r11) goto L37;
     */
    /* JADX WARN: Code restructure failed: missing block: B:36:0x0086, code lost:
        if (r10 == r11) goto L37;
     */
    /* JADX WARN: Code restructure failed: missing block: B:37:0x0088, code lost:
        r10 = true;
     */
    /* JADX WARN: Code restructure failed: missing block: B:38:0x008a, code lost:
        r10 = false;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    android.view.View r2() {
        /*
            r12 = this;
            int r0 = r12.J()
            r1 = 1
            int r0 = r0 - r1
            java.util.BitSet r2 = new java.util.BitSet
            int r3 = r12.f2287s
            r2.<init>(r3)
            int r3 = r12.f2287s
            r4 = 0
            r2.set(r4, r3, r1)
            int r3 = r12.f2291w
            r5 = -1
            if (r3 != r1) goto L20
            boolean r3 = r12.t2()
            if (r3 == 0) goto L20
            r3 = 1
            goto L21
        L20:
            r3 = -1
        L21:
            boolean r6 = r12.A
            if (r6 == 0) goto L27
            r6 = -1
            goto L2b
        L27:
            int r0 = r0 + 1
            r6 = r0
            r0 = 0
        L2b:
            if (r0 >= r6) goto L2e
            r5 = 1
        L2e:
            if (r0 == r6) goto Lab
            android.view.View r7 = r12.I(r0)
            android.view.ViewGroup$LayoutParams r8 = r7.getLayoutParams()
            androidx.recyclerview.widget.StaggeredGridLayoutManager$c r8 = (androidx.recyclerview.widget.StaggeredGridLayoutManager.c) r8
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f r9 = r8.f2303e
            int r9 = r9.f2325e
            boolean r9 = r2.get(r9)
            if (r9 == 0) goto L54
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f r9 = r8.f2303e
            boolean r9 = r12.T1(r9)
            if (r9 == 0) goto L4d
            return r7
        L4d:
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f r9 = r8.f2303e
            int r9 = r9.f2325e
            r2.clear(r9)
        L54:
            boolean r9 = r8.f2304f
            if (r9 == 0) goto L59
            goto La9
        L59:
            int r9 = r0 + r5
            if (r9 == r6) goto La9
            android.view.View r9 = r12.I(r9)
            boolean r10 = r12.A
            if (r10 == 0) goto L77
            androidx.recyclerview.widget.i r10 = r12.f2289u
            int r10 = r10.d(r7)
            androidx.recyclerview.widget.i r11 = r12.f2289u
            int r11 = r11.d(r9)
            if (r10 >= r11) goto L74
            return r7
        L74:
            if (r10 != r11) goto L8a
            goto L88
        L77:
            androidx.recyclerview.widget.i r10 = r12.f2289u
            int r10 = r10.g(r7)
            androidx.recyclerview.widget.i r11 = r12.f2289u
            int r11 = r11.g(r9)
            if (r10 <= r11) goto L86
            return r7
        L86:
            if (r10 != r11) goto L8a
        L88:
            r10 = 1
            goto L8b
        L8a:
            r10 = 0
        L8b:
            if (r10 == 0) goto La9
            android.view.ViewGroup$LayoutParams r9 = r9.getLayoutParams()
            androidx.recyclerview.widget.StaggeredGridLayoutManager$c r9 = (androidx.recyclerview.widget.StaggeredGridLayoutManager.c) r9
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f r8 = r8.f2303e
            int r8 = r8.f2325e
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f r9 = r9.f2303e
            int r9 = r9.f2325e
            int r8 = r8 - r9
            if (r8 >= 0) goto La0
            r8 = 1
            goto La1
        La0:
            r8 = 0
        La1:
            if (r3 >= 0) goto La5
            r9 = 1
            goto La6
        La5:
            r9 = 0
        La6:
            if (r8 == r9) goto La9
            return r7
        La9:
            int r0 = r0 + r5
            goto L2e
        Lab:
            r0 = 0
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.StaggeredGridLayoutManager.r2():android.view.View");
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public int s(RecyclerView.a0 a0Var) {
        return W1(a0Var);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public boolean s0() {
        return this.F != 0;
    }

    public void s2() {
        this.E.b();
        t1();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public int t(RecyclerView.a0 a0Var) {
        return U1(a0Var);
    }

    boolean t2() {
        return Z() == 1;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public int u(RecyclerView.a0 a0Var) {
        return V1(a0Var);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public int v(RecyclerView.a0 a0Var) {
        return W1(a0Var);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public int w1(int i2, RecyclerView.v vVar, RecyclerView.a0 a0Var) {
        return F2(i2, vVar, a0Var);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public void x1(int i2) {
        e eVar = this.I;
        if (eVar != null && eVar.f2311b != i2) {
            eVar.j();
        }
        this.C = i2;
        this.D = Integer.MIN_VALUE;
        t1();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public int y1(int i2, RecyclerView.v vVar, RecyclerView.a0 a0Var) {
        return F2(i2, vVar, a0Var);
    }

    void y2(int i2, RecyclerView.a0 a0Var) {
        int j2;
        int i3;
        if (i2 > 0) {
            j2 = k2();
            i3 = 1;
        } else {
            j2 = j2();
            i3 = -1;
        }
        this.f2293y.f2441a = true;
        O2(j2, a0Var);
        G2(i3);
        androidx.recyclerview.widget.f fVar = this.f2293y;
        fVar.f2443c = j2 + fVar.f2444d;
        fVar.f2442b = Math.abs(i2);
    }
}
