package androidx.navigation;
/* loaded from: classes.dex */
public interface b {
}
