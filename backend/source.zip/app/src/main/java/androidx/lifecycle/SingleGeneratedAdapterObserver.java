package androidx.lifecycle;

import androidx.lifecycle.d;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes.dex */
public class SingleGeneratedAdapterObserver implements e {

    /* renamed from: a  reason: collision with root package name */
    private final c f1839a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public SingleGeneratedAdapterObserver(c cVar) {
        this.f1839a = cVar;
    }

    @Override // androidx.lifecycle.e
    public void f(g gVar, d.a aVar) {
        this.f1839a.a(gVar, aVar, false, null);
        this.f1839a.a(gVar, aVar, true, null);
    }
}
