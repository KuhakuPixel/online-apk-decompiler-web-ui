package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.util.AttributeSet;
import android.widget.ImageView;
/* loaded from: classes.dex */
public class n {

    /* renamed from: a  reason: collision with root package name */
    private final ImageView f856a;

    /* renamed from: b  reason: collision with root package name */
    private r0 f857b;

    /* renamed from: c  reason: collision with root package name */
    private r0 f858c;

    /* renamed from: d  reason: collision with root package name */
    private r0 f859d;

    public n(ImageView imageView) {
        this.f856a = imageView;
    }

    private boolean a(Drawable drawable) {
        if (this.f859d == null) {
            this.f859d = new r0();
        }
        r0 r0Var = this.f859d;
        r0Var.a();
        ColorStateList a2 = androidx.core.widget.e.a(this.f856a);
        if (a2 != null) {
            r0Var.f907d = true;
            r0Var.f904a = a2;
        }
        PorterDuff.Mode b2 = androidx.core.widget.e.b(this.f856a);
        if (b2 != null) {
            r0Var.f906c = true;
            r0Var.f905b = b2;
        }
        if (r0Var.f907d || r0Var.f906c) {
            j.i(drawable, r0Var, this.f856a.getDrawableState());
            return true;
        }
        return false;
    }

    private boolean j() {
        int i2 = Build.VERSION.SDK_INT;
        return i2 > 21 ? this.f857b != null : i2 == 21;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void b() {
        Drawable drawable = this.f856a.getDrawable();
        if (drawable != null) {
            c0.b(drawable);
        }
        if (drawable != null) {
            if (j() && a(drawable)) {
                return;
            }
            r0 r0Var = this.f858c;
            if (r0Var != null) {
                j.i(drawable, r0Var, this.f856a.getDrawableState());
                return;
            }
            r0 r0Var2 = this.f857b;
            if (r0Var2 != null) {
                j.i(drawable, r0Var2, this.f856a.getDrawableState());
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public ColorStateList c() {
        r0 r0Var = this.f858c;
        if (r0Var != null) {
            return r0Var.f904a;
        }
        return null;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public PorterDuff.Mode d() {
        r0 r0Var = this.f858c;
        if (r0Var != null) {
            return r0Var.f905b;
        }
        return null;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public boolean e() {
        return !(this.f856a.getBackground() instanceof RippleDrawable);
    }

    public void f(AttributeSet attributeSet, int i2) {
        int n2;
        Context context = this.f856a.getContext();
        int[] iArr = a.j.R;
        t0 v2 = t0.v(context, attributeSet, iArr, i2, 0);
        ImageView imageView = this.f856a;
        e0.q.i0(imageView, imageView.getContext(), iArr, attributeSet, v2.r(), i2, 0);
        try {
            Drawable drawable = this.f856a.getDrawable();
            if (drawable == null && (n2 = v2.n(a.j.S, -1)) != -1 && (drawable = c.a.d(this.f856a.getContext(), n2)) != null) {
                this.f856a.setImageDrawable(drawable);
            }
            if (drawable != null) {
                c0.b(drawable);
            }
            int i3 = a.j.T;
            if (v2.s(i3)) {
                androidx.core.widget.e.c(this.f856a, v2.c(i3));
            }
            int i4 = a.j.U;
            if (v2.s(i4)) {
                androidx.core.widget.e.d(this.f856a, c0.d(v2.k(i4, -1), null));
            }
        } finally {
            v2.w();
        }
    }

    public void g(int i2) {
        if (i2 != 0) {
            Drawable d2 = c.a.d(this.f856a.getContext(), i2);
            if (d2 != null) {
                c0.b(d2);
            }
            this.f856a.setImageDrawable(d2);
        } else {
            this.f856a.setImageDrawable(null);
        }
        b();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void h(ColorStateList colorStateList) {
        if (this.f858c == null) {
            this.f858c = new r0();
        }
        r0 r0Var = this.f858c;
        r0Var.f904a = colorStateList;
        r0Var.f907d = true;
        b();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void i(PorterDuff.Mode mode) {
        if (this.f858c == null) {
            this.f858c = new r0();
        }
        r0 r0Var = this.f858c;
        r0Var.f905b = mode;
        r0Var.f906c = true;
        b();
    }
}
