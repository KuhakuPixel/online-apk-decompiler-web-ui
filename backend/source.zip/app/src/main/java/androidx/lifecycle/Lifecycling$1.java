package androidx.lifecycle;

import androidx.lifecycle.d;
/* loaded from: classes.dex */
final class Lifecycling$1 implements e {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ e f1815a;

    @Override // androidx.lifecycle.e
    public void f(g gVar, d.a aVar) {
        this.f1815a.f(gVar, aVar);
    }
}
