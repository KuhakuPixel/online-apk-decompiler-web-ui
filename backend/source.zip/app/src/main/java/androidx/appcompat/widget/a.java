package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes.dex */
public abstract class a extends ViewGroup {

    /* renamed from: b  reason: collision with root package name */
    protected final C0003a f678b;

    /* renamed from: c  reason: collision with root package name */
    protected final Context f679c;

    /* renamed from: d  reason: collision with root package name */
    protected ActionMenuView f680d;

    /* renamed from: e  reason: collision with root package name */
    protected c f681e;

    /* renamed from: f  reason: collision with root package name */
    protected int f682f;

    /* renamed from: g  reason: collision with root package name */
    protected e0.u f683g;

    /* renamed from: h  reason: collision with root package name */
    private boolean f684h;

    /* renamed from: i  reason: collision with root package name */
    private boolean f685i;

    /* renamed from: androidx.appcompat.widget.a$a  reason: collision with other inner class name */
    /* loaded from: classes.dex */
    protected class C0003a implements e0.v {

        /* renamed from: a  reason: collision with root package name */
        private boolean f686a = false;

        /* renamed from: b  reason: collision with root package name */
        int f687b;

        protected C0003a() {
        }

        @Override // e0.v
        public void a(View view) {
            if (this.f686a) {
                return;
            }
            a aVar = a.this;
            aVar.f683g = null;
            a.super.setVisibility(this.f687b);
        }

        @Override // e0.v
        public void b(View view) {
            a.super.setVisibility(0);
            this.f686a = false;
        }

        @Override // e0.v
        public void c(View view) {
            this.f686a = true;
        }

        public C0003a d(e0.u uVar, int i2) {
            a.this.f683g = uVar;
            this.f687b = i2;
            return this;
        }
    }

    a(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public a(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.f678b = new C0003a();
        TypedValue typedValue = new TypedValue();
        if (!context.getTheme().resolveAttribute(a.a.actionBarPopupTheme, typedValue, true) || typedValue.resourceId == 0) {
            this.f679c = context;
        } else {
            this.f679c = new ContextThemeWrapper(context, typedValue.resourceId);
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static int d(int i2, int i3, boolean z2) {
        return z2 ? i2 - i3 : i2 + i3;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public int c(View view, int i2, int i3, int i4) {
        view.measure(View.MeasureSpec.makeMeasureSpec(i2, Integer.MIN_VALUE), i3);
        return Math.max(0, (i2 - view.getMeasuredWidth()) - i4);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public int e(View view, int i2, int i3, int i4, boolean z2) {
        int measuredWidth = view.getMeasuredWidth();
        int measuredHeight = view.getMeasuredHeight();
        int i5 = i3 + ((i4 - measuredHeight) / 2);
        if (z2) {
            view.layout(i2 - measuredWidth, i5, i2, measuredHeight + i5);
        } else {
            view.layout(i2, i5, i2 + measuredWidth, measuredHeight + i5);
        }
        return z2 ? -measuredWidth : measuredWidth;
    }

    public e0.u f(int i2, long j2) {
        e0.u a2;
        e0.u uVar = this.f683g;
        if (uVar != null) {
            uVar.b();
        }
        if (i2 == 0) {
            if (getVisibility() != 0) {
                setAlpha(0.0f);
            }
            a2 = e0.q.d(this).a(1.0f);
        } else {
            a2 = e0.q.d(this).a(0.0f);
        }
        a2.d(j2);
        a2.f(this.f678b.d(a2, i2));
        return a2;
    }

    public int getAnimatedVisibility() {
        return this.f683g != null ? this.f678b.f687b : getVisibility();
    }

    public int getContentHeight() {
        return this.f682f;
    }

    @Override // android.view.View
    protected void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(null, a.j.f15a, a.a.actionBarStyle, 0);
        setContentHeight(obtainStyledAttributes.getLayoutDimension(a.j.f42j, 0));
        obtainStyledAttributes.recycle();
        c cVar = this.f681e;
        if (cVar != null) {
            cVar.F(configuration);
        }
    }

    @Override // android.view.View
    public boolean onHoverEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 9) {
            this.f685i = false;
        }
        if (!this.f685i) {
            boolean onHoverEvent = super.onHoverEvent(motionEvent);
            if (actionMasked == 9 && !onHoverEvent) {
                this.f685i = true;
            }
        }
        if (actionMasked == 10 || actionMasked == 3) {
            this.f685i = false;
        }
        return true;
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.f684h = false;
        }
        if (!this.f684h) {
            boolean onTouchEvent = super.onTouchEvent(motionEvent);
            if (actionMasked == 0 && !onTouchEvent) {
                this.f684h = true;
            }
        }
        if (actionMasked == 1 || actionMasked == 3) {
            this.f684h = false;
        }
        return true;
    }

    public void setContentHeight(int i2) {
        this.f682f = i2;
        requestLayout();
    }

    @Override // android.view.View
    public void setVisibility(int i2) {
        if (i2 != getVisibility()) {
            e0.u uVar = this.f683g;
            if (uVar != null) {
                uVar.b();
            }
            super.setVisibility(i2);
        }
    }
}
