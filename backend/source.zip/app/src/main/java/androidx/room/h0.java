package androidx.room;

import android.content.Context;
import android.util.Log;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Objects;
import java.util.concurrent.Callable;
/* loaded from: classes.dex */
class h0 implements u0.c, i {

    /* renamed from: b  reason: collision with root package name */
    private final Context f2609b;

    /* renamed from: c  reason: collision with root package name */
    private final String f2610c;

    /* renamed from: d  reason: collision with root package name */
    private final File f2611d;

    /* renamed from: e  reason: collision with root package name */
    private final Callable<InputStream> f2612e;

    /* renamed from: f  reason: collision with root package name */
    private final int f2613f;

    /* renamed from: g  reason: collision with root package name */
    private final u0.c f2614g;

    /* renamed from: h  reason: collision with root package name */
    private h f2615h;

    /* renamed from: i  reason: collision with root package name */
    private boolean f2616i;

    /* JADX INFO: Access modifiers changed from: package-private */
    public h0(Context context, String str, File file, Callable<InputStream> callable, int i2, u0.c cVar) {
        this.f2609b = context;
        this.f2610c = str;
        this.f2611d = file;
        this.f2612e = callable;
        this.f2613f = i2;
        this.f2614g = cVar;
    }

    /* JADX WARN: Removed duplicated region for block: B:24:0x0084 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:25:0x0085  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private void v(java.io.File r5, boolean r6) {
        /*
            r4 = this;
            java.lang.String r0 = r4.f2610c
            if (r0 == 0) goto L15
            android.content.Context r0 = r4.f2609b
            android.content.res.AssetManager r0 = r0.getAssets()
            java.lang.String r1 = r4.f2610c
            java.io.InputStream r0 = r0.open(r1)
        L10:
            java.nio.channels.ReadableByteChannel r0 = java.nio.channels.Channels.newChannel(r0)
            goto L30
        L15:
            java.io.File r0 = r4.f2611d
            if (r0 == 0) goto L25
            java.io.FileInputStream r0 = new java.io.FileInputStream
            java.io.File r1 = r4.f2611d
            r0.<init>(r1)
            java.nio.channels.FileChannel r0 = r0.getChannel()
            goto L30
        L25:
            java.util.concurrent.Callable<java.io.InputStream> r0 = r4.f2612e
            if (r0 == 0) goto Lba
            java.lang.Object r0 = r0.call()     // Catch: java.lang.Exception -> Lb1
            java.io.InputStream r0 = (java.io.InputStream) r0     // Catch: java.lang.Exception -> Lb1
            goto L10
        L30:
            android.content.Context r1 = r4.f2609b
            java.io.File r1 = r1.getCacheDir()
            java.lang.String r2 = "room-copy-helper"
            java.lang.String r3 = ".tmp"
            java.io.File r1 = java.io.File.createTempFile(r2, r3, r1)
            r1.deleteOnExit()
            java.io.FileOutputStream r2 = new java.io.FileOutputStream
            r2.<init>(r1)
            java.nio.channels.FileChannel r2 = r2.getChannel()
            t0.d.a(r0, r2)
            java.io.File r0 = r5.getParentFile()
            if (r0 == 0) goto L7b
            boolean r2 = r0.exists()
            if (r2 != 0) goto L7b
            boolean r0 = r0.mkdirs()
            if (r0 == 0) goto L60
            goto L7b
        L60:
            java.io.IOException r6 = new java.io.IOException
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>()
            java.lang.String r1 = "Failed to create directories for "
            r0.append(r1)
            java.lang.String r5 = r5.getAbsolutePath()
            r0.append(r5)
            java.lang.String r5 = r0.toString()
            r6.<init>(r5)
            throw r6
        L7b:
            r4.x(r1, r6)
            boolean r6 = r1.renameTo(r5)
            if (r6 == 0) goto L85
            return
        L85:
            java.io.IOException r6 = new java.io.IOException
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>()
            java.lang.String r2 = "Failed to move intermediate file ("
            r0.append(r2)
            java.lang.String r1 = r1.getAbsolutePath()
            r0.append(r1)
            java.lang.String r1 = ") to destination ("
            r0.append(r1)
            java.lang.String r5 = r5.getAbsolutePath()
            r0.append(r5)
            java.lang.String r5 = ")."
            r0.append(r5)
            java.lang.String r5 = r0.toString()
            r6.<init>(r5)
            throw r6
        Lb1:
            r5 = move-exception
            java.io.IOException r6 = new java.io.IOException
            java.lang.String r0 = "inputStreamCallable exception on call"
            r6.<init>(r0, r5)
            throw r6
        Lba:
            java.lang.IllegalStateException r5 = new java.lang.IllegalStateException
            java.lang.String r6 = "copyFromAssetPath, copyFromFile and copyFromInputStream are all null!"
            r5.<init>(r6)
            throw r5
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.room.h0.v(java.io.File, boolean):void");
    }

    private void x(File file, boolean z2) {
        h hVar = this.f2615h;
        if (hVar != null) {
            Objects.requireNonNull(hVar);
        }
    }

    private void z(boolean z2) {
        String databaseName = getDatabaseName();
        File databasePath = this.f2609b.getDatabasePath(databaseName);
        h hVar = this.f2615h;
        t0.a aVar = new t0.a(databaseName, this.f2609b.getFilesDir(), hVar == null || hVar.f2602k);
        try {
            aVar.b();
            if (!databasePath.exists()) {
                try {
                    v(databasePath, z2);
                    aVar.c();
                    return;
                } catch (IOException e2) {
                    throw new RuntimeException("Unable to copy database file.", e2);
                }
            } else if (this.f2615h == null) {
                aVar.c();
                return;
            } else {
                try {
                    int c2 = t0.c.c(databasePath);
                    int i2 = this.f2613f;
                    if (c2 == i2) {
                        aVar.c();
                        return;
                    } else if (this.f2615h.a(c2, i2)) {
                        aVar.c();
                        return;
                    } else {
                        if (this.f2609b.deleteDatabase(databaseName)) {
                            try {
                                v(databasePath, z2);
                            } catch (IOException e3) {
                                Log.w("ROOM", "Unable to copy database file.", e3);
                            }
                        } else {
                            Log.w("ROOM", "Failed to delete database file (" + databaseName + ") for a copy destructive migration.");
                        }
                        aVar.c();
                        return;
                    }
                } catch (IOException e4) {
                    Log.w("ROOM", "Unable to read database version.", e4);
                    aVar.c();
                    return;
                }
            }
        } catch (Throwable th) {
            aVar.c();
            throw th;
        }
        aVar.c();
        throw th;
    }

    @Override // u0.c, java.io.Closeable, java.lang.AutoCloseable
    public synchronized void close() {
        this.f2614g.close();
        this.f2616i = false;
    }

    @Override // androidx.room.i
    public u0.c e() {
        return this.f2614g;
    }

    @Override // u0.c
    public String getDatabaseName() {
        return this.f2614g.getDatabaseName();
    }

    @Override // u0.c
    public synchronized u0.b r() {
        if (!this.f2616i) {
            z(true);
            this.f2616i = true;
        }
        return this.f2614g.r();
    }

    @Override // u0.c
    public void setWriteAheadLoggingEnabled(boolean z2) {
        this.f2614g.setWriteAheadLoggingEnabled(z2);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void y(h hVar) {
        this.f2615h = hVar;
    }
}
