package z0;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes.dex */
public final class z extends v {

    /* renamed from: d  reason: collision with root package name */
    private final b0 f5708d;

    /* JADX INFO: Access modifiers changed from: package-private */
    public z(b0 b0Var, int i2) {
        super(b0Var.size(), i2);
        this.f5708d = b0Var;
    }

    @Override // z0.v
    protected final Object a(int i2) {
        return this.f5708d.get(i2);
    }
}
