package z0;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes.dex */
public final class b extends b0 {

    /* renamed from: f  reason: collision with root package name */
    static final b0 f5674f = new b(new Object[0], 0);

    /* renamed from: d  reason: collision with root package name */
    final transient Object[] f5675d;

    /* renamed from: e  reason: collision with root package name */
    private final transient int f5676e;

    /* JADX INFO: Access modifiers changed from: package-private */
    public b(Object[] objArr, int i2) {
        this.f5675d = objArr;
        this.f5676e = i2;
    }

    @Override // z0.b0, z0.y
    final int c(Object[] objArr, int i2) {
        System.arraycopy(this.f5675d, 0, objArr, 0, this.f5676e);
        return this.f5676e;
    }

    @Override // z0.y
    final int d() {
        return this.f5676e;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    @Override // z0.y
    public final int e() {
        return 0;
    }

    @Override // java.util.List
    public final Object get(int i2) {
        t.a(i2, this.f5676e, "index");
        Object obj = this.f5675d[i2];
        obj.getClass();
        return obj;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    @Override // z0.y
    public final boolean h() {
        return false;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    @Override // z0.y
    public final Object[] i() {
        return this.f5675d;
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public final int size() {
        return this.f5676e;
    }
}
