package a;
/* loaded from: classes.dex */
public final class g {

    /* renamed from: a */
    public static final int abc_action_bar_title_item = 2131558400;

    /* renamed from: b */
    public static final int abc_action_menu_item_layout = 2131558402;

    /* renamed from: c */
    public static final int abc_action_menu_layout = 2131558403;

    /* renamed from: d */
    public static final int abc_action_mode_close_item_material = 2131558405;

    /* renamed from: e */
    public static final int abc_cascading_menu_item_layout = 2131558411;

    /* renamed from: f */
    public static final int abc_dialog_title_material = 2131558412;

    /* renamed from: g */
    public static final int abc_expanded_menu_layout = 2131558413;

    /* renamed from: h */
    public static final int abc_list_menu_item_checkbox = 2131558414;

    /* renamed from: i */
    public static final int abc_list_menu_item_icon = 2131558415;

    /* renamed from: j */
    public static final int abc_list_menu_item_layout = 2131558416;

    /* renamed from: k */
    public static final int abc_list_menu_item_radio = 2131558417;

    /* renamed from: l */
    public static final int abc_popup_menu_header_item_layout = 2131558418;

    /* renamed from: m */
    public static final int abc_popup_menu_item_layout = 2131558419;

    /* renamed from: n */
    public static final int abc_screen_simple = 2131558421;

    /* renamed from: o */
    public static final int abc_screen_simple_overlay_action_mode = 2131558422;

    /* renamed from: p */
    public static final int abc_screen_toolbar = 2131558423;

    /* renamed from: q */
    public static final int abc_search_dropdown_item_icons_2line = 2131558424;

    /* renamed from: r */
    public static final int abc_search_view = 2131558425;

    /* renamed from: s */
    public static final int abc_tooltip = 2131558427;

    /* renamed from: t */
    public static final int support_simple_spinner_dropdown_item = 2131558500;
}
