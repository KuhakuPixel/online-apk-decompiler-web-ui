package e0;

import android.view.ViewGroup;
/* loaded from: classes.dex */
public final class s {
    public static boolean a(ViewGroup viewGroup) {
        return viewGroup.isTransitionGroup();
    }
}
