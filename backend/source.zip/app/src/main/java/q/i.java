package q;

import java.util.ArrayList;
import p.e;
/* loaded from: classes.dex */
public class i {
    public static o a(p.e eVar, int i2, ArrayList<o> arrayList, o oVar) {
        p.d dVar;
        int b12;
        int i3 = i2 == 0 ? eVar.A0 : eVar.B0;
        if (i3 != -1 && (oVar == null || i3 != oVar.f5045b)) {
            int i4 = 0;
            while (true) {
                if (i4 >= arrayList.size()) {
                    break;
                }
                o oVar2 = arrayList.get(i4);
                if (oVar2.c() == i3) {
                    if (oVar != null) {
                        oVar.g(i2, oVar2);
                        arrayList.remove(oVar);
                    }
                    oVar = oVar2;
                } else {
                    i4++;
                }
            }
        } else if (i3 != -1) {
            return oVar;
        }
        if (oVar == null) {
            if ((eVar instanceof p.i) && (b12 = ((p.i) eVar).b1(i2)) != -1) {
                int i5 = 0;
                while (true) {
                    if (i5 >= arrayList.size()) {
                        break;
                    }
                    o oVar3 = arrayList.get(i5);
                    if (oVar3.c() == b12) {
                        oVar = oVar3;
                        break;
                    }
                    i5++;
                }
            }
            if (oVar == null) {
                oVar = new o(i2);
            }
            arrayList.add(oVar);
        }
        if (oVar.a(eVar)) {
            if (eVar instanceof p.g) {
                p.g gVar = (p.g) eVar;
                gVar.a1().b(gVar.b1() == 0 ? 1 : 0, arrayList, oVar);
            }
            int c2 = oVar.c();
            if (i2 == 0) {
                eVar.A0 = c2;
                eVar.H.b(i2, arrayList, oVar);
                dVar = eVar.J;
            } else {
                eVar.B0 = c2;
                eVar.I.b(i2, arrayList, oVar);
                eVar.L.b(i2, arrayList, oVar);
                dVar = eVar.K;
            }
            dVar.b(i2, arrayList, oVar);
            eVar.O.b(i2, arrayList, oVar);
        }
        return oVar;
    }

    private static o b(ArrayList<o> arrayList, int i2) {
        int size = arrayList.size();
        for (int i3 = 0; i3 < size; i3++) {
            o oVar = arrayList.get(i3);
            if (i2 == oVar.f5045b) {
                return oVar;
            }
        }
        return null;
    }

    /* JADX WARN: Removed duplicated region for block: B:175:0x033f  */
    /* JADX WARN: Removed duplicated region for block: B:187:0x0379  */
    /* JADX WARN: Removed duplicated region for block: B:190:0x037d A[ADDED_TO_REGION] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static boolean c(p.f r16, q.b.InterfaceC0068b r17) {
        /*
            Method dump skipped, instructions count: 900
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: q.i.c(p.f, q.b$b):boolean");
    }

    public static boolean d(e.b bVar, e.b bVar2, e.b bVar3, e.b bVar4) {
        e.b bVar5;
        e.b bVar6;
        e.b bVar7 = e.b.FIXED;
        return (bVar3 == bVar7 || bVar3 == (bVar6 = e.b.WRAP_CONTENT) || (bVar3 == e.b.MATCH_PARENT && bVar != bVar6)) || (bVar4 == bVar7 || bVar4 == (bVar5 = e.b.WRAP_CONTENT) || (bVar4 == e.b.MATCH_PARENT && bVar2 != bVar5));
    }
}
