package u1;

import android.app.Activity;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.r;
import androidx.lifecycle.s;
import com.sample.android.kuhakupixelinapppurchase.R;
import java.util.HashMap;
import java.util.Map;
/* loaded from: classes.dex */
public class d extends r {

    /* renamed from: d  reason: collision with root package name */
    private static final Map<String, Integer> f5349d;

    /* renamed from: c  reason: collision with root package name */
    private final com.sample.android.kuhakupixelinapppurchase.a f5350c;

    /* loaded from: classes.dex */
    public static class a implements s.a {

        /* renamed from: a  reason: collision with root package name */
        private final com.sample.android.kuhakupixelinapppurchase.a f5351a;

        public a(com.sample.android.kuhakupixelinapppurchase.a aVar) {
            this.f5351a = aVar;
        }

        @Override // androidx.lifecycle.s.a
        public <T extends r> T a(Class<T> cls) {
            if (cls.isAssignableFrom(d.class)) {
                return new d(this.f5351a);
            }
            throw new IllegalArgumentException("Unknown ViewModel class");
        }
    }

    /* loaded from: classes.dex */
    public static class b {

        /* renamed from: a  reason: collision with root package name */
        public final String f5352a;

        /* renamed from: b  reason: collision with root package name */
        public final LiveData<String> f5353b;

        /* renamed from: c  reason: collision with root package name */
        public final LiveData<String> f5354c;

        /* renamed from: d  reason: collision with root package name */
        public final LiveData<String> f5355d;

        /* renamed from: e  reason: collision with root package name */
        public final int f5356e;

        b(String str, com.sample.android.kuhakupixelinapppurchase.a aVar) {
            this.f5352a = str;
            this.f5353b = aVar.t(str);
            this.f5354c = aVar.r(str);
            this.f5355d = aVar.s(str);
            this.f5356e = ((Integer) d.f5349d.get(str)).intValue();
        }
    }

    static {
        HashMap hashMap = new HashMap();
        f5349d = hashMap;
        hashMap.put("gas", Integer.valueOf((int) R.drawable.buy_gas));
        hashMap.put("premium", Integer.valueOf((int) R.drawable.upgrade_app));
        Integer valueOf = Integer.valueOf((int) R.drawable.get_infinite_gas);
        hashMap.put("infinite_gas_monthly", valueOf);
        hashMap.put("infinite_gas_yearly", valueOf);
    }

    public d(com.sample.android.kuhakupixelinapppurchase.a aVar) {
        this.f5350c = aVar;
    }

    public void f(Activity activity, String str) {
        this.f5350c.h(activity, str);
    }

    public LiveData<Boolean> g(String str) {
        return this.f5350c.i(str);
    }

    public LiveData<Boolean> h() {
        return this.f5350c.o();
    }

    public b i(String str) {
        return new b(str, this.f5350c);
    }

    public LiveData<Boolean> j(String str) {
        return this.f5350c.u(str);
    }
}
