package c0;

import android.text.SpannableStringBuilder;
import java.util.Locale;
/* loaded from: classes.dex */
public final class a {

    /* renamed from: d  reason: collision with root package name */
    static final c f3054d;

    /* renamed from: e  reason: collision with root package name */
    private static final String f3055e;

    /* renamed from: f  reason: collision with root package name */
    private static final String f3056f;

    /* renamed from: g  reason: collision with root package name */
    static final a f3057g;

    /* renamed from: h  reason: collision with root package name */
    static final a f3058h;

    /* renamed from: a  reason: collision with root package name */
    private final boolean f3059a;

    /* renamed from: b  reason: collision with root package name */
    private final int f3060b;

    /* renamed from: c  reason: collision with root package name */
    private final c f3061c;

    /* renamed from: c0.a$a  reason: collision with other inner class name */
    /* loaded from: classes.dex */
    public static final class C0030a {

        /* renamed from: a  reason: collision with root package name */
        private boolean f3062a;

        /* renamed from: b  reason: collision with root package name */
        private int f3063b;

        /* renamed from: c  reason: collision with root package name */
        private c f3064c;

        public C0030a() {
            c(a.e(Locale.getDefault()));
        }

        private static a b(boolean z2) {
            return z2 ? a.f3058h : a.f3057g;
        }

        private void c(boolean z2) {
            this.f3062a = z2;
            this.f3064c = a.f3054d;
            this.f3063b = 2;
        }

        public a a() {
            return (this.f3063b == 2 && this.f3064c == a.f3054d) ? b(this.f3062a) : new a(this.f3062a, this.f3063b, this.f3064c);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public static class b {

        /* renamed from: f  reason: collision with root package name */
        private static final byte[] f3065f = new byte[1792];

        /* renamed from: a  reason: collision with root package name */
        private final CharSequence f3066a;

        /* renamed from: b  reason: collision with root package name */
        private final boolean f3067b;

        /* renamed from: c  reason: collision with root package name */
        private final int f3068c;

        /* renamed from: d  reason: collision with root package name */
        private int f3069d;

        /* renamed from: e  reason: collision with root package name */
        private char f3070e;

        static {
            for (int i2 = 0; i2 < 1792; i2++) {
                f3065f[i2] = Character.getDirectionality(i2);
            }
        }

        b(CharSequence charSequence, boolean z2) {
            this.f3066a = charSequence;
            this.f3067b = z2;
            this.f3068c = charSequence.length();
        }

        private static byte c(char c2) {
            return c2 < 1792 ? f3065f[c2] : Character.getDirectionality(c2);
        }

        private byte f() {
            char charAt;
            int i2 = this.f3069d;
            do {
                int i3 = this.f3069d;
                if (i3 <= 0) {
                    break;
                }
                CharSequence charSequence = this.f3066a;
                int i4 = i3 - 1;
                this.f3069d = i4;
                charAt = charSequence.charAt(i4);
                this.f3070e = charAt;
                if (charAt == '&') {
                    return (byte) 12;
                }
            } while (charAt != ';');
            this.f3069d = i2;
            this.f3070e = ';';
            return (byte) 13;
        }

        private byte g() {
            char charAt;
            do {
                int i2 = this.f3069d;
                if (i2 >= this.f3068c) {
                    return (byte) 12;
                }
                CharSequence charSequence = this.f3066a;
                this.f3069d = i2 + 1;
                charAt = charSequence.charAt(i2);
                this.f3070e = charAt;
            } while (charAt != ';');
            return (byte) 12;
        }

        private byte h() {
            char charAt;
            int i2 = this.f3069d;
            while (true) {
                int i3 = this.f3069d;
                if (i3 <= 0) {
                    break;
                }
                CharSequence charSequence = this.f3066a;
                int i4 = i3 - 1;
                this.f3069d = i4;
                char charAt2 = charSequence.charAt(i4);
                this.f3070e = charAt2;
                if (charAt2 == '<') {
                    return (byte) 12;
                }
                if (charAt2 == '>') {
                    break;
                } else if (charAt2 == '\"' || charAt2 == '\'') {
                    do {
                        int i5 = this.f3069d;
                        if (i5 > 0) {
                            CharSequence charSequence2 = this.f3066a;
                            int i6 = i5 - 1;
                            this.f3069d = i6;
                            charAt = charSequence2.charAt(i6);
                            this.f3070e = charAt;
                        }
                    } while (charAt != charAt2);
                }
            }
            this.f3069d = i2;
            this.f3070e = '>';
            return (byte) 13;
        }

        private byte i() {
            char charAt;
            int i2 = this.f3069d;
            while (true) {
                int i3 = this.f3069d;
                if (i3 >= this.f3068c) {
                    this.f3069d = i2;
                    this.f3070e = '<';
                    return (byte) 13;
                }
                CharSequence charSequence = this.f3066a;
                this.f3069d = i3 + 1;
                char charAt2 = charSequence.charAt(i3);
                this.f3070e = charAt2;
                if (charAt2 == '>') {
                    return (byte) 12;
                }
                if (charAt2 == '\"' || charAt2 == '\'') {
                    do {
                        int i4 = this.f3069d;
                        if (i4 < this.f3068c) {
                            CharSequence charSequence2 = this.f3066a;
                            this.f3069d = i4 + 1;
                            charAt = charSequence2.charAt(i4);
                            this.f3070e = charAt;
                        }
                    } while (charAt != charAt2);
                }
            }
        }

        byte a() {
            char charAt = this.f3066a.charAt(this.f3069d - 1);
            this.f3070e = charAt;
            if (Character.isLowSurrogate(charAt)) {
                int codePointBefore = Character.codePointBefore(this.f3066a, this.f3069d);
                this.f3069d -= Character.charCount(codePointBefore);
                return Character.getDirectionality(codePointBefore);
            }
            this.f3069d--;
            byte c2 = c(this.f3070e);
            if (this.f3067b) {
                char c3 = this.f3070e;
                return c3 == '>' ? h() : c3 == ';' ? f() : c2;
            }
            return c2;
        }

        byte b() {
            char charAt = this.f3066a.charAt(this.f3069d);
            this.f3070e = charAt;
            if (Character.isHighSurrogate(charAt)) {
                int codePointAt = Character.codePointAt(this.f3066a, this.f3069d);
                this.f3069d += Character.charCount(codePointAt);
                return Character.getDirectionality(codePointAt);
            }
            this.f3069d++;
            byte c2 = c(this.f3070e);
            if (this.f3067b) {
                char c3 = this.f3070e;
                return c3 == '<' ? i() : c3 == '&' ? g() : c2;
            }
            return c2;
        }

        int d() {
            this.f3069d = 0;
            int i2 = 0;
            int i3 = 0;
            int i4 = 0;
            while (this.f3069d < this.f3068c && i2 == 0) {
                byte b2 = b();
                if (b2 != 0) {
                    if (b2 == 1 || b2 == 2) {
                        if (i4 == 0) {
                            return 1;
                        }
                    } else if (b2 != 9) {
                        switch (b2) {
                            case 14:
                            case 15:
                                i4++;
                                i3 = -1;
                                break;
                            case 16:
                            case 17:
                                i4++;
                                i3 = 1;
                                break;
                            case 18:
                                i4--;
                                i3 = 0;
                                break;
                        }
                    }
                } else if (i4 == 0) {
                    return -1;
                }
                i2 = i4;
            }
            if (i2 == 0) {
                return 0;
            }
            if (i3 != 0) {
                return i3;
            }
            while (this.f3069d > 0) {
                switch (a()) {
                    case 14:
                    case 15:
                        if (i2 == i4) {
                            return -1;
                        }
                        break;
                    case 16:
                    case 17:
                        if (i2 == i4) {
                            return 1;
                        }
                        break;
                    case 18:
                        i4++;
                        continue;
                }
                i4--;
            }
            return 0;
        }

        int e() {
            this.f3069d = this.f3068c;
            int i2 = 0;
            int i3 = 0;
            while (this.f3069d > 0) {
                byte a2 = a();
                if (a2 != 0) {
                    if (a2 == 1 || a2 == 2) {
                        if (i2 == 0) {
                            return 1;
                        }
                        if (i3 == 0) {
                            i3 = i2;
                        }
                    } else if (a2 != 9) {
                        switch (a2) {
                            case 14:
                            case 15:
                                if (i3 == i2) {
                                    return -1;
                                }
                                i2--;
                                break;
                            case 16:
                            case 17:
                                if (i3 == i2) {
                                    return 1;
                                }
                                i2--;
                                break;
                            case 18:
                                i2++;
                                break;
                            default:
                                if (i3 != 0) {
                                    break;
                                } else {
                                    i3 = i2;
                                    break;
                                }
                        }
                    } else {
                        continue;
                    }
                } else if (i2 == 0) {
                    return -1;
                } else {
                    if (i3 == 0) {
                        i3 = i2;
                    }
                }
            }
            return 0;
        }
    }

    static {
        c cVar = d.f3086c;
        f3054d = cVar;
        f3055e = Character.toString((char) 8206);
        f3056f = Character.toString((char) 8207);
        f3057g = new a(false, 2, cVar);
        f3058h = new a(true, 2, cVar);
    }

    a(boolean z2, int i2, c cVar) {
        this.f3059a = z2;
        this.f3060b = i2;
        this.f3061c = cVar;
    }

    private static int a(CharSequence charSequence) {
        return new b(charSequence, false).d();
    }

    private static int b(CharSequence charSequence) {
        return new b(charSequence, false).e();
    }

    public static a c() {
        return new C0030a().a();
    }

    static boolean e(Locale locale) {
        return e.a(locale) == 1;
    }

    private String f(CharSequence charSequence, c cVar) {
        boolean a2 = cVar.a(charSequence, 0, charSequence.length());
        return (this.f3059a || !(a2 || b(charSequence) == 1)) ? this.f3059a ? (!a2 || b(charSequence) == -1) ? f3056f : "" : "" : f3055e;
    }

    private String g(CharSequence charSequence, c cVar) {
        boolean a2 = cVar.a(charSequence, 0, charSequence.length());
        return (this.f3059a || !(a2 || a(charSequence) == 1)) ? this.f3059a ? (!a2 || a(charSequence) == -1) ? f3056f : "" : "" : f3055e;
    }

    public boolean d() {
        return (this.f3060b & 2) != 0;
    }

    public CharSequence h(CharSequence charSequence) {
        return i(charSequence, this.f3061c, true);
    }

    public CharSequence i(CharSequence charSequence, c cVar, boolean z2) {
        if (charSequence == null) {
            return null;
        }
        boolean a2 = cVar.a(charSequence, 0, charSequence.length());
        SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder();
        if (d() && z2) {
            spannableStringBuilder.append((CharSequence) g(charSequence, a2 ? d.f3085b : d.f3084a));
        }
        if (a2 != this.f3059a) {
            spannableStringBuilder.append(a2 ? (char) 8235 : (char) 8234);
            spannableStringBuilder.append(charSequence);
            spannableStringBuilder.append((char) 8236);
        } else {
            spannableStringBuilder.append(charSequence);
        }
        if (z2) {
            spannableStringBuilder.append((CharSequence) f(charSequence, a2 ? d.f3085b : d.f3084a));
        }
        return spannableStringBuilder;
    }

    public String j(String str) {
        return k(str, this.f3061c, true);
    }

    public String k(String str, c cVar, boolean z2) {
        if (str == null) {
            return null;
        }
        return i(str, cVar, z2).toString();
    }
}
