package v0;

import android.database.Cursor;
import android.database.sqlite.SQLiteCursor;
import android.database.sqlite.SQLiteCursorDriver;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteQuery;
import android.os.CancellationSignal;
import android.util.Pair;
import java.util.List;
import u0.f;
/* loaded from: classes.dex */
class a implements u0.b {

    /* renamed from: c  reason: collision with root package name */
    private static final String[] f5405c = {"", " OR ROLLBACK ", " OR ABORT ", " OR FAIL ", " OR IGNORE ", " OR REPLACE "};

    /* renamed from: d  reason: collision with root package name */
    private static final String[] f5406d = new String[0];

    /* renamed from: b  reason: collision with root package name */
    private final SQLiteDatabase f5407b;

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: v0.a$a  reason: collision with other inner class name */
    /* loaded from: classes.dex */
    public class C0076a implements SQLiteDatabase.CursorFactory {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ u0.e f5408a;

        C0076a(u0.e eVar) {
            this.f5408a = eVar;
        }

        @Override // android.database.sqlite.SQLiteDatabase.CursorFactory
        public Cursor newCursor(SQLiteDatabase sQLiteDatabase, SQLiteCursorDriver sQLiteCursorDriver, String str, SQLiteQuery sQLiteQuery) {
            this.f5408a.v(new d(sQLiteQuery));
            return new SQLiteCursor(sQLiteCursorDriver, str, sQLiteQuery);
        }
    }

    /* loaded from: classes.dex */
    class b implements SQLiteDatabase.CursorFactory {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ u0.e f5410a;

        b(u0.e eVar) {
            this.f5410a = eVar;
        }

        @Override // android.database.sqlite.SQLiteDatabase.CursorFactory
        public Cursor newCursor(SQLiteDatabase sQLiteDatabase, SQLiteCursorDriver sQLiteCursorDriver, String str, SQLiteQuery sQLiteQuery) {
            this.f5410a.v(new d(sQLiteQuery));
            return new SQLiteCursor(sQLiteCursorDriver, str, sQLiteQuery);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public a(SQLiteDatabase sQLiteDatabase) {
        this.f5407b = sQLiteDatabase;
    }

    @Override // u0.b
    public void a() {
        this.f5407b.endTransaction();
    }

    @Override // u0.b
    public void b() {
        this.f5407b.beginTransaction();
    }

    @Override // u0.b
    public boolean c() {
        return this.f5407b.isOpen();
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public void close() {
        this.f5407b.close();
    }

    @Override // u0.b
    public List<Pair<String, String>> d() {
        return this.f5407b.getAttachedDbs();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public boolean e(SQLiteDatabase sQLiteDatabase) {
        return this.f5407b == sQLiteDatabase;
    }

    @Override // u0.b
    public boolean f() {
        return this.f5407b.isWriteAheadLoggingEnabled();
    }

    @Override // u0.b
    public void g(String str) {
        this.f5407b.execSQL(str);
    }

    @Override // u0.b
    public Cursor j(u0.e eVar) {
        return this.f5407b.rawQueryWithFactory(new C0076a(eVar), eVar.e(), f5406d, null);
    }

    @Override // u0.b
    public void k() {
        this.f5407b.setTransactionSuccessful();
    }

    @Override // u0.b
    public f m(String str) {
        return new e(this.f5407b.compileStatement(str));
    }

    @Override // u0.b
    public void n() {
        this.f5407b.beginTransactionNonExclusive();
    }

    @Override // u0.b
    public Cursor s(String str) {
        return j(new u0.a(str));
    }

    @Override // u0.b
    public String t() {
        return this.f5407b.getPath();
    }

    @Override // u0.b
    public boolean u() {
        return this.f5407b.inTransaction();
    }

    @Override // u0.b
    public Cursor w(u0.e eVar, CancellationSignal cancellationSignal) {
        return this.f5407b.rawQueryWithFactory(new b(eVar), eVar.e(), f5406d, null, cancellationSignal);
    }
}
