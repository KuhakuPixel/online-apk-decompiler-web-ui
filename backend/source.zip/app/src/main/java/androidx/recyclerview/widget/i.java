package androidx.recyclerview.widget;

import android.graphics.Rect;
import android.view.View;
import android.view.ViewGroup;
import androidx.recyclerview.widget.RecyclerView;
/* loaded from: classes.dex */
public abstract class i {

    /* renamed from: a  reason: collision with root package name */
    protected final RecyclerView.o f2459a;

    /* renamed from: b  reason: collision with root package name */
    private int f2460b;

    /* renamed from: c  reason: collision with root package name */
    final Rect f2461c;

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public static class a extends i {
        a(RecyclerView.o oVar) {
            super(oVar, null);
        }

        @Override // androidx.recyclerview.widget.i
        public int d(View view) {
            return this.f2459a.T(view) + ((ViewGroup.MarginLayoutParams) ((RecyclerView.p) view.getLayoutParams())).rightMargin;
        }

        @Override // androidx.recyclerview.widget.i
        public int e(View view) {
            RecyclerView.p pVar = (RecyclerView.p) view.getLayoutParams();
            return this.f2459a.S(view) + ((ViewGroup.MarginLayoutParams) pVar).leftMargin + ((ViewGroup.MarginLayoutParams) pVar).rightMargin;
        }

        @Override // androidx.recyclerview.widget.i
        public int f(View view) {
            RecyclerView.p pVar = (RecyclerView.p) view.getLayoutParams();
            return this.f2459a.R(view) + ((ViewGroup.MarginLayoutParams) pVar).topMargin + ((ViewGroup.MarginLayoutParams) pVar).bottomMargin;
        }

        @Override // androidx.recyclerview.widget.i
        public int g(View view) {
            return this.f2459a.Q(view) - ((ViewGroup.MarginLayoutParams) ((RecyclerView.p) view.getLayoutParams())).leftMargin;
        }

        @Override // androidx.recyclerview.widget.i
        public int h() {
            return this.f2459a.o0();
        }

        @Override // androidx.recyclerview.widget.i
        public int i() {
            return this.f2459a.o0() - this.f2459a.f0();
        }

        @Override // androidx.recyclerview.widget.i
        public int j() {
            return this.f2459a.f0();
        }

        @Override // androidx.recyclerview.widget.i
        public int k() {
            return this.f2459a.p0();
        }

        @Override // androidx.recyclerview.widget.i
        public int l() {
            return this.f2459a.X();
        }

        @Override // androidx.recyclerview.widget.i
        public int m() {
            return this.f2459a.e0();
        }

        @Override // androidx.recyclerview.widget.i
        public int n() {
            return (this.f2459a.o0() - this.f2459a.e0()) - this.f2459a.f0();
        }

        @Override // androidx.recyclerview.widget.i
        public int p(View view) {
            this.f2459a.n0(view, true, this.f2461c);
            return this.f2461c.right;
        }

        @Override // androidx.recyclerview.widget.i
        public int q(View view) {
            this.f2459a.n0(view, true, this.f2461c);
            return this.f2461c.left;
        }

        @Override // androidx.recyclerview.widget.i
        public void r(int i2) {
            this.f2459a.C0(i2);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public static class b extends i {
        b(RecyclerView.o oVar) {
            super(oVar, null);
        }

        @Override // androidx.recyclerview.widget.i
        public int d(View view) {
            return this.f2459a.O(view) + ((ViewGroup.MarginLayoutParams) ((RecyclerView.p) view.getLayoutParams())).bottomMargin;
        }

        @Override // androidx.recyclerview.widget.i
        public int e(View view) {
            RecyclerView.p pVar = (RecyclerView.p) view.getLayoutParams();
            return this.f2459a.R(view) + ((ViewGroup.MarginLayoutParams) pVar).topMargin + ((ViewGroup.MarginLayoutParams) pVar).bottomMargin;
        }

        @Override // androidx.recyclerview.widget.i
        public int f(View view) {
            RecyclerView.p pVar = (RecyclerView.p) view.getLayoutParams();
            return this.f2459a.S(view) + ((ViewGroup.MarginLayoutParams) pVar).leftMargin + ((ViewGroup.MarginLayoutParams) pVar).rightMargin;
        }

        @Override // androidx.recyclerview.widget.i
        public int g(View view) {
            return this.f2459a.U(view) - ((ViewGroup.MarginLayoutParams) ((RecyclerView.p) view.getLayoutParams())).topMargin;
        }

        @Override // androidx.recyclerview.widget.i
        public int h() {
            return this.f2459a.W();
        }

        @Override // androidx.recyclerview.widget.i
        public int i() {
            return this.f2459a.W() - this.f2459a.d0();
        }

        @Override // androidx.recyclerview.widget.i
        public int j() {
            return this.f2459a.d0();
        }

        @Override // androidx.recyclerview.widget.i
        public int k() {
            return this.f2459a.X();
        }

        @Override // androidx.recyclerview.widget.i
        public int l() {
            return this.f2459a.p0();
        }

        @Override // androidx.recyclerview.widget.i
        public int m() {
            return this.f2459a.g0();
        }

        @Override // androidx.recyclerview.widget.i
        public int n() {
            return (this.f2459a.W() - this.f2459a.g0()) - this.f2459a.d0();
        }

        @Override // androidx.recyclerview.widget.i
        public int p(View view) {
            this.f2459a.n0(view, true, this.f2461c);
            return this.f2461c.bottom;
        }

        @Override // androidx.recyclerview.widget.i
        public int q(View view) {
            this.f2459a.n0(view, true, this.f2461c);
            return this.f2461c.top;
        }

        @Override // androidx.recyclerview.widget.i
        public void r(int i2) {
            this.f2459a.D0(i2);
        }
    }

    private i(RecyclerView.o oVar) {
        this.f2460b = Integer.MIN_VALUE;
        this.f2461c = new Rect();
        this.f2459a = oVar;
    }

    /* synthetic */ i(RecyclerView.o oVar, a aVar) {
        this(oVar);
    }

    public static i a(RecyclerView.o oVar) {
        return new a(oVar);
    }

    public static i b(RecyclerView.o oVar, int i2) {
        if (i2 != 0) {
            if (i2 == 1) {
                return c(oVar);
            }
            throw new IllegalArgumentException("invalid orientation");
        }
        return a(oVar);
    }

    public static i c(RecyclerView.o oVar) {
        return new b(oVar);
    }

    public abstract int d(View view);

    public abstract int e(View view);

    public abstract int f(View view);

    public abstract int g(View view);

    public abstract int h();

    public abstract int i();

    public abstract int j();

    public abstract int k();

    public abstract int l();

    public abstract int m();

    public abstract int n();

    public int o() {
        if (Integer.MIN_VALUE == this.f2460b) {
            return 0;
        }
        return n() - this.f2460b;
    }

    public abstract int p(View view);

    public abstract int q(View view);

    public abstract void r(int i2);

    public void s() {
        this.f2460b = n();
    }
}
