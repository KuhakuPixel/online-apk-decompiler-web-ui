package z0;

import java.util.List;
import javax.annotation.CheckForNull;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes.dex */
public final class a0 extends b0 {

    /* renamed from: d  reason: collision with root package name */
    final transient int f5671d;

    /* renamed from: e  reason: collision with root package name */
    final transient int f5672e;

    /* renamed from: f  reason: collision with root package name */
    final /* synthetic */ b0 f5673f;

    /* JADX INFO: Access modifiers changed from: package-private */
    public a0(b0 b0Var, int i2, int i3) {
        this.f5673f = b0Var;
        this.f5671d = i2;
        this.f5672e = i3;
    }

    @Override // z0.y
    final int d() {
        return this.f5673f.e() + this.f5671d + this.f5672e;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    @Override // z0.y
    public final int e() {
        return this.f5673f.e() + this.f5671d;
    }

    @Override // java.util.List
    public final Object get(int i2) {
        t.a(i2, this.f5672e, "index");
        return this.f5673f.get(i2 + this.f5671d);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    @Override // z0.y
    public final boolean h() {
        return true;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    @Override // z0.y
    @CheckForNull
    public final Object[] i() {
        return this.f5673f.i();
    }

    @Override // z0.b0
    /* renamed from: j */
    public final b0 subList(int i2, int i3) {
        t.c(i2, i3, this.f5672e);
        b0 b0Var = this.f5673f;
        int i4 = this.f5671d;
        return b0Var.subList(i2 + i4, i3 + i4);
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public final int size() {
        return this.f5672e;
    }

    @Override // z0.b0, java.util.List
    public final /* bridge */ /* synthetic */ List subList(int i2, int i3) {
        return subList(i2, i3);
    }
}
