package androidx.lifecycle;

import java.io.Closeable;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
/* loaded from: classes.dex */
public abstract class r {

    /* renamed from: a  reason: collision with root package name */
    private final Map<String, Object> f1875a = new HashMap();

    /* renamed from: b  reason: collision with root package name */
    private volatile boolean f1876b = false;

    private static void b(Object obj) {
        if (obj instanceof Closeable) {
            try {
                ((Closeable) obj).close();
            } catch (IOException e2) {
                throw new RuntimeException(e2);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final void a() {
        this.f1876b = true;
        Map<String, Object> map = this.f1875a;
        if (map != null) {
            synchronized (map) {
                Iterator<Object> it = this.f1875a.values().iterator();
                while (it.hasNext()) {
                    b(it.next());
                }
            }
        }
        d();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public <T> T c(String str) {
        T t2;
        Map<String, Object> map = this.f1875a;
        if (map == null) {
            return null;
        }
        synchronized (map) {
            t2 = (T) this.f1875a.get(str);
        }
        return t2;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public void d() {
    }
}
