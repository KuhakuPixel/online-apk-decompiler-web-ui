package o;

import java.util.Arrays;
import o.b;
/* loaded from: classes.dex */
public class a implements b.a {

    /* renamed from: l  reason: collision with root package name */
    private static float f4706l = 0.001f;

    /* renamed from: b  reason: collision with root package name */
    private final b f4708b;

    /* renamed from: c  reason: collision with root package name */
    protected final c f4709c;

    /* renamed from: a  reason: collision with root package name */
    int f4707a = 0;

    /* renamed from: d  reason: collision with root package name */
    private int f4710d = 8;

    /* renamed from: e  reason: collision with root package name */
    private i f4711e = null;

    /* renamed from: f  reason: collision with root package name */
    private int[] f4712f = new int[8];

    /* renamed from: g  reason: collision with root package name */
    private int[] f4713g = new int[8];

    /* renamed from: h  reason: collision with root package name */
    private float[] f4714h = new float[8];

    /* renamed from: i  reason: collision with root package name */
    private int f4715i = -1;

    /* renamed from: j  reason: collision with root package name */
    private int f4716j = -1;

    /* renamed from: k  reason: collision with root package name */
    private boolean f4717k = false;

    /* JADX INFO: Access modifiers changed from: package-private */
    public a(b bVar, c cVar) {
        this.f4708b = bVar;
        this.f4709c = cVar;
    }

    @Override // o.b.a
    public float a(int i2) {
        int i3 = this.f4715i;
        for (int i4 = 0; i3 != -1 && i4 < this.f4707a; i4++) {
            if (i4 == i2) {
                return this.f4714h[i3];
            }
            i3 = this.f4713g[i3];
        }
        return 0.0f;
    }

    @Override // o.b.a
    public void b(i iVar, float f2, boolean z2) {
        float f3 = f4706l;
        if (f2 <= (-f3) || f2 >= f3) {
            int i2 = this.f4715i;
            if (i2 == -1) {
                this.f4715i = 0;
                this.f4714h[0] = f2;
                this.f4712f[0] = iVar.f4769c;
                this.f4713g[0] = -1;
                iVar.f4779m++;
                iVar.a(this.f4708b);
                this.f4707a++;
                if (this.f4717k) {
                    return;
                }
                int i3 = this.f4716j + 1;
                this.f4716j = i3;
                int[] iArr = this.f4712f;
                if (i3 >= iArr.length) {
                    this.f4717k = true;
                    this.f4716j = iArr.length - 1;
                    return;
                }
                return;
            }
            int i4 = -1;
            for (int i5 = 0; i2 != -1 && i5 < this.f4707a; i5++) {
                int[] iArr2 = this.f4712f;
                int i6 = iArr2[i2];
                int i7 = iVar.f4769c;
                if (i6 == i7) {
                    float[] fArr = this.f4714h;
                    float f4 = fArr[i2] + f2;
                    float f5 = f4706l;
                    if (f4 > (-f5) && f4 < f5) {
                        f4 = 0.0f;
                    }
                    fArr[i2] = f4;
                    if (f4 == 0.0f) {
                        if (i2 == this.f4715i) {
                            this.f4715i = this.f4713g[i2];
                        } else {
                            int[] iArr3 = this.f4713g;
                            iArr3[i4] = iArr3[i2];
                        }
                        if (z2) {
                            iVar.c(this.f4708b);
                        }
                        if (this.f4717k) {
                            this.f4716j = i2;
                        }
                        iVar.f4779m--;
                        this.f4707a--;
                        return;
                    }
                    return;
                }
                if (iArr2[i2] < i7) {
                    i4 = i2;
                }
                i2 = this.f4713g[i2];
            }
            int i8 = this.f4716j;
            int i9 = i8 + 1;
            if (this.f4717k) {
                int[] iArr4 = this.f4712f;
                if (iArr4[i8] != -1) {
                    i8 = iArr4.length;
                }
            } else {
                i8 = i9;
            }
            int[] iArr5 = this.f4712f;
            if (i8 >= iArr5.length && this.f4707a < iArr5.length) {
                int i10 = 0;
                while (true) {
                    int[] iArr6 = this.f4712f;
                    if (i10 >= iArr6.length) {
                        break;
                    } else if (iArr6[i10] == -1) {
                        i8 = i10;
                        break;
                    } else {
                        i10++;
                    }
                }
            }
            int[] iArr7 = this.f4712f;
            if (i8 >= iArr7.length) {
                i8 = iArr7.length;
                int i11 = this.f4710d * 2;
                this.f4710d = i11;
                this.f4717k = false;
                this.f4716j = i8 - 1;
                this.f4714h = Arrays.copyOf(this.f4714h, i11);
                this.f4712f = Arrays.copyOf(this.f4712f, this.f4710d);
                this.f4713g = Arrays.copyOf(this.f4713g, this.f4710d);
            }
            this.f4712f[i8] = iVar.f4769c;
            this.f4714h[i8] = f2;
            int[] iArr8 = this.f4713g;
            if (i4 != -1) {
                iArr8[i8] = iArr8[i4];
                iArr8[i4] = i8;
            } else {
                iArr8[i8] = this.f4715i;
                this.f4715i = i8;
            }
            iVar.f4779m++;
            iVar.a(this.f4708b);
            this.f4707a++;
            if (!this.f4717k) {
                this.f4716j++;
            }
            int i12 = this.f4716j;
            int[] iArr9 = this.f4712f;
            if (i12 >= iArr9.length) {
                this.f4717k = true;
                this.f4716j = iArr9.length - 1;
            }
        }
    }

    @Override // o.b.a
    public boolean c(i iVar) {
        int i2 = this.f4715i;
        if (i2 == -1) {
            return false;
        }
        for (int i3 = 0; i2 != -1 && i3 < this.f4707a; i3++) {
            if (this.f4712f[i2] == iVar.f4769c) {
                return true;
            }
            i2 = this.f4713g[i2];
        }
        return false;
    }

    @Override // o.b.a
    public final void clear() {
        int i2 = this.f4715i;
        for (int i3 = 0; i2 != -1 && i3 < this.f4707a; i3++) {
            i iVar = this.f4709c.f4727d[this.f4712f[i2]];
            if (iVar != null) {
                iVar.c(this.f4708b);
            }
            i2 = this.f4713g[i2];
        }
        this.f4715i = -1;
        this.f4716j = -1;
        this.f4717k = false;
        this.f4707a = 0;
    }

    @Override // o.b.a
    public float d(b bVar, boolean z2) {
        float f2 = f(bVar.f4718a);
        i(bVar.f4718a, z2);
        b.a aVar = bVar.f4722e;
        int k2 = aVar.k();
        for (int i2 = 0; i2 < k2; i2++) {
            i g2 = aVar.g(i2);
            b(g2, aVar.f(g2) * f2, z2);
        }
        return f2;
    }

    @Override // o.b.a
    public final void e(i iVar, float f2) {
        if (f2 == 0.0f) {
            i(iVar, true);
            return;
        }
        int i2 = this.f4715i;
        if (i2 == -1) {
            this.f4715i = 0;
            this.f4714h[0] = f2;
            this.f4712f[0] = iVar.f4769c;
            this.f4713g[0] = -1;
            iVar.f4779m++;
            iVar.a(this.f4708b);
            this.f4707a++;
            if (this.f4717k) {
                return;
            }
            int i3 = this.f4716j + 1;
            this.f4716j = i3;
            int[] iArr = this.f4712f;
            if (i3 >= iArr.length) {
                this.f4717k = true;
                this.f4716j = iArr.length - 1;
                return;
            }
            return;
        }
        int i4 = -1;
        for (int i5 = 0; i2 != -1 && i5 < this.f4707a; i5++) {
            int[] iArr2 = this.f4712f;
            int i6 = iArr2[i2];
            int i7 = iVar.f4769c;
            if (i6 == i7) {
                this.f4714h[i2] = f2;
                return;
            }
            if (iArr2[i2] < i7) {
                i4 = i2;
            }
            i2 = this.f4713g[i2];
        }
        int i8 = this.f4716j;
        int i9 = i8 + 1;
        if (this.f4717k) {
            int[] iArr3 = this.f4712f;
            if (iArr3[i8] != -1) {
                i8 = iArr3.length;
            }
        } else {
            i8 = i9;
        }
        int[] iArr4 = this.f4712f;
        if (i8 >= iArr4.length && this.f4707a < iArr4.length) {
            int i10 = 0;
            while (true) {
                int[] iArr5 = this.f4712f;
                if (i10 >= iArr5.length) {
                    break;
                } else if (iArr5[i10] == -1) {
                    i8 = i10;
                    break;
                } else {
                    i10++;
                }
            }
        }
        int[] iArr6 = this.f4712f;
        if (i8 >= iArr6.length) {
            i8 = iArr6.length;
            int i11 = this.f4710d * 2;
            this.f4710d = i11;
            this.f4717k = false;
            this.f4716j = i8 - 1;
            this.f4714h = Arrays.copyOf(this.f4714h, i11);
            this.f4712f = Arrays.copyOf(this.f4712f, this.f4710d);
            this.f4713g = Arrays.copyOf(this.f4713g, this.f4710d);
        }
        this.f4712f[i8] = iVar.f4769c;
        this.f4714h[i8] = f2;
        int[] iArr7 = this.f4713g;
        if (i4 != -1) {
            iArr7[i8] = iArr7[i4];
            iArr7[i4] = i8;
        } else {
            iArr7[i8] = this.f4715i;
            this.f4715i = i8;
        }
        iVar.f4779m++;
        iVar.a(this.f4708b);
        int i12 = this.f4707a + 1;
        this.f4707a = i12;
        if (!this.f4717k) {
            this.f4716j++;
        }
        int[] iArr8 = this.f4712f;
        if (i12 >= iArr8.length) {
            this.f4717k = true;
        }
        if (this.f4716j >= iArr8.length) {
            this.f4717k = true;
            this.f4716j = iArr8.length - 1;
        }
    }

    @Override // o.b.a
    public final float f(i iVar) {
        int i2 = this.f4715i;
        for (int i3 = 0; i2 != -1 && i3 < this.f4707a; i3++) {
            if (this.f4712f[i2] == iVar.f4769c) {
                return this.f4714h[i2];
            }
            i2 = this.f4713g[i2];
        }
        return 0.0f;
    }

    @Override // o.b.a
    public i g(int i2) {
        int i3 = this.f4715i;
        for (int i4 = 0; i3 != -1 && i4 < this.f4707a; i4++) {
            if (i4 == i2) {
                return this.f4709c.f4727d[this.f4712f[i3]];
            }
            i3 = this.f4713g[i3];
        }
        return null;
    }

    @Override // o.b.a
    public void h(float f2) {
        int i2 = this.f4715i;
        for (int i3 = 0; i2 != -1 && i3 < this.f4707a; i3++) {
            float[] fArr = this.f4714h;
            fArr[i2] = fArr[i2] / f2;
            i2 = this.f4713g[i2];
        }
    }

    @Override // o.b.a
    public final float i(i iVar, boolean z2) {
        if (this.f4711e == iVar) {
            this.f4711e = null;
        }
        int i2 = this.f4715i;
        if (i2 == -1) {
            return 0.0f;
        }
        int i3 = 0;
        int i4 = -1;
        while (i2 != -1 && i3 < this.f4707a) {
            if (this.f4712f[i2] == iVar.f4769c) {
                if (i2 == this.f4715i) {
                    this.f4715i = this.f4713g[i2];
                } else {
                    int[] iArr = this.f4713g;
                    iArr[i4] = iArr[i2];
                }
                if (z2) {
                    iVar.c(this.f4708b);
                }
                iVar.f4779m--;
                this.f4707a--;
                this.f4712f[i2] = -1;
                if (this.f4717k) {
                    this.f4716j = i2;
                }
                return this.f4714h[i2];
            }
            i3++;
            i4 = i2;
            i2 = this.f4713g[i2];
        }
        return 0.0f;
    }

    @Override // o.b.a
    public void j() {
        int i2 = this.f4715i;
        for (int i3 = 0; i2 != -1 && i3 < this.f4707a; i3++) {
            float[] fArr = this.f4714h;
            fArr[i2] = fArr[i2] * (-1.0f);
            i2 = this.f4713g[i2];
        }
    }

    @Override // o.b.a
    public int k() {
        return this.f4707a;
    }

    public String toString() {
        int i2 = this.f4715i;
        String str = "";
        for (int i3 = 0; i2 != -1 && i3 < this.f4707a; i3++) {
            str = ((str + " -> ") + this.f4714h[i2] + " : ") + this.f4709c.f4727d[this.f4712f[i2]];
            i2 = this.f4713g[i2];
        }
        return str;
    }
}
