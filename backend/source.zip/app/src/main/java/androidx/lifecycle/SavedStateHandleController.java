package androidx.lifecycle;

import androidx.lifecycle.d;
import androidx.savedstate.SavedStateRegistry;
import java.util.Iterator;
/* loaded from: classes.dex */
final class SavedStateHandleController implements e {

    /* renamed from: a  reason: collision with root package name */
    private boolean f1836a;

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public static final class a implements SavedStateRegistry.a {
        a() {
        }

        @Override // androidx.savedstate.SavedStateRegistry.a
        public void a(androidx.savedstate.b bVar) {
            if (!(bVar instanceof u)) {
                throw new IllegalStateException("Internal error: OnRecreation should be registered only on componentsthat implement ViewModelStoreOwner");
            }
            t g2 = ((u) bVar).g();
            SavedStateRegistry c2 = bVar.c();
            Iterator<String> it = g2.c().iterator();
            while (it.hasNext()) {
                SavedStateHandleController.d(g2.b(it.next()), c2, bVar.a());
            }
            if (g2.c().isEmpty()) {
                return;
            }
            c2.e(a.class);
        }
    }

    static void d(r rVar, SavedStateRegistry savedStateRegistry, d dVar) {
        SavedStateHandleController savedStateHandleController = (SavedStateHandleController) rVar.c("androidx.lifecycle.savedstate.vm.tag");
        if (savedStateHandleController == null || savedStateHandleController.i()) {
            return;
        }
        savedStateHandleController.e(savedStateRegistry, dVar);
        k(savedStateRegistry, dVar);
    }

    private static void k(final SavedStateRegistry savedStateRegistry, final d dVar) {
        d.b b2 = dVar.b();
        if (b2 == d.b.INITIALIZED || b2.a(d.b.STARTED)) {
            savedStateRegistry.e(a.class);
        } else {
            dVar.a(new e() { // from class: androidx.lifecycle.SavedStateHandleController.1
                @Override // androidx.lifecycle.e
                public void f(g gVar, d.a aVar) {
                    if (aVar == d.a.ON_START) {
                        d.this.c(this);
                        savedStateRegistry.e(a.class);
                    }
                }
            });
        }
    }

    void e(SavedStateRegistry savedStateRegistry, d dVar) {
        if (this.f1836a) {
            throw new IllegalStateException("Already attached to lifecycleOwner");
        }
        this.f1836a = true;
        dVar.a(this);
        throw null;
    }

    @Override // androidx.lifecycle.e
    public void f(g gVar, d.a aVar) {
        if (aVar == d.a.ON_DESTROY) {
            this.f1836a = false;
            gVar.a().c(this);
        }
    }

    boolean i() {
        return this.f1836a;
    }
}
