package a1;
/* loaded from: classes.dex */
public final class f {

    /* renamed from: A */
    public static final int mtrl_internal_children_alpha_tag = 2131362052;

    /* renamed from: B */
    public static final int mtrl_picker_header_selection_text = 2131362056;

    /* renamed from: C */
    public static final int mtrl_picker_header_toggle = 2131362058;

    /* renamed from: D */
    public static final int mtrl_picker_title_text = 2131362062;

    /* renamed from: E */
    public static final int row_index_key = 2131362108;

    /* renamed from: F */
    public static final int selection_type = 2131362131;

    /* renamed from: G */
    public static final int snackbar_action = 2131362144;

    /* renamed from: H */
    public static final int snackbar_text = 2131362145;

    /* renamed from: I */
    public static final int text_input_error_icon = 2131362190;

    /* renamed from: J */
    public static final int textinput_counter = 2131362192;

    /* renamed from: K */
    public static final int textinput_error = 2131362193;

    /* renamed from: L */
    public static final int textinput_helper_text = 2131362194;

    /* renamed from: M */
    public static final int textinput_placeholder = 2131362195;

    /* renamed from: N */
    public static final int textinput_prefix_text = 2131362196;

    /* renamed from: O */
    public static final int textinput_suffix_text = 2131362197;

    /* renamed from: a */
    public static final int cancel_button = 2131361883;

    /* renamed from: b */
    public static final int circle_center = 2131361897;

    /* renamed from: c */
    public static final int confirm_button = 2131361903;

    /* renamed from: d */
    public static final int design_menu_item_action_area_stub = 2131361925;

    /* renamed from: e */
    public static final int design_menu_item_text = 2131361926;

    /* renamed from: f */
    public static final int material_clock_display = 2131362011;

    /* renamed from: g */
    public static final int material_clock_face = 2131362012;

    /* renamed from: h */
    public static final int material_clock_hand = 2131362013;

    /* renamed from: i */
    public static final int material_clock_period_pm_button = 2131362015;

    /* renamed from: j */
    public static final int material_clock_period_toggle = 2131362016;

    /* renamed from: k */
    public static final int material_hour_tv = 2131362018;

    /* renamed from: l */
    public static final int material_label = 2131362019;

    /* renamed from: m */
    public static final int material_minute_tv = 2131362021;

    /* renamed from: n */
    public static final int material_value_index = 2131362029;

    /* renamed from: o */
    public static final int month_grid = 2131362034;

    /* renamed from: p */
    public static final int month_navigation_fragment_toggle = 2131362036;

    /* renamed from: q */
    public static final int month_navigation_next = 2131362037;

    /* renamed from: r */
    public static final int month_navigation_previous = 2131362038;

    /* renamed from: s */
    public static final int month_title = 2131362039;

    /* renamed from: t */
    public static final int mtrl_calendar_day_selector_frame = 2131362042;

    /* renamed from: u */
    public static final int mtrl_calendar_days_of_week = 2131362043;

    /* renamed from: v */
    public static final int mtrl_calendar_frame = 2131362044;

    /* renamed from: w */
    public static final int mtrl_calendar_main_pane = 2131362045;

    /* renamed from: x */
    public static final int mtrl_calendar_months = 2131362046;

    /* renamed from: y */
    public static final int mtrl_calendar_year_selector_frame = 2131362049;

    /* renamed from: z */
    public static final int mtrl_child_content_container = 2131362051;
}
