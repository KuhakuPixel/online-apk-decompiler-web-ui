package o;

import java.util.Arrays;
import o.b;
/* loaded from: classes.dex */
public class j implements b.a {

    /* renamed from: n  reason: collision with root package name */
    private static float f4790n = 0.001f;

    /* renamed from: a  reason: collision with root package name */
    private final int f4791a = -1;

    /* renamed from: b  reason: collision with root package name */
    private int f4792b = 16;

    /* renamed from: c  reason: collision with root package name */
    private int f4793c = 16;

    /* renamed from: d  reason: collision with root package name */
    int[] f4794d = new int[16];

    /* renamed from: e  reason: collision with root package name */
    int[] f4795e = new int[16];

    /* renamed from: f  reason: collision with root package name */
    int[] f4796f = new int[16];

    /* renamed from: g  reason: collision with root package name */
    float[] f4797g = new float[16];

    /* renamed from: h  reason: collision with root package name */
    int[] f4798h = new int[16];

    /* renamed from: i  reason: collision with root package name */
    int[] f4799i = new int[16];

    /* renamed from: j  reason: collision with root package name */
    int f4800j = 0;

    /* renamed from: k  reason: collision with root package name */
    int f4801k = -1;

    /* renamed from: l  reason: collision with root package name */
    private final b f4802l;

    /* renamed from: m  reason: collision with root package name */
    protected final c f4803m;

    /* JADX INFO: Access modifiers changed from: package-private */
    public j(b bVar, c cVar) {
        this.f4802l = bVar;
        this.f4803m = cVar;
        clear();
    }

    private void l(i iVar, int i2) {
        int[] iArr;
        int i3 = iVar.f4769c % this.f4793c;
        int[] iArr2 = this.f4794d;
        int i4 = iArr2[i3];
        if (i4 == -1) {
            iArr2[i3] = i2;
        } else {
            while (true) {
                iArr = this.f4795e;
                if (iArr[i4] == -1) {
                    break;
                }
                i4 = iArr[i4];
            }
            iArr[i4] = i2;
        }
        this.f4795e[i2] = -1;
    }

    private void m(int i2, i iVar, float f2) {
        this.f4796f[i2] = iVar.f4769c;
        this.f4797g[i2] = f2;
        this.f4798h[i2] = -1;
        this.f4799i[i2] = -1;
        iVar.a(this.f4802l);
        iVar.f4779m++;
        this.f4800j++;
    }

    private int n() {
        for (int i2 = 0; i2 < this.f4792b; i2++) {
            if (this.f4796f[i2] == -1) {
                return i2;
            }
        }
        return -1;
    }

    private void o() {
        int i2 = this.f4792b * 2;
        this.f4796f = Arrays.copyOf(this.f4796f, i2);
        this.f4797g = Arrays.copyOf(this.f4797g, i2);
        this.f4798h = Arrays.copyOf(this.f4798h, i2);
        this.f4799i = Arrays.copyOf(this.f4799i, i2);
        this.f4795e = Arrays.copyOf(this.f4795e, i2);
        for (int i3 = this.f4792b; i3 < i2; i3++) {
            this.f4796f[i3] = -1;
            this.f4795e[i3] = -1;
        }
        this.f4792b = i2;
    }

    private void q(int i2, i iVar, float f2) {
        int n2 = n();
        m(n2, iVar, f2);
        if (i2 != -1) {
            this.f4798h[n2] = i2;
            int[] iArr = this.f4799i;
            iArr[n2] = iArr[i2];
            iArr[i2] = n2;
        } else {
            this.f4798h[n2] = -1;
            if (this.f4800j > 0) {
                this.f4799i[n2] = this.f4801k;
                this.f4801k = n2;
            } else {
                this.f4799i[n2] = -1;
            }
        }
        int[] iArr2 = this.f4799i;
        if (iArr2[n2] != -1) {
            this.f4798h[iArr2[n2]] = n2;
        }
        l(iVar, n2);
    }

    private void r(i iVar) {
        int[] iArr;
        int i2 = iVar.f4769c;
        int i3 = i2 % this.f4793c;
        int[] iArr2 = this.f4794d;
        int i4 = iArr2[i3];
        if (i4 == -1) {
            return;
        }
        if (this.f4796f[i4] == i2) {
            int[] iArr3 = this.f4795e;
            iArr2[i3] = iArr3[i4];
            iArr3[i4] = -1;
            return;
        }
        while (true) {
            iArr = this.f4795e;
            if (iArr[i4] == -1 || this.f4796f[iArr[i4]] == i2) {
                break;
            }
            i4 = iArr[i4];
        }
        int i5 = iArr[i4];
        if (i5 == -1 || this.f4796f[i5] != i2) {
            return;
        }
        iArr[i4] = iArr[i5];
        iArr[i5] = -1;
    }

    @Override // o.b.a
    public float a(int i2) {
        int i3 = this.f4800j;
        int i4 = this.f4801k;
        for (int i5 = 0; i5 < i3; i5++) {
            if (i5 == i2) {
                return this.f4797g[i4];
            }
            i4 = this.f4799i[i4];
            if (i4 == -1) {
                return 0.0f;
            }
        }
        return 0.0f;
    }

    @Override // o.b.a
    public void b(i iVar, float f2, boolean z2) {
        float f3 = f4790n;
        if (f2 <= (-f3) || f2 >= f3) {
            int p2 = p(iVar);
            if (p2 == -1) {
                e(iVar, f2);
                return;
            }
            float[] fArr = this.f4797g;
            fArr[p2] = fArr[p2] + f2;
            float f4 = fArr[p2];
            float f5 = f4790n;
            if (f4 <= (-f5) || fArr[p2] >= f5) {
                return;
            }
            fArr[p2] = 0.0f;
            i(iVar, z2);
        }
    }

    @Override // o.b.a
    public boolean c(i iVar) {
        return p(iVar) != -1;
    }

    @Override // o.b.a
    public void clear() {
        int i2 = this.f4800j;
        for (int i3 = 0; i3 < i2; i3++) {
            i g2 = g(i3);
            if (g2 != null) {
                g2.c(this.f4802l);
            }
        }
        for (int i4 = 0; i4 < this.f4792b; i4++) {
            this.f4796f[i4] = -1;
            this.f4795e[i4] = -1;
        }
        for (int i5 = 0; i5 < this.f4793c; i5++) {
            this.f4794d[i5] = -1;
        }
        this.f4800j = 0;
        this.f4801k = -1;
    }

    @Override // o.b.a
    public float d(b bVar, boolean z2) {
        float f2 = f(bVar.f4718a);
        i(bVar.f4718a, z2);
        j jVar = (j) bVar.f4722e;
        int k2 = jVar.k();
        int i2 = 0;
        int i3 = 0;
        while (i2 < k2) {
            int[] iArr = jVar.f4796f;
            if (iArr[i3] != -1) {
                b(this.f4803m.f4727d[iArr[i3]], jVar.f4797g[i3] * f2, z2);
                i2++;
            }
            i3++;
        }
        return f2;
    }

    @Override // o.b.a
    public void e(i iVar, float f2) {
        float f3 = f4790n;
        if (f2 > (-f3) && f2 < f3) {
            i(iVar, true);
            return;
        }
        if (this.f4800j == 0) {
            m(0, iVar, f2);
            l(iVar, 0);
            this.f4801k = 0;
            return;
        }
        int p2 = p(iVar);
        if (p2 != -1) {
            this.f4797g[p2] = f2;
            return;
        }
        if (this.f4800j + 1 >= this.f4792b) {
            o();
        }
        int i2 = this.f4800j;
        int i3 = this.f4801k;
        int i4 = -1;
        for (int i5 = 0; i5 < i2; i5++) {
            int[] iArr = this.f4796f;
            int i6 = iArr[i3];
            int i7 = iVar.f4769c;
            if (i6 == i7) {
                this.f4797g[i3] = f2;
                return;
            }
            if (iArr[i3] < i7) {
                i4 = i3;
            }
            i3 = this.f4799i[i3];
            if (i3 == -1) {
                break;
            }
        }
        q(i4, iVar, f2);
    }

    @Override // o.b.a
    public float f(i iVar) {
        int p2 = p(iVar);
        if (p2 != -1) {
            return this.f4797g[p2];
        }
        return 0.0f;
    }

    @Override // o.b.a
    public i g(int i2) {
        int i3 = this.f4800j;
        if (i3 == 0) {
            return null;
        }
        int i4 = this.f4801k;
        for (int i5 = 0; i5 < i3; i5++) {
            if (i5 == i2 && i4 != -1) {
                return this.f4803m.f4727d[this.f4796f[i4]];
            }
            i4 = this.f4799i[i4];
            if (i4 == -1) {
                break;
            }
        }
        return null;
    }

    @Override // o.b.a
    public void h(float f2) {
        int i2 = this.f4800j;
        int i3 = this.f4801k;
        for (int i4 = 0; i4 < i2; i4++) {
            float[] fArr = this.f4797g;
            fArr[i3] = fArr[i3] / f2;
            i3 = this.f4799i[i3];
            if (i3 == -1) {
                return;
            }
        }
    }

    @Override // o.b.a
    public float i(i iVar, boolean z2) {
        int p2 = p(iVar);
        if (p2 == -1) {
            return 0.0f;
        }
        r(iVar);
        float f2 = this.f4797g[p2];
        if (this.f4801k == p2) {
            this.f4801k = this.f4799i[p2];
        }
        this.f4796f[p2] = -1;
        int[] iArr = this.f4798h;
        if (iArr[p2] != -1) {
            int[] iArr2 = this.f4799i;
            iArr2[iArr[p2]] = iArr2[p2];
        }
        int[] iArr3 = this.f4799i;
        if (iArr3[p2] != -1) {
            iArr[iArr3[p2]] = iArr[p2];
        }
        this.f4800j--;
        iVar.f4779m--;
        if (z2) {
            iVar.c(this.f4802l);
        }
        return f2;
    }

    @Override // o.b.a
    public void j() {
        int i2 = this.f4800j;
        int i3 = this.f4801k;
        for (int i4 = 0; i4 < i2; i4++) {
            float[] fArr = this.f4797g;
            fArr[i3] = fArr[i3] * (-1.0f);
            i3 = this.f4799i[i3];
            if (i3 == -1) {
                return;
            }
        }
    }

    @Override // o.b.a
    public int k() {
        return this.f4800j;
    }

    public int p(i iVar) {
        int[] iArr;
        if (this.f4800j != 0 && iVar != null) {
            int i2 = iVar.f4769c;
            int i3 = this.f4794d[i2 % this.f4793c];
            if (i3 == -1) {
                return -1;
            }
            if (this.f4796f[i3] == i2) {
                return i3;
            }
            while (true) {
                iArr = this.f4795e;
                if (iArr[i3] == -1 || this.f4796f[iArr[i3]] == i2) {
                    break;
                }
                i3 = iArr[i3];
            }
            if (iArr[i3] != -1 && this.f4796f[iArr[i3]] == i2) {
                return iArr[i3];
            }
        }
        return -1;
    }

    public String toString() {
        StringBuilder sb;
        String str = hashCode() + " { ";
        int i2 = this.f4800j;
        for (int i3 = 0; i3 < i2; i3++) {
            i g2 = g(i3);
            if (g2 != null) {
                String str2 = str + g2 + " = " + a(i3) + " ";
                int p2 = p(g2);
                String str3 = str2 + "[p: ";
                if (this.f4798h[p2] != -1) {
                    sb = new StringBuilder();
                    sb.append(str3);
                    sb.append(this.f4803m.f4727d[this.f4796f[this.f4798h[p2]]]);
                } else {
                    sb = new StringBuilder();
                    sb.append(str3);
                    sb.append("none");
                }
                String str4 = sb.toString() + ", n: ";
                str = (this.f4799i[p2] != -1 ? str4 + this.f4803m.f4727d[this.f4796f[this.f4799i[p2]]] : str4 + "none") + "]";
            }
        }
        return str + " }";
    }
}
