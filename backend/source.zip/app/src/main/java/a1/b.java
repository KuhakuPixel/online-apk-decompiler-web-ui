package a1;
/* loaded from: classes.dex */
public final class b {

    /* renamed from: A */
    public static final int state_collapsible = 2130969308;

    /* renamed from: B */
    public static final int state_dragged = 2130969309;

    /* renamed from: C */
    public static final int state_liftable = 2130969310;

    /* renamed from: D */
    public static final int state_lifted = 2130969311;

    /* renamed from: E */
    public static final int textAppearanceLineHeightEnabled = 2130969375;

    /* renamed from: F */
    public static final int textInputStyle = 2130969390;

    /* renamed from: G */
    public static final int theme = 2130969393;
    public static final int H = 2130969426;

    /* renamed from: a  reason: collision with root package name */
    public static final int f102a = 2130968629;

    /* renamed from: b */
    public static final int bottomSheetStyle = 2130968670;

    /* renamed from: c  reason: collision with root package name */
    public static final int f103c = 2130968705;

    /* renamed from: d */
    public static final int chipGroupStyle = 2130968718;

    /* renamed from: e */
    public static final int chipStyle = 2130968733;

    /* renamed from: f  reason: collision with root package name */
    public static final int f104f = 2130968760;

    /* renamed from: g  reason: collision with root package name */
    public static final int f105g = 2130968761;

    /* renamed from: h */
    public static final int colorOnSurface = 2130968769;

    /* renamed from: i */
    public static final int colorPrimary = 2130968770;

    /* renamed from: j */
    public static final int colorPrimaryVariant = 2130968773;

    /* renamed from: k */
    public static final int colorSurface = 2130968776;

    /* renamed from: l  reason: collision with root package name */
    public static final int f106l = 2130968875;

    /* renamed from: m */
    public static final int elevationOverlayColor = 2130968877;

    /* renamed from: n */
    public static final int elevationOverlayEnabled = 2130968878;

    /* renamed from: o */
    public static final int isMaterialTheme = 2130968999;

    /* renamed from: p */
    public static final int materialButtonStyle = 2130969126;

    /* renamed from: q */
    public static final int materialButtonToggleGroupStyle = 2130969127;

    /* renamed from: r */
    public static final int materialCalendarStyle = 2130969139;

    /* renamed from: s */
    public static final int materialClockStyle = 2130969144;

    /* renamed from: t */
    public static final int materialThemeOverlay = 2130969145;

    /* renamed from: u */
    public static final int nestedScrollable = 2130969188;

    /* renamed from: v  reason: collision with root package name */
    public static final int f107v = 2130969244;

    /* renamed from: w */
    public static final int snackbarButtonStyle = 2130969289;

    /* renamed from: x */
    public static final int snackbarStyle = 2130969290;

    /* renamed from: y */
    public static final int snackbarTextViewStyle = 2130969291;

    /* renamed from: z */
    public static final int state_collapsed = 2130969307;
}
