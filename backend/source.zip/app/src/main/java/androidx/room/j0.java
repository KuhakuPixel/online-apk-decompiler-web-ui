package androidx.room;

import java.util.ArrayDeque;
import java.util.concurrent.Executor;
/* loaded from: classes.dex */
class j0 implements Executor {

    /* renamed from: a  reason: collision with root package name */
    private final Executor f2623a;

    /* renamed from: b  reason: collision with root package name */
    private final ArrayDeque<Runnable> f2624b = new ArrayDeque<>();

    /* renamed from: c  reason: collision with root package name */
    private Runnable f2625c;

    /* loaded from: classes.dex */
    class a implements Runnable {

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ Runnable f2626b;

        a(Runnable runnable) {
            this.f2626b = runnable;
        }

        @Override // java.lang.Runnable
        public void run() {
            try {
                this.f2626b.run();
            } finally {
                j0.this.a();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public j0(Executor executor) {
        this.f2623a = executor;
    }

    synchronized void a() {
        Runnable poll = this.f2624b.poll();
        this.f2625c = poll;
        if (poll != null) {
            this.f2623a.execute(poll);
        }
    }

    @Override // java.util.concurrent.Executor
    public synchronized void execute(Runnable runnable) {
        this.f2624b.offer(new a(runnable));
        if (this.f2625c == null) {
            a();
        }
    }
}
