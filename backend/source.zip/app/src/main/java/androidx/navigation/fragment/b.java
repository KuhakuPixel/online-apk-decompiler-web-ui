package androidx.navigation.fragment;
/* loaded from: classes.dex */
public final class b {

    /* renamed from: a */
    public static final int nav_host_fragment_container = 2131362067;
}
