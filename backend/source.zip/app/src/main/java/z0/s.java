package z0;

import javax.annotation.CheckForNull;
/* loaded from: classes.dex */
public final class s extends r {
    public static boolean a(@CheckForNull Object obj, @CheckForNull Object obj2) {
        return obj == obj2 || (obj != null && obj.equals(obj2));
    }
}
