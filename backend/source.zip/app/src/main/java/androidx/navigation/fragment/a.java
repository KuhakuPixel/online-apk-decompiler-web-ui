package androidx.navigation.fragment;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.l;
import androidx.navigation.k;
import androidx.navigation.s;
import java.util.ArrayDeque;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
@s.b("fragment")
/* loaded from: classes.dex */
public class a extends s<C0013a> {

    /* renamed from: a  reason: collision with root package name */
    private final Context f1946a;

    /* renamed from: b  reason: collision with root package name */
    private final l f1947b;

    /* renamed from: c  reason: collision with root package name */
    private final int f1948c;

    /* renamed from: d  reason: collision with root package name */
    private ArrayDeque<Integer> f1949d = new ArrayDeque<>();

    /* renamed from: androidx.navigation.fragment.a$a  reason: collision with other inner class name */
    /* loaded from: classes.dex */
    public static class C0013a extends k {

        /* renamed from: k  reason: collision with root package name */
        private String f1950k;

        public C0013a(s<? extends C0013a> sVar) {
            super(sVar);
        }

        @Override // androidx.navigation.k
        public void p(Context context, AttributeSet attributeSet) {
            super.p(context, attributeSet);
            TypedArray obtainAttributes = context.getResources().obtainAttributes(attributeSet, c.f1960i);
            String string = obtainAttributes.getString(c.f1961j);
            if (string != null) {
                w(string);
            }
            obtainAttributes.recycle();
        }

        @Override // androidx.navigation.k
        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append(super.toString());
            sb.append(" class=");
            String str = this.f1950k;
            if (str == null) {
                str = "null";
            }
            sb.append(str);
            return sb.toString();
        }

        public final String v() {
            String str = this.f1950k;
            if (str != null) {
                return str;
            }
            throw new IllegalStateException("Fragment class was not set");
        }

        public final C0013a w(String str) {
            this.f1950k = str;
            return this;
        }
    }

    /* loaded from: classes.dex */
    public static final class b implements s.a {

        /* renamed from: a  reason: collision with root package name */
        private final LinkedHashMap<View, String> f1951a;

        public Map<View, String> a() {
            return Collections.unmodifiableMap(this.f1951a);
        }
    }

    public a(Context context, l lVar, int i2) {
        this.f1946a = context;
        this.f1947b = lVar;
        this.f1948c = i2;
    }

    private String g(int i2, int i3) {
        return i2 + "-" + i3;
    }

    @Override // androidx.navigation.s
    public void c(Bundle bundle) {
        int[] intArray;
        if (bundle == null || (intArray = bundle.getIntArray("androidx-nav-fragment:navigator:backStackIds")) == null) {
            return;
        }
        this.f1949d.clear();
        for (int i2 : intArray) {
            this.f1949d.add(Integer.valueOf(i2));
        }
    }

    @Override // androidx.navigation.s
    public Bundle d() {
        Bundle bundle = new Bundle();
        int[] iArr = new int[this.f1949d.size()];
        Iterator<Integer> it = this.f1949d.iterator();
        int i2 = 0;
        while (it.hasNext()) {
            iArr[i2] = it.next().intValue();
            i2++;
        }
        bundle.putIntArray("androidx-nav-fragment:navigator:backStackIds", iArr);
        return bundle;
    }

    @Override // androidx.navigation.s
    public boolean e() {
        if (this.f1949d.isEmpty()) {
            return false;
        }
        if (this.f1947b.t0()) {
            Log.i("FragmentNavigator", "Ignoring popBackStack() call: FragmentManager has already saved its state");
            return false;
        }
        this.f1947b.E0(g(this.f1949d.size(), this.f1949d.peekLast().intValue()), 1);
        this.f1949d.removeLast();
        return true;
    }

    @Override // androidx.navigation.s
    /* renamed from: f  reason: merged with bridge method [inline-methods] */
    public C0013a a() {
        return new C0013a(this);
    }

    @Deprecated
    public Fragment h(Context context, l lVar, String str, Bundle bundle) {
        return lVar.e0().a(context.getClassLoader(), str);
    }

    /* JADX WARN: Removed duplicated region for block: B:57:0x00f8  */
    /* JADX WARN: Removed duplicated region for block: B:63:0x012a  */
    /* JADX WARN: Removed duplicated region for block: B:65:0x0134 A[RETURN] */
    @Override // androidx.navigation.s
    /* renamed from: i  reason: merged with bridge method [inline-methods] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public androidx.navigation.k b(androidx.navigation.fragment.a.C0013a r9, android.os.Bundle r10, androidx.navigation.p r11, androidx.navigation.s.a r12) {
        /*
            Method dump skipped, instructions count: 309
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.navigation.fragment.a.b(androidx.navigation.fragment.a$a, android.os.Bundle, androidx.navigation.p, androidx.navigation.s$a):androidx.navigation.k");
    }
}
