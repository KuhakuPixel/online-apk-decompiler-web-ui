package androidx.fragment.app;

import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
/* loaded from: classes.dex */
public abstract class i<E> extends f {

    /* renamed from: b  reason: collision with root package name */
    private final Activity f1631b;

    /* renamed from: c  reason: collision with root package name */
    private final Context f1632c;

    /* renamed from: d  reason: collision with root package name */
    private final Handler f1633d;

    /* renamed from: e  reason: collision with root package name */
    private final int f1634e;

    /* renamed from: f  reason: collision with root package name */
    final l f1635f;

    i(Activity activity, Context context, Handler handler, int i2) {
        this.f1635f = new m();
        this.f1631b = activity;
        this.f1632c = (Context) d0.h.d(context, "context == null");
        this.f1633d = (Handler) d0.h.d(handler, "handler == null");
        this.f1634e = i2;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public i(d dVar) {
        this(dVar, dVar, new Handler(), 0);
    }

    @Override // androidx.fragment.app.f
    public View e(int i2) {
        return null;
    }

    @Override // androidx.fragment.app.f
    public boolean f() {
        return true;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public Activity h() {
        return this.f1631b;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public Context i() {
        return this.f1632c;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public Handler j() {
        return this.f1633d;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void k(Fragment fragment) {
    }

    public abstract E l();

    public LayoutInflater m() {
        return LayoutInflater.from(this.f1632c);
    }

    public boolean n(Fragment fragment) {
        return true;
    }

    public void o() {
    }
}
