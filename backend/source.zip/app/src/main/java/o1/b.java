package o1;

import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Build;
import android.util.Log;
/* loaded from: classes.dex */
public class b {

    /* renamed from: a  reason: collision with root package name */
    public static final boolean f4833a = true;

    /* renamed from: b  reason: collision with root package name */
    private static final int[] f4834b = {16842919};

    /* renamed from: c  reason: collision with root package name */
    private static final int[] f4835c = {16843623, 16842908};

    /* renamed from: d  reason: collision with root package name */
    private static final int[] f4836d = {16842908};

    /* renamed from: e  reason: collision with root package name */
    private static final int[] f4837e = {16843623};

    /* renamed from: f  reason: collision with root package name */
    private static final int[] f4838f = {16842913, 16842919};

    /* renamed from: g  reason: collision with root package name */
    private static final int[] f4839g = {16842913, 16843623, 16842908};

    /* renamed from: h  reason: collision with root package name */
    private static final int[] f4840h = {16842913, 16842908};

    /* renamed from: i  reason: collision with root package name */
    private static final int[] f4841i = {16842913, 16843623};

    /* renamed from: j  reason: collision with root package name */
    private static final int[] f4842j = {16842913};

    /* renamed from: k  reason: collision with root package name */
    private static final int[] f4843k = {16842910, 16842919};

    /* renamed from: l  reason: collision with root package name */
    static final String f4844l = b.class.getSimpleName();

    private b() {
    }

    public static ColorStateList a(ColorStateList colorStateList) {
        if (colorStateList != null) {
            int i2 = Build.VERSION.SDK_INT;
            if (i2 >= 22 && i2 <= 27 && Color.alpha(colorStateList.getDefaultColor()) == 0 && Color.alpha(colorStateList.getColorForState(f4843k, 0)) != 0) {
                Log.w(f4844l, "Use a non-transparent color for the default color as it will be used to finish ripple animations.");
            }
            return colorStateList;
        }
        return ColorStateList.valueOf(0);
    }

    public static boolean b(int[] iArr) {
        boolean z2 = false;
        boolean z3 = false;
        for (int i2 : iArr) {
            if (i2 == 16842910) {
                z2 = true;
            } else if (i2 == 16842908 || i2 == 16842919 || i2 == 16843623) {
                z3 = true;
            }
        }
        return z2 && z3;
    }
}
