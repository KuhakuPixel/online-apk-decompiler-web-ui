package q;
/* loaded from: classes.dex */
public interface d {
    void a(d dVar);
}
