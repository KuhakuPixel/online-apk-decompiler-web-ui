package b1;

import android.animation.Animator;
import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
/* loaded from: classes.dex */
public class i {

    /* renamed from: a  reason: collision with root package name */
    private long f3041a;

    /* renamed from: b  reason: collision with root package name */
    private long f3042b;

    /* renamed from: c  reason: collision with root package name */
    private TimeInterpolator f3043c;

    /* renamed from: d  reason: collision with root package name */
    private int f3044d;

    /* renamed from: e  reason: collision with root package name */
    private int f3045e;

    public i(long j2, long j3) {
        this.f3043c = null;
        this.f3044d = 0;
        this.f3045e = 1;
        this.f3041a = j2;
        this.f3042b = j3;
    }

    public i(long j2, long j3, TimeInterpolator timeInterpolator) {
        this.f3044d = 0;
        this.f3045e = 1;
        this.f3041a = j2;
        this.f3042b = j3;
        this.f3043c = timeInterpolator;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static i b(ValueAnimator valueAnimator) {
        i iVar = new i(valueAnimator.getStartDelay(), valueAnimator.getDuration(), f(valueAnimator));
        iVar.f3044d = valueAnimator.getRepeatCount();
        iVar.f3045e = valueAnimator.getRepeatMode();
        return iVar;
    }

    private static TimeInterpolator f(ValueAnimator valueAnimator) {
        TimeInterpolator interpolator = valueAnimator.getInterpolator();
        return ((interpolator instanceof AccelerateDecelerateInterpolator) || interpolator == null) ? a.f3027b : interpolator instanceof AccelerateInterpolator ? a.f3028c : interpolator instanceof DecelerateInterpolator ? a.f3029d : interpolator;
    }

    public void a(Animator animator) {
        animator.setStartDelay(c());
        animator.setDuration(d());
        animator.setInterpolator(e());
        if (animator instanceof ValueAnimator) {
            ValueAnimator valueAnimator = (ValueAnimator) animator;
            valueAnimator.setRepeatCount(g());
            valueAnimator.setRepeatMode(h());
        }
    }

    public long c() {
        return this.f3041a;
    }

    public long d() {
        return this.f3042b;
    }

    public TimeInterpolator e() {
        TimeInterpolator timeInterpolator = this.f3043c;
        return timeInterpolator != null ? timeInterpolator : a.f3027b;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof i) {
            i iVar = (i) obj;
            if (c() == iVar.c() && d() == iVar.d() && g() == iVar.g() && h() == iVar.h()) {
                return e().getClass().equals(iVar.e().getClass());
            }
            return false;
        }
        return false;
    }

    public int g() {
        return this.f3044d;
    }

    public int h() {
        return this.f3045e;
    }

    public int hashCode() {
        return (((((((((int) (c() ^ (c() >>> 32))) * 31) + ((int) (d() ^ (d() >>> 32)))) * 31) + e().getClass().hashCode()) * 31) + g()) * 31) + h();
    }

    public String toString() {
        return '\n' + getClass().getName() + '{' + Integer.toHexString(System.identityHashCode(this)) + " delay: " + c() + " duration: " + d() + " interpolator: " + e().getClass() + " repeatCount: " + g() + " repeatMode: " + h() + "}\n";
    }
}
