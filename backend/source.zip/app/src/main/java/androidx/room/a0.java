package androidx.room;

import java.util.ArrayList;
import java.util.List;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes.dex */
public final class a0 implements u0.d {

    /* renamed from: b  reason: collision with root package name */
    private List<Object> f2508b = new ArrayList();

    private void v(int i2, Object obj) {
        int i3 = i2 - 1;
        if (i3 >= this.f2508b.size()) {
            for (int size = this.f2508b.size(); size <= i3; size++) {
                this.f2508b.add(null);
            }
        }
        this.f2508b.set(i3, obj);
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public void close() {
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public List<Object> e() {
        return this.f2508b;
    }

    @Override // u0.d
    public void h(int i2, String str) {
        v(i2, str);
    }

    @Override // u0.d
    public void i(int i2, long j2) {
        v(i2, Long.valueOf(j2));
    }

    @Override // u0.d
    public void o(int i2, byte[] bArr) {
        v(i2, bArr);
    }

    @Override // u0.d
    public void p(int i2) {
        v(i2, null);
    }

    @Override // u0.d
    public void q(int i2, double d2) {
        v(i2, Double.valueOf(d2));
    }
}
