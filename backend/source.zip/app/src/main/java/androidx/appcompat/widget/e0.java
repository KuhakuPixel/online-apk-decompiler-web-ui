package androidx.appcompat.widget;

import android.graphics.Rect;
/* loaded from: classes.dex */
public interface e0 {
    void a(Rect rect);
}
