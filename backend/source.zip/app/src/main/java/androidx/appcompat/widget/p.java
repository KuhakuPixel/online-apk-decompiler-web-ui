package androidx.appcompat.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.PopupWindow;
/* loaded from: classes.dex */
class p extends PopupWindow {

    /* renamed from: b  reason: collision with root package name */
    private static final boolean f892b = false;

    /* renamed from: a  reason: collision with root package name */
    private boolean f893a;

    public p(Context context, AttributeSet attributeSet, int i2, int i3) {
        super(context, attributeSet, i2, i3);
        a(context, attributeSet, i2, i3);
    }

    private void a(Context context, AttributeSet attributeSet, int i2, int i3) {
        t0 v2 = t0.v(context, attributeSet, a.j.j2, i2, i3);
        int i4 = a.j.l2;
        if (v2.s(i4)) {
            b(v2.a(i4, false));
        }
        setBackgroundDrawable(v2.g(a.j.k2));
        v2.w();
    }

    private void b(boolean z2) {
        if (f892b) {
            this.f893a = z2;
        } else {
            androidx.core.widget.h.a(this, z2);
        }
    }

    @Override // android.widget.PopupWindow
    public void showAsDropDown(View view, int i2, int i3) {
        if (f892b && this.f893a) {
            i3 -= view.getHeight();
        }
        super.showAsDropDown(view, i2, i3);
    }

    @Override // android.widget.PopupWindow
    public void showAsDropDown(View view, int i2, int i3, int i4) {
        if (f892b && this.f893a) {
            i3 -= view.getHeight();
        }
        super.showAsDropDown(view, i2, i3, i4);
    }

    @Override // android.widget.PopupWindow
    public void update(View view, int i2, int i3, int i4, int i5) {
        if (f892b && this.f893a) {
            i3 -= view.getHeight();
        }
        super.update(view, i2, i3, i4, i5);
    }
}
