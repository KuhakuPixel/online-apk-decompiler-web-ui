package a1;
/* loaded from: classes.dex */
public final class e {

    /* renamed from: a */
    public static final int design_password_eye = 2131230827;

    /* renamed from: b */
    public static final int material_ic_calendar_black_24dp = 2131230845;

    /* renamed from: c */
    public static final int material_ic_edit_black_24dp = 2131230847;

    /* renamed from: d */
    public static final int mtrl_dropdown_arrow = 2131230855;

    /* renamed from: e */
    public static final int mtrl_ic_arrow_drop_down = 2131230856;

    /* renamed from: f */
    public static final int mtrl_ic_cancel = 2131230858;

    /* renamed from: g */
    public static final int navigation_empty_icon = 2131230863;
}
