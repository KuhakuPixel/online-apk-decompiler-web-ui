package q;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes.dex */
public class j extends p {
    public j(p.e eVar) {
        super(eVar);
        eVar.f4895e.f();
        eVar.f4897f.f();
        this.f5063f = ((p.g) eVar).b1();
    }

    private void q(f fVar) {
        this.f5065h.f5017k.add(fVar);
        fVar.f5018l.add(this.f5065h);
    }

    @Override // q.p, q.d
    public void a(d dVar) {
        f fVar = this.f5065h;
        if (fVar.f5009c && !fVar.f5016j) {
            this.f5065h.d((int) ((fVar.f5018l.get(0).f5013g * ((p.g) this.f5059b).e1()) + 0.5f));
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    @Override // q.p
    public void d() {
        f fVar;
        p pVar;
        f fVar2;
        p.g gVar = (p.g) this.f5059b;
        int c12 = gVar.c1();
        int d12 = gVar.d1();
        gVar.e1();
        if (gVar.b1() == 1) {
            f fVar3 = this.f5065h;
            if (c12 != -1) {
                fVar3.f5018l.add(this.f5059b.T.f4895e.f5065h);
                this.f5059b.T.f4895e.f5065h.f5017k.add(this.f5065h);
                fVar2 = this.f5065h;
            } else if (d12 != -1) {
                fVar3.f5018l.add(this.f5059b.T.f4895e.f5066i);
                this.f5059b.T.f4895e.f5066i.f5017k.add(this.f5065h);
                fVar2 = this.f5065h;
                c12 = -d12;
            } else {
                fVar3.f5008b = true;
                fVar3.f5018l.add(this.f5059b.T.f4895e.f5066i);
                this.f5059b.T.f4895e.f5066i.f5017k.add(this.f5065h);
                q(this.f5059b.f4895e.f5065h);
                pVar = this.f5059b.f4895e;
            }
            fVar2.f5012f = c12;
            q(this.f5059b.f4895e.f5065h);
            pVar = this.f5059b.f4895e;
        } else {
            f fVar4 = this.f5065h;
            if (c12 != -1) {
                fVar4.f5018l.add(this.f5059b.T.f4897f.f5065h);
                this.f5059b.T.f4897f.f5065h.f5017k.add(this.f5065h);
                fVar = this.f5065h;
            } else if (d12 != -1) {
                fVar4.f5018l.add(this.f5059b.T.f4897f.f5066i);
                this.f5059b.T.f4897f.f5066i.f5017k.add(this.f5065h);
                fVar = this.f5065h;
                c12 = -d12;
            } else {
                fVar4.f5008b = true;
                fVar4.f5018l.add(this.f5059b.T.f4897f.f5066i);
                this.f5059b.T.f4897f.f5066i.f5017k.add(this.f5065h);
                q(this.f5059b.f4897f.f5065h);
                pVar = this.f5059b.f4897f;
            }
            fVar.f5012f = c12;
            q(this.f5059b.f4897f.f5065h);
            pVar = this.f5059b.f4897f;
        }
        q(pVar.f5066i);
    }

    @Override // q.p
    public void e() {
        if (((p.g) this.f5059b).b1() == 1) {
            this.f5059b.V0(this.f5065h.f5013g);
        } else {
            this.f5059b.W0(this.f5065h.f5013g);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    @Override // q.p
    public void f() {
        this.f5065h.c();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    @Override // q.p
    public boolean m() {
        return false;
    }
}
