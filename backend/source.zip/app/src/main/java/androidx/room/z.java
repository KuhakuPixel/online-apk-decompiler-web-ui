package androidx.room;

import androidx.room.e0;
import java.util.concurrent.Executor;
import u0.c;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes.dex */
public final class z implements c.InterfaceC0072c {

    /* renamed from: a  reason: collision with root package name */
    private final c.InterfaceC0072c f2699a;

    /* renamed from: b  reason: collision with root package name */
    private final e0.f f2700b;

    /* renamed from: c  reason: collision with root package name */
    private final Executor f2701c;

    /* JADX INFO: Access modifiers changed from: package-private */
    public z(c.InterfaceC0072c interfaceC0072c, e0.f fVar, Executor executor) {
        this.f2699a = interfaceC0072c;
        this.f2700b = fVar;
        this.f2701c = executor;
    }

    @Override // u0.c.InterfaceC0072c
    public u0.c a(c.b bVar) {
        return new y(this.f2699a.a(bVar), this.f2700b, this.f2701c);
    }
}
