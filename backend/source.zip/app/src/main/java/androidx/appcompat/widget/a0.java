package androidx.appcompat.widget;

import android.view.Menu;
import android.view.Window;
import androidx.appcompat.view.menu.j;
/* loaded from: classes.dex */
public interface a0 {
    void a(Menu menu, j.a aVar);

    boolean b();

    boolean c();

    boolean d();

    boolean e();

    void f();

    boolean g();

    void k(int i2);

    void l();

    void setWindowCallback(Window.Callback callback);

    void setWindowTitle(CharSequence charSequence);
}
