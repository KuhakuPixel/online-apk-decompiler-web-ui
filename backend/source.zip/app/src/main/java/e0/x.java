package e0;

import android.view.View;
/* loaded from: classes.dex */
public interface x {
    void a(View view);
}
