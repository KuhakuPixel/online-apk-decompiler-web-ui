package androidx.appcompat.widget;
/* loaded from: classes.dex */
class l0 {

    /* renamed from: a  reason: collision with root package name */
    private int f826a = 0;

    /* renamed from: b  reason: collision with root package name */
    private int f827b = 0;

    /* renamed from: c  reason: collision with root package name */
    private int f828c = Integer.MIN_VALUE;

    /* renamed from: d  reason: collision with root package name */
    private int f829d = Integer.MIN_VALUE;

    /* renamed from: e  reason: collision with root package name */
    private int f830e = 0;

    /* renamed from: f  reason: collision with root package name */
    private int f831f = 0;

    /* renamed from: g  reason: collision with root package name */
    private boolean f832g = false;

    /* renamed from: h  reason: collision with root package name */
    private boolean f833h = false;

    public int a() {
        return this.f832g ? this.f826a : this.f827b;
    }

    public int b() {
        return this.f826a;
    }

    public int c() {
        return this.f827b;
    }

    public int d() {
        return this.f832g ? this.f827b : this.f826a;
    }

    public void e(int i2, int i3) {
        this.f833h = false;
        if (i2 != Integer.MIN_VALUE) {
            this.f830e = i2;
            this.f826a = i2;
        }
        if (i3 != Integer.MIN_VALUE) {
            this.f831f = i3;
            this.f827b = i3;
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:14:0x001a, code lost:
        if (r2 != Integer.MIN_VALUE) goto L25;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x0028, code lost:
        if (r2 != Integer.MIN_VALUE) goto L25;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void f(boolean r2) {
        /*
            r1 = this;
            boolean r0 = r1.f832g
            if (r2 != r0) goto L5
            return
        L5:
            r1.f832g = r2
            boolean r0 = r1.f833h
            if (r0 == 0) goto L2b
            r0 = -2147483648(0xffffffff80000000, float:-0.0)
            if (r2 == 0) goto L1d
            int r2 = r1.f829d
            if (r2 == r0) goto L14
            goto L16
        L14:
            int r2 = r1.f830e
        L16:
            r1.f826a = r2
            int r2 = r1.f828c
            if (r2 == r0) goto L2f
            goto L31
        L1d:
            int r2 = r1.f828c
            if (r2 == r0) goto L22
            goto L24
        L22:
            int r2 = r1.f830e
        L24:
            r1.f826a = r2
            int r2 = r1.f829d
            if (r2 == r0) goto L2f
            goto L31
        L2b:
            int r2 = r1.f830e
            r1.f826a = r2
        L2f:
            int r2 = r1.f831f
        L31:
            r1.f827b = r2
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.l0.f(boolean):void");
    }

    public void g(int i2, int i3) {
        this.f828c = i2;
        this.f829d = i3;
        this.f833h = true;
        if (this.f832g) {
            if (i3 != Integer.MIN_VALUE) {
                this.f826a = i3;
            }
            if (i2 != Integer.MIN_VALUE) {
                this.f827b = i2;
                return;
            }
            return;
        }
        if (i2 != Integer.MIN_VALUE) {
            this.f826a = i2;
        }
        if (i3 != Integer.MIN_VALUE) {
            this.f827b = i3;
        }
    }
}
