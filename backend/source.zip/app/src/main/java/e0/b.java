package e0;

import android.content.Context;
import android.util.Log;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
/* loaded from: classes.dex */
public abstract class b {

    /* renamed from: a  reason: collision with root package name */
    private final Context f4284a;

    /* renamed from: b  reason: collision with root package name */
    private a f4285b;

    /* renamed from: c  reason: collision with root package name */
    private InterfaceC0052b f4286c;

    /* loaded from: classes.dex */
    public interface a {
    }

    /* renamed from: e0.b$b  reason: collision with other inner class name */
    /* loaded from: classes.dex */
    public interface InterfaceC0052b {
        void onActionProviderVisibilityChanged(boolean z2);
    }

    public b(Context context) {
        this.f4284a = context;
    }

    public boolean a() {
        return false;
    }

    public boolean b() {
        return true;
    }

    public abstract View c();

    public View d(MenuItem menuItem) {
        return c();
    }

    public boolean e() {
        return false;
    }

    public void f(SubMenu subMenu) {
    }

    public boolean g() {
        return false;
    }

    public void h() {
        this.f4286c = null;
        this.f4285b = null;
    }

    public void i(a aVar) {
        this.f4285b = aVar;
    }

    public void j(InterfaceC0052b interfaceC0052b) {
        if (this.f4286c != null && interfaceC0052b != null) {
            Log.w("ActionProvider(support)", "setVisibilityListener: Setting a new ActionProvider.VisibilityListener when one is already set. Are you reusing this " + getClass().getSimpleName() + " instance while it is still in use somewhere else?");
        }
        this.f4286c = interfaceC0052b;
    }
}
