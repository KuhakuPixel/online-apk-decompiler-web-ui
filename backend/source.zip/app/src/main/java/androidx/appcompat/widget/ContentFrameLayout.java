package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.widget.FrameLayout;
/* loaded from: classes.dex */
public class ContentFrameLayout extends FrameLayout {

    /* renamed from: b  reason: collision with root package name */
    private TypedValue f559b;

    /* renamed from: c  reason: collision with root package name */
    private TypedValue f560c;

    /* renamed from: d  reason: collision with root package name */
    private TypedValue f561d;

    /* renamed from: e  reason: collision with root package name */
    private TypedValue f562e;

    /* renamed from: f  reason: collision with root package name */
    private TypedValue f563f;

    /* renamed from: g  reason: collision with root package name */
    private TypedValue f564g;

    /* renamed from: h  reason: collision with root package name */
    private final Rect f565h;

    /* renamed from: i  reason: collision with root package name */
    private a f566i;

    /* loaded from: classes.dex */
    public interface a {
        void a();

        void onDetachedFromWindow();
    }

    public ContentFrameLayout(Context context) {
        this(context, null);
    }

    public ContentFrameLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public ContentFrameLayout(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.f565h = new Rect();
    }

    public void a(int i2, int i3, int i4, int i5) {
        this.f565h.set(i2, i3, i4, i5);
        if (e0.q.Q(this)) {
            requestLayout();
        }
    }

    public TypedValue getFixedHeightMajor() {
        if (this.f563f == null) {
            this.f563f = new TypedValue();
        }
        return this.f563f;
    }

    public TypedValue getFixedHeightMinor() {
        if (this.f564g == null) {
            this.f564g = new TypedValue();
        }
        return this.f564g;
    }

    public TypedValue getFixedWidthMajor() {
        if (this.f561d == null) {
            this.f561d = new TypedValue();
        }
        return this.f561d;
    }

    public TypedValue getFixedWidthMinor() {
        if (this.f562e == null) {
            this.f562e = new TypedValue();
        }
        return this.f562e;
    }

    public TypedValue getMinWidthMajor() {
        if (this.f559b == null) {
            this.f559b = new TypedValue();
        }
        return this.f559b;
    }

    public TypedValue getMinWidthMinor() {
        if (this.f560c == null) {
            this.f560c = new TypedValue();
        }
        return this.f560c;
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        a aVar = this.f566i;
        if (aVar != null) {
            aVar.a();
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        a aVar = this.f566i;
        if (aVar != null) {
            aVar.onDetachedFromWindow();
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:21:0x004a  */
    /* JADX WARN: Removed duplicated region for block: B:24:0x0063  */
    /* JADX WARN: Removed duplicated region for block: B:37:0x0086  */
    /* JADX WARN: Removed duplicated region for block: B:42:0x00ab  */
    /* JADX WARN: Removed duplicated region for block: B:43:0x00ae  */
    /* JADX WARN: Removed duplicated region for block: B:48:0x00b8  */
    /* JADX WARN: Removed duplicated region for block: B:50:0x00be  */
    /* JADX WARN: Removed duplicated region for block: B:54:0x00cc  */
    /* JADX WARN: Removed duplicated region for block: B:56:0x00d6  */
    /* JADX WARN: Removed duplicated region for block: B:59:0x00de  */
    /* JADX WARN: Removed duplicated region for block: B:61:? A[RETURN, SYNTHETIC] */
    @Override // android.widget.FrameLayout, android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    protected void onMeasure(int r14, int r15) {
        /*
            Method dump skipped, instructions count: 226
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.ContentFrameLayout.onMeasure(int, int):void");
    }

    public void setAttachListener(a aVar) {
        this.f566i = aVar;
    }
}
