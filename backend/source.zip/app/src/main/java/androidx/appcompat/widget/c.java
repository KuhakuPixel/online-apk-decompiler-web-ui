package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.util.SparseBooleanArray;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import androidx.appcompat.view.menu.ActionMenuItemView;
import androidx.appcompat.view.menu.j;
import androidx.appcompat.view.menu.k;
import androidx.appcompat.widget.ActionMenuView;
import e0.b;
import java.util.ArrayList;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes.dex */
public class c extends androidx.appcompat.view.menu.a implements b.a {
    a A;
    RunnableC0004c B;
    private b C;
    final f D;
    int E;

    /* renamed from: l  reason: collision with root package name */
    d f690l;

    /* renamed from: m  reason: collision with root package name */
    private Drawable f691m;

    /* renamed from: n  reason: collision with root package name */
    private boolean f692n;

    /* renamed from: o  reason: collision with root package name */
    private boolean f693o;

    /* renamed from: p  reason: collision with root package name */
    private boolean f694p;

    /* renamed from: q  reason: collision with root package name */
    private int f695q;

    /* renamed from: r  reason: collision with root package name */
    private int f696r;

    /* renamed from: s  reason: collision with root package name */
    private int f697s;

    /* renamed from: t  reason: collision with root package name */
    private boolean f698t;

    /* renamed from: u  reason: collision with root package name */
    private boolean f699u;

    /* renamed from: v  reason: collision with root package name */
    private boolean f700v;

    /* renamed from: w  reason: collision with root package name */
    private boolean f701w;

    /* renamed from: x  reason: collision with root package name */
    private int f702x;

    /* renamed from: y  reason: collision with root package name */
    private final SparseBooleanArray f703y;

    /* renamed from: z  reason: collision with root package name */
    e f704z;

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public class a extends androidx.appcompat.view.menu.i {
        public a(Context context, androidx.appcompat.view.menu.m mVar, View view) {
            super(context, mVar, view, false, a.a.actionOverflowMenuStyle);
            if (!((androidx.appcompat.view.menu.g) mVar.getItem()).l()) {
                View view2 = c.this.f690l;
                f(view2 == null ? (View) ((androidx.appcompat.view.menu.a) c.this).f334j : view2);
            }
            j(c.this.D);
        }

        @Override // androidx.appcompat.view.menu.i
        protected void e() {
            c cVar = c.this;
            cVar.A = null;
            cVar.E = 0;
            super.e();
        }
    }

    /* loaded from: classes.dex */
    private class b extends ActionMenuItemView.b {
        b() {
        }

        @Override // androidx.appcompat.view.menu.ActionMenuItemView.b
        public g.e a() {
            a aVar = c.this.A;
            if (aVar != null) {
                return aVar.c();
            }
            return null;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* renamed from: androidx.appcompat.widget.c$c  reason: collision with other inner class name */
    /* loaded from: classes.dex */
    public class RunnableC0004c implements Runnable {

        /* renamed from: b  reason: collision with root package name */
        private e f707b;

        public RunnableC0004c(e eVar) {
            this.f707b = eVar;
        }

        @Override // java.lang.Runnable
        public void run() {
            if (((androidx.appcompat.view.menu.a) c.this).f328d != null) {
                ((androidx.appcompat.view.menu.a) c.this).f328d.d();
            }
            View view = (View) ((androidx.appcompat.view.menu.a) c.this).f334j;
            if (view != null && view.getWindowToken() != null && this.f707b.m()) {
                c.this.f704z = this.f707b;
            }
            c.this.B = null;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public class d extends AppCompatImageView implements ActionMenuView.a {

        /* loaded from: classes.dex */
        class a extends f0 {

            /* renamed from: k  reason: collision with root package name */
            final /* synthetic */ c f710k;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            a(View view, c cVar) {
                super(view);
                this.f710k = cVar;
            }

            @Override // androidx.appcompat.widget.f0
            public g.e b() {
                e eVar = c.this.f704z;
                if (eVar == null) {
                    return null;
                }
                return eVar.c();
            }

            @Override // androidx.appcompat.widget.f0
            public boolean c() {
                c.this.K();
                return true;
            }

            @Override // androidx.appcompat.widget.f0
            public boolean d() {
                c cVar = c.this;
                if (cVar.B != null) {
                    return false;
                }
                cVar.B();
                return true;
            }
        }

        public d(Context context) {
            super(context, null, a.a.actionOverflowButtonStyle);
            setClickable(true);
            setFocusable(true);
            setVisibility(0);
            setEnabled(true);
            v0.a(this, getContentDescription());
            setOnTouchListener(new a(this, c.this));
        }

        @Override // androidx.appcompat.widget.ActionMenuView.a
        public boolean a() {
            return false;
        }

        @Override // androidx.appcompat.widget.ActionMenuView.a
        public boolean b() {
            return false;
        }

        @Override // android.view.View
        public boolean performClick() {
            if (super.performClick()) {
                return true;
            }
            playSoundEffect(0);
            c.this.K();
            return true;
        }

        @Override // android.widget.ImageView
        protected boolean setFrame(int i2, int i3, int i4, int i5) {
            boolean frame = super.setFrame(i2, i3, i4, i5);
            Drawable drawable = getDrawable();
            Drawable background = getBackground();
            if (drawable != null && background != null) {
                int width = getWidth();
                int height = getHeight();
                int max = Math.max(width, height) / 2;
                int paddingLeft = (width + (getPaddingLeft() - getPaddingRight())) / 2;
                int paddingTop = (height + (getPaddingTop() - getPaddingBottom())) / 2;
                x.a.l(background, paddingLeft - max, paddingTop - max, paddingLeft + max, paddingTop + max);
            }
            return frame;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public class e extends androidx.appcompat.view.menu.i {
        public e(Context context, androidx.appcompat.view.menu.e eVar, View view, boolean z2) {
            super(context, eVar, view, z2, a.a.actionOverflowMenuStyle);
            h(8388613);
            j(c.this.D);
        }

        @Override // androidx.appcompat.view.menu.i
        protected void e() {
            if (((androidx.appcompat.view.menu.a) c.this).f328d != null) {
                ((androidx.appcompat.view.menu.a) c.this).f328d.close();
            }
            c.this.f704z = null;
            super.e();
        }
    }

    /* loaded from: classes.dex */
    private class f implements j.a {
        f() {
        }

        @Override // androidx.appcompat.view.menu.j.a
        public void b(androidx.appcompat.view.menu.e eVar, boolean z2) {
            if (eVar instanceof androidx.appcompat.view.menu.m) {
                eVar.D().e(false);
            }
            j.a m2 = c.this.m();
            if (m2 != null) {
                m2.b(eVar, z2);
            }
        }

        @Override // androidx.appcompat.view.menu.j.a
        public boolean c(androidx.appcompat.view.menu.e eVar) {
            if (eVar == ((androidx.appcompat.view.menu.a) c.this).f328d) {
                return false;
            }
            c.this.E = ((androidx.appcompat.view.menu.m) eVar).getItem().getItemId();
            j.a m2 = c.this.m();
            if (m2 != null) {
                return m2.c(eVar);
            }
            return false;
        }
    }

    public c(Context context) {
        super(context, a.g.abc_action_menu_layout, a.g.abc_action_menu_item_layout);
        this.f703y = new SparseBooleanArray();
        this.D = new f();
    }

    private View z(MenuItem menuItem) {
        ViewGroup viewGroup = (ViewGroup) this.f334j;
        if (viewGroup == null) {
            return null;
        }
        int childCount = viewGroup.getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = viewGroup.getChildAt(i2);
            if ((childAt instanceof k.a) && ((k.a) childAt).getItemData() == menuItem) {
                return childAt;
            }
        }
        return null;
    }

    public Drawable A() {
        d dVar = this.f690l;
        if (dVar != null) {
            return dVar.getDrawable();
        }
        if (this.f692n) {
            return this.f691m;
        }
        return null;
    }

    public boolean B() {
        androidx.appcompat.view.menu.k kVar;
        RunnableC0004c runnableC0004c = this.B;
        if (runnableC0004c != null && (kVar = this.f334j) != null) {
            ((View) kVar).removeCallbacks(runnableC0004c);
            this.B = null;
            return true;
        }
        e eVar = this.f704z;
        if (eVar != null) {
            eVar.b();
            return true;
        }
        return false;
    }

    public boolean C() {
        a aVar = this.A;
        if (aVar != null) {
            aVar.b();
            return true;
        }
        return false;
    }

    public boolean D() {
        return this.B != null || E();
    }

    public boolean E() {
        e eVar = this.f704z;
        return eVar != null && eVar.d();
    }

    public void F(Configuration configuration) {
        if (!this.f698t) {
            this.f697s = f.a.b(this.f327c).d();
        }
        androidx.appcompat.view.menu.e eVar = this.f328d;
        if (eVar != null) {
            eVar.K(true);
        }
    }

    public void G(boolean z2) {
        this.f701w = z2;
    }

    public void H(ActionMenuView actionMenuView) {
        this.f334j = actionMenuView;
        actionMenuView.b(this.f328d);
    }

    public void I(Drawable drawable) {
        d dVar = this.f690l;
        if (dVar != null) {
            dVar.setImageDrawable(drawable);
            return;
        }
        this.f692n = true;
        this.f691m = drawable;
    }

    public void J(boolean z2) {
        this.f693o = z2;
        this.f694p = true;
    }

    public boolean K() {
        androidx.appcompat.view.menu.e eVar;
        if (!this.f693o || E() || (eVar = this.f328d) == null || this.f334j == null || this.B != null || eVar.z().isEmpty()) {
            return false;
        }
        RunnableC0004c runnableC0004c = new RunnableC0004c(new e(this.f327c, this.f328d, this.f690l, true));
        this.B = runnableC0004c;
        ((View) this.f334j).post(runnableC0004c);
        return true;
    }

    @Override // androidx.appcompat.view.menu.a, androidx.appcompat.view.menu.j
    public void b(androidx.appcompat.view.menu.e eVar, boolean z2) {
        y();
        super.b(eVar, z2);
    }

    @Override // androidx.appcompat.view.menu.a
    public void c(androidx.appcompat.view.menu.g gVar, k.a aVar) {
        aVar.e(gVar, 0);
        ActionMenuItemView actionMenuItemView = (ActionMenuItemView) aVar;
        actionMenuItemView.setItemInvoker((ActionMenuView) this.f334j);
        if (this.C == null) {
            this.C = new b();
        }
        actionMenuItemView.setPopupCallback(this.C);
    }

    @Override // androidx.appcompat.view.menu.j
    public boolean d() {
        ArrayList<androidx.appcompat.view.menu.g> arrayList;
        int i2;
        int i3;
        int i4;
        int i5;
        c cVar = this;
        androidx.appcompat.view.menu.e eVar = cVar.f328d;
        View view = null;
        int i6 = 0;
        if (eVar != null) {
            arrayList = eVar.E();
            i2 = arrayList.size();
        } else {
            arrayList = null;
            i2 = 0;
        }
        int i7 = cVar.f697s;
        int i8 = cVar.f696r;
        int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
        ViewGroup viewGroup = (ViewGroup) cVar.f334j;
        boolean z2 = false;
        int i9 = 0;
        int i10 = 0;
        for (int i11 = 0; i11 < i2; i11++) {
            androidx.appcompat.view.menu.g gVar = arrayList.get(i11);
            if (gVar.o()) {
                i9++;
            } else if (gVar.n()) {
                i10++;
            } else {
                z2 = true;
            }
            if (cVar.f701w && gVar.isActionViewExpanded()) {
                i7 = 0;
            }
        }
        if (cVar.f693o && (z2 || i10 + i9 > i7)) {
            i7--;
        }
        int i12 = i7 - i9;
        SparseBooleanArray sparseBooleanArray = cVar.f703y;
        sparseBooleanArray.clear();
        if (cVar.f699u) {
            int i13 = cVar.f702x;
            i4 = i8 / i13;
            i3 = i13 + ((i8 % i13) / i4);
        } else {
            i3 = 0;
            i4 = 0;
        }
        int i14 = 0;
        int i15 = 0;
        while (i14 < i2) {
            androidx.appcompat.view.menu.g gVar2 = arrayList.get(i14);
            if (gVar2.o()) {
                View n2 = cVar.n(gVar2, view, viewGroup);
                if (cVar.f699u) {
                    i4 -= ActionMenuView.L(n2, i3, i4, makeMeasureSpec, i6);
                } else {
                    n2.measure(makeMeasureSpec, makeMeasureSpec);
                }
                int measuredWidth = n2.getMeasuredWidth();
                i8 -= measuredWidth;
                if (i15 == 0) {
                    i15 = measuredWidth;
                }
                int groupId = gVar2.getGroupId();
                if (groupId != 0) {
                    sparseBooleanArray.put(groupId, true);
                }
                gVar2.u(true);
                i5 = i2;
            } else if (gVar2.n()) {
                int groupId2 = gVar2.getGroupId();
                boolean z3 = sparseBooleanArray.get(groupId2);
                boolean z4 = (i12 > 0 || z3) && i8 > 0 && (!cVar.f699u || i4 > 0);
                boolean z5 = z4;
                i5 = i2;
                if (z4) {
                    View n3 = cVar.n(gVar2, null, viewGroup);
                    if (cVar.f699u) {
                        int L = ActionMenuView.L(n3, i3, i4, makeMeasureSpec, 0);
                        i4 -= L;
                        if (L == 0) {
                            z5 = false;
                        }
                    } else {
                        n3.measure(makeMeasureSpec, makeMeasureSpec);
                    }
                    boolean z6 = z5;
                    int measuredWidth2 = n3.getMeasuredWidth();
                    i8 -= measuredWidth2;
                    if (i15 == 0) {
                        i15 = measuredWidth2;
                    }
                    z4 = z6 & (!cVar.f699u ? i8 + i15 <= 0 : i8 < 0);
                }
                if (z4 && groupId2 != 0) {
                    sparseBooleanArray.put(groupId2, true);
                } else if (z3) {
                    sparseBooleanArray.put(groupId2, false);
                    for (int i16 = 0; i16 < i14; i16++) {
                        androidx.appcompat.view.menu.g gVar3 = arrayList.get(i16);
                        if (gVar3.getGroupId() == groupId2) {
                            if (gVar3.l()) {
                                i12++;
                            }
                            gVar3.u(false);
                        }
                    }
                }
                if (z4) {
                    i12--;
                }
                gVar2.u(z4);
            } else {
                i5 = i2;
                gVar2.u(false);
                i14++;
                view = null;
                cVar = this;
                i2 = i5;
                i6 = 0;
            }
            i14++;
            view = null;
            cVar = this;
            i2 = i5;
            i6 = 0;
        }
        return true;
    }

    @Override // androidx.appcompat.view.menu.a, androidx.appcompat.view.menu.j
    public void e(Context context, androidx.appcompat.view.menu.e eVar) {
        super.e(context, eVar);
        Resources resources = context.getResources();
        f.a b2 = f.a.b(context);
        if (!this.f694p) {
            this.f693o = b2.h();
        }
        if (!this.f700v) {
            this.f695q = b2.c();
        }
        if (!this.f698t) {
            this.f697s = b2.d();
        }
        int i2 = this.f695q;
        if (this.f693o) {
            if (this.f690l == null) {
                d dVar = new d(this.f326b);
                this.f690l = dVar;
                if (this.f692n) {
                    dVar.setImageDrawable(this.f691m);
                    this.f691m = null;
                    this.f692n = false;
                }
                int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
                this.f690l.measure(makeMeasureSpec, makeMeasureSpec);
            }
            i2 -= this.f690l.getMeasuredWidth();
        } else {
            this.f690l = null;
        }
        this.f696r = i2;
        this.f702x = (int) (resources.getDisplayMetrics().density * 56.0f);
    }

    @Override // androidx.appcompat.view.menu.a, androidx.appcompat.view.menu.j
    public boolean i(androidx.appcompat.view.menu.m mVar) {
        boolean z2 = false;
        if (mVar.hasVisibleItems()) {
            androidx.appcompat.view.menu.m mVar2 = mVar;
            while (mVar2.e0() != this.f328d) {
                mVar2 = (androidx.appcompat.view.menu.m) mVar2.e0();
            }
            View z3 = z(mVar2.getItem());
            if (z3 == null) {
                return false;
            }
            this.E = mVar.getItem().getItemId();
            int size = mVar.size();
            int i2 = 0;
            while (true) {
                if (i2 >= size) {
                    break;
                }
                MenuItem item = mVar.getItem(i2);
                if (item.isVisible() && item.getIcon() != null) {
                    z2 = true;
                    break;
                }
                i2++;
            }
            a aVar = new a(this.f327c, mVar, z3);
            this.A = aVar;
            aVar.g(z2);
            this.A.k();
            super.i(mVar);
            return true;
        }
        return false;
    }

    @Override // androidx.appcompat.view.menu.a, androidx.appcompat.view.menu.j
    public void j(boolean z2) {
        super.j(z2);
        ((View) this.f334j).requestLayout();
        androidx.appcompat.view.menu.e eVar = this.f328d;
        boolean z3 = false;
        if (eVar != null) {
            ArrayList<androidx.appcompat.view.menu.g> s2 = eVar.s();
            int size = s2.size();
            for (int i2 = 0; i2 < size; i2++) {
                e0.b b2 = s2.get(i2).b();
                if (b2 != null) {
                    b2.i(this);
                }
            }
        }
        androidx.appcompat.view.menu.e eVar2 = this.f328d;
        ArrayList<androidx.appcompat.view.menu.g> z4 = eVar2 != null ? eVar2.z() : null;
        if (this.f693o && z4 != null) {
            int size2 = z4.size();
            if (size2 == 1) {
                z3 = !z4.get(0).isActionViewExpanded();
            } else if (size2 > 0) {
                z3 = true;
            }
        }
        d dVar = this.f690l;
        if (z3) {
            if (dVar == null) {
                this.f690l = new d(this.f326b);
            }
            ViewGroup viewGroup = (ViewGroup) this.f690l.getParent();
            if (viewGroup != this.f334j) {
                if (viewGroup != null) {
                    viewGroup.removeView(this.f690l);
                }
                ActionMenuView actionMenuView = (ActionMenuView) this.f334j;
                actionMenuView.addView(this.f690l, actionMenuView.F());
            }
        } else if (dVar != null) {
            ViewParent parent = dVar.getParent();
            androidx.appcompat.view.menu.k kVar = this.f334j;
            if (parent == kVar) {
                ((ViewGroup) kVar).removeView(this.f690l);
            }
        }
        ((ActionMenuView) this.f334j).setOverflowReserved(this.f693o);
    }

    @Override // androidx.appcompat.view.menu.a
    public boolean l(ViewGroup viewGroup, int i2) {
        if (viewGroup.getChildAt(i2) == this.f690l) {
            return false;
        }
        return super.l(viewGroup, i2);
    }

    @Override // androidx.appcompat.view.menu.a
    public View n(androidx.appcompat.view.menu.g gVar, View view, ViewGroup viewGroup) {
        View actionView = gVar.getActionView();
        if (actionView == null || gVar.j()) {
            actionView = super.n(gVar, view, viewGroup);
        }
        actionView.setVisibility(gVar.isActionViewExpanded() ? 8 : 0);
        ActionMenuView actionMenuView = (ActionMenuView) viewGroup;
        ViewGroup.LayoutParams layoutParams = actionView.getLayoutParams();
        if (!actionMenuView.checkLayoutParams(layoutParams)) {
            actionView.setLayoutParams(actionMenuView.generateLayoutParams(layoutParams));
        }
        return actionView;
    }

    @Override // androidx.appcompat.view.menu.a
    public androidx.appcompat.view.menu.k o(ViewGroup viewGroup) {
        androidx.appcompat.view.menu.k kVar = this.f334j;
        androidx.appcompat.view.menu.k o2 = super.o(viewGroup);
        if (kVar != o2) {
            ((ActionMenuView) o2).setPresenter(this);
        }
        return o2;
    }

    @Override // androidx.appcompat.view.menu.a
    public boolean q(int i2, androidx.appcompat.view.menu.g gVar) {
        return gVar.l();
    }

    public boolean y() {
        return B() | C();
    }
}
