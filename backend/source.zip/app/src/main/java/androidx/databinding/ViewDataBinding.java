package androidx.databinding;

import android.annotation.TargetApi;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.util.SparseIntArray;
import android.view.Choreographer;
import android.view.View;
import android.view.ViewGroup;
import androidx.databinding.b;
import androidx.databinding.g;
import androidx.databinding.h;
import androidx.databinding.i;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.d;
import androidx.lifecycle.n;
import androidx.lifecycle.o;
import java.lang.ref.Reference;
import java.lang.ref.ReferenceQueue;
import java.lang.ref.WeakReference;
/* loaded from: classes.dex */
public abstract class ViewDataBinding extends androidx.databinding.a {

    /* renamed from: s  reason: collision with root package name */
    private static final int f1476s = 8;

    /* renamed from: b  reason: collision with root package name */
    private final Runnable f1484b;

    /* renamed from: c  reason: collision with root package name */
    private boolean f1485c;

    /* renamed from: d  reason: collision with root package name */
    private boolean f1486d;

    /* renamed from: e  reason: collision with root package name */
    private androidx.databinding.m[] f1487e;

    /* renamed from: f  reason: collision with root package name */
    private final View f1488f;

    /* renamed from: g  reason: collision with root package name */
    private androidx.databinding.b<androidx.databinding.k, ViewDataBinding, Void> f1489g;

    /* renamed from: h  reason: collision with root package name */
    private boolean f1490h;

    /* renamed from: i  reason: collision with root package name */
    private Choreographer f1491i;

    /* renamed from: j  reason: collision with root package name */
    private final Choreographer.FrameCallback f1492j;

    /* renamed from: k  reason: collision with root package name */
    private Handler f1493k;

    /* renamed from: l  reason: collision with root package name */
    protected final androidx.databinding.e f1494l;

    /* renamed from: m  reason: collision with root package name */
    private ViewDataBinding f1495m;

    /* renamed from: n  reason: collision with root package name */
    private androidx.lifecycle.g f1496n;

    /* renamed from: o  reason: collision with root package name */
    private OnStartListener f1497o;

    /* renamed from: p  reason: collision with root package name */
    private boolean f1498p;

    /* renamed from: q  reason: collision with root package name */
    protected boolean f1499q;

    /* renamed from: r  reason: collision with root package name */
    static int f1475r = Build.VERSION.SDK_INT;

    /* renamed from: t  reason: collision with root package name */
    private static final boolean f1477t = true;

    /* renamed from: u  reason: collision with root package name */
    private static final androidx.databinding.c f1478u = new a();

    /* renamed from: v  reason: collision with root package name */
    private static final androidx.databinding.c f1479v = new b();

    /* renamed from: w  reason: collision with root package name */
    private static final androidx.databinding.c f1480w = new c();

    /* renamed from: x  reason: collision with root package name */
    private static final androidx.databinding.c f1481x = new d();

    /* renamed from: y  reason: collision with root package name */
    private static final b.a<androidx.databinding.k, ViewDataBinding, Void> f1482y = new e();

    /* renamed from: z  reason: collision with root package name */
    private static final ReferenceQueue<ViewDataBinding> f1483z = new ReferenceQueue<>();
    private static final View.OnAttachStateChangeListener A = new f();

    /* loaded from: classes.dex */
    static class OnStartListener implements androidx.lifecycle.f {

        /* renamed from: a  reason: collision with root package name */
        final WeakReference<ViewDataBinding> f1500a;

        private OnStartListener(ViewDataBinding viewDataBinding) {
            this.f1500a = new WeakReference<>(viewDataBinding);
        }

        /* synthetic */ OnStartListener(ViewDataBinding viewDataBinding, a aVar) {
            this(viewDataBinding);
        }

        @o(d.a.ON_START)
        public void onStart() {
            ViewDataBinding viewDataBinding = this.f1500a.get();
            if (viewDataBinding != null) {
                viewDataBinding.n();
            }
        }
    }

    /* loaded from: classes.dex */
    class a implements androidx.databinding.c {
        a() {
        }

        @Override // androidx.databinding.c
        public androidx.databinding.m a(ViewDataBinding viewDataBinding, int i2, ReferenceQueue<ViewDataBinding> referenceQueue) {
            return new m(viewDataBinding, i2, referenceQueue).f();
        }
    }

    /* loaded from: classes.dex */
    class b implements androidx.databinding.c {
        b() {
        }

        @Override // androidx.databinding.c
        public androidx.databinding.m a(ViewDataBinding viewDataBinding, int i2, ReferenceQueue<ViewDataBinding> referenceQueue) {
            return new k(viewDataBinding, i2, referenceQueue).e();
        }
    }

    /* loaded from: classes.dex */
    class c implements androidx.databinding.c {
        c() {
        }

        @Override // androidx.databinding.c
        public androidx.databinding.m a(ViewDataBinding viewDataBinding, int i2, ReferenceQueue<ViewDataBinding> referenceQueue) {
            return new l(viewDataBinding, i2, referenceQueue).e();
        }
    }

    /* loaded from: classes.dex */
    class d implements androidx.databinding.c {
        d() {
        }

        @Override // androidx.databinding.c
        public androidx.databinding.m a(ViewDataBinding viewDataBinding, int i2, ReferenceQueue<ViewDataBinding> referenceQueue) {
            return new j(viewDataBinding, i2, referenceQueue).g();
        }
    }

    /* loaded from: classes.dex */
    class e extends b.a<androidx.databinding.k, ViewDataBinding, Void> {
        e() {
        }

        @Override // androidx.databinding.b.a
        /* renamed from: b  reason: merged with bridge method [inline-methods] */
        public void a(androidx.databinding.k kVar, ViewDataBinding viewDataBinding, int i2, Void r4) {
            if (i2 == 1) {
                if (kVar.c(viewDataBinding)) {
                    return;
                }
                viewDataBinding.f1486d = true;
            } else if (i2 == 2) {
                kVar.b(viewDataBinding);
            } else if (i2 != 3) {
            } else {
                kVar.a(viewDataBinding);
            }
        }
    }

    /* loaded from: classes.dex */
    class f implements View.OnAttachStateChangeListener {
        f() {
        }

        @Override // android.view.View.OnAttachStateChangeListener
        @TargetApi(19)
        public void onViewAttachedToWindow(View view) {
            ViewDataBinding.o(view).f1484b.run();
            view.removeOnAttachStateChangeListener(this);
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewDetachedFromWindow(View view) {
        }
    }

    /* loaded from: classes.dex */
    class g implements Runnable {
        g() {
        }

        @Override // java.lang.Runnable
        public void run() {
            synchronized (this) {
                ViewDataBinding.this.f1485c = false;
            }
            ViewDataBinding.x();
            if (ViewDataBinding.this.f1488f.isAttachedToWindow()) {
                ViewDataBinding.this.n();
                return;
            }
            ViewDataBinding.this.f1488f.removeOnAttachStateChangeListener(ViewDataBinding.A);
            ViewDataBinding.this.f1488f.addOnAttachStateChangeListener(ViewDataBinding.A);
        }
    }

    /* loaded from: classes.dex */
    class h implements Choreographer.FrameCallback {
        h() {
        }

        @Override // android.view.Choreographer.FrameCallback
        public void doFrame(long j2) {
            ViewDataBinding.this.f1484b.run();
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    /* loaded from: classes.dex */
    public static class i {
    }

    /* loaded from: classes.dex */
    private static class j implements n, androidx.databinding.j<LiveData<?>> {

        /* renamed from: a  reason: collision with root package name */
        final androidx.databinding.m<LiveData<?>> f1503a;

        /* renamed from: b  reason: collision with root package name */
        WeakReference<androidx.lifecycle.g> f1504b = null;

        public j(ViewDataBinding viewDataBinding, int i2, ReferenceQueue<ViewDataBinding> referenceQueue) {
            this.f1503a = new androidx.databinding.m<>(viewDataBinding, i2, this, referenceQueue);
        }

        private androidx.lifecycle.g f() {
            WeakReference<androidx.lifecycle.g> weakReference = this.f1504b;
            if (weakReference == null) {
                return null;
            }
            return weakReference.get();
        }

        @Override // androidx.databinding.j
        public void b(androidx.lifecycle.g gVar) {
            androidx.lifecycle.g f2 = f();
            LiveData<?> b2 = this.f1503a.b();
            if (b2 != null) {
                if (f2 != null) {
                    b2.l(this);
                }
                if (gVar != null) {
                    b2.g(gVar, this);
                }
            }
            if (gVar != null) {
                this.f1504b = new WeakReference<>(gVar);
            }
        }

        @Override // androidx.lifecycle.n
        public void c(Object obj) {
            ViewDataBinding a2 = this.f1503a.a();
            if (a2 != null) {
                androidx.databinding.m<LiveData<?>> mVar = this.f1503a;
                a2.q(mVar.f1519b, mVar.b(), 0);
            }
        }

        @Override // androidx.databinding.j
        /* renamed from: e  reason: merged with bridge method [inline-methods] */
        public void a(LiveData<?> liveData) {
            androidx.lifecycle.g f2 = f();
            if (f2 != null) {
                liveData.g(f2, this);
            }
        }

        public androidx.databinding.m<LiveData<?>> g() {
            return this.f1503a;
        }

        @Override // androidx.databinding.j
        /* renamed from: h  reason: merged with bridge method [inline-methods] */
        public void d(LiveData<?> liveData) {
            liveData.l(this);
        }
    }

    /* loaded from: classes.dex */
    private static class k extends h.a implements androidx.databinding.j<androidx.databinding.h> {

        /* renamed from: a  reason: collision with root package name */
        final androidx.databinding.m<androidx.databinding.h> f1505a;

        public k(ViewDataBinding viewDataBinding, int i2, ReferenceQueue<ViewDataBinding> referenceQueue) {
            this.f1505a = new androidx.databinding.m<>(viewDataBinding, i2, this, referenceQueue);
        }

        @Override // androidx.databinding.j
        public void b(androidx.lifecycle.g gVar) {
        }

        @Override // androidx.databinding.j
        /* renamed from: c  reason: merged with bridge method [inline-methods] */
        public void a(androidx.databinding.h hVar) {
            hVar.b(this);
        }

        public androidx.databinding.m<androidx.databinding.h> e() {
            return this.f1505a;
        }

        @Override // androidx.databinding.j
        /* renamed from: f  reason: merged with bridge method [inline-methods] */
        public void d(androidx.databinding.h hVar) {
            hVar.a(this);
        }
    }

    /* loaded from: classes.dex */
    private static class l extends i.a implements androidx.databinding.j<androidx.databinding.i> {

        /* renamed from: a  reason: collision with root package name */
        final androidx.databinding.m<androidx.databinding.i> f1506a;

        public l(ViewDataBinding viewDataBinding, int i2, ReferenceQueue<ViewDataBinding> referenceQueue) {
            this.f1506a = new androidx.databinding.m<>(viewDataBinding, i2, this, referenceQueue);
        }

        @Override // androidx.databinding.j
        public void b(androidx.lifecycle.g gVar) {
        }

        @Override // androidx.databinding.j
        /* renamed from: c  reason: merged with bridge method [inline-methods] */
        public void a(androidx.databinding.i iVar) {
            iVar.a(this);
        }

        public androidx.databinding.m<androidx.databinding.i> e() {
            return this.f1506a;
        }

        @Override // androidx.databinding.j
        /* renamed from: f  reason: merged with bridge method [inline-methods] */
        public void d(androidx.databinding.i iVar) {
            iVar.b(this);
        }
    }

    /* loaded from: classes.dex */
    private static class m extends g.a implements androidx.databinding.j<androidx.databinding.g> {

        /* renamed from: a  reason: collision with root package name */
        final androidx.databinding.m<androidx.databinding.g> f1507a;

        public m(ViewDataBinding viewDataBinding, int i2, ReferenceQueue<ViewDataBinding> referenceQueue) {
            this.f1507a = new androidx.databinding.m<>(viewDataBinding, i2, this, referenceQueue);
        }

        @Override // androidx.databinding.j
        public void b(androidx.lifecycle.g gVar) {
        }

        @Override // androidx.databinding.g.a
        public void c(androidx.databinding.g gVar, int i2) {
            ViewDataBinding a2 = this.f1507a.a();
            if (a2 != null && this.f1507a.b() == gVar) {
                a2.q(this.f1507a.f1519b, gVar, i2);
            }
        }

        @Override // androidx.databinding.j
        /* renamed from: e  reason: merged with bridge method [inline-methods] */
        public void a(androidx.databinding.g gVar) {
            gVar.a(this);
        }

        public androidx.databinding.m<androidx.databinding.g> f() {
            return this.f1507a;
        }

        @Override // androidx.databinding.j
        /* renamed from: g  reason: merged with bridge method [inline-methods] */
        public void d(androidx.databinding.g gVar) {
            gVar.c(this);
        }
    }

    protected ViewDataBinding(androidx.databinding.e eVar, View view, int i2) {
        this.f1484b = new g();
        this.f1485c = false;
        this.f1486d = false;
        this.f1494l = eVar;
        this.f1487e = new androidx.databinding.m[i2];
        this.f1488f = view;
        if (Looper.myLooper() == null) {
            throw new IllegalStateException("DataBinding must be created in view's UI Thread");
        }
        if (f1477t) {
            this.f1491i = Choreographer.getInstance();
            this.f1492j = new h();
            return;
        }
        this.f1492j = null;
        this.f1493k = new Handler(Looper.myLooper());
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public ViewDataBinding(Object obj, View view, int i2) {
        this(k(obj), view, i2);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static int A(Integer num) {
        if (num == null) {
            return 0;
        }
        return num.intValue();
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static boolean B(Boolean bool) {
        if (bool == null) {
            return false;
        }
        return bool.booleanValue();
    }

    private static androidx.databinding.e k(Object obj) {
        if (obj == null) {
            return null;
        }
        if (obj instanceof androidx.databinding.e) {
            return (androidx.databinding.e) obj;
        }
        throw new IllegalArgumentException("The provided bindingComponent parameter must be an instance of DataBindingComponent. See  https://issuetracker.google.com/issues/116541301 for details of why this parameter is not defined as DataBindingComponent");
    }

    private void m() {
        if (this.f1490h) {
            z();
        } else if (r()) {
            this.f1490h = true;
            this.f1486d = false;
            androidx.databinding.b<androidx.databinding.k, ViewDataBinding, Void> bVar = this.f1489g;
            if (bVar != null) {
                bVar.d(this, 1, null);
                if (this.f1486d) {
                    this.f1489g.d(this, 2, null);
                }
            }
            if (!this.f1486d) {
                l();
                androidx.databinding.b<androidx.databinding.k, ViewDataBinding, Void> bVar2 = this.f1489g;
                if (bVar2 != null) {
                    bVar2.d(this, 3, null);
                }
            }
            this.f1490h = false;
        }
    }

    static ViewDataBinding o(View view) {
        if (view != null) {
            return (ViewDataBinding) view.getTag(k0.a.dataBinding);
        }
        return null;
    }

    private static boolean s(String str, int i2) {
        int length = str.length();
        if (length == i2) {
            return false;
        }
        while (i2 < length) {
            if (!Character.isDigit(str.charAt(i2))) {
                return false;
            }
            i2++;
        }
        return true;
    }

    private static void t(androidx.databinding.e eVar, View view, Object[] objArr, i iVar, SparseIntArray sparseIntArray, boolean z2) {
        int id;
        int i2;
        if (o(view) != null) {
            return;
        }
        Object tag = view.getTag();
        String str = tag instanceof String ? (String) tag : null;
        boolean z3 = true;
        if (z2 && str != null && str.startsWith("layout")) {
            int lastIndexOf = str.lastIndexOf(95);
            if (lastIndexOf > 0) {
                int i3 = lastIndexOf + 1;
                if (s(str, i3)) {
                    int w2 = w(str, i3);
                    if (objArr[w2] == null) {
                        objArr[w2] = view;
                    }
                }
            }
            z3 = false;
        } else {
            if (str != null && str.startsWith("binding_")) {
                int w3 = w(str, f1476s);
                if (objArr[w3] == null) {
                    objArr[w3] = view;
                }
            }
            z3 = false;
        }
        if (!z3 && (id = view.getId()) > 0 && sparseIntArray != null && (i2 = sparseIntArray.get(id, -1)) >= 0 && objArr[i2] == null) {
            objArr[i2] = view;
        }
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            int childCount = viewGroup.getChildCount();
            for (int i4 = 0; i4 < childCount; i4++) {
                t(eVar, viewGroup.getChildAt(i4), objArr, iVar, sparseIntArray, false);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public static Object[] u(androidx.databinding.e eVar, View view, int i2, i iVar, SparseIntArray sparseIntArray) {
        Object[] objArr = new Object[i2];
        t(eVar, view, objArr, iVar, sparseIntArray, true);
        return objArr;
    }

    private static int w(String str, int i2) {
        int i3 = 0;
        while (i2 < str.length()) {
            i3 = (i3 * 10) + (str.charAt(i2) - '0');
            i2++;
        }
        return i3;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void x() {
        while (true) {
            Reference<? extends ViewDataBinding> poll = f1483z.poll();
            if (poll == null) {
                return;
            }
            if (poll instanceof androidx.databinding.m) {
                ((androidx.databinding.m) poll).e();
            }
        }
    }

    public void C(androidx.lifecycle.g gVar) {
        if (gVar instanceof Fragment) {
            Log.w("DataBinding", "Setting the fragment as the LifecycleOwner might cause memory leaks because views lives shorter than the Fragment. Consider using Fragment's view lifecycle");
        }
        androidx.lifecycle.g gVar2 = this.f1496n;
        if (gVar2 == gVar) {
            return;
        }
        if (gVar2 != null) {
            gVar2.a().c(this.f1497o);
        }
        this.f1496n = gVar;
        if (gVar != null) {
            if (this.f1497o == null) {
                this.f1497o = new OnStartListener(this, null);
            }
            gVar.a().a(this.f1497o);
        }
        for (androidx.databinding.m mVar : this.f1487e) {
            if (mVar != null) {
                mVar.c(gVar);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public void D(View view) {
        view.setTag(k0.a.dataBinding, this);
    }

    protected boolean E(int i2) {
        androidx.databinding.m mVar = this.f1487e[i2];
        if (mVar != null) {
            return mVar.e();
        }
        return false;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public boolean F(int i2, LiveData<?> liveData) {
        this.f1498p = true;
        try {
            return G(i2, liveData, f1481x);
        } finally {
            this.f1498p = false;
        }
    }

    protected boolean G(int i2, Object obj, androidx.databinding.c cVar) {
        if (obj == null) {
            return E(i2);
        }
        androidx.databinding.m mVar = this.f1487e[i2];
        if (mVar == null) {
            y(i2, obj, cVar);
            return true;
        } else if (mVar.b() == obj) {
            return false;
        } else {
            E(i2);
            y(i2, obj, cVar);
            return true;
        }
    }

    protected abstract void l();

    public void n() {
        ViewDataBinding viewDataBinding = this.f1495m;
        if (viewDataBinding == null) {
            m();
        } else {
            viewDataBinding.n();
        }
    }

    public View p() {
        return this.f1488f;
    }

    protected void q(int i2, Object obj, int i3) {
        if (this.f1498p || this.f1499q || !v(i2, obj, i3)) {
            return;
        }
        z();
    }

    public abstract boolean r();

    protected abstract boolean v(int i2, Object obj, int i3);

    protected void y(int i2, Object obj, androidx.databinding.c cVar) {
        if (obj == null) {
            return;
        }
        androidx.databinding.m mVar = this.f1487e[i2];
        if (mVar == null) {
            mVar = cVar.a(this, i2, f1483z);
            this.f1487e[i2] = mVar;
            androidx.lifecycle.g gVar = this.f1496n;
            if (gVar != null) {
                mVar.c(gVar);
            }
        }
        mVar.d(obj);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public void z() {
        ViewDataBinding viewDataBinding = this.f1495m;
        if (viewDataBinding != null) {
            viewDataBinding.z();
            return;
        }
        androidx.lifecycle.g gVar = this.f1496n;
        if (gVar == null || gVar.a().b().a(d.b.STARTED)) {
            synchronized (this) {
                if (this.f1485c) {
                    return;
                }
                this.f1485c = true;
                if (f1477t) {
                    this.f1491i.postFrameCallback(this.f1492j);
                } else {
                    this.f1493k.post(this.f1484b);
                }
            }
        }
    }
}
