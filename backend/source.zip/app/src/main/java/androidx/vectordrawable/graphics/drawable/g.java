package androidx.vectordrawable.graphics.drawable;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.VectorDrawable;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.util.Xml;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import w.c;
/* loaded from: classes.dex */
public class g extends androidx.vectordrawable.graphics.drawable.f {

    /* renamed from: l  reason: collision with root package name */
    static final PorterDuff.Mode f2740l = PorterDuff.Mode.SRC_IN;

    /* renamed from: c  reason: collision with root package name */
    private h f2741c;

    /* renamed from: d  reason: collision with root package name */
    private PorterDuffColorFilter f2742d;

    /* renamed from: e  reason: collision with root package name */
    private ColorFilter f2743e;

    /* renamed from: f  reason: collision with root package name */
    private boolean f2744f;

    /* renamed from: g  reason: collision with root package name */
    private boolean f2745g;

    /* renamed from: h  reason: collision with root package name */
    private Drawable.ConstantState f2746h;

    /* renamed from: i  reason: collision with root package name */
    private final float[] f2747i;

    /* renamed from: j  reason: collision with root package name */
    private final Matrix f2748j;

    /* renamed from: k  reason: collision with root package name */
    private final Rect f2749k;

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public static class b extends f {
        b() {
        }

        b(b bVar) {
            super(bVar);
        }

        private void f(TypedArray typedArray, XmlPullParser xmlPullParser) {
            String string = typedArray.getString(0);
            if (string != null) {
                this.f2776b = string;
            }
            String string2 = typedArray.getString(1);
            if (string2 != null) {
                this.f2775a = w.c.d(string2);
            }
            this.f2777c = v.g.g(typedArray, xmlPullParser, "fillType", 2, 0);
        }

        @Override // androidx.vectordrawable.graphics.drawable.g.f
        public boolean c() {
            return true;
        }

        public void e(Resources resources, AttributeSet attributeSet, Resources.Theme theme, XmlPullParser xmlPullParser) {
            if (v.g.j(xmlPullParser, "pathData")) {
                TypedArray k2 = v.g.k(resources, theme, attributeSet, androidx.vectordrawable.graphics.drawable.a.f2715d);
                f(k2, xmlPullParser);
                k2.recycle();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public static class c extends f {

        /* renamed from: e  reason: collision with root package name */
        private int[] f2750e;

        /* renamed from: f  reason: collision with root package name */
        v.b f2751f;

        /* renamed from: g  reason: collision with root package name */
        float f2752g;

        /* renamed from: h  reason: collision with root package name */
        v.b f2753h;

        /* renamed from: i  reason: collision with root package name */
        float f2754i;

        /* renamed from: j  reason: collision with root package name */
        float f2755j;

        /* renamed from: k  reason: collision with root package name */
        float f2756k;

        /* renamed from: l  reason: collision with root package name */
        float f2757l;

        /* renamed from: m  reason: collision with root package name */
        float f2758m;

        /* renamed from: n  reason: collision with root package name */
        Paint.Cap f2759n;

        /* renamed from: o  reason: collision with root package name */
        Paint.Join f2760o;

        /* renamed from: p  reason: collision with root package name */
        float f2761p;

        c() {
            this.f2752g = 0.0f;
            this.f2754i = 1.0f;
            this.f2755j = 1.0f;
            this.f2756k = 0.0f;
            this.f2757l = 1.0f;
            this.f2758m = 0.0f;
            this.f2759n = Paint.Cap.BUTT;
            this.f2760o = Paint.Join.MITER;
            this.f2761p = 4.0f;
        }

        c(c cVar) {
            super(cVar);
            this.f2752g = 0.0f;
            this.f2754i = 1.0f;
            this.f2755j = 1.0f;
            this.f2756k = 0.0f;
            this.f2757l = 1.0f;
            this.f2758m = 0.0f;
            this.f2759n = Paint.Cap.BUTT;
            this.f2760o = Paint.Join.MITER;
            this.f2761p = 4.0f;
            this.f2750e = cVar.f2750e;
            this.f2751f = cVar.f2751f;
            this.f2752g = cVar.f2752g;
            this.f2754i = cVar.f2754i;
            this.f2753h = cVar.f2753h;
            this.f2777c = cVar.f2777c;
            this.f2755j = cVar.f2755j;
            this.f2756k = cVar.f2756k;
            this.f2757l = cVar.f2757l;
            this.f2758m = cVar.f2758m;
            this.f2759n = cVar.f2759n;
            this.f2760o = cVar.f2760o;
            this.f2761p = cVar.f2761p;
        }

        private Paint.Cap e(int i2, Paint.Cap cap) {
            return i2 != 0 ? i2 != 1 ? i2 != 2 ? cap : Paint.Cap.SQUARE : Paint.Cap.ROUND : Paint.Cap.BUTT;
        }

        private Paint.Join f(int i2, Paint.Join join) {
            return i2 != 0 ? i2 != 1 ? i2 != 2 ? join : Paint.Join.BEVEL : Paint.Join.ROUND : Paint.Join.MITER;
        }

        private void h(TypedArray typedArray, XmlPullParser xmlPullParser, Resources.Theme theme) {
            this.f2750e = null;
            if (v.g.j(xmlPullParser, "pathData")) {
                String string = typedArray.getString(0);
                if (string != null) {
                    this.f2776b = string;
                }
                String string2 = typedArray.getString(2);
                if (string2 != null) {
                    this.f2775a = w.c.d(string2);
                }
                this.f2753h = v.g.e(typedArray, xmlPullParser, theme, "fillColor", 1, 0);
                this.f2755j = v.g.f(typedArray, xmlPullParser, "fillAlpha", 12, this.f2755j);
                this.f2759n = e(v.g.g(typedArray, xmlPullParser, "strokeLineCap", 8, -1), this.f2759n);
                this.f2760o = f(v.g.g(typedArray, xmlPullParser, "strokeLineJoin", 9, -1), this.f2760o);
                this.f2761p = v.g.f(typedArray, xmlPullParser, "strokeMiterLimit", 10, this.f2761p);
                this.f2751f = v.g.e(typedArray, xmlPullParser, theme, "strokeColor", 3, 0);
                this.f2754i = v.g.f(typedArray, xmlPullParser, "strokeAlpha", 11, this.f2754i);
                this.f2752g = v.g.f(typedArray, xmlPullParser, "strokeWidth", 4, this.f2752g);
                this.f2757l = v.g.f(typedArray, xmlPullParser, "trimPathEnd", 6, this.f2757l);
                this.f2758m = v.g.f(typedArray, xmlPullParser, "trimPathOffset", 7, this.f2758m);
                this.f2756k = v.g.f(typedArray, xmlPullParser, "trimPathStart", 5, this.f2756k);
                this.f2777c = v.g.g(typedArray, xmlPullParser, "fillType", 13, this.f2777c);
            }
        }

        @Override // androidx.vectordrawable.graphics.drawable.g.e
        public boolean a() {
            return this.f2753h.i() || this.f2751f.i();
        }

        @Override // androidx.vectordrawable.graphics.drawable.g.e
        public boolean b(int[] iArr) {
            return this.f2751f.j(iArr) | this.f2753h.j(iArr);
        }

        public void g(Resources resources, AttributeSet attributeSet, Resources.Theme theme, XmlPullParser xmlPullParser) {
            TypedArray k2 = v.g.k(resources, theme, attributeSet, androidx.vectordrawable.graphics.drawable.a.f2714c);
            h(k2, xmlPullParser, theme);
            k2.recycle();
        }

        float getFillAlpha() {
            return this.f2755j;
        }

        int getFillColor() {
            return this.f2753h.e();
        }

        float getStrokeAlpha() {
            return this.f2754i;
        }

        int getStrokeColor() {
            return this.f2751f.e();
        }

        float getStrokeWidth() {
            return this.f2752g;
        }

        float getTrimPathEnd() {
            return this.f2757l;
        }

        float getTrimPathOffset() {
            return this.f2758m;
        }

        float getTrimPathStart() {
            return this.f2756k;
        }

        void setFillAlpha(float f2) {
            this.f2755j = f2;
        }

        void setFillColor(int i2) {
            this.f2753h.k(i2);
        }

        void setStrokeAlpha(float f2) {
            this.f2754i = f2;
        }

        void setStrokeColor(int i2) {
            this.f2751f.k(i2);
        }

        void setStrokeWidth(float f2) {
            this.f2752g = f2;
        }

        void setTrimPathEnd(float f2) {
            this.f2757l = f2;
        }

        void setTrimPathOffset(float f2) {
            this.f2758m = f2;
        }

        void setTrimPathStart(float f2) {
            this.f2756k = f2;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public static class d extends e {

        /* renamed from: a  reason: collision with root package name */
        final Matrix f2762a;

        /* renamed from: b  reason: collision with root package name */
        final ArrayList<e> f2763b;

        /* renamed from: c  reason: collision with root package name */
        float f2764c;

        /* renamed from: d  reason: collision with root package name */
        private float f2765d;

        /* renamed from: e  reason: collision with root package name */
        private float f2766e;

        /* renamed from: f  reason: collision with root package name */
        private float f2767f;

        /* renamed from: g  reason: collision with root package name */
        private float f2768g;

        /* renamed from: h  reason: collision with root package name */
        private float f2769h;

        /* renamed from: i  reason: collision with root package name */
        private float f2770i;

        /* renamed from: j  reason: collision with root package name */
        final Matrix f2771j;

        /* renamed from: k  reason: collision with root package name */
        int f2772k;

        /* renamed from: l  reason: collision with root package name */
        private int[] f2773l;

        /* renamed from: m  reason: collision with root package name */
        private String f2774m;

        public d() {
            super();
            this.f2762a = new Matrix();
            this.f2763b = new ArrayList<>();
            this.f2764c = 0.0f;
            this.f2765d = 0.0f;
            this.f2766e = 0.0f;
            this.f2767f = 1.0f;
            this.f2768g = 1.0f;
            this.f2769h = 0.0f;
            this.f2770i = 0.0f;
            this.f2771j = new Matrix();
            this.f2774m = null;
        }

        public d(d dVar, l.a<String, Object> aVar) {
            super();
            f bVar;
            this.f2762a = new Matrix();
            this.f2763b = new ArrayList<>();
            this.f2764c = 0.0f;
            this.f2765d = 0.0f;
            this.f2766e = 0.0f;
            this.f2767f = 1.0f;
            this.f2768g = 1.0f;
            this.f2769h = 0.0f;
            this.f2770i = 0.0f;
            Matrix matrix = new Matrix();
            this.f2771j = matrix;
            this.f2774m = null;
            this.f2764c = dVar.f2764c;
            this.f2765d = dVar.f2765d;
            this.f2766e = dVar.f2766e;
            this.f2767f = dVar.f2767f;
            this.f2768g = dVar.f2768g;
            this.f2769h = dVar.f2769h;
            this.f2770i = dVar.f2770i;
            this.f2773l = dVar.f2773l;
            String str = dVar.f2774m;
            this.f2774m = str;
            this.f2772k = dVar.f2772k;
            if (str != null) {
                aVar.put(str, this);
            }
            matrix.set(dVar.f2771j);
            ArrayList<e> arrayList = dVar.f2763b;
            for (int i2 = 0; i2 < arrayList.size(); i2++) {
                e eVar = arrayList.get(i2);
                if (eVar instanceof d) {
                    this.f2763b.add(new d((d) eVar, aVar));
                } else {
                    if (eVar instanceof c) {
                        bVar = new c((c) eVar);
                    } else if (!(eVar instanceof b)) {
                        throw new IllegalStateException("Unknown object in the tree!");
                    } else {
                        bVar = new b((b) eVar);
                    }
                    this.f2763b.add(bVar);
                    String str2 = bVar.f2776b;
                    if (str2 != null) {
                        aVar.put(str2, bVar);
                    }
                }
            }
        }

        private void d() {
            this.f2771j.reset();
            this.f2771j.postTranslate(-this.f2765d, -this.f2766e);
            this.f2771j.postScale(this.f2767f, this.f2768g);
            this.f2771j.postRotate(this.f2764c, 0.0f, 0.0f);
            this.f2771j.postTranslate(this.f2769h + this.f2765d, this.f2770i + this.f2766e);
        }

        private void e(TypedArray typedArray, XmlPullParser xmlPullParser) {
            this.f2773l = null;
            this.f2764c = v.g.f(typedArray, xmlPullParser, "rotation", 5, this.f2764c);
            this.f2765d = typedArray.getFloat(1, this.f2765d);
            this.f2766e = typedArray.getFloat(2, this.f2766e);
            this.f2767f = v.g.f(typedArray, xmlPullParser, "scaleX", 3, this.f2767f);
            this.f2768g = v.g.f(typedArray, xmlPullParser, "scaleY", 4, this.f2768g);
            this.f2769h = v.g.f(typedArray, xmlPullParser, "translateX", 6, this.f2769h);
            this.f2770i = v.g.f(typedArray, xmlPullParser, "translateY", 7, this.f2770i);
            String string = typedArray.getString(0);
            if (string != null) {
                this.f2774m = string;
            }
            d();
        }

        @Override // androidx.vectordrawable.graphics.drawable.g.e
        public boolean a() {
            for (int i2 = 0; i2 < this.f2763b.size(); i2++) {
                if (this.f2763b.get(i2).a()) {
                    return true;
                }
            }
            return false;
        }

        @Override // androidx.vectordrawable.graphics.drawable.g.e
        public boolean b(int[] iArr) {
            boolean z2 = false;
            for (int i2 = 0; i2 < this.f2763b.size(); i2++) {
                z2 |= this.f2763b.get(i2).b(iArr);
            }
            return z2;
        }

        public void c(Resources resources, AttributeSet attributeSet, Resources.Theme theme, XmlPullParser xmlPullParser) {
            TypedArray k2 = v.g.k(resources, theme, attributeSet, androidx.vectordrawable.graphics.drawable.a.f2713b);
            e(k2, xmlPullParser);
            k2.recycle();
        }

        public String getGroupName() {
            return this.f2774m;
        }

        public Matrix getLocalMatrix() {
            return this.f2771j;
        }

        public float getPivotX() {
            return this.f2765d;
        }

        public float getPivotY() {
            return this.f2766e;
        }

        public float getRotation() {
            return this.f2764c;
        }

        public float getScaleX() {
            return this.f2767f;
        }

        public float getScaleY() {
            return this.f2768g;
        }

        public float getTranslateX() {
            return this.f2769h;
        }

        public float getTranslateY() {
            return this.f2770i;
        }

        public void setPivotX(float f2) {
            if (f2 != this.f2765d) {
                this.f2765d = f2;
                d();
            }
        }

        public void setPivotY(float f2) {
            if (f2 != this.f2766e) {
                this.f2766e = f2;
                d();
            }
        }

        public void setRotation(float f2) {
            if (f2 != this.f2764c) {
                this.f2764c = f2;
                d();
            }
        }

        public void setScaleX(float f2) {
            if (f2 != this.f2767f) {
                this.f2767f = f2;
                d();
            }
        }

        public void setScaleY(float f2) {
            if (f2 != this.f2768g) {
                this.f2768g = f2;
                d();
            }
        }

        public void setTranslateX(float f2) {
            if (f2 != this.f2769h) {
                this.f2769h = f2;
                d();
            }
        }

        public void setTranslateY(float f2) {
            if (f2 != this.f2770i) {
                this.f2770i = f2;
                d();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public static abstract class e {
        private e() {
        }

        public boolean a() {
            return false;
        }

        public boolean b(int[] iArr) {
            return false;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public static abstract class f extends e {

        /* renamed from: a  reason: collision with root package name */
        protected c.b[] f2775a;

        /* renamed from: b  reason: collision with root package name */
        String f2776b;

        /* renamed from: c  reason: collision with root package name */
        int f2777c;

        /* renamed from: d  reason: collision with root package name */
        int f2778d;

        public f() {
            super();
            this.f2775a = null;
            this.f2777c = 0;
        }

        public f(f fVar) {
            super();
            this.f2775a = null;
            this.f2777c = 0;
            this.f2776b = fVar.f2776b;
            this.f2778d = fVar.f2778d;
            this.f2775a = w.c.f(fVar.f2775a);
        }

        public boolean c() {
            return false;
        }

        public void d(Path path) {
            path.reset();
            c.b[] bVarArr = this.f2775a;
            if (bVarArr != null) {
                c.b.e(bVarArr, path);
            }
        }

        public c.b[] getPathData() {
            return this.f2775a;
        }

        public String getPathName() {
            return this.f2776b;
        }

        public void setPathData(c.b[] bVarArr) {
            if (w.c.b(this.f2775a, bVarArr)) {
                w.c.j(this.f2775a, bVarArr);
            } else {
                this.f2775a = w.c.f(bVarArr);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* renamed from: androidx.vectordrawable.graphics.drawable.g$g  reason: collision with other inner class name */
    /* loaded from: classes.dex */
    public static class C0024g {

        /* renamed from: q  reason: collision with root package name */
        private static final Matrix f2779q = new Matrix();

        /* renamed from: a  reason: collision with root package name */
        private final Path f2780a;

        /* renamed from: b  reason: collision with root package name */
        private final Path f2781b;

        /* renamed from: c  reason: collision with root package name */
        private final Matrix f2782c;

        /* renamed from: d  reason: collision with root package name */
        Paint f2783d;

        /* renamed from: e  reason: collision with root package name */
        Paint f2784e;

        /* renamed from: f  reason: collision with root package name */
        private PathMeasure f2785f;

        /* renamed from: g  reason: collision with root package name */
        private int f2786g;

        /* renamed from: h  reason: collision with root package name */
        final d f2787h;

        /* renamed from: i  reason: collision with root package name */
        float f2788i;

        /* renamed from: j  reason: collision with root package name */
        float f2789j;

        /* renamed from: k  reason: collision with root package name */
        float f2790k;

        /* renamed from: l  reason: collision with root package name */
        float f2791l;

        /* renamed from: m  reason: collision with root package name */
        int f2792m;

        /* renamed from: n  reason: collision with root package name */
        String f2793n;

        /* renamed from: o  reason: collision with root package name */
        Boolean f2794o;

        /* renamed from: p  reason: collision with root package name */
        final l.a<String, Object> f2795p;

        public C0024g() {
            this.f2782c = new Matrix();
            this.f2788i = 0.0f;
            this.f2789j = 0.0f;
            this.f2790k = 0.0f;
            this.f2791l = 0.0f;
            this.f2792m = 255;
            this.f2793n = null;
            this.f2794o = null;
            this.f2795p = new l.a<>();
            this.f2787h = new d();
            this.f2780a = new Path();
            this.f2781b = new Path();
        }

        public C0024g(C0024g c0024g) {
            this.f2782c = new Matrix();
            this.f2788i = 0.0f;
            this.f2789j = 0.0f;
            this.f2790k = 0.0f;
            this.f2791l = 0.0f;
            this.f2792m = 255;
            this.f2793n = null;
            this.f2794o = null;
            l.a<String, Object> aVar = new l.a<>();
            this.f2795p = aVar;
            this.f2787h = new d(c0024g.f2787h, aVar);
            this.f2780a = new Path(c0024g.f2780a);
            this.f2781b = new Path(c0024g.f2781b);
            this.f2788i = c0024g.f2788i;
            this.f2789j = c0024g.f2789j;
            this.f2790k = c0024g.f2790k;
            this.f2791l = c0024g.f2791l;
            this.f2786g = c0024g.f2786g;
            this.f2792m = c0024g.f2792m;
            this.f2793n = c0024g.f2793n;
            String str = c0024g.f2793n;
            if (str != null) {
                aVar.put(str, this);
            }
            this.f2794o = c0024g.f2794o;
        }

        private static float a(float f2, float f3, float f4, float f5) {
            return (f2 * f5) - (f3 * f4);
        }

        private void c(d dVar, Matrix matrix, Canvas canvas, int i2, int i3, ColorFilter colorFilter) {
            dVar.f2762a.set(matrix);
            dVar.f2762a.preConcat(dVar.f2771j);
            canvas.save();
            for (int i4 = 0; i4 < dVar.f2763b.size(); i4++) {
                e eVar = dVar.f2763b.get(i4);
                if (eVar instanceof d) {
                    c((d) eVar, dVar.f2762a, canvas, i2, i3, colorFilter);
                } else if (eVar instanceof f) {
                    d(dVar, (f) eVar, canvas, i2, i3, colorFilter);
                }
            }
            canvas.restore();
        }

        private void d(d dVar, f fVar, Canvas canvas, int i2, int i3, ColorFilter colorFilter) {
            float f2 = i2 / this.f2790k;
            float f3 = i3 / this.f2791l;
            float min = Math.min(f2, f3);
            Matrix matrix = dVar.f2762a;
            this.f2782c.set(matrix);
            this.f2782c.postScale(f2, f3);
            float e2 = e(matrix);
            if (e2 == 0.0f) {
                return;
            }
            fVar.d(this.f2780a);
            Path path = this.f2780a;
            this.f2781b.reset();
            if (fVar.c()) {
                this.f2781b.setFillType(fVar.f2777c == 0 ? Path.FillType.WINDING : Path.FillType.EVEN_ODD);
                this.f2781b.addPath(path, this.f2782c);
                canvas.clipPath(this.f2781b);
                return;
            }
            c cVar = (c) fVar;
            float f4 = cVar.f2756k;
            if (f4 != 0.0f || cVar.f2757l != 1.0f) {
                float f5 = cVar.f2758m;
                float f6 = (f4 + f5) % 1.0f;
                float f7 = (cVar.f2757l + f5) % 1.0f;
                if (this.f2785f == null) {
                    this.f2785f = new PathMeasure();
                }
                this.f2785f.setPath(this.f2780a, false);
                float length = this.f2785f.getLength();
                float f8 = f6 * length;
                float f9 = f7 * length;
                path.reset();
                if (f8 > f9) {
                    this.f2785f.getSegment(f8, length, path, true);
                    this.f2785f.getSegment(0.0f, f9, path, true);
                } else {
                    this.f2785f.getSegment(f8, f9, path, true);
                }
                path.rLineTo(0.0f, 0.0f);
            }
            this.f2781b.addPath(path, this.f2782c);
            if (cVar.f2753h.l()) {
                v.b bVar = cVar.f2753h;
                if (this.f2784e == null) {
                    Paint paint = new Paint(1);
                    this.f2784e = paint;
                    paint.setStyle(Paint.Style.FILL);
                }
                Paint paint2 = this.f2784e;
                if (bVar.h()) {
                    Shader f10 = bVar.f();
                    f10.setLocalMatrix(this.f2782c);
                    paint2.setShader(f10);
                    paint2.setAlpha(Math.round(cVar.f2755j * 255.0f));
                } else {
                    paint2.setShader(null);
                    paint2.setAlpha(255);
                    paint2.setColor(g.a(bVar.e(), cVar.f2755j));
                }
                paint2.setColorFilter(colorFilter);
                this.f2781b.setFillType(cVar.f2777c == 0 ? Path.FillType.WINDING : Path.FillType.EVEN_ODD);
                canvas.drawPath(this.f2781b, paint2);
            }
            if (cVar.f2751f.l()) {
                v.b bVar2 = cVar.f2751f;
                if (this.f2783d == null) {
                    Paint paint3 = new Paint(1);
                    this.f2783d = paint3;
                    paint3.setStyle(Paint.Style.STROKE);
                }
                Paint paint4 = this.f2783d;
                Paint.Join join = cVar.f2760o;
                if (join != null) {
                    paint4.setStrokeJoin(join);
                }
                Paint.Cap cap = cVar.f2759n;
                if (cap != null) {
                    paint4.setStrokeCap(cap);
                }
                paint4.setStrokeMiter(cVar.f2761p);
                if (bVar2.h()) {
                    Shader f11 = bVar2.f();
                    f11.setLocalMatrix(this.f2782c);
                    paint4.setShader(f11);
                    paint4.setAlpha(Math.round(cVar.f2754i * 255.0f));
                } else {
                    paint4.setShader(null);
                    paint4.setAlpha(255);
                    paint4.setColor(g.a(bVar2.e(), cVar.f2754i));
                }
                paint4.setColorFilter(colorFilter);
                paint4.setStrokeWidth(cVar.f2752g * min * e2);
                canvas.drawPath(this.f2781b, paint4);
            }
        }

        private float e(Matrix matrix) {
            float[] fArr = {0.0f, 1.0f, 1.0f, 0.0f};
            matrix.mapVectors(fArr);
            float hypot = (float) Math.hypot(fArr[0], fArr[1]);
            float hypot2 = (float) Math.hypot(fArr[2], fArr[3]);
            float a2 = a(fArr[0], fArr[1], fArr[2], fArr[3]);
            float max = Math.max(hypot, hypot2);
            if (max > 0.0f) {
                return Math.abs(a2) / max;
            }
            return 0.0f;
        }

        public void b(Canvas canvas, int i2, int i3, ColorFilter colorFilter) {
            c(this.f2787h, f2779q, canvas, i2, i3, colorFilter);
        }

        public boolean f() {
            if (this.f2794o == null) {
                this.f2794o = Boolean.valueOf(this.f2787h.a());
            }
            return this.f2794o.booleanValue();
        }

        public boolean g(int[] iArr) {
            return this.f2787h.b(iArr);
        }

        public float getAlpha() {
            return getRootAlpha() / 255.0f;
        }

        public int getRootAlpha() {
            return this.f2792m;
        }

        public void setAlpha(float f2) {
            setRootAlpha((int) (f2 * 255.0f));
        }

        public void setRootAlpha(int i2) {
            this.f2792m = i2;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public static class h extends Drawable.ConstantState {

        /* renamed from: a  reason: collision with root package name */
        int f2796a;

        /* renamed from: b  reason: collision with root package name */
        C0024g f2797b;

        /* renamed from: c  reason: collision with root package name */
        ColorStateList f2798c;

        /* renamed from: d  reason: collision with root package name */
        PorterDuff.Mode f2799d;

        /* renamed from: e  reason: collision with root package name */
        boolean f2800e;

        /* renamed from: f  reason: collision with root package name */
        Bitmap f2801f;

        /* renamed from: g  reason: collision with root package name */
        ColorStateList f2802g;

        /* renamed from: h  reason: collision with root package name */
        PorterDuff.Mode f2803h;

        /* renamed from: i  reason: collision with root package name */
        int f2804i;

        /* renamed from: j  reason: collision with root package name */
        boolean f2805j;

        /* renamed from: k  reason: collision with root package name */
        boolean f2806k;

        /* renamed from: l  reason: collision with root package name */
        Paint f2807l;

        public h() {
            this.f2798c = null;
            this.f2799d = g.f2740l;
            this.f2797b = new C0024g();
        }

        public h(h hVar) {
            this.f2798c = null;
            this.f2799d = g.f2740l;
            if (hVar != null) {
                this.f2796a = hVar.f2796a;
                C0024g c0024g = new C0024g(hVar.f2797b);
                this.f2797b = c0024g;
                if (hVar.f2797b.f2784e != null) {
                    c0024g.f2784e = new Paint(hVar.f2797b.f2784e);
                }
                if (hVar.f2797b.f2783d != null) {
                    this.f2797b.f2783d = new Paint(hVar.f2797b.f2783d);
                }
                this.f2798c = hVar.f2798c;
                this.f2799d = hVar.f2799d;
                this.f2800e = hVar.f2800e;
            }
        }

        public boolean a(int i2, int i3) {
            return i2 == this.f2801f.getWidth() && i3 == this.f2801f.getHeight();
        }

        public boolean b() {
            return !this.f2806k && this.f2802g == this.f2798c && this.f2803h == this.f2799d && this.f2805j == this.f2800e && this.f2804i == this.f2797b.getRootAlpha();
        }

        public void c(int i2, int i3) {
            if (this.f2801f == null || !a(i2, i3)) {
                this.f2801f = Bitmap.createBitmap(i2, i3, Bitmap.Config.ARGB_8888);
                this.f2806k = true;
            }
        }

        public void d(Canvas canvas, ColorFilter colorFilter, Rect rect) {
            canvas.drawBitmap(this.f2801f, (Rect) null, rect, e(colorFilter));
        }

        public Paint e(ColorFilter colorFilter) {
            if (f() || colorFilter != null) {
                if (this.f2807l == null) {
                    Paint paint = new Paint();
                    this.f2807l = paint;
                    paint.setFilterBitmap(true);
                }
                this.f2807l.setAlpha(this.f2797b.getRootAlpha());
                this.f2807l.setColorFilter(colorFilter);
                return this.f2807l;
            }
            return null;
        }

        public boolean f() {
            return this.f2797b.getRootAlpha() < 255;
        }

        public boolean g() {
            return this.f2797b.f();
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public int getChangingConfigurations() {
            return this.f2796a;
        }

        public boolean h(int[] iArr) {
            boolean g2 = this.f2797b.g(iArr);
            this.f2806k |= g2;
            return g2;
        }

        public void i() {
            this.f2802g = this.f2798c;
            this.f2803h = this.f2799d;
            this.f2804i = this.f2797b.getRootAlpha();
            this.f2805j = this.f2800e;
            this.f2806k = false;
        }

        public void j(int i2, int i3) {
            this.f2801f.eraseColor(0);
            this.f2797b.b(new Canvas(this.f2801f), i2, i3, null);
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public Drawable newDrawable() {
            return new g(this);
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public Drawable newDrawable(Resources resources) {
            return new g(this);
        }
    }

    /* loaded from: classes.dex */
    private static class i extends Drawable.ConstantState {

        /* renamed from: a  reason: collision with root package name */
        private final Drawable.ConstantState f2808a;

        public i(Drawable.ConstantState constantState) {
            this.f2808a = constantState;
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public boolean canApplyTheme() {
            return this.f2808a.canApplyTheme();
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public int getChangingConfigurations() {
            return this.f2808a.getChangingConfigurations();
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public Drawable newDrawable() {
            g gVar = new g();
            gVar.f2739b = (VectorDrawable) this.f2808a.newDrawable();
            return gVar;
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public Drawable newDrawable(Resources resources) {
            g gVar = new g();
            gVar.f2739b = (VectorDrawable) this.f2808a.newDrawable(resources);
            return gVar;
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public Drawable newDrawable(Resources resources, Resources.Theme theme) {
            g gVar = new g();
            gVar.f2739b = (VectorDrawable) this.f2808a.newDrawable(resources, theme);
            return gVar;
        }
    }

    g() {
        this.f2745g = true;
        this.f2747i = new float[9];
        this.f2748j = new Matrix();
        this.f2749k = new Rect();
        this.f2741c = new h();
    }

    g(h hVar) {
        this.f2745g = true;
        this.f2747i = new float[9];
        this.f2748j = new Matrix();
        this.f2749k = new Rect();
        this.f2741c = hVar;
        this.f2742d = j(this.f2742d, hVar.f2798c, hVar.f2799d);
    }

    static int a(int i2, float f2) {
        return (i2 & 16777215) | (((int) (Color.alpha(i2) * f2)) << 24);
    }

    public static g b(Resources resources, int i2, Resources.Theme theme) {
        int next;
        if (Build.VERSION.SDK_INT >= 24) {
            g gVar = new g();
            gVar.f2739b = v.f.a(resources, i2, theme);
            gVar.f2746h = new i(gVar.f2739b.getConstantState());
            return gVar;
        }
        try {
            XmlResourceParser xml = resources.getXml(i2);
            AttributeSet asAttributeSet = Xml.asAttributeSet(xml);
            do {
                next = xml.next();
                if (next == 2) {
                    break;
                }
            } while (next != 1);
            if (next == 2) {
                return c(resources, xml, asAttributeSet, theme);
            }
            throw new XmlPullParserException("No start tag found");
        } catch (IOException | XmlPullParserException e2) {
            Log.e("VectorDrawableCompat", "parser error", e2);
            return null;
        }
    }

    public static g c(Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme) {
        g gVar = new g();
        gVar.inflate(resources, xmlPullParser, attributeSet, theme);
        return gVar;
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void e(Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme) {
        int i2;
        int i3;
        b bVar;
        h hVar = this.f2741c;
        C0024g c0024g = hVar.f2797b;
        ArrayDeque arrayDeque = new ArrayDeque();
        arrayDeque.push(c0024g.f2787h);
        int eventType = xmlPullParser.getEventType();
        int depth = xmlPullParser.getDepth() + 1;
        boolean z2 = true;
        while (eventType != 1 && (xmlPullParser.getDepth() >= depth || eventType != 3)) {
            if (eventType == 2) {
                String name = xmlPullParser.getName();
                d dVar = (d) arrayDeque.peek();
                if ("path".equals(name)) {
                    c cVar = new c();
                    cVar.g(resources, attributeSet, theme, xmlPullParser);
                    dVar.f2763b.add(cVar);
                    if (cVar.getPathName() != null) {
                        c0024g.f2795p.put(cVar.getPathName(), cVar);
                    }
                    z2 = false;
                    bVar = cVar;
                } else if ("clip-path".equals(name)) {
                    b bVar2 = new b();
                    bVar2.e(resources, attributeSet, theme, xmlPullParser);
                    dVar.f2763b.add(bVar2);
                    String pathName = bVar2.getPathName();
                    bVar = bVar2;
                    if (pathName != null) {
                        c0024g.f2795p.put(bVar2.getPathName(), bVar2);
                        bVar = bVar2;
                    }
                } else if ("group".equals(name)) {
                    d dVar2 = new d();
                    dVar2.c(resources, attributeSet, theme, xmlPullParser);
                    dVar.f2763b.add(dVar2);
                    arrayDeque.push(dVar2);
                    if (dVar2.getGroupName() != null) {
                        c0024g.f2795p.put(dVar2.getGroupName(), dVar2);
                    }
                    i2 = hVar.f2796a;
                    i3 = dVar2.f2772k;
                    hVar.f2796a = i3 | i2;
                }
                i2 = hVar.f2796a;
                i3 = bVar.f2778d;
                hVar.f2796a = i3 | i2;
            } else if (eventType == 3 && "group".equals(xmlPullParser.getName())) {
                arrayDeque.pop();
            }
            eventType = xmlPullParser.next();
        }
        if (z2) {
            throw new XmlPullParserException("no path defined");
        }
    }

    private boolean f() {
        return isAutoMirrored() && x.a.f(this) == 1;
    }

    private static PorterDuff.Mode g(int i2, PorterDuff.Mode mode) {
        if (i2 != 3) {
            if (i2 != 5) {
                if (i2 != 9) {
                    switch (i2) {
                        case 14:
                            return PorterDuff.Mode.MULTIPLY;
                        case 15:
                            return PorterDuff.Mode.SCREEN;
                        case 16:
                            return PorterDuff.Mode.ADD;
                        default:
                            return mode;
                    }
                }
                return PorterDuff.Mode.SRC_ATOP;
            }
            return PorterDuff.Mode.SRC_IN;
        }
        return PorterDuff.Mode.SRC_OVER;
    }

    private void i(TypedArray typedArray, XmlPullParser xmlPullParser, Resources.Theme theme) {
        h hVar = this.f2741c;
        C0024g c0024g = hVar.f2797b;
        hVar.f2799d = g(v.g.g(typedArray, xmlPullParser, "tintMode", 6, -1), PorterDuff.Mode.SRC_IN);
        ColorStateList c2 = v.g.c(typedArray, xmlPullParser, theme, "tint", 1);
        if (c2 != null) {
            hVar.f2798c = c2;
        }
        hVar.f2800e = v.g.a(typedArray, xmlPullParser, "autoMirrored", 5, hVar.f2800e);
        c0024g.f2790k = v.g.f(typedArray, xmlPullParser, "viewportWidth", 7, c0024g.f2790k);
        float f2 = v.g.f(typedArray, xmlPullParser, "viewportHeight", 8, c0024g.f2791l);
        c0024g.f2791l = f2;
        if (c0024g.f2790k <= 0.0f) {
            throw new XmlPullParserException(typedArray.getPositionDescription() + "<vector> tag requires viewportWidth > 0");
        } else if (f2 <= 0.0f) {
            throw new XmlPullParserException(typedArray.getPositionDescription() + "<vector> tag requires viewportHeight > 0");
        } else {
            c0024g.f2788i = typedArray.getDimension(3, c0024g.f2788i);
            float dimension = typedArray.getDimension(2, c0024g.f2789j);
            c0024g.f2789j = dimension;
            if (c0024g.f2788i <= 0.0f) {
                throw new XmlPullParserException(typedArray.getPositionDescription() + "<vector> tag requires width > 0");
            } else if (dimension <= 0.0f) {
                throw new XmlPullParserException(typedArray.getPositionDescription() + "<vector> tag requires height > 0");
            } else {
                c0024g.setAlpha(v.g.f(typedArray, xmlPullParser, "alpha", 4, c0024g.getAlpha()));
                String string = typedArray.getString(0);
                if (string != null) {
                    c0024g.f2793n = string;
                    c0024g.f2795p.put(string, c0024g);
                }
            }
        }
    }

    @Override // androidx.vectordrawable.graphics.drawable.f, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ void applyTheme(Resources.Theme theme) {
        super.applyTheme(theme);
    }

    @Override // android.graphics.drawable.Drawable
    public boolean canApplyTheme() {
        Drawable drawable = this.f2739b;
        if (drawable != null) {
            x.a.b(drawable);
            return false;
        }
        return false;
    }

    @Override // androidx.vectordrawable.graphics.drawable.f, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ void clearColorFilter() {
        super.clearColorFilter();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public Object d(String str) {
        return this.f2741c.f2797b.f2795p.get(str);
    }

    @Override // android.graphics.drawable.Drawable
    public void draw(Canvas canvas) {
        Drawable drawable = this.f2739b;
        if (drawable != null) {
            drawable.draw(canvas);
            return;
        }
        copyBounds(this.f2749k);
        if (this.f2749k.width() <= 0 || this.f2749k.height() <= 0) {
            return;
        }
        ColorFilter colorFilter = this.f2743e;
        if (colorFilter == null) {
            colorFilter = this.f2742d;
        }
        canvas.getMatrix(this.f2748j);
        this.f2748j.getValues(this.f2747i);
        float abs = Math.abs(this.f2747i[0]);
        float abs2 = Math.abs(this.f2747i[4]);
        float abs3 = Math.abs(this.f2747i[1]);
        float abs4 = Math.abs(this.f2747i[3]);
        if (abs3 != 0.0f || abs4 != 0.0f) {
            abs = 1.0f;
            abs2 = 1.0f;
        }
        int min = Math.min(2048, (int) (this.f2749k.width() * abs));
        int min2 = Math.min(2048, (int) (this.f2749k.height() * abs2));
        if (min <= 0 || min2 <= 0) {
            return;
        }
        int save = canvas.save();
        Rect rect = this.f2749k;
        canvas.translate(rect.left, rect.top);
        if (f()) {
            canvas.translate(this.f2749k.width(), 0.0f);
            canvas.scale(-1.0f, 1.0f);
        }
        this.f2749k.offsetTo(0, 0);
        this.f2741c.c(min, min2);
        if (!this.f2745g) {
            this.f2741c.j(min, min2);
        } else if (!this.f2741c.b()) {
            this.f2741c.j(min, min2);
            this.f2741c.i();
        }
        this.f2741c.d(canvas, colorFilter, this.f2749k);
        canvas.restoreToCount(save);
    }

    @Override // android.graphics.drawable.Drawable
    public int getAlpha() {
        Drawable drawable = this.f2739b;
        return drawable != null ? x.a.d(drawable) : this.f2741c.f2797b.getRootAlpha();
    }

    @Override // android.graphics.drawable.Drawable
    public int getChangingConfigurations() {
        Drawable drawable = this.f2739b;
        return drawable != null ? drawable.getChangingConfigurations() : super.getChangingConfigurations() | this.f2741c.getChangingConfigurations();
    }

    @Override // android.graphics.drawable.Drawable
    public ColorFilter getColorFilter() {
        Drawable drawable = this.f2739b;
        return drawable != null ? x.a.e(drawable) : this.f2743e;
    }

    @Override // android.graphics.drawable.Drawable
    public Drawable.ConstantState getConstantState() {
        if (this.f2739b == null || Build.VERSION.SDK_INT < 24) {
            this.f2741c.f2796a = getChangingConfigurations();
            return this.f2741c;
        }
        return new i(this.f2739b.getConstantState());
    }

    @Override // androidx.vectordrawable.graphics.drawable.f, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ Drawable getCurrent() {
        return super.getCurrent();
    }

    @Override // android.graphics.drawable.Drawable
    public int getIntrinsicHeight() {
        Drawable drawable = this.f2739b;
        return drawable != null ? drawable.getIntrinsicHeight() : (int) this.f2741c.f2797b.f2789j;
    }

    @Override // android.graphics.drawable.Drawable
    public int getIntrinsicWidth() {
        Drawable drawable = this.f2739b;
        return drawable != null ? drawable.getIntrinsicWidth() : (int) this.f2741c.f2797b.f2788i;
    }

    @Override // androidx.vectordrawable.graphics.drawable.f, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ int getMinimumHeight() {
        return super.getMinimumHeight();
    }

    @Override // androidx.vectordrawable.graphics.drawable.f, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ int getMinimumWidth() {
        return super.getMinimumWidth();
    }

    @Override // android.graphics.drawable.Drawable
    public int getOpacity() {
        Drawable drawable = this.f2739b;
        if (drawable != null) {
            return drawable.getOpacity();
        }
        return -3;
    }

    @Override // androidx.vectordrawable.graphics.drawable.f, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ boolean getPadding(Rect rect) {
        return super.getPadding(rect);
    }

    @Override // androidx.vectordrawable.graphics.drawable.f, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ int[] getState() {
        return super.getState();
    }

    @Override // androidx.vectordrawable.graphics.drawable.f, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ Region getTransparentRegion() {
        return super.getTransparentRegion();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void h(boolean z2) {
        this.f2745g = z2;
    }

    @Override // android.graphics.drawable.Drawable
    public void inflate(Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet) {
        Drawable drawable = this.f2739b;
        if (drawable != null) {
            drawable.inflate(resources, xmlPullParser, attributeSet);
        } else {
            inflate(resources, xmlPullParser, attributeSet, null);
        }
    }

    @Override // android.graphics.drawable.Drawable
    public void inflate(Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme) {
        Drawable drawable = this.f2739b;
        if (drawable != null) {
            x.a.g(drawable, resources, xmlPullParser, attributeSet, theme);
            return;
        }
        h hVar = this.f2741c;
        hVar.f2797b = new C0024g();
        TypedArray k2 = v.g.k(resources, theme, attributeSet, androidx.vectordrawable.graphics.drawable.a.f2712a);
        i(k2, xmlPullParser, theme);
        k2.recycle();
        hVar.f2796a = getChangingConfigurations();
        hVar.f2806k = true;
        e(resources, xmlPullParser, attributeSet, theme);
        this.f2742d = j(this.f2742d, hVar.f2798c, hVar.f2799d);
    }

    @Override // android.graphics.drawable.Drawable
    public void invalidateSelf() {
        Drawable drawable = this.f2739b;
        if (drawable != null) {
            drawable.invalidateSelf();
        } else {
            super.invalidateSelf();
        }
    }

    @Override // android.graphics.drawable.Drawable
    public boolean isAutoMirrored() {
        Drawable drawable = this.f2739b;
        return drawable != null ? x.a.h(drawable) : this.f2741c.f2800e;
    }

    @Override // android.graphics.drawable.Drawable
    public boolean isStateful() {
        h hVar;
        ColorStateList colorStateList;
        Drawable drawable = this.f2739b;
        return drawable != null ? drawable.isStateful() : super.isStateful() || ((hVar = this.f2741c) != null && (hVar.g() || ((colorStateList = this.f2741c.f2798c) != null && colorStateList.isStateful())));
    }

    PorterDuffColorFilter j(PorterDuffColorFilter porterDuffColorFilter, ColorStateList colorStateList, PorterDuff.Mode mode) {
        if (colorStateList == null || mode == null) {
            return null;
        }
        return new PorterDuffColorFilter(colorStateList.getColorForState(getState(), 0), mode);
    }

    @Override // androidx.vectordrawable.graphics.drawable.f, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ void jumpToCurrentState() {
        super.jumpToCurrentState();
    }

    @Override // android.graphics.drawable.Drawable
    public Drawable mutate() {
        Drawable drawable = this.f2739b;
        if (drawable != null) {
            drawable.mutate();
            return this;
        }
        if (!this.f2744f && super.mutate() == this) {
            this.f2741c = new h(this.f2741c);
            this.f2744f = true;
        }
        return this;
    }

    @Override // android.graphics.drawable.Drawable
    protected void onBoundsChange(Rect rect) {
        Drawable drawable = this.f2739b;
        if (drawable != null) {
            drawable.setBounds(rect);
        }
    }

    @Override // android.graphics.drawable.Drawable
    protected boolean onStateChange(int[] iArr) {
        PorterDuff.Mode mode;
        Drawable drawable = this.f2739b;
        if (drawable != null) {
            return drawable.setState(iArr);
        }
        boolean z2 = false;
        h hVar = this.f2741c;
        ColorStateList colorStateList = hVar.f2798c;
        if (colorStateList != null && (mode = hVar.f2799d) != null) {
            this.f2742d = j(this.f2742d, colorStateList, mode);
            invalidateSelf();
            z2 = true;
        }
        if (hVar.g() && hVar.h(iArr)) {
            invalidateSelf();
            return true;
        }
        return z2;
    }

    @Override // android.graphics.drawable.Drawable
    public void scheduleSelf(Runnable runnable, long j2) {
        Drawable drawable = this.f2739b;
        if (drawable != null) {
            drawable.scheduleSelf(runnable, j2);
        } else {
            super.scheduleSelf(runnable, j2);
        }
    }

    @Override // android.graphics.drawable.Drawable
    public void setAlpha(int i2) {
        Drawable drawable = this.f2739b;
        if (drawable != null) {
            drawable.setAlpha(i2);
        } else if (this.f2741c.f2797b.getRootAlpha() != i2) {
            this.f2741c.f2797b.setRootAlpha(i2);
            invalidateSelf();
        }
    }

    @Override // android.graphics.drawable.Drawable
    public void setAutoMirrored(boolean z2) {
        Drawable drawable = this.f2739b;
        if (drawable != null) {
            x.a.j(drawable, z2);
        } else {
            this.f2741c.f2800e = z2;
        }
    }

    @Override // androidx.vectordrawable.graphics.drawable.f, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ void setChangingConfigurations(int i2) {
        super.setChangingConfigurations(i2);
    }

    @Override // androidx.vectordrawable.graphics.drawable.f, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ void setColorFilter(int i2, PorterDuff.Mode mode) {
        super.setColorFilter(i2, mode);
    }

    @Override // android.graphics.drawable.Drawable
    public void setColorFilter(ColorFilter colorFilter) {
        Drawable drawable = this.f2739b;
        if (drawable != null) {
            drawable.setColorFilter(colorFilter);
            return;
        }
        this.f2743e = colorFilter;
        invalidateSelf();
    }

    @Override // androidx.vectordrawable.graphics.drawable.f, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ void setFilterBitmap(boolean z2) {
        super.setFilterBitmap(z2);
    }

    @Override // androidx.vectordrawable.graphics.drawable.f, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ void setHotspot(float f2, float f3) {
        super.setHotspot(f2, f3);
    }

    @Override // androidx.vectordrawable.graphics.drawable.f, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ void setHotspotBounds(int i2, int i3, int i4, int i5) {
        super.setHotspotBounds(i2, i3, i4, i5);
    }

    @Override // androidx.vectordrawable.graphics.drawable.f, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ boolean setState(int[] iArr) {
        return super.setState(iArr);
    }

    @Override // android.graphics.drawable.Drawable
    public void setTint(int i2) {
        Drawable drawable = this.f2739b;
        if (drawable != null) {
            x.a.n(drawable, i2);
        } else {
            setTintList(ColorStateList.valueOf(i2));
        }
    }

    @Override // android.graphics.drawable.Drawable
    public void setTintList(ColorStateList colorStateList) {
        Drawable drawable = this.f2739b;
        if (drawable != null) {
            x.a.o(drawable, colorStateList);
            return;
        }
        h hVar = this.f2741c;
        if (hVar.f2798c != colorStateList) {
            hVar.f2798c = colorStateList;
            this.f2742d = j(this.f2742d, colorStateList, hVar.f2799d);
            invalidateSelf();
        }
    }

    @Override // android.graphics.drawable.Drawable
    public void setTintMode(PorterDuff.Mode mode) {
        Drawable drawable = this.f2739b;
        if (drawable != null) {
            x.a.p(drawable, mode);
            return;
        }
        h hVar = this.f2741c;
        if (hVar.f2799d != mode) {
            hVar.f2799d = mode;
            this.f2742d = j(this.f2742d, hVar.f2798c, mode);
            invalidateSelf();
        }
    }

    @Override // android.graphics.drawable.Drawable
    public boolean setVisible(boolean z2, boolean z3) {
        Drawable drawable = this.f2739b;
        return drawable != null ? drawable.setVisible(z2, z3) : super.setVisible(z2, z3);
    }

    @Override // android.graphics.drawable.Drawable
    public void unscheduleSelf(Runnable runnable) {
        Drawable drawable = this.f2739b;
        if (drawable != null) {
            drawable.unscheduleSelf(runnable);
        } else {
            super.unscheduleSelf(runnable);
        }
    }
}
