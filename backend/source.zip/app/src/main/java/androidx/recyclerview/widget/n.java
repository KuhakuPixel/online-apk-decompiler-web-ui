package androidx.recyclerview.widget;

import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.Scroller;
import androidx.recyclerview.widget.RecyclerView;
/* loaded from: classes.dex */
public abstract class n extends RecyclerView.r {

    /* renamed from: a  reason: collision with root package name */
    RecyclerView f2470a;

    /* renamed from: b  reason: collision with root package name */
    private Scroller f2471b;

    /* renamed from: c  reason: collision with root package name */
    private final RecyclerView.t f2472c = new a();

    /* loaded from: classes.dex */
    class a extends RecyclerView.t {

        /* renamed from: a  reason: collision with root package name */
        boolean f2473a = false;

        a() {
        }

        @Override // androidx.recyclerview.widget.RecyclerView.t
        public void a(RecyclerView recyclerView, int i2) {
            super.a(recyclerView, i2);
            if (i2 == 0 && this.f2473a) {
                this.f2473a = false;
                n.this.k();
            }
        }

        @Override // androidx.recyclerview.widget.RecyclerView.t
        public void b(RecyclerView recyclerView, int i2, int i3) {
            if (i2 == 0 && i3 == 0) {
                return;
            }
            this.f2473a = true;
        }
    }

    private void f() {
        this.f2470a.X0(this.f2472c);
        this.f2470a.setOnFlingListener(null);
    }

    private void i() {
        if (this.f2470a.getOnFlingListener() != null) {
            throw new IllegalStateException("An instance of OnFlingListener already set.");
        }
        this.f2470a.k(this.f2472c);
        this.f2470a.setOnFlingListener(this);
    }

    private boolean j(RecyclerView.o oVar, int i2, int i3) {
        RecyclerView.z d2;
        int h2;
        if (!(oVar instanceof RecyclerView.z.b) || (d2 = d(oVar)) == null || (h2 = h(oVar, i2, i3)) == -1) {
            return false;
        }
        d2.p(h2);
        oVar.J1(d2);
        return true;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.r
    public boolean a(int i2, int i3) {
        RecyclerView.o layoutManager = this.f2470a.getLayoutManager();
        if (layoutManager == null || this.f2470a.getAdapter() == null) {
            return false;
        }
        int minFlingVelocity = this.f2470a.getMinFlingVelocity();
        return (Math.abs(i3) > minFlingVelocity || Math.abs(i2) > minFlingVelocity) && j(layoutManager, i2, i3);
    }

    public void b(RecyclerView recyclerView) {
        RecyclerView recyclerView2 = this.f2470a;
        if (recyclerView2 == recyclerView) {
            return;
        }
        if (recyclerView2 != null) {
            f();
        }
        this.f2470a = recyclerView;
        if (recyclerView != null) {
            i();
            this.f2471b = new Scroller(this.f2470a.getContext(), new DecelerateInterpolator());
            k();
        }
    }

    public abstract int[] c(RecyclerView.o oVar, View view);

    protected RecyclerView.z d(RecyclerView.o oVar) {
        return e(oVar);
    }

    @Deprecated
    protected abstract g e(RecyclerView.o oVar);

    public abstract View g(RecyclerView.o oVar);

    public abstract int h(RecyclerView.o oVar, int i2, int i3);

    void k() {
        RecyclerView.o layoutManager;
        View g2;
        RecyclerView recyclerView = this.f2470a;
        if (recyclerView == null || (layoutManager = recyclerView.getLayoutManager()) == null || (g2 = g(layoutManager)) == null) {
            return;
        }
        int[] c2 = c(layoutManager, g2);
        if (c2[0] == 0 && c2[1] == 0) {
            return;
        }
        this.f2470a.k1(c2[0], c2[1]);
    }
}
