package l;
/* loaded from: classes.dex */
public class d<E> implements Cloneable {

    /* renamed from: f  reason: collision with root package name */
    private static final Object f4616f = new Object();

    /* renamed from: b  reason: collision with root package name */
    private boolean f4617b;

    /* renamed from: c  reason: collision with root package name */
    private long[] f4618c;

    /* renamed from: d  reason: collision with root package name */
    private Object[] f4619d;

    /* renamed from: e  reason: collision with root package name */
    private int f4620e;

    public d() {
        this(10);
    }

    public d(int i2) {
        this.f4617b = false;
        if (i2 == 0) {
            this.f4618c = c.f4614b;
            this.f4619d = c.f4615c;
            return;
        }
        int f2 = c.f(i2);
        this.f4618c = new long[f2];
        this.f4619d = new Object[f2];
    }

    private void d() {
        int i2 = this.f4620e;
        long[] jArr = this.f4618c;
        Object[] objArr = this.f4619d;
        int i3 = 0;
        for (int i4 = 0; i4 < i2; i4++) {
            Object obj = objArr[i4];
            if (obj != f4616f) {
                if (i4 != i3) {
                    jArr[i3] = jArr[i4];
                    objArr[i3] = obj;
                    objArr[i4] = null;
                }
                i3++;
            }
        }
        this.f4617b = false;
        this.f4620e = i3;
    }

    public void a(long j2, E e2) {
        int i2 = this.f4620e;
        if (i2 != 0 && j2 <= this.f4618c[i2 - 1]) {
            i(j2, e2);
            return;
        }
        if (this.f4617b && i2 >= this.f4618c.length) {
            d();
        }
        int i3 = this.f4620e;
        if (i3 >= this.f4618c.length) {
            int f2 = c.f(i3 + 1);
            long[] jArr = new long[f2];
            Object[] objArr = new Object[f2];
            long[] jArr2 = this.f4618c;
            System.arraycopy(jArr2, 0, jArr, 0, jArr2.length);
            Object[] objArr2 = this.f4619d;
            System.arraycopy(objArr2, 0, objArr, 0, objArr2.length);
            this.f4618c = jArr;
            this.f4619d = objArr;
        }
        this.f4618c[i3] = j2;
        this.f4619d[i3] = e2;
        this.f4620e = i3 + 1;
    }

    public void b() {
        int i2 = this.f4620e;
        Object[] objArr = this.f4619d;
        for (int i3 = 0; i3 < i2; i3++) {
            objArr[i3] = null;
        }
        this.f4620e = 0;
        this.f4617b = false;
    }

    /* renamed from: c  reason: merged with bridge method [inline-methods] */
    public d<E> clone() {
        try {
            d<E> dVar = (d) super.clone();
            dVar.f4618c = (long[]) this.f4618c.clone();
            dVar.f4619d = (Object[]) this.f4619d.clone();
            return dVar;
        } catch (CloneNotSupportedException e2) {
            throw new AssertionError(e2);
        }
    }

    public E e(long j2) {
        return f(j2, null);
    }

    public E f(long j2, E e2) {
        int b2 = c.b(this.f4618c, this.f4620e, j2);
        if (b2 >= 0) {
            Object[] objArr = this.f4619d;
            if (objArr[b2] != f4616f) {
                return (E) objArr[b2];
            }
        }
        return e2;
    }

    public int g(long j2) {
        if (this.f4617b) {
            d();
        }
        return c.b(this.f4618c, this.f4620e, j2);
    }

    public long h(int i2) {
        if (this.f4617b) {
            d();
        }
        return this.f4618c[i2];
    }

    public void i(long j2, E e2) {
        int b2 = c.b(this.f4618c, this.f4620e, j2);
        if (b2 >= 0) {
            this.f4619d[b2] = e2;
            return;
        }
        int i2 = ~b2;
        int i3 = this.f4620e;
        if (i2 < i3) {
            Object[] objArr = this.f4619d;
            if (objArr[i2] == f4616f) {
                this.f4618c[i2] = j2;
                objArr[i2] = e2;
                return;
            }
        }
        if (this.f4617b && i3 >= this.f4618c.length) {
            d();
            i2 = ~c.b(this.f4618c, this.f4620e, j2);
        }
        int i4 = this.f4620e;
        if (i4 >= this.f4618c.length) {
            int f2 = c.f(i4 + 1);
            long[] jArr = new long[f2];
            Object[] objArr2 = new Object[f2];
            long[] jArr2 = this.f4618c;
            System.arraycopy(jArr2, 0, jArr, 0, jArr2.length);
            Object[] objArr3 = this.f4619d;
            System.arraycopy(objArr3, 0, objArr2, 0, objArr3.length);
            this.f4618c = jArr;
            this.f4619d = objArr2;
        }
        int i5 = this.f4620e;
        if (i5 - i2 != 0) {
            long[] jArr3 = this.f4618c;
            int i6 = i2 + 1;
            System.arraycopy(jArr3, i2, jArr3, i6, i5 - i2);
            Object[] objArr4 = this.f4619d;
            System.arraycopy(objArr4, i2, objArr4, i6, this.f4620e - i2);
        }
        this.f4618c[i2] = j2;
        this.f4619d[i2] = e2;
        this.f4620e++;
    }

    public void j(long j2) {
        int b2 = c.b(this.f4618c, this.f4620e, j2);
        if (b2 >= 0) {
            Object[] objArr = this.f4619d;
            Object obj = objArr[b2];
            Object obj2 = f4616f;
            if (obj != obj2) {
                objArr[b2] = obj2;
                this.f4617b = true;
            }
        }
    }

    public void k(int i2) {
        Object[] objArr = this.f4619d;
        Object obj = objArr[i2];
        Object obj2 = f4616f;
        if (obj != obj2) {
            objArr[i2] = obj2;
            this.f4617b = true;
        }
    }

    public int l() {
        if (this.f4617b) {
            d();
        }
        return this.f4620e;
    }

    public E m(int i2) {
        if (this.f4617b) {
            d();
        }
        return (E) this.f4619d[i2];
    }

    public String toString() {
        if (l() <= 0) {
            return "{}";
        }
        StringBuilder sb = new StringBuilder(this.f4620e * 28);
        sb.append('{');
        for (int i2 = 0; i2 < this.f4620e; i2++) {
            if (i2 > 0) {
                sb.append(", ");
            }
            sb.append(h(i2));
            sb.append('=');
            E m2 = m(i2);
            if (m2 != this) {
                sb.append(m2);
            } else {
                sb.append("(this Map)");
            }
        }
        sb.append('}');
        return sb.toString();
    }
}
