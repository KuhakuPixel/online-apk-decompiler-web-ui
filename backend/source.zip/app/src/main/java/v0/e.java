package v0;

import android.database.sqlite.SQLiteStatement;
import u0.f;
/* loaded from: classes.dex */
class e extends d implements f {

    /* renamed from: c  reason: collision with root package name */
    private final SQLiteStatement f5425c;

    /* JADX INFO: Access modifiers changed from: package-private */
    public e(SQLiteStatement sQLiteStatement) {
        super(sQLiteStatement);
        this.f5425c = sQLiteStatement;
    }

    @Override // u0.f
    public int l() {
        return this.f5425c.executeUpdateDelete();
    }
}
