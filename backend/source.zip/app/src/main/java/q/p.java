package q;

import p.d;
import p.e;
/* loaded from: classes.dex */
public abstract class p implements d {

    /* renamed from: a  reason: collision with root package name */
    public int f5058a;

    /* renamed from: b  reason: collision with root package name */
    p.e f5059b;

    /* renamed from: c  reason: collision with root package name */
    m f5060c;

    /* renamed from: d  reason: collision with root package name */
    protected e.b f5061d;

    /* renamed from: e  reason: collision with root package name */
    g f5062e = new g(this);

    /* renamed from: f  reason: collision with root package name */
    public int f5063f = 0;

    /* renamed from: g  reason: collision with root package name */
    boolean f5064g = false;

    /* renamed from: h  reason: collision with root package name */
    public f f5065h = new f(this);

    /* renamed from: i  reason: collision with root package name */
    public f f5066i = new f(this);

    /* renamed from: j  reason: collision with root package name */
    protected b f5067j = b.NONE;

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public static /* synthetic */ class a {

        /* renamed from: a  reason: collision with root package name */
        static final /* synthetic */ int[] f5068a;

        static {
            int[] iArr = new int[d.b.values().length];
            f5068a = iArr;
            try {
                iArr[d.b.LEFT.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                f5068a[d.b.RIGHT.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                f5068a[d.b.TOP.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                f5068a[d.b.BASELINE.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                f5068a[d.b.BOTTOM.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
        }
    }

    /* loaded from: classes.dex */
    enum b {
        NONE,
        START,
        END,
        CENTER
    }

    public p(p.e eVar) {
        this.f5059b = eVar;
    }

    private void l(int i2, int i3) {
        g gVar;
        int g2;
        int i4 = this.f5058a;
        if (i4 != 0) {
            if (i4 == 1) {
                int g3 = g(this.f5062e.f5028m, i2);
                gVar = this.f5062e;
                g2 = Math.min(g3, i3);
                gVar.d(g2);
            } else if (i4 != 2) {
                if (i4 != 3) {
                    return;
                }
                p.e eVar = this.f5059b;
                p pVar = eVar.f4895e;
                e.b bVar = pVar.f5061d;
                e.b bVar2 = e.b.MATCH_CONSTRAINT;
                if (bVar == bVar2 && pVar.f5058a == 3) {
                    n nVar = eVar.f4897f;
                    if (nVar.f5061d == bVar2 && nVar.f5058a == 3) {
                        return;
                    }
                }
                if (i2 == 0) {
                    pVar = eVar.f4897f;
                }
                if (pVar.f5062e.f5016j) {
                    float t2 = eVar.t();
                    this.f5062e.d(i2 == 1 ? (int) ((pVar.f5062e.f5013g / t2) + 0.5f) : (int) ((t2 * pVar.f5062e.f5013g) + 0.5f));
                    return;
                }
                return;
            } else {
                p.e I = this.f5059b.I();
                if (I == null) {
                    return;
                }
                if (!(i2 == 0 ? I.f4895e : I.f4897f).f5062e.f5016j) {
                    return;
                }
                p.e eVar2 = this.f5059b;
                i3 = (int) ((r9.f5013g * (i2 == 0 ? eVar2.f4927u : eVar2.f4933x)) + 0.5f);
            }
        }
        gVar = this.f5062e;
        g2 = g(i3, i2);
        gVar.d(g2);
    }

    @Override // q.d
    public void a(d dVar) {
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public final void b(f fVar, f fVar2, int i2) {
        fVar.f5018l.add(fVar2);
        fVar.f5012f = i2;
        fVar2.f5017k.add(fVar);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public final void c(f fVar, f fVar2, int i2, g gVar) {
        fVar.f5018l.add(fVar2);
        fVar.f5018l.add(this.f5062e);
        fVar.f5014h = i2;
        fVar.f5015i = gVar;
        fVar2.f5017k.add(fVar);
        gVar.f5017k.add(fVar);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public abstract void d();

    /* JADX INFO: Access modifiers changed from: package-private */
    public abstract void e();

    /* JADX INFO: Access modifiers changed from: package-private */
    public abstract void f();

    /* JADX INFO: Access modifiers changed from: protected */
    public final int g(int i2, int i3) {
        int max;
        if (i3 == 0) {
            p.e eVar = this.f5059b;
            int i4 = eVar.f4925t;
            max = Math.max(eVar.f4923s, i2);
            if (i4 > 0) {
                max = Math.min(i4, i2);
            }
            if (max == i2) {
                return i2;
            }
        } else {
            p.e eVar2 = this.f5059b;
            int i5 = eVar2.f4931w;
            max = Math.max(eVar2.f4929v, i2);
            if (i5 > 0) {
                max = Math.min(i5, i2);
            }
            if (max == i2) {
                return i2;
            }
        }
        return max;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public final f h(p.d dVar) {
        p pVar;
        p pVar2;
        p.d dVar2 = dVar.f4872f;
        if (dVar2 == null) {
            return null;
        }
        p.e eVar = dVar2.f4870d;
        int i2 = a.f5068a[dVar2.f4871e.ordinal()];
        if (i2 != 1) {
            if (i2 == 2) {
                pVar2 = eVar.f4895e;
            } else if (i2 == 3) {
                pVar = eVar.f4897f;
            } else if (i2 == 4) {
                return eVar.f4897f.f5040k;
            } else {
                if (i2 != 5) {
                    return null;
                }
                pVar2 = eVar.f4897f;
            }
            return pVar2.f5066i;
        }
        pVar = eVar.f4895e;
        return pVar.f5065h;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public final f i(p.d dVar, int i2) {
        p.d dVar2 = dVar.f4872f;
        if (dVar2 == null) {
            return null;
        }
        p.e eVar = dVar2.f4870d;
        p pVar = i2 == 0 ? eVar.f4895e : eVar.f4897f;
        int i3 = a.f5068a[dVar2.f4871e.ordinal()];
        if (i3 != 1) {
            if (i3 != 2) {
                if (i3 != 3) {
                    if (i3 != 5) {
                        return null;
                    }
                }
            }
            return pVar.f5066i;
        }
        return pVar.f5065h;
    }

    public long j() {
        if (this.f5062e.f5016j) {
            return r0.f5013g;
        }
        return 0L;
    }

    public boolean k() {
        return this.f5064g;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public abstract boolean m();

    /* JADX INFO: Access modifiers changed from: protected */
    public void n(d dVar, p.d dVar2, p.d dVar3, int i2) {
        f fVar;
        f h2 = h(dVar2);
        f h3 = h(dVar3);
        if (h2.f5016j && h3.f5016j) {
            int e2 = h2.f5013g + dVar2.e();
            int e3 = h3.f5013g - dVar3.e();
            int i3 = e3 - e2;
            if (!this.f5062e.f5016j && this.f5061d == e.b.MATCH_CONSTRAINT) {
                l(i2, i3);
            }
            g gVar = this.f5062e;
            if (gVar.f5016j) {
                if (gVar.f5013g == i3) {
                    this.f5065h.d(e2);
                    fVar = this.f5066i;
                } else {
                    p.e eVar = this.f5059b;
                    float w2 = i2 == 0 ? eVar.w() : eVar.M();
                    if (h2 == h3) {
                        e2 = h2.f5013g;
                        e3 = h3.f5013g;
                        w2 = 0.5f;
                    }
                    this.f5065h.d((int) (e2 + 0.5f + (((e3 - e2) - this.f5062e.f5013g) * w2)));
                    fVar = this.f5066i;
                    e3 = this.f5065h.f5013g + this.f5062e.f5013g;
                }
                fVar.d(e3);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public void o(d dVar) {
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public void p(d dVar) {
    }
}
