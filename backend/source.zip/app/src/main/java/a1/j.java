package a1;
/* loaded from: classes.dex */
public final class j {

    /* renamed from: a */
    public static final int TextAppearance_AppCompat_Caption = 2131886390;

    /* renamed from: b */
    public static final int Widget_AppCompat_AutoCompleteTextView = 2131886609;

    /* renamed from: c */
    public static final int Widget_Design_AppBarLayout = 2131886674;

    /* renamed from: d */
    public static final int Widget_Design_BottomSheet_Modal = 2131886676;

    /* renamed from: e */
    public static final int Widget_Design_FloatingActionButton = 2131886678;

    /* renamed from: f */
    public static final int Widget_Design_TextInputEditText = 2131886683;

    /* renamed from: g */
    public static final int Widget_Design_TextInputLayout = 2131886684;

    /* renamed from: h */
    public static final int Widget_MaterialComponents_BottomAppBar = 2131886697;

    /* renamed from: i */
    public static final int Widget_MaterialComponents_Button = 2131886705;

    /* renamed from: j */
    public static final int Widget_MaterialComponents_CardView = 2131886717;

    /* renamed from: k */
    public static final int Widget_MaterialComponents_ChipGroup = 2131886723;

    /* renamed from: l */
    public static final int Widget_MaterialComponents_Chip_Action = 2131886719;

    /* renamed from: m */
    public static final int Widget_MaterialComponents_CompoundButton_CheckBox = 2131886729;

    /* renamed from: n */
    public static final int Widget_MaterialComponents_CompoundButton_RadioButton = 2131886730;

    /* renamed from: o */
    public static final int Widget_MaterialComponents_ExtendedFloatingActionButton_Icon = 2131886733;

    /* renamed from: p */
    public static final int Widget_MaterialComponents_MaterialButtonToggleGroup = 2131886737;

    /* renamed from: q */
    public static final int Widget_MaterialComponents_MaterialCalendar = 2131886738;

    /* renamed from: r */
    public static final int Widget_MaterialComponents_TimePicker_Clock = 2131886789;

    /* renamed from: s */
    public static final int Widget_MaterialComponents_Toolbar = 2131886794;
}
