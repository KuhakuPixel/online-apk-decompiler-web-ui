package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
/* loaded from: classes.dex */
public class o0 {

    /* renamed from: a  reason: collision with root package name */
    private static final ThreadLocal<TypedValue> f882a = new ThreadLocal<>();

    /* renamed from: b  reason: collision with root package name */
    static final int[] f883b = {-16842910};

    /* renamed from: c  reason: collision with root package name */
    static final int[] f884c = {16842908};

    /* renamed from: d  reason: collision with root package name */
    static final int[] f885d = {16843518};

    /* renamed from: e  reason: collision with root package name */
    static final int[] f886e = {16842919};

    /* renamed from: f  reason: collision with root package name */
    static final int[] f887f = {16842912};

    /* renamed from: g  reason: collision with root package name */
    static final int[] f888g = {16842913};

    /* renamed from: h  reason: collision with root package name */
    static final int[] f889h = {-16842919, -16842908};

    /* renamed from: i  reason: collision with root package name */
    static final int[] f890i = new int[0];

    /* renamed from: j  reason: collision with root package name */
    private static final int[] f891j = new int[1];

    public static void a(View view, Context context) {
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(a.j.f91z0);
        try {
            if (!obtainStyledAttributes.hasValue(a.j.E0)) {
                Log.e("ThemeUtils", "View " + view.getClass() + " is an AppCompat widget that can only be used with a Theme.AppCompat theme (or descendant).");
            }
        } finally {
            obtainStyledAttributes.recycle();
        }
    }

    public static int b(Context context, int i2) {
        ColorStateList e2 = e(context, i2);
        if (e2 == null || !e2.isStateful()) {
            TypedValue f2 = f();
            context.getTheme().resolveAttribute(16842803, f2, true);
            return d(context, i2, f2.getFloat());
        }
        return e2.getColorForState(f883b, e2.getDefaultColor());
    }

    public static int c(Context context, int i2) {
        int[] iArr = f891j;
        iArr[0] = i2;
        t0 u2 = t0.u(context, null, iArr);
        try {
            return u2.b(0, 0);
        } finally {
            u2.w();
        }
    }

    static int d(Context context, int i2, float f2) {
        return w.a.d(c(context, i2), Math.round(Color.alpha(r0) * f2));
    }

    public static ColorStateList e(Context context, int i2) {
        int[] iArr = f891j;
        iArr[0] = i2;
        t0 u2 = t0.u(context, null, iArr);
        try {
            return u2.c(0);
        } finally {
            u2.w();
        }
    }

    private static TypedValue f() {
        ThreadLocal<TypedValue> threadLocal = f882a;
        TypedValue typedValue = threadLocal.get();
        if (typedValue == null) {
            TypedValue typedValue2 = new TypedValue();
            threadLocal.set(typedValue2);
            return typedValue2;
        }
        return typedValue;
    }
}
