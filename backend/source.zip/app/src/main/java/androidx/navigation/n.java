package androidx.navigation;

import android.content.Context;
import androidx.activity.OnBackPressedDispatcher;
/* loaded from: classes.dex */
public class n extends NavController {
    public n(Context context) {
        super(context);
    }

    @Override // androidx.navigation.NavController
    public final void D(androidx.lifecycle.g gVar) {
        super.D(gVar);
    }

    @Override // androidx.navigation.NavController
    public final void E(OnBackPressedDispatcher onBackPressedDispatcher) {
        super.E(onBackPressedDispatcher);
    }

    @Override // androidx.navigation.NavController
    public final void F(androidx.lifecycle.t tVar) {
        super.F(tVar);
    }

    @Override // androidx.navigation.NavController
    public final void c(boolean z2) {
        super.c(z2);
    }
}
