package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import java.lang.reflect.Method;
/* loaded from: classes.dex */
public class g0 implements g.e {
    private static Method H;
    private static Method I;
    private static Method J;
    private final c A;
    private Runnable B;
    final Handler C;
    private final Rect D;
    private Rect E;
    private boolean F;
    PopupWindow G;

    /* renamed from: b  reason: collision with root package name */
    private Context f759b;

    /* renamed from: c  reason: collision with root package name */
    private ListAdapter f760c;

    /* renamed from: d  reason: collision with root package name */
    d0 f761d;

    /* renamed from: e  reason: collision with root package name */
    private int f762e;

    /* renamed from: f  reason: collision with root package name */
    private int f763f;

    /* renamed from: g  reason: collision with root package name */
    private int f764g;

    /* renamed from: h  reason: collision with root package name */
    private int f765h;

    /* renamed from: i  reason: collision with root package name */
    private int f766i;

    /* renamed from: j  reason: collision with root package name */
    private boolean f767j;

    /* renamed from: k  reason: collision with root package name */
    private boolean f768k;

    /* renamed from: l  reason: collision with root package name */
    private boolean f769l;

    /* renamed from: m  reason: collision with root package name */
    private int f770m;

    /* renamed from: n  reason: collision with root package name */
    private boolean f771n;

    /* renamed from: o  reason: collision with root package name */
    private boolean f772o;

    /* renamed from: p  reason: collision with root package name */
    int f773p;

    /* renamed from: q  reason: collision with root package name */
    private View f774q;

    /* renamed from: r  reason: collision with root package name */
    private int f775r;

    /* renamed from: s  reason: collision with root package name */
    private DataSetObserver f776s;

    /* renamed from: t  reason: collision with root package name */
    private View f777t;

    /* renamed from: u  reason: collision with root package name */
    private Drawable f778u;

    /* renamed from: v  reason: collision with root package name */
    private AdapterView.OnItemClickListener f779v;

    /* renamed from: w  reason: collision with root package name */
    private AdapterView.OnItemSelectedListener f780w;

    /* renamed from: x  reason: collision with root package name */
    final g f781x;

    /* renamed from: y  reason: collision with root package name */
    private final f f782y;

    /* renamed from: z  reason: collision with root package name */
    private final e f783z;

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public class a implements Runnable {
        a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            View t2 = g0.this.t();
            if (t2 == null || t2.getWindowToken() == null) {
                return;
            }
            g0.this.a();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public class b implements AdapterView.OnItemSelectedListener {
        b() {
        }

        @Override // android.widget.AdapterView.OnItemSelectedListener
        public void onItemSelected(AdapterView<?> adapterView, View view, int i2, long j2) {
            d0 d0Var;
            if (i2 == -1 || (d0Var = g0.this.f761d) == null) {
                return;
            }
            d0Var.setListSelectionHidden(false);
        }

        @Override // android.widget.AdapterView.OnItemSelectedListener
        public void onNothingSelected(AdapterView<?> adapterView) {
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public class c implements Runnable {
        c() {
        }

        @Override // java.lang.Runnable
        public void run() {
            g0.this.r();
        }
    }

    /* loaded from: classes.dex */
    private class d extends DataSetObserver {
        d() {
        }

        @Override // android.database.DataSetObserver
        public void onChanged() {
            if (g0.this.c()) {
                g0.this.a();
            }
        }

        @Override // android.database.DataSetObserver
        public void onInvalidated() {
            g0.this.dismiss();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public class e implements AbsListView.OnScrollListener {
        e() {
        }

        @Override // android.widget.AbsListView.OnScrollListener
        public void onScroll(AbsListView absListView, int i2, int i3, int i4) {
        }

        @Override // android.widget.AbsListView.OnScrollListener
        public void onScrollStateChanged(AbsListView absListView, int i2) {
            if (i2 != 1 || g0.this.A() || g0.this.G.getContentView() == null) {
                return;
            }
            g0 g0Var = g0.this;
            g0Var.C.removeCallbacks(g0Var.f781x);
            g0.this.f781x.run();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public class f implements View.OnTouchListener {
        f() {
        }

        @Override // android.view.View.OnTouchListener
        public boolean onTouch(View view, MotionEvent motionEvent) {
            PopupWindow popupWindow;
            int action = motionEvent.getAction();
            int x2 = (int) motionEvent.getX();
            int y2 = (int) motionEvent.getY();
            if (action == 0 && (popupWindow = g0.this.G) != null && popupWindow.isShowing() && x2 >= 0 && x2 < g0.this.G.getWidth() && y2 >= 0 && y2 < g0.this.G.getHeight()) {
                g0 g0Var = g0.this;
                g0Var.C.postDelayed(g0Var.f781x, 250L);
                return false;
            } else if (action == 1) {
                g0 g0Var2 = g0.this;
                g0Var2.C.removeCallbacks(g0Var2.f781x);
                return false;
            } else {
                return false;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public class g implements Runnable {
        g() {
        }

        @Override // java.lang.Runnable
        public void run() {
            d0 d0Var = g0.this.f761d;
            if (d0Var == null || !e0.q.P(d0Var) || g0.this.f761d.getCount() <= g0.this.f761d.getChildCount()) {
                return;
            }
            int childCount = g0.this.f761d.getChildCount();
            g0 g0Var = g0.this;
            if (childCount <= g0Var.f773p) {
                g0Var.G.setInputMethodMode(2);
                g0.this.a();
            }
        }
    }

    static {
        if (Build.VERSION.SDK_INT <= 28) {
            try {
                H = PopupWindow.class.getDeclaredMethod("setClipToScreenEnabled", Boolean.TYPE);
            } catch (NoSuchMethodException unused) {
                Log.i("ListPopupWindow", "Could not find method setClipToScreenEnabled() on PopupWindow. Oh well.");
            }
            try {
                J = PopupWindow.class.getDeclaredMethod("setEpicenterBounds", Rect.class);
            } catch (NoSuchMethodException unused2) {
                Log.i("ListPopupWindow", "Could not find method setEpicenterBounds(Rect) on PopupWindow. Oh well.");
            }
        }
        if (Build.VERSION.SDK_INT <= 23) {
            try {
                I = PopupWindow.class.getDeclaredMethod("getMaxAvailableHeight", View.class, Integer.TYPE, Boolean.TYPE);
            } catch (NoSuchMethodException unused3) {
                Log.i("ListPopupWindow", "Could not find method getMaxAvailableHeight(View, int, boolean) on PopupWindow. Oh well.");
            }
        }
    }

    public g0(Context context) {
        this(context, null, a.a.listPopupWindowStyle);
    }

    public g0(Context context, AttributeSet attributeSet, int i2) {
        this(context, attributeSet, i2, 0);
    }

    public g0(Context context, AttributeSet attributeSet, int i2, int i3) {
        this.f762e = -2;
        this.f763f = -2;
        this.f766i = 1002;
        this.f770m = 0;
        this.f771n = false;
        this.f772o = false;
        this.f773p = Integer.MAX_VALUE;
        this.f775r = 0;
        this.f781x = new g();
        this.f782y = new f();
        this.f783z = new e();
        this.A = new c();
        this.D = new Rect();
        this.f759b = context;
        this.C = new Handler(context.getMainLooper());
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, a.j.f83w1, i2, i3);
        this.f764g = obtainStyledAttributes.getDimensionPixelOffset(a.j.f86x1, 0);
        int dimensionPixelOffset = obtainStyledAttributes.getDimensionPixelOffset(a.j.f89y1, 0);
        this.f765h = dimensionPixelOffset;
        if (dimensionPixelOffset != 0) {
            this.f767j = true;
        }
        obtainStyledAttributes.recycle();
        p pVar = new p(context, attributeSet, i2, i3);
        this.G = pVar;
        pVar.setInputMethodMode(1);
    }

    private void C() {
        View view = this.f774q;
        if (view != null) {
            ViewParent parent = view.getParent();
            if (parent instanceof ViewGroup) {
                ((ViewGroup) parent).removeView(this.f774q);
            }
        }
    }

    private void N(boolean z2) {
        if (Build.VERSION.SDK_INT > 28) {
            this.G.setIsClippedToScreen(z2);
            return;
        }
        Method method = H;
        if (method != null) {
            try {
                method.invoke(this.G, Boolean.valueOf(z2));
            } catch (Exception unused) {
                Log.i("ListPopupWindow", "Could not call setClipToScreenEnabled() on PopupWindow. Oh well.");
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:52:0x0151  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private int q() {
        /*
            Method dump skipped, instructions count: 356
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.g0.q():int");
    }

    private int u(View view, int i2, boolean z2) {
        if (Build.VERSION.SDK_INT <= 23) {
            Method method = I;
            if (method != null) {
                try {
                    return ((Integer) method.invoke(this.G, view, Integer.valueOf(i2), Boolean.valueOf(z2))).intValue();
                } catch (Exception unused) {
                    Log.i("ListPopupWindow", "Could not call getMaxAvailableHeightMethod(View, int, boolean) on PopupWindow. Using the public version.");
                }
            }
            return this.G.getMaxAvailableHeight(view, i2);
        }
        return this.G.getMaxAvailableHeight(view, i2, z2);
    }

    public boolean A() {
        return this.G.getInputMethodMode() == 2;
    }

    public boolean B() {
        return this.F;
    }

    public void D(View view) {
        this.f777t = view;
    }

    public void E(int i2) {
        this.G.setAnimationStyle(i2);
    }

    public void F(int i2) {
        Drawable background = this.G.getBackground();
        if (background == null) {
            Q(i2);
            return;
        }
        background.getPadding(this.D);
        Rect rect = this.D;
        this.f763f = rect.left + rect.right + i2;
    }

    public void G(int i2) {
        this.f770m = i2;
    }

    public void H(Rect rect) {
        this.E = rect != null ? new Rect(rect) : null;
    }

    public void I(int i2) {
        this.G.setInputMethodMode(i2);
    }

    public void J(boolean z2) {
        this.F = z2;
        this.G.setFocusable(z2);
    }

    public void K(PopupWindow.OnDismissListener onDismissListener) {
        this.G.setOnDismissListener(onDismissListener);
    }

    public void L(AdapterView.OnItemClickListener onItemClickListener) {
        this.f779v = onItemClickListener;
    }

    public void M(boolean z2) {
        this.f769l = true;
        this.f768k = z2;
    }

    public void O(int i2) {
        this.f775r = i2;
    }

    public void P(int i2) {
        d0 d0Var = this.f761d;
        if (!c() || d0Var == null) {
            return;
        }
        d0Var.setListSelectionHidden(false);
        d0Var.setSelection(i2);
        if (d0Var.getChoiceMode() != 0) {
            d0Var.setItemChecked(i2, true);
        }
    }

    public void Q(int i2) {
        this.f763f = i2;
    }

    @Override // g.e
    public void a() {
        int q2 = q();
        boolean A = A();
        androidx.core.widget.h.b(this.G, this.f766i);
        if (this.G.isShowing()) {
            if (e0.q.P(t())) {
                int i2 = this.f763f;
                if (i2 == -1) {
                    i2 = -1;
                } else if (i2 == -2) {
                    i2 = t().getWidth();
                }
                int i3 = this.f762e;
                if (i3 == -1) {
                    if (!A) {
                        q2 = -1;
                    }
                    if (A) {
                        this.G.setWidth(this.f763f == -1 ? -1 : 0);
                        this.G.setHeight(0);
                    } else {
                        this.G.setWidth(this.f763f == -1 ? -1 : 0);
                        this.G.setHeight(-1);
                    }
                } else if (i3 != -2) {
                    q2 = i3;
                }
                this.G.setOutsideTouchable((this.f772o || this.f771n) ? false : true);
                this.G.update(t(), this.f764g, this.f765h, i2 < 0 ? -1 : i2, q2 < 0 ? -1 : q2);
                return;
            }
            return;
        }
        int i4 = this.f763f;
        if (i4 == -1) {
            i4 = -1;
        } else if (i4 == -2) {
            i4 = t().getWidth();
        }
        int i5 = this.f762e;
        if (i5 == -1) {
            q2 = -1;
        } else if (i5 != -2) {
            q2 = i5;
        }
        this.G.setWidth(i4);
        this.G.setHeight(q2);
        N(true);
        this.G.setOutsideTouchable((this.f772o || this.f771n) ? false : true);
        this.G.setTouchInterceptor(this.f782y);
        if (this.f769l) {
            androidx.core.widget.h.a(this.G, this.f768k);
        }
        if (Build.VERSION.SDK_INT <= 28) {
            Method method = J;
            if (method != null) {
                try {
                    method.invoke(this.G, this.E);
                } catch (Exception e2) {
                    Log.e("ListPopupWindow", "Could not invoke setEpicenterBounds on PopupWindow", e2);
                }
            }
        } else {
            this.G.setEpicenterBounds(this.E);
        }
        androidx.core.widget.h.c(this.G, t(), this.f764g, this.f765h, this.f770m);
        this.f761d.setSelection(-1);
        if (!this.F || this.f761d.isInTouchMode()) {
            r();
        }
        if (this.F) {
            return;
        }
        this.C.post(this.A);
    }

    @Override // g.e
    public boolean c() {
        return this.G.isShowing();
    }

    public void d(Drawable drawable) {
        this.G.setBackgroundDrawable(drawable);
    }

    @Override // g.e
    public void dismiss() {
        this.G.dismiss();
        C();
        this.G.setContentView(null);
        this.f761d = null;
        this.C.removeCallbacks(this.f781x);
    }

    public void e(int i2) {
        this.f764g = i2;
    }

    public int f() {
        return this.f764g;
    }

    public int h() {
        if (this.f767j) {
            return this.f765h;
        }
        return 0;
    }

    public Drawable j() {
        return this.G.getBackground();
    }

    @Override // g.e
    public ListView l() {
        return this.f761d;
    }

    public void n(int i2) {
        this.f765h = i2;
        this.f767j = true;
    }

    public void o(ListAdapter listAdapter) {
        DataSetObserver dataSetObserver = this.f776s;
        if (dataSetObserver == null) {
            this.f776s = new d();
        } else {
            ListAdapter listAdapter2 = this.f760c;
            if (listAdapter2 != null) {
                listAdapter2.unregisterDataSetObserver(dataSetObserver);
            }
        }
        this.f760c = listAdapter;
        if (listAdapter != null) {
            listAdapter.registerDataSetObserver(this.f776s);
        }
        d0 d0Var = this.f761d;
        if (d0Var != null) {
            d0Var.setAdapter(this.f760c);
        }
    }

    public void r() {
        d0 d0Var = this.f761d;
        if (d0Var != null) {
            d0Var.setListSelectionHidden(true);
            d0Var.requestLayout();
        }
    }

    d0 s(Context context, boolean z2) {
        return new d0(context, z2);
    }

    public View t() {
        return this.f777t;
    }

    public Object v() {
        if (c()) {
            return this.f761d.getSelectedItem();
        }
        return null;
    }

    public long w() {
        if (c()) {
            return this.f761d.getSelectedItemId();
        }
        return Long.MIN_VALUE;
    }

    public int x() {
        if (c()) {
            return this.f761d.getSelectedItemPosition();
        }
        return -1;
    }

    public View y() {
        if (c()) {
            return this.f761d.getSelectedView();
        }
        return null;
    }

    public int z() {
        return this.f763f;
    }
}
