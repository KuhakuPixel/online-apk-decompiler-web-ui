package androidx.savedstate;

import android.os.Bundle;
import androidx.lifecycle.d;
/* loaded from: classes.dex */
public final class a {

    /* renamed from: a  reason: collision with root package name */
    private final b f2710a;

    /* renamed from: b  reason: collision with root package name */
    private final SavedStateRegistry f2711b = new SavedStateRegistry();

    private a(b bVar) {
        this.f2710a = bVar;
    }

    public static a a(b bVar) {
        return new a(bVar);
    }

    public SavedStateRegistry b() {
        return this.f2711b;
    }

    public void c(Bundle bundle) {
        d a2 = this.f2710a.a();
        if (a2.b() != d.b.INITIALIZED) {
            throw new IllegalStateException("Restarter must be created only during owner's initialization stage");
        }
        a2.a(new Recreator(this.f2710a));
        this.f2711b.b(a2, bundle);
    }

    public void d(Bundle bundle) {
        this.f2711b.c(bundle);
    }
}
