package c0;

import android.annotation.SuppressLint;
import android.os.Build;
import android.text.PrecomputedText;
import android.text.Spannable;
import android.text.TextDirectionHeuristic;
import android.text.TextDirectionHeuristics;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.style.MetricAffectingSpan;
/* loaded from: classes.dex */
public class b implements Spannable {

    /* renamed from: e  reason: collision with root package name */
    private static final Object f3071e = new Object();

    /* renamed from: b  reason: collision with root package name */
    private final Spannable f3072b;

    /* renamed from: c  reason: collision with root package name */
    private final a f3073c;

    /* renamed from: d  reason: collision with root package name */
    private final PrecomputedText f3074d;

    /* loaded from: classes.dex */
    public static final class a {

        /* renamed from: a  reason: collision with root package name */
        private final TextPaint f3075a;

        /* renamed from: b  reason: collision with root package name */
        private final TextDirectionHeuristic f3076b;

        /* renamed from: c  reason: collision with root package name */
        private final int f3077c;

        /* renamed from: d  reason: collision with root package name */
        private final int f3078d;

        /* renamed from: e  reason: collision with root package name */
        final PrecomputedText.Params f3079e;

        /* renamed from: c0.b$a$a  reason: collision with other inner class name */
        /* loaded from: classes.dex */
        public static class C0031a {

            /* renamed from: a  reason: collision with root package name */
            private final TextPaint f3080a;

            /* renamed from: b  reason: collision with root package name */
            private TextDirectionHeuristic f3081b;

            /* renamed from: c  reason: collision with root package name */
            private int f3082c;

            /* renamed from: d  reason: collision with root package name */
            private int f3083d;

            public C0031a(TextPaint textPaint) {
                this.f3080a = textPaint;
                if (Build.VERSION.SDK_INT >= 23) {
                    this.f3082c = 1;
                    this.f3083d = 1;
                } else {
                    this.f3083d = 0;
                    this.f3082c = 0;
                }
                this.f3081b = TextDirectionHeuristics.FIRSTSTRONG_LTR;
            }

            public a a() {
                return new a(this.f3080a, this.f3081b, this.f3082c, this.f3083d);
            }

            public C0031a b(int i2) {
                this.f3082c = i2;
                return this;
            }

            public C0031a c(int i2) {
                this.f3083d = i2;
                return this;
            }

            public C0031a d(TextDirectionHeuristic textDirectionHeuristic) {
                this.f3081b = textDirectionHeuristic;
                return this;
            }
        }

        public a(PrecomputedText.Params params) {
            this.f3075a = params.getTextPaint();
            this.f3076b = params.getTextDirection();
            this.f3077c = params.getBreakStrategy();
            this.f3078d = params.getHyphenationFrequency();
            this.f3079e = Build.VERSION.SDK_INT < 29 ? null : params;
        }

        @SuppressLint({"NewApi"})
        a(TextPaint textPaint, TextDirectionHeuristic textDirectionHeuristic, int i2, int i3) {
            this.f3079e = Build.VERSION.SDK_INT >= 29 ? new PrecomputedText.Params.Builder(textPaint).setBreakStrategy(i2).setHyphenationFrequency(i3).setTextDirection(textDirectionHeuristic).build() : null;
            this.f3075a = textPaint;
            this.f3076b = textDirectionHeuristic;
            this.f3077c = i2;
            this.f3078d = i3;
        }

        public boolean a(a aVar) {
            int i2 = Build.VERSION.SDK_INT;
            if ((i2 < 23 || (this.f3077c == aVar.b() && this.f3078d == aVar.c())) && this.f3075a.getTextSize() == aVar.e().getTextSize() && this.f3075a.getTextScaleX() == aVar.e().getTextScaleX() && this.f3075a.getTextSkewX() == aVar.e().getTextSkewX() && this.f3075a.getLetterSpacing() == aVar.e().getLetterSpacing() && TextUtils.equals(this.f3075a.getFontFeatureSettings(), aVar.e().getFontFeatureSettings()) && this.f3075a.getFlags() == aVar.e().getFlags()) {
                if (i2 >= 24) {
                    if (!this.f3075a.getTextLocales().equals(aVar.e().getTextLocales())) {
                        return false;
                    }
                } else if (!this.f3075a.getTextLocale().equals(aVar.e().getTextLocale())) {
                    return false;
                }
                return this.f3075a.getTypeface() == null ? aVar.e().getTypeface() == null : this.f3075a.getTypeface().equals(aVar.e().getTypeface());
            }
            return false;
        }

        public int b() {
            return this.f3077c;
        }

        public int c() {
            return this.f3078d;
        }

        public TextDirectionHeuristic d() {
            return this.f3076b;
        }

        public TextPaint e() {
            return this.f3075a;
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (obj instanceof a) {
                a aVar = (a) obj;
                return a(aVar) && this.f3076b == aVar.d();
            }
            return false;
        }

        public int hashCode() {
            return Build.VERSION.SDK_INT >= 24 ? d0.c.b(Float.valueOf(this.f3075a.getTextSize()), Float.valueOf(this.f3075a.getTextScaleX()), Float.valueOf(this.f3075a.getTextSkewX()), Float.valueOf(this.f3075a.getLetterSpacing()), Integer.valueOf(this.f3075a.getFlags()), this.f3075a.getTextLocales(), this.f3075a.getTypeface(), Boolean.valueOf(this.f3075a.isElegantTextHeight()), this.f3076b, Integer.valueOf(this.f3077c), Integer.valueOf(this.f3078d)) : d0.c.b(Float.valueOf(this.f3075a.getTextSize()), Float.valueOf(this.f3075a.getTextScaleX()), Float.valueOf(this.f3075a.getTextSkewX()), Float.valueOf(this.f3075a.getLetterSpacing()), Integer.valueOf(this.f3075a.getFlags()), this.f3075a.getTextLocale(), this.f3075a.getTypeface(), Boolean.valueOf(this.f3075a.isElegantTextHeight()), this.f3076b, Integer.valueOf(this.f3077c), Integer.valueOf(this.f3078d));
        }

        public String toString() {
            StringBuilder sb;
            Object textLocale;
            StringBuilder sb2 = new StringBuilder("{");
            sb2.append("textSize=" + this.f3075a.getTextSize());
            sb2.append(", textScaleX=" + this.f3075a.getTextScaleX());
            sb2.append(", textSkewX=" + this.f3075a.getTextSkewX());
            int i2 = Build.VERSION.SDK_INT;
            sb2.append(", letterSpacing=" + this.f3075a.getLetterSpacing());
            sb2.append(", elegantTextHeight=" + this.f3075a.isElegantTextHeight());
            if (i2 >= 24) {
                sb = new StringBuilder();
                sb.append(", textLocale=");
                textLocale = this.f3075a.getTextLocales();
            } else {
                sb = new StringBuilder();
                sb.append(", textLocale=");
                textLocale = this.f3075a.getTextLocale();
            }
            sb.append(textLocale);
            sb2.append(sb.toString());
            sb2.append(", typeface=" + this.f3075a.getTypeface());
            if (i2 >= 26) {
                sb2.append(", variationSettings=" + this.f3075a.getFontVariationSettings());
            }
            sb2.append(", textDir=" + this.f3076b);
            sb2.append(", breakStrategy=" + this.f3077c);
            sb2.append(", hyphenationFrequency=" + this.f3078d);
            sb2.append("}");
            return sb2.toString();
        }
    }

    public a a() {
        return this.f3073c;
    }

    public PrecomputedText b() {
        Spannable spannable = this.f3072b;
        if (spannable instanceof PrecomputedText) {
            return (PrecomputedText) spannable;
        }
        return null;
    }

    @Override // java.lang.CharSequence
    public char charAt(int i2) {
        return this.f3072b.charAt(i2);
    }

    @Override // android.text.Spanned
    public int getSpanEnd(Object obj) {
        return this.f3072b.getSpanEnd(obj);
    }

    @Override // android.text.Spanned
    public int getSpanFlags(Object obj) {
        return this.f3072b.getSpanFlags(obj);
    }

    @Override // android.text.Spanned
    public int getSpanStart(Object obj) {
        return this.f3072b.getSpanStart(obj);
    }

    @Override // android.text.Spanned
    @SuppressLint({"NewApi"})
    public <T> T[] getSpans(int i2, int i3, Class<T> cls) {
        return Build.VERSION.SDK_INT >= 29 ? (T[]) this.f3074d.getSpans(i2, i3, cls) : (T[]) this.f3072b.getSpans(i2, i3, cls);
    }

    @Override // java.lang.CharSequence
    public int length() {
        return this.f3072b.length();
    }

    @Override // android.text.Spanned
    public int nextSpanTransition(int i2, int i3, Class cls) {
        return this.f3072b.nextSpanTransition(i2, i3, cls);
    }

    @Override // android.text.Spannable
    @SuppressLint({"NewApi"})
    public void removeSpan(Object obj) {
        if (obj instanceof MetricAffectingSpan) {
            throw new IllegalArgumentException("MetricAffectingSpan can not be removed from PrecomputedText.");
        }
        if (Build.VERSION.SDK_INT >= 29) {
            this.f3074d.removeSpan(obj);
        } else {
            this.f3072b.removeSpan(obj);
        }
    }

    @Override // android.text.Spannable
    @SuppressLint({"NewApi"})
    public void setSpan(Object obj, int i2, int i3, int i4) {
        if (obj instanceof MetricAffectingSpan) {
            throw new IllegalArgumentException("MetricAffectingSpan can not be set to PrecomputedText.");
        }
        if (Build.VERSION.SDK_INT >= 29) {
            this.f3074d.setSpan(obj, i2, i3, i4);
        } else {
            this.f3072b.setSpan(obj, i2, i3, i4);
        }
    }

    @Override // java.lang.CharSequence
    public CharSequence subSequence(int i2, int i3) {
        return this.f3072b.subSequence(i2, i3);
    }

    @Override // java.lang.CharSequence
    public String toString() {
        return this.f3072b.toString();
    }
}
