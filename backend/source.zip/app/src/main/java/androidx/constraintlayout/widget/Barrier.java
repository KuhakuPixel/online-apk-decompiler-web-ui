package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
/* loaded from: classes.dex */
public class Barrier extends b {

    /* renamed from: k  reason: collision with root package name */
    private int f1046k;

    /* renamed from: l  reason: collision with root package name */
    private int f1047l;

    /* renamed from: m  reason: collision with root package name */
    private p.a f1048m;

    public Barrier(Context context) {
        super(context);
        super.setVisibility(8);
    }

    public Barrier(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        super.setVisibility(8);
    }

    /* JADX WARN: Code restructure failed: missing block: B:12:0x0019, code lost:
        if (r6 == 6) goto L6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x000f, code lost:
        if (r6 == 6) goto L11;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private void p(p.e r4, int r5, boolean r6) {
        /*
            r3 = this;
            r3.f1047l = r5
            r5 = 1
            r0 = 0
            r1 = 6
            r2 = 5
            if (r6 == 0) goto L12
            int r6 = r3.f1046k
            if (r6 != r2) goto Lf
        Lc:
            r3.f1047l = r5
            goto L1c
        Lf:
            if (r6 != r1) goto L1c
            goto L16
        L12:
            int r6 = r3.f1046k
            if (r6 != r2) goto L19
        L16:
            r3.f1047l = r0
            goto L1c
        L19:
            if (r6 != r1) goto L1c
            goto Lc
        L1c:
            boolean r5 = r4 instanceof p.a
            if (r5 == 0) goto L27
            p.a r4 = (p.a) r4
            int r5 = r3.f1047l
            r4.j1(r5)
        L27:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.widget.Barrier.p(p.e, int, boolean):void");
    }

    public int getMargin() {
        return this.f1048m.f1();
    }

    public int getType() {
        return this.f1046k;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.constraintlayout.widget.b
    public void h(AttributeSet attributeSet) {
        super.h(attributeSet);
        this.f1048m = new p.a();
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, i.f1255a1);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i2 = 0; i2 < indexCount; i2++) {
                int index = obtainStyledAttributes.getIndex(i2);
                if (index == i.f1282j1) {
                    setType(obtainStyledAttributes.getInt(index, 0));
                } else if (index == i.f1279i1) {
                    this.f1048m.i1(obtainStyledAttributes.getBoolean(index, true));
                } else if (index == i.f1285k1) {
                    this.f1048m.k1(obtainStyledAttributes.getDimensionPixelSize(index, 0));
                }
            }
            obtainStyledAttributes.recycle();
        }
        this.f1142e = this.f1048m;
        n();
    }

    @Override // androidx.constraintlayout.widget.b
    public void i(p.e eVar, boolean z2) {
        p(eVar, this.f1046k, z2);
    }

    public boolean o() {
        return this.f1048m.d1();
    }

    public void setAllowsGoneWidget(boolean z2) {
        this.f1048m.i1(z2);
    }

    public void setDpMargin(int i2) {
        this.f1048m.k1((int) ((i2 * getResources().getDisplayMetrics().density) + 0.5f));
    }

    public void setMargin(int i2) {
        this.f1048m.k1(i2);
    }

    public void setType(int i2) {
        this.f1046k = i2;
    }
}
