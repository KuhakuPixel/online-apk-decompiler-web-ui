package androidx.core.widget;

import android.widget.ListView;
/* loaded from: classes.dex */
public final class g {
    public static void a(ListView listView, int i2) {
        listView.scrollListBy(i2);
    }
}
