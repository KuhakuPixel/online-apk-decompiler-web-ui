package androidx.navigation;

import android.annotation.SuppressLint;
import androidx.navigation.s;
import java.util.HashMap;
import java.util.Map;
@SuppressLint({"TypeParameterUnusedInFormals"})
/* loaded from: classes.dex */
public class t {

    /* renamed from: b  reason: collision with root package name */
    private static final HashMap<Class<?>, String> f2055b = new HashMap<>();

    /* renamed from: a  reason: collision with root package name */
    private final HashMap<String, s<? extends k>> f2056a = new HashMap<>();

    /* JADX INFO: Access modifiers changed from: package-private */
    public static String c(Class<? extends s> cls) {
        HashMap<Class<?>, String> hashMap = f2055b;
        String str = hashMap.get(cls);
        if (str == null) {
            s.b bVar = (s.b) cls.getAnnotation(s.b.class);
            str = bVar != null ? bVar.value() : null;
            if (!g(str)) {
                throw new IllegalArgumentException("No @Navigator.Name annotation found for " + cls.getSimpleName());
            }
            hashMap.put(cls, str);
        }
        return str;
    }

    private static boolean g(String str) {
        return (str == null || str.isEmpty()) ? false : true;
    }

    public final s<? extends k> a(s<? extends k> sVar) {
        return b(c(sVar.getClass()), sVar);
    }

    public s<? extends k> b(String str, s<? extends k> sVar) {
        if (g(str)) {
            return this.f2056a.put(str, sVar);
        }
        throw new IllegalArgumentException("navigator name cannot be an empty string");
    }

    public final <T extends s<?>> T d(Class<T> cls) {
        return (T) e(c(cls));
    }

    public <T extends s<?>> T e(String str) {
        if (g(str)) {
            s<? extends k> sVar = this.f2056a.get(str);
            if (sVar != null) {
                return sVar;
            }
            throw new IllegalStateException("Could not find Navigator with name \"" + str + "\". You must call NavController.addNavigator() for each navigation type.");
        }
        throw new IllegalArgumentException("navigator name cannot be an empty string");
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public Map<String, s<? extends k>> f() {
        return this.f2056a;
    }
}
