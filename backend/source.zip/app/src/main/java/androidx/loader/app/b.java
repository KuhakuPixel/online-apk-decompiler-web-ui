package androidx.loader.app;

import android.os.Bundle;
import android.util.Log;
import androidx.lifecycle.g;
import androidx.lifecycle.m;
import androidx.lifecycle.n;
import androidx.lifecycle.r;
import androidx.lifecycle.s;
import androidx.lifecycle.t;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import l.h;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes.dex */
public class b extends androidx.loader.app.a {

    /* renamed from: c  reason: collision with root package name */
    static boolean f1880c = false;

    /* renamed from: a  reason: collision with root package name */
    private final g f1881a;

    /* renamed from: b  reason: collision with root package name */
    private final C0011b f1882b;

    /* loaded from: classes.dex */
    public static class a<D> extends m<D> {

        /* renamed from: k  reason: collision with root package name */
        private final int f1883k;

        /* renamed from: l  reason: collision with root package name */
        private final Bundle f1884l;

        /* renamed from: m  reason: collision with root package name */
        private g f1885m;

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // androidx.lifecycle.LiveData
        public void i() {
            if (b.f1880c) {
                Log.v("LoaderManager", "  Starting: " + this);
            }
            throw null;
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // androidx.lifecycle.LiveData
        public void j() {
            if (b.f1880c) {
                Log.v("LoaderManager", "  Stopping: " + this);
            }
            throw null;
        }

        /* JADX WARN: Multi-variable type inference failed */
        @Override // androidx.lifecycle.LiveData
        public void l(n<? super D> nVar) {
            super.l(nVar);
            this.f1885m = null;
        }

        @Override // androidx.lifecycle.m, androidx.lifecycle.LiveData
        public void m(D d2) {
            super.m(d2);
        }

        n0.a<D> n(boolean z2) {
            if (b.f1880c) {
                Log.v("LoaderManager", "  Destroying: " + this);
            }
            throw null;
        }

        public void o(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
            printWriter.print(str);
            printWriter.print("mId=");
            printWriter.print(this.f1883k);
            printWriter.print(" mArgs=");
            printWriter.println(this.f1884l);
            printWriter.print(str);
            printWriter.print("mLoader=");
            printWriter.println((Object) null);
            StringBuilder sb = new StringBuilder();
            sb.append(str);
            sb.append("  ");
            throw null;
        }

        void p() {
        }

        public String toString() {
            StringBuilder sb = new StringBuilder(64);
            sb.append("LoaderInfo{");
            sb.append(Integer.toHexString(System.identityHashCode(this)));
            sb.append(" #");
            sb.append(this.f1883k);
            sb.append(" : ");
            d0.a.a(null, sb);
            sb.append("}}");
            return sb.toString();
        }
    }

    /* renamed from: androidx.loader.app.b$b  reason: collision with other inner class name */
    /* loaded from: classes.dex */
    static class C0011b extends r {

        /* renamed from: e  reason: collision with root package name */
        private static final s.a f1886e = new a();

        /* renamed from: c  reason: collision with root package name */
        private h<a> f1887c = new h<>();

        /* renamed from: d  reason: collision with root package name */
        private boolean f1888d = false;

        /* renamed from: androidx.loader.app.b$b$a */
        /* loaded from: classes.dex */
        static class a implements s.a {
            a() {
            }

            @Override // androidx.lifecycle.s.a
            public <T extends r> T a(Class<T> cls) {
                return new C0011b();
            }
        }

        C0011b() {
        }

        static C0011b f(t tVar) {
            return (C0011b) new s(tVar, f1886e).a(C0011b.class);
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // androidx.lifecycle.r
        public void d() {
            super.d();
            int l2 = this.f1887c.l();
            for (int i2 = 0; i2 < l2; i2++) {
                this.f1887c.m(i2).n(true);
            }
            this.f1887c.b();
        }

        public void e(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
            if (this.f1887c.l() > 0) {
                printWriter.print(str);
                printWriter.println("Loaders:");
                String str2 = str + "    ";
                for (int i2 = 0; i2 < this.f1887c.l(); i2++) {
                    a m2 = this.f1887c.m(i2);
                    printWriter.print(str);
                    printWriter.print("  #");
                    printWriter.print(this.f1887c.h(i2));
                    printWriter.print(": ");
                    printWriter.println(m2.toString());
                    m2.o(str2, fileDescriptor, printWriter, strArr);
                }
            }
        }

        void g() {
            int l2 = this.f1887c.l();
            for (int i2 = 0; i2 < l2; i2++) {
                this.f1887c.m(i2).p();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public b(g gVar, t tVar) {
        this.f1881a = gVar;
        this.f1882b = C0011b.f(tVar);
    }

    @Override // androidx.loader.app.a
    @Deprecated
    public void a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        this.f1882b.e(str, fileDescriptor, printWriter, strArr);
    }

    @Override // androidx.loader.app.a
    public void c() {
        this.f1882b.g();
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append("LoaderManager{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        sb.append(" in ");
        d0.a.a(this.f1881a, sb);
        sb.append("}}");
        return sb.toString();
    }
}
