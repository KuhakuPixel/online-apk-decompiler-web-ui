package w1;

import android.view.View;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.databinding.ViewDataBinding;
/* loaded from: classes.dex */
public abstract class g extends ViewDataBinding {
    public final AppCompatTextView B;

    /* JADX INFO: Access modifiers changed from: protected */
    public g(Object obj, View view, int i2, AppCompatTextView appCompatTextView) {
        super(obj, view, i2);
        this.B = appCompatTextView;
    }
}
