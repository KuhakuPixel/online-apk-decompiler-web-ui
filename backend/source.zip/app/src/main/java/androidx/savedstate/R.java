package androidx.savedstate;
/* loaded from: classes.dex */
public final class R {

    /* loaded from: classes.dex */
    public static final class id {
        public static final int view_tree_saved_state_registry_owner = 0x7f0800c9;

        private id() {
        }
    }

    private R() {
    }
}
