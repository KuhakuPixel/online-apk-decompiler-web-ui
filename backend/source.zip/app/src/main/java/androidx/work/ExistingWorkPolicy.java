package androidx.work;
/* loaded from: classes.dex */
public enum ExistingWorkPolicy {
    REPLACE,
    KEEP,
    APPEND,
    APPEND_OR_REPLACE
}
