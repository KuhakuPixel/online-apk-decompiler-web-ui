package z0;

import java.util.Iterator;
/* loaded from: classes.dex */
public abstract class i implements Iterator {
    @Override // java.util.Iterator
    @Deprecated
    public final void remove() {
        throw new UnsupportedOperationException();
    }
}
