package androidx.navigation;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import androidx.navigation.s;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
@s.b("activity")
/* loaded from: classes.dex */
public class a extends s<C0012a> {

    /* renamed from: a  reason: collision with root package name */
    private Context f1906a;

    /* renamed from: b  reason: collision with root package name */
    private Activity f1907b;

    /* renamed from: androidx.navigation.a$a  reason: collision with other inner class name */
    /* loaded from: classes.dex */
    public static class C0012a extends k {

        /* renamed from: k  reason: collision with root package name */
        private Intent f1908k;

        /* renamed from: l  reason: collision with root package name */
        private String f1909l;

        public C0012a(s<? extends C0012a> sVar) {
            super(sVar);
        }

        public final C0012a A(ComponentName componentName) {
            if (this.f1908k == null) {
                this.f1908k = new Intent();
            }
            this.f1908k.setComponent(componentName);
            return this;
        }

        public final C0012a B(Uri uri) {
            if (this.f1908k == null) {
                this.f1908k = new Intent();
            }
            this.f1908k.setData(uri);
            return this;
        }

        public final C0012a C(String str) {
            this.f1909l = str;
            return this;
        }

        public final C0012a D(String str) {
            if (this.f1908k == null) {
                this.f1908k = new Intent();
            }
            this.f1908k.setPackage(str);
            return this;
        }

        @Override // androidx.navigation.k
        public void p(Context context, AttributeSet attributeSet) {
            super.p(context, attributeSet);
            TypedArray obtainAttributes = context.getResources().obtainAttributes(attributeSet, v.f2057a);
            String string = obtainAttributes.getString(v.f2062f);
            if (string != null) {
                string = string.replace("${applicationId}", context.getPackageName());
            }
            D(string);
            String string2 = obtainAttributes.getString(v.f2058b);
            if (string2 != null) {
                if (string2.charAt(0) == '.') {
                    string2 = context.getPackageName() + string2;
                }
                A(new ComponentName(context, string2));
            }
            z(obtainAttributes.getString(v.f2059c));
            String string3 = obtainAttributes.getString(v.f2060d);
            if (string3 != null) {
                B(Uri.parse(string3));
            }
            C(obtainAttributes.getString(v.f2061e));
            obtainAttributes.recycle();
        }

        @Override // androidx.navigation.k
        public String toString() {
            String v2;
            ComponentName w2 = w();
            StringBuilder sb = new StringBuilder();
            sb.append(super.toString());
            if (w2 == null) {
                v2 = v();
                if (v2 != null) {
                    sb.append(" action=");
                }
                return sb.toString();
            }
            sb.append(" class=");
            v2 = w2.getClassName();
            sb.append(v2);
            return sb.toString();
        }

        @Override // androidx.navigation.k
        boolean u() {
            return false;
        }

        public final String v() {
            Intent intent = this.f1908k;
            if (intent == null) {
                return null;
            }
            return intent.getAction();
        }

        public final ComponentName w() {
            Intent intent = this.f1908k;
            if (intent == null) {
                return null;
            }
            return intent.getComponent();
        }

        public final String x() {
            return this.f1909l;
        }

        public final Intent y() {
            return this.f1908k;
        }

        public final C0012a z(String str) {
            if (this.f1908k == null) {
                this.f1908k = new Intent();
            }
            this.f1908k.setAction(str);
            return this;
        }
    }

    /* loaded from: classes.dex */
    public static final class b implements s.a {

        /* renamed from: a  reason: collision with root package name */
        private final int f1910a;

        public t.b a() {
            return null;
        }

        public int b() {
            return this.f1910a;
        }
    }

    public a(Context context) {
        this.f1906a = context;
        while (context instanceof ContextWrapper) {
            if (context instanceof Activity) {
                this.f1907b = (Activity) context;
                return;
            }
            context = ((ContextWrapper) context).getBaseContext();
        }
    }

    @Override // androidx.navigation.s
    public boolean e() {
        Activity activity = this.f1907b;
        if (activity != null) {
            activity.finish();
            return true;
        }
        return false;
    }

    @Override // androidx.navigation.s
    /* renamed from: f  reason: merged with bridge method [inline-methods] */
    public C0012a a() {
        return new C0012a(this);
    }

    final Context g() {
        return this.f1906a;
    }

    @Override // androidx.navigation.s
    /* renamed from: h  reason: merged with bridge method [inline-methods] */
    public k b(C0012a c0012a, Bundle bundle, p pVar, s.a aVar) {
        Intent intent;
        int intExtra;
        if (c0012a.y() == null) {
            throw new IllegalStateException("Destination " + c0012a.k() + " does not have an Intent set.");
        }
        Intent intent2 = new Intent(c0012a.y());
        if (bundle != null) {
            intent2.putExtras(bundle);
            String x2 = c0012a.x();
            if (!TextUtils.isEmpty(x2)) {
                StringBuffer stringBuffer = new StringBuffer();
                Matcher matcher = Pattern.compile("\\{(.+?)\\}").matcher(x2);
                while (matcher.find()) {
                    String group = matcher.group(1);
                    if (!bundle.containsKey(group)) {
                        throw new IllegalArgumentException("Could not find " + group + " in " + bundle + " to fill data pattern " + x2);
                    }
                    matcher.appendReplacement(stringBuffer, "");
                    stringBuffer.append(Uri.encode(bundle.get(group).toString()));
                }
                matcher.appendTail(stringBuffer);
                intent2.setData(Uri.parse(stringBuffer.toString()));
            }
        }
        boolean z2 = aVar instanceof b;
        if (z2) {
            intent2.addFlags(((b) aVar).b());
        }
        if (!(this.f1906a instanceof Activity)) {
            intent2.addFlags(268435456);
        }
        if (pVar != null && pVar.g()) {
            intent2.addFlags(536870912);
        }
        Activity activity = this.f1907b;
        if (activity != null && (intent = activity.getIntent()) != null && (intExtra = intent.getIntExtra("android-support-navigation:ActivityNavigator:current", 0)) != 0) {
            intent2.putExtra("android-support-navigation:ActivityNavigator:source", intExtra);
        }
        intent2.putExtra("android-support-navigation:ActivityNavigator:current", c0012a.k());
        Resources resources = g().getResources();
        if (pVar != null) {
            int c2 = pVar.c();
            int d2 = pVar.d();
            if ((c2 <= 0 || !resources.getResourceTypeName(c2).equals("animator")) && (d2 <= 0 || !resources.getResourceTypeName(d2).equals("animator"))) {
                intent2.putExtra("android-support-navigation:ActivityNavigator:popEnterAnim", c2);
                intent2.putExtra("android-support-navigation:ActivityNavigator:popExitAnim", d2);
            } else {
                Log.w("ActivityNavigator", "Activity destinations do not support Animator resource. Ignoring popEnter resource " + resources.getResourceName(c2) + " and popExit resource " + resources.getResourceName(d2) + "when launching " + c0012a);
            }
        }
        if (z2) {
            ((b) aVar).a();
        }
        this.f1906a.startActivity(intent2);
        if (pVar == null || this.f1907b == null) {
            return null;
        }
        int a2 = pVar.a();
        int b2 = pVar.b();
        if ((a2 <= 0 || !resources.getResourceTypeName(a2).equals("animator")) && (b2 <= 0 || !resources.getResourceTypeName(b2).equals("animator"))) {
            if (a2 >= 0 || b2 >= 0) {
                this.f1907b.overridePendingTransition(Math.max(a2, 0), Math.max(b2, 0));
                return null;
            }
            return null;
        }
        Log.w("ActivityNavigator", "Activity destinations do not support Animator resource. Ignoring enter resource " + resources.getResourceName(a2) + " and exit resource " + resources.getResourceName(b2) + "when launching " + c0012a);
        return null;
    }
}
