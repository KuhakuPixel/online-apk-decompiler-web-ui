package w1;

import android.view.View;
import androidx.appcompat.widget.LinearLayoutCompat;
import androidx.appcompat.widget.Toolbar;
import androidx.databinding.ViewDataBinding;
import androidx.fragment.app.FragmentContainerView;
/* loaded from: classes.dex */
public abstract class a extends ViewDataBinding {
    public final LinearLayoutCompat B;
    public final FragmentContainerView C;
    public final Toolbar D;

    /* JADX INFO: Access modifiers changed from: protected */
    public a(Object obj, View view, int i2, LinearLayoutCompat linearLayoutCompat, FragmentContainerView fragmentContainerView, Toolbar toolbar) {
        super(obj, view, i2);
        this.B = linearLayoutCompat;
        this.C = fragmentContainerView;
        this.D = toolbar;
    }
}
