package androidx.viewpager2.adapter;

import androidx.lifecycle.d;
import androidx.lifecycle.e;
import androidx.lifecycle.g;
/* loaded from: classes.dex */
class FragmentStateAdapter$FragmentMaxLifecycleEnforcer$3 implements e {
    @Override // androidx.lifecycle.e
    public void f(g gVar, d.a aVar) {
        throw null;
    }
}
