package androidx.room;

import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;
import java.io.IOException;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;
/* loaded from: classes.dex */
final class a {

    /* renamed from: e  reason: collision with root package name */
    final long f2498e;

    /* renamed from: f  reason: collision with root package name */
    final Executor f2499f;

    /* renamed from: i  reason: collision with root package name */
    u0.b f2502i;

    /* renamed from: a  reason: collision with root package name */
    private u0.c f2494a = null;

    /* renamed from: b  reason: collision with root package name */
    private final Handler f2495b = new Handler(Looper.getMainLooper());

    /* renamed from: c  reason: collision with root package name */
    Runnable f2496c = null;

    /* renamed from: d  reason: collision with root package name */
    final Object f2497d = new Object();

    /* renamed from: g  reason: collision with root package name */
    int f2500g = 0;

    /* renamed from: h  reason: collision with root package name */
    long f2501h = SystemClock.uptimeMillis();

    /* renamed from: j  reason: collision with root package name */
    private boolean f2503j = false;

    /* renamed from: k  reason: collision with root package name */
    private final Runnable f2504k = new RunnableC0019a();

    /* renamed from: l  reason: collision with root package name */
    final Runnable f2505l = new b();

    /* renamed from: androidx.room.a$a  reason: collision with other inner class name */
    /* loaded from: classes.dex */
    class RunnableC0019a implements Runnable {
        RunnableC0019a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            a aVar = a.this;
            aVar.f2499f.execute(aVar.f2505l);
        }
    }

    /* loaded from: classes.dex */
    class b implements Runnable {
        b() {
        }

        @Override // java.lang.Runnable
        public void run() {
            synchronized (a.this.f2497d) {
                long uptimeMillis = SystemClock.uptimeMillis();
                a aVar = a.this;
                if (uptimeMillis - aVar.f2501h < aVar.f2498e) {
                    return;
                }
                if (aVar.f2500g != 0) {
                    return;
                }
                Runnable runnable = aVar.f2496c;
                if (runnable == null) {
                    throw new IllegalStateException("mOnAutoCloseCallback is null but it should have been set before use. Please file a bug against Room at: https://issuetracker.google.com/issues/new?component=413107&template=1096568");
                }
                runnable.run();
                u0.b bVar = a.this.f2502i;
                if (bVar != null && bVar.c()) {
                    try {
                        a.this.f2502i.close();
                    } catch (IOException e2) {
                        t0.e.a(e2);
                    }
                    a.this.f2502i = null;
                }
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public a(long j2, TimeUnit timeUnit, Executor executor) {
        this.f2498e = timeUnit.toMillis(j2);
        this.f2499f = executor;
    }

    public void a() {
        synchronized (this.f2497d) {
            this.f2503j = true;
            u0.b bVar = this.f2502i;
            if (bVar != null) {
                bVar.close();
            }
            this.f2502i = null;
        }
    }

    public void b() {
        synchronized (this.f2497d) {
            int i2 = this.f2500g;
            if (i2 <= 0) {
                throw new IllegalStateException("ref count is 0 or lower but we're supposed to decrement");
            }
            int i3 = i2 - 1;
            this.f2500g = i3;
            if (i3 == 0) {
                if (this.f2502i == null) {
                    return;
                }
                this.f2495b.postDelayed(this.f2504k, this.f2498e);
            }
        }
    }

    public <V> V c(j.a<u0.b, V> aVar) {
        try {
            return aVar.a(e());
        } finally {
            b();
        }
    }

    public u0.b d() {
        u0.b bVar;
        synchronized (this.f2497d) {
            bVar = this.f2502i;
        }
        return bVar;
    }

    public u0.b e() {
        synchronized (this.f2497d) {
            this.f2495b.removeCallbacks(this.f2504k);
            this.f2500g++;
            if (this.f2503j) {
                throw new IllegalStateException("Attempting to open already closed database.");
            }
            u0.b bVar = this.f2502i;
            if (bVar != null && bVar.c()) {
                return this.f2502i;
            }
            u0.c cVar = this.f2494a;
            if (cVar != null) {
                u0.b r2 = cVar.r();
                this.f2502i = r2;
                return r2;
            }
            throw new IllegalStateException("AutoCloser has not been initialized. Please file a bug against Room at: https://issuetracker.google.com/issues/new?component=413107&template=1096568");
        }
    }

    public void f(u0.c cVar) {
        if (this.f2494a != null) {
            Log.e("ROOM", "AutoCloser initialized multiple times. Please file a bug against room at: https://issuetracker.google.com/issues/new?component=413107&template=1096568");
        } else {
            this.f2494a = cVar;
        }
    }

    public boolean g() {
        return !this.f2503j;
    }

    public void h(Runnable runnable) {
        this.f2496c = runnable;
    }
}
