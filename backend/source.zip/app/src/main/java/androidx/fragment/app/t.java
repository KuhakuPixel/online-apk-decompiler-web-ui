package androidx.fragment.app;

import android.graphics.Rect;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes.dex */
public class t {

    /* renamed from: a  reason: collision with root package name */
    private static final int[] f1739a = {0, 3, 0, 1, 5, 4, 7, 6, 9, 8, 10};

    /* renamed from: b  reason: collision with root package name */
    private static final v f1740b = new u();

    /* renamed from: c  reason: collision with root package name */
    private static final v f1741c = w();

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public static class a implements Runnable {

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ g f1742b;

        /* renamed from: c  reason: collision with root package name */
        final /* synthetic */ Fragment f1743c;

        /* renamed from: d  reason: collision with root package name */
        final /* synthetic */ a0.a f1744d;

        a(g gVar, Fragment fragment, a0.a aVar) {
            this.f1742b = gVar;
            this.f1743c = fragment;
            this.f1744d = aVar;
        }

        @Override // java.lang.Runnable
        public void run() {
            this.f1742b.a(this.f1743c, this.f1744d);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public static class b implements Runnable {

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ ArrayList f1745b;

        b(ArrayList arrayList) {
            this.f1745b = arrayList;
        }

        @Override // java.lang.Runnable
        public void run() {
            t.A(this.f1745b, 4);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public static class c implements Runnable {

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ g f1746b;

        /* renamed from: c  reason: collision with root package name */
        final /* synthetic */ Fragment f1747c;

        /* renamed from: d  reason: collision with root package name */
        final /* synthetic */ a0.a f1748d;

        c(g gVar, Fragment fragment, a0.a aVar) {
            this.f1746b = gVar;
            this.f1747c = fragment;
            this.f1748d = aVar;
        }

        @Override // java.lang.Runnable
        public void run() {
            this.f1746b.a(this.f1747c, this.f1748d);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public static class d implements Runnable {

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ Object f1749b;

        /* renamed from: c  reason: collision with root package name */
        final /* synthetic */ v f1750c;

        /* renamed from: d  reason: collision with root package name */
        final /* synthetic */ View f1751d;

        /* renamed from: e  reason: collision with root package name */
        final /* synthetic */ Fragment f1752e;

        /* renamed from: f  reason: collision with root package name */
        final /* synthetic */ ArrayList f1753f;

        /* renamed from: g  reason: collision with root package name */
        final /* synthetic */ ArrayList f1754g;

        /* renamed from: h  reason: collision with root package name */
        final /* synthetic */ ArrayList f1755h;

        /* renamed from: i  reason: collision with root package name */
        final /* synthetic */ Object f1756i;

        d(Object obj, v vVar, View view, Fragment fragment, ArrayList arrayList, ArrayList arrayList2, ArrayList arrayList3, Object obj2) {
            this.f1749b = obj;
            this.f1750c = vVar;
            this.f1751d = view;
            this.f1752e = fragment;
            this.f1753f = arrayList;
            this.f1754g = arrayList2;
            this.f1755h = arrayList3;
            this.f1756i = obj2;
        }

        @Override // java.lang.Runnable
        public void run() {
            Object obj = this.f1749b;
            if (obj != null) {
                this.f1750c.p(obj, this.f1751d);
                this.f1754g.addAll(t.k(this.f1750c, this.f1749b, this.f1752e, this.f1753f, this.f1751d));
            }
            if (this.f1755h != null) {
                if (this.f1756i != null) {
                    ArrayList<View> arrayList = new ArrayList<>();
                    arrayList.add(this.f1751d);
                    this.f1750c.q(this.f1756i, this.f1755h, arrayList);
                }
                this.f1755h.clear();
                this.f1755h.add(this.f1751d);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public static class e implements Runnable {

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ Fragment f1757b;

        /* renamed from: c  reason: collision with root package name */
        final /* synthetic */ Fragment f1758c;

        /* renamed from: d  reason: collision with root package name */
        final /* synthetic */ boolean f1759d;

        /* renamed from: e  reason: collision with root package name */
        final /* synthetic */ l.a f1760e;

        /* renamed from: f  reason: collision with root package name */
        final /* synthetic */ View f1761f;

        /* renamed from: g  reason: collision with root package name */
        final /* synthetic */ v f1762g;

        /* renamed from: h  reason: collision with root package name */
        final /* synthetic */ Rect f1763h;

        e(Fragment fragment, Fragment fragment2, boolean z2, l.a aVar, View view, v vVar, Rect rect) {
            this.f1757b = fragment;
            this.f1758c = fragment2;
            this.f1759d = z2;
            this.f1760e = aVar;
            this.f1761f = view;
            this.f1762g = vVar;
            this.f1763h = rect;
        }

        @Override // java.lang.Runnable
        public void run() {
            t.f(this.f1757b, this.f1758c, this.f1759d, this.f1760e, false);
            View view = this.f1761f;
            if (view != null) {
                this.f1762g.k(view, this.f1763h);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public static class f implements Runnable {

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ v f1764b;

        /* renamed from: c  reason: collision with root package name */
        final /* synthetic */ l.a f1765c;

        /* renamed from: d  reason: collision with root package name */
        final /* synthetic */ Object f1766d;

        /* renamed from: e  reason: collision with root package name */
        final /* synthetic */ h f1767e;

        /* renamed from: f  reason: collision with root package name */
        final /* synthetic */ ArrayList f1768f;

        /* renamed from: g  reason: collision with root package name */
        final /* synthetic */ View f1769g;

        /* renamed from: h  reason: collision with root package name */
        final /* synthetic */ Fragment f1770h;

        /* renamed from: i  reason: collision with root package name */
        final /* synthetic */ Fragment f1771i;

        /* renamed from: j  reason: collision with root package name */
        final /* synthetic */ boolean f1772j;

        /* renamed from: k  reason: collision with root package name */
        final /* synthetic */ ArrayList f1773k;

        /* renamed from: l  reason: collision with root package name */
        final /* synthetic */ Object f1774l;

        /* renamed from: m  reason: collision with root package name */
        final /* synthetic */ Rect f1775m;

        f(v vVar, l.a aVar, Object obj, h hVar, ArrayList arrayList, View view, Fragment fragment, Fragment fragment2, boolean z2, ArrayList arrayList2, Object obj2, Rect rect) {
            this.f1764b = vVar;
            this.f1765c = aVar;
            this.f1766d = obj;
            this.f1767e = hVar;
            this.f1768f = arrayList;
            this.f1769g = view;
            this.f1770h = fragment;
            this.f1771i = fragment2;
            this.f1772j = z2;
            this.f1773k = arrayList2;
            this.f1774l = obj2;
            this.f1775m = rect;
        }

        @Override // java.lang.Runnable
        public void run() {
            l.a<String, View> h2 = t.h(this.f1764b, this.f1765c, this.f1766d, this.f1767e);
            if (h2 != null) {
                this.f1768f.addAll(h2.values());
                this.f1768f.add(this.f1769g);
            }
            t.f(this.f1770h, this.f1771i, this.f1772j, h2, false);
            Object obj = this.f1766d;
            if (obj != null) {
                this.f1764b.A(obj, this.f1773k, this.f1768f);
                View s2 = t.s(h2, this.f1767e, this.f1774l, this.f1772j);
                if (s2 != null) {
                    this.f1764b.k(s2, this.f1775m);
                }
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public interface g {
        void a(Fragment fragment, a0.a aVar);

        void b(Fragment fragment, a0.a aVar);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public static class h {

        /* renamed from: a  reason: collision with root package name */
        public Fragment f1776a;

        /* renamed from: b  reason: collision with root package name */
        public boolean f1777b;

        /* renamed from: c  reason: collision with root package name */
        public androidx.fragment.app.a f1778c;

        /* renamed from: d  reason: collision with root package name */
        public Fragment f1779d;

        /* renamed from: e  reason: collision with root package name */
        public boolean f1780e;

        /* renamed from: f  reason: collision with root package name */
        public androidx.fragment.app.a f1781f;

        h() {
        }
    }

    static void A(ArrayList<View> arrayList, int i2) {
        if (arrayList == null) {
            return;
        }
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            arrayList.get(size).setVisibility(i2);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void B(l lVar, ArrayList<androidx.fragment.app.a> arrayList, ArrayList<Boolean> arrayList2, int i2, int i3, boolean z2, g gVar) {
        if (lVar.f1653n < 1) {
            return;
        }
        SparseArray sparseArray = new SparseArray();
        for (int i4 = i2; i4 < i3; i4++) {
            androidx.fragment.app.a aVar = arrayList.get(i4);
            if (arrayList2.get(i4).booleanValue()) {
                e(aVar, sparseArray, z2);
            } else {
                c(aVar, sparseArray, z2);
            }
        }
        if (sparseArray.size() != 0) {
            View view = new View(lVar.f1654o.i());
            int size = sparseArray.size();
            for (int i5 = 0; i5 < size; i5++) {
                int keyAt = sparseArray.keyAt(i5);
                l.a<String, String> d2 = d(keyAt, arrayList, arrayList2, i2, i3);
                h hVar = (h) sparseArray.valueAt(i5);
                if (z2) {
                    o(lVar, keyAt, hVar, view, d2, gVar);
                } else {
                    n(lVar, keyAt, hVar, view, d2, gVar);
                }
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static boolean C() {
        return (f1740b == null && f1741c == null) ? false : true;
    }

    private static void a(ArrayList<View> arrayList, l.a<String, View> aVar, Collection<String> collection) {
        for (int size = aVar.size() - 1; size >= 0; size--) {
            View o2 = aVar.o(size);
            if (collection.contains(e0.q.I(o2))) {
                arrayList.add(o2);
            }
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:31:0x0039, code lost:
        if (r0.f1531l != false) goto L69;
     */
    /* JADX WARN: Code restructure failed: missing block: B:56:0x006e, code lost:
        r9 = true;
     */
    /* JADX WARN: Code restructure failed: missing block: B:68:0x0088, code lost:
        if (r0.f1545z == false) goto L69;
     */
    /* JADX WARN: Code restructure failed: missing block: B:69:0x008a, code lost:
        r9 = true;
     */
    /* JADX WARN: Removed duplicated region for block: B:101:? A[ADDED_TO_REGION, RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:74:0x0098  */
    /* JADX WARN: Removed duplicated region for block: B:77:0x00a5 A[ADDED_TO_REGION] */
    /* JADX WARN: Removed duplicated region for block: B:90:0x00c5 A[ADDED_TO_REGION] */
    /* JADX WARN: Removed duplicated region for block: B:95:0x00d7 A[ADDED_TO_REGION] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private static void b(androidx.fragment.app.a r8, androidx.fragment.app.s.a r9, android.util.SparseArray<androidx.fragment.app.t.h> r10, boolean r11, boolean r12) {
        /*
            Method dump skipped, instructions count: 226
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.fragment.app.t.b(androidx.fragment.app.a, androidx.fragment.app.s$a, android.util.SparseArray, boolean, boolean):void");
    }

    public static void c(androidx.fragment.app.a aVar, SparseArray<h> sparseArray, boolean z2) {
        int size = aVar.f1714c.size();
        for (int i2 = 0; i2 < size; i2++) {
            b(aVar, aVar.f1714c.get(i2), sparseArray, false, z2);
        }
    }

    private static l.a<String, String> d(int i2, ArrayList<androidx.fragment.app.a> arrayList, ArrayList<Boolean> arrayList2, int i3, int i4) {
        ArrayList<String> arrayList3;
        ArrayList<String> arrayList4;
        l.a<String, String> aVar = new l.a<>();
        for (int i5 = i4 - 1; i5 >= i3; i5--) {
            androidx.fragment.app.a aVar2 = arrayList.get(i5);
            if (aVar2.B(i2)) {
                boolean booleanValue = arrayList2.get(i5).booleanValue();
                ArrayList<String> arrayList5 = aVar2.f1727p;
                if (arrayList5 != null) {
                    int size = arrayList5.size();
                    if (booleanValue) {
                        arrayList3 = aVar2.f1727p;
                        arrayList4 = aVar2.f1728q;
                    } else {
                        ArrayList<String> arrayList6 = aVar2.f1727p;
                        arrayList3 = aVar2.f1728q;
                        arrayList4 = arrayList6;
                    }
                    for (int i6 = 0; i6 < size; i6++) {
                        String str = arrayList4.get(i6);
                        String str2 = arrayList3.get(i6);
                        String remove = aVar.remove(str2);
                        if (remove != null) {
                            aVar.put(str, remove);
                        } else {
                            aVar.put(str, str2);
                        }
                    }
                }
            }
        }
        return aVar;
    }

    public static void e(androidx.fragment.app.a aVar, SparseArray<h> sparseArray, boolean z2) {
        if (aVar.f1569t.f1655p.f()) {
            for (int size = aVar.f1714c.size() - 1; size >= 0; size--) {
                b(aVar, aVar.f1714c.get(size), sparseArray, true, z2);
            }
        }
    }

    static void f(Fragment fragment, Fragment fragment2, boolean z2, l.a<String, View> aVar, boolean z3) {
        if (z2) {
            fragment2.r();
        } else {
            fragment.r();
        }
    }

    private static boolean g(v vVar, List<Object> list) {
        int size = list.size();
        for (int i2 = 0; i2 < size; i2++) {
            if (!vVar.e(list.get(i2))) {
                return false;
            }
        }
        return true;
    }

    static l.a<String, View> h(v vVar, l.a<String, String> aVar, Object obj, h hVar) {
        ArrayList<String> arrayList;
        Fragment fragment = hVar.f1776a;
        View M = fragment.M();
        if (aVar.isEmpty() || obj == null || M == null) {
            aVar.clear();
            return null;
        }
        l.a<String, View> aVar2 = new l.a<>();
        vVar.j(aVar2, M);
        androidx.fragment.app.a aVar3 = hVar.f1778c;
        if (hVar.f1777b) {
            fragment.t();
            arrayList = aVar3.f1727p;
        } else {
            fragment.r();
            arrayList = aVar3.f1728q;
        }
        if (arrayList != null) {
            aVar2.q(arrayList);
            aVar2.q(aVar.values());
        }
        x(aVar, aVar2);
        return aVar2;
    }

    private static l.a<String, View> i(v vVar, l.a<String, String> aVar, Object obj, h hVar) {
        ArrayList<String> arrayList;
        if (aVar.isEmpty() || obj == null) {
            aVar.clear();
            return null;
        }
        Fragment fragment = hVar.f1779d;
        l.a<String, View> aVar2 = new l.a<>();
        vVar.j(aVar2, fragment.d1());
        androidx.fragment.app.a aVar3 = hVar.f1781f;
        if (hVar.f1780e) {
            fragment.r();
            arrayList = aVar3.f1728q;
        } else {
            fragment.t();
            arrayList = aVar3.f1727p;
        }
        if (arrayList != null) {
            aVar2.q(arrayList);
        }
        aVar.q(aVar2.keySet());
        return aVar2;
    }

    private static v j(Fragment fragment, Fragment fragment2) {
        ArrayList arrayList = new ArrayList();
        if (fragment != null) {
            Object s2 = fragment.s();
            if (s2 != null) {
                arrayList.add(s2);
            }
            Object E = fragment.E();
            if (E != null) {
                arrayList.add(E);
            }
            Object G = fragment.G();
            if (G != null) {
                arrayList.add(G);
            }
        }
        if (fragment2 != null) {
            Object q2 = fragment2.q();
            if (q2 != null) {
                arrayList.add(q2);
            }
            Object B = fragment2.B();
            if (B != null) {
                arrayList.add(B);
            }
            Object F = fragment2.F();
            if (F != null) {
                arrayList.add(F);
            }
        }
        if (arrayList.isEmpty()) {
            return null;
        }
        v vVar = f1740b;
        if (vVar == null || !g(vVar, arrayList)) {
            v vVar2 = f1741c;
            if (vVar2 == null || !g(vVar2, arrayList)) {
                if (vVar == null && vVar2 == null) {
                    return null;
                }
                throw new IllegalArgumentException("Invalid Transition types");
            }
            return vVar2;
        }
        return vVar;
    }

    static ArrayList<View> k(v vVar, Object obj, Fragment fragment, ArrayList<View> arrayList, View view) {
        if (obj != null) {
            ArrayList<View> arrayList2 = new ArrayList<>();
            View M = fragment.M();
            if (M != null) {
                vVar.f(arrayList2, M);
            }
            if (arrayList != null) {
                arrayList2.removeAll(arrayList);
            }
            if (arrayList2.isEmpty()) {
                return arrayList2;
            }
            arrayList2.add(view);
            vVar.b(obj, arrayList2);
            return arrayList2;
        }
        return null;
    }

    private static Object l(v vVar, ViewGroup viewGroup, View view, l.a<String, String> aVar, h hVar, ArrayList<View> arrayList, ArrayList<View> arrayList2, Object obj, Object obj2) {
        Object t2;
        l.a<String, String> aVar2;
        Object obj3;
        Rect rect;
        Fragment fragment = hVar.f1776a;
        Fragment fragment2 = hVar.f1779d;
        if (fragment == null || fragment2 == null) {
            return null;
        }
        boolean z2 = hVar.f1777b;
        if (aVar.isEmpty()) {
            aVar2 = aVar;
            t2 = null;
        } else {
            t2 = t(vVar, fragment, fragment2, z2);
            aVar2 = aVar;
        }
        l.a<String, View> i2 = i(vVar, aVar2, t2, hVar);
        if (aVar.isEmpty()) {
            obj3 = null;
        } else {
            arrayList.addAll(i2.values());
            obj3 = t2;
        }
        if (obj == null && obj2 == null && obj3 == null) {
            return null;
        }
        f(fragment, fragment2, z2, i2, true);
        if (obj3 != null) {
            rect = new Rect();
            vVar.z(obj3, view, arrayList);
            z(vVar, obj3, obj2, i2, hVar.f1780e, hVar.f1781f);
            if (obj != null) {
                vVar.u(obj, rect);
            }
        } else {
            rect = null;
        }
        e0.p.a(viewGroup, new f(vVar, aVar, obj3, hVar, arrayList2, view, fragment, fragment2, z2, arrayList, obj, rect));
        return obj3;
    }

    private static Object m(v vVar, ViewGroup viewGroup, View view, l.a<String, String> aVar, h hVar, ArrayList<View> arrayList, ArrayList<View> arrayList2, Object obj, Object obj2) {
        Object obj3;
        View view2;
        Rect rect;
        Fragment fragment = hVar.f1776a;
        Fragment fragment2 = hVar.f1779d;
        if (fragment != null) {
            fragment.d1().setVisibility(0);
        }
        if (fragment == null || fragment2 == null) {
            return null;
        }
        boolean z2 = hVar.f1777b;
        Object t2 = aVar.isEmpty() ? null : t(vVar, fragment, fragment2, z2);
        l.a<String, View> i2 = i(vVar, aVar, t2, hVar);
        l.a<String, View> h2 = h(vVar, aVar, t2, hVar);
        if (aVar.isEmpty()) {
            if (i2 != null) {
                i2.clear();
            }
            if (h2 != null) {
                h2.clear();
            }
            obj3 = null;
        } else {
            a(arrayList, i2, aVar.keySet());
            a(arrayList2, h2, aVar.values());
            obj3 = t2;
        }
        if (obj == null && obj2 == null && obj3 == null) {
            return null;
        }
        f(fragment, fragment2, z2, i2, true);
        if (obj3 != null) {
            arrayList2.add(view);
            vVar.z(obj3, view, arrayList);
            z(vVar, obj3, obj2, i2, hVar.f1780e, hVar.f1781f);
            Rect rect2 = new Rect();
            View s2 = s(h2, hVar, obj, z2);
            if (s2 != null) {
                vVar.u(obj, rect2);
            }
            rect = rect2;
            view2 = s2;
        } else {
            view2 = null;
            rect = null;
        }
        e0.p.a(viewGroup, new e(fragment, fragment2, z2, h2, view2, vVar, rect));
        return obj3;
    }

    private static void n(l lVar, int i2, h hVar, View view, l.a<String, String> aVar, g gVar) {
        Fragment fragment;
        Fragment fragment2;
        v j2;
        Object obj;
        ViewGroup viewGroup = lVar.f1655p.f() ? (ViewGroup) lVar.f1655p.e(i2) : null;
        if (viewGroup == null || (j2 = j((fragment2 = hVar.f1779d), (fragment = hVar.f1776a))) == null) {
            return;
        }
        boolean z2 = hVar.f1777b;
        boolean z3 = hVar.f1780e;
        Object q2 = q(j2, fragment, z2);
        Object r2 = r(j2, fragment2, z3);
        ArrayList arrayList = new ArrayList();
        ArrayList<View> arrayList2 = new ArrayList<>();
        Object l2 = l(j2, viewGroup, view, aVar, hVar, arrayList, arrayList2, q2, r2);
        if (q2 == null && l2 == null) {
            obj = r2;
            if (obj == null) {
                return;
            }
        } else {
            obj = r2;
        }
        ArrayList<View> k2 = k(j2, obj, fragment2, arrayList, view);
        Object obj2 = (k2 == null || k2.isEmpty()) ? null : obj;
        j2.a(q2, view);
        Object u2 = u(j2, q2, obj2, l2, fragment, hVar.f1777b);
        if (fragment2 != null && k2 != null && (k2.size() > 0 || arrayList.size() > 0)) {
            a0.a aVar2 = new a0.a();
            gVar.b(fragment2, aVar2);
            j2.w(fragment2, u2, aVar2, new c(gVar, fragment2, aVar2));
        }
        if (u2 != null) {
            ArrayList<View> arrayList3 = new ArrayList<>();
            j2.t(u2, q2, arrayList3, obj2, k2, l2, arrayList2);
            y(j2, viewGroup, fragment, view, arrayList2, q2, arrayList3, obj2, k2);
            j2.x(viewGroup, arrayList2, aVar);
            j2.c(viewGroup, u2);
            j2.s(viewGroup, arrayList2, aVar);
        }
    }

    private static void o(l lVar, int i2, h hVar, View view, l.a<String, String> aVar, g gVar) {
        Fragment fragment;
        Fragment fragment2;
        v j2;
        Object obj;
        ViewGroup viewGroup = lVar.f1655p.f() ? (ViewGroup) lVar.f1655p.e(i2) : null;
        if (viewGroup == null || (j2 = j((fragment2 = hVar.f1779d), (fragment = hVar.f1776a))) == null) {
            return;
        }
        boolean z2 = hVar.f1777b;
        boolean z3 = hVar.f1780e;
        ArrayList<View> arrayList = new ArrayList<>();
        ArrayList<View> arrayList2 = new ArrayList<>();
        Object q2 = q(j2, fragment, z2);
        Object r2 = r(j2, fragment2, z3);
        Object m2 = m(j2, viewGroup, view, aVar, hVar, arrayList2, arrayList, q2, r2);
        if (q2 == null && m2 == null) {
            obj = r2;
            if (obj == null) {
                return;
            }
        } else {
            obj = r2;
        }
        ArrayList<View> k2 = k(j2, obj, fragment2, arrayList2, view);
        ArrayList<View> k3 = k(j2, q2, fragment, arrayList, view);
        A(k3, 4);
        Object u2 = u(j2, q2, obj, m2, fragment, z2);
        if (fragment2 != null && k2 != null && (k2.size() > 0 || arrayList2.size() > 0)) {
            a0.a aVar2 = new a0.a();
            gVar.b(fragment2, aVar2);
            j2.w(fragment2, u2, aVar2, new a(gVar, fragment2, aVar2));
        }
        if (u2 != null) {
            v(j2, obj, fragment2, k2);
            ArrayList<String> o2 = j2.o(arrayList);
            j2.t(u2, q2, k3, obj, k2, m2, arrayList);
            j2.c(viewGroup, u2);
            j2.y(viewGroup, arrayList2, arrayList, o2, aVar);
            A(k3, 0);
            j2.A(m2, arrayList2, arrayList);
        }
    }

    private static h p(h hVar, SparseArray<h> sparseArray, int i2) {
        if (hVar == null) {
            h hVar2 = new h();
            sparseArray.put(i2, hVar2);
            return hVar2;
        }
        return hVar;
    }

    private static Object q(v vVar, Fragment fragment, boolean z2) {
        if (fragment == null) {
            return null;
        }
        return vVar.g(z2 ? fragment.B() : fragment.q());
    }

    private static Object r(v vVar, Fragment fragment, boolean z2) {
        if (fragment == null) {
            return null;
        }
        return vVar.g(z2 ? fragment.E() : fragment.s());
    }

    static View s(l.a<String, View> aVar, h hVar, Object obj, boolean z2) {
        ArrayList<String> arrayList;
        androidx.fragment.app.a aVar2 = hVar.f1778c;
        if (obj == null || aVar == null || (arrayList = aVar2.f1727p) == null || arrayList.isEmpty()) {
            return null;
        }
        return aVar.get((z2 ? aVar2.f1727p : aVar2.f1728q).get(0));
    }

    private static Object t(v vVar, Fragment fragment, Fragment fragment2, boolean z2) {
        if (fragment == null || fragment2 == null) {
            return null;
        }
        return vVar.B(vVar.g(z2 ? fragment2.G() : fragment.F()));
    }

    private static Object u(v vVar, Object obj, Object obj2, Object obj3, Fragment fragment, boolean z2) {
        return (obj == null || obj2 == null || fragment == null) ? true : z2 ? fragment.k() : fragment.j() ? vVar.n(obj2, obj, obj3) : vVar.m(obj2, obj, obj3);
    }

    private static void v(v vVar, Object obj, Fragment fragment, ArrayList<View> arrayList) {
        if (fragment != null && obj != null && fragment.f1531l && fragment.f1545z && fragment.N) {
            fragment.j1(true);
            vVar.r(obj, fragment.M(), arrayList);
            e0.p.a(fragment.G, new b(arrayList));
        }
    }

    private static v w() {
        try {
            return (v) w0.e.class.getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
        } catch (Exception unused) {
            return null;
        }
    }

    private static void x(l.a<String, String> aVar, l.a<String, View> aVar2) {
        for (int size = aVar.size() - 1; size >= 0; size--) {
            if (!aVar2.containsKey(aVar.o(size))) {
                aVar.m(size);
            }
        }
    }

    private static void y(v vVar, ViewGroup viewGroup, Fragment fragment, View view, ArrayList<View> arrayList, Object obj, ArrayList<View> arrayList2, Object obj2, ArrayList<View> arrayList3) {
        e0.p.a(viewGroup, new d(obj, vVar, view, fragment, arrayList, arrayList2, arrayList3, obj2));
    }

    private static void z(v vVar, Object obj, Object obj2, l.a<String, View> aVar, boolean z2, androidx.fragment.app.a aVar2) {
        ArrayList<String> arrayList = aVar2.f1727p;
        if (arrayList == null || arrayList.isEmpty()) {
            return;
        }
        View view = aVar.get((z2 ? aVar2.f1728q : aVar2.f1727p).get(0));
        vVar.v(obj, view);
        if (obj2 != null) {
            vVar.v(obj2, view);
        }
    }
}
