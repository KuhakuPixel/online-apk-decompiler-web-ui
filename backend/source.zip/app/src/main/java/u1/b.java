package u1;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.q;
import androidx.lifecycle.r;
import androidx.lifecycle.s;
/* loaded from: classes.dex */
public class b extends r {

    /* renamed from: c  reason: collision with root package name */
    private final com.sample.android.kuhakupixelinapppurchase.a f5344c;

    /* loaded from: classes.dex */
    public static class a implements s.a {

        /* renamed from: a  reason: collision with root package name */
        private final com.sample.android.kuhakupixelinapppurchase.a f5345a;

        public a(com.sample.android.kuhakupixelinapppurchase.a aVar) {
            this.f5345a = aVar;
        }

        @Override // androidx.lifecycle.s.a
        public <T extends r> T a(Class<T> cls) {
            if (cls.isAssignableFrom(b.class)) {
                return new b(this.f5345a);
            }
            throw new IllegalArgumentException("Unknown ViewModel class");
        }
    }

    public b(com.sample.android.kuhakupixelinapppurchase.a aVar) {
        this.f5344c = aVar;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ Boolean j(Integer num) {
        return Boolean.valueOf(num.intValue() > 0);
    }

    public LiveData<Boolean> f() {
        return q.a(h(), new j.a() { // from class: u1.a
            @Override // j.a
            public final Object a(Object obj) {
                Boolean j2;
                j2 = b.j((Integer) obj);
                return j2;
            }
        });
    }

    public void g() {
        this.f5344c.m();
    }

    public LiveData<Integer> h() {
        return this.f5344c.n();
    }

    public LiveData<Boolean> i() {
        return this.f5344c.u("premium");
    }
}
