package androidx.appcompat.widget;

import android.view.MenuItem;
/* loaded from: classes.dex */
public interface h0 {
    void b(androidx.appcompat.view.menu.e eVar, MenuItem menuItem);

    void i(androidx.appcompat.view.menu.e eVar, MenuItem menuItem);
}
