package z0;

import java.util.AbstractMap;
/* loaded from: classes.dex */
final class c extends b0 {

    /* renamed from: d  reason: collision with root package name */
    final /* synthetic */ d f5678d;

    /* JADX INFO: Access modifiers changed from: package-private */
    public c(d dVar) {
        this.f5678d = dVar;
    }

    @Override // java.util.List
    public final /* bridge */ /* synthetic */ Object get(int i2) {
        int i3;
        Object[] objArr;
        Object[] objArr2;
        i3 = this.f5678d.f5684f;
        t.a(i2, i3, "index");
        d dVar = this.f5678d;
        int i4 = i2 + i2;
        objArr = dVar.f5683e;
        Object obj = objArr[i4];
        obj.getClass();
        objArr2 = dVar.f5683e;
        Object obj2 = objArr2[i4 + 1];
        obj2.getClass();
        return new AbstractMap.SimpleImmutableEntry(obj, obj2);
    }

    @Override // z0.y
    public final boolean h() {
        return true;
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public final int size() {
        int i2;
        i2 = this.f5678d.f5684f;
        return i2;
    }
}
