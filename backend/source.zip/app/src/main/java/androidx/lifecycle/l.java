package androidx.lifecycle;

import java.util.HashMap;
import java.util.Map;
/* loaded from: classes.dex */
public class l {

    /* renamed from: a  reason: collision with root package name */
    private Map<String, Integer> f1871a = new HashMap();
}
