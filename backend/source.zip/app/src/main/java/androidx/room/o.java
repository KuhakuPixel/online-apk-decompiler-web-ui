package androidx.room;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;
import androidx.room.j;
import androidx.room.k;
import androidx.room.n;
import java.util.Set;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicBoolean;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes.dex */
public class o {

    /* renamed from: a  reason: collision with root package name */
    final Context f2660a;

    /* renamed from: b  reason: collision with root package name */
    final String f2661b;

    /* renamed from: c  reason: collision with root package name */
    int f2662c;

    /* renamed from: d  reason: collision with root package name */
    final n f2663d;

    /* renamed from: e  reason: collision with root package name */
    final n.c f2664e;

    /* renamed from: f  reason: collision with root package name */
    k f2665f;

    /* renamed from: g  reason: collision with root package name */
    final Executor f2666g;

    /* renamed from: h  reason: collision with root package name */
    final j f2667h = new a();

    /* renamed from: i  reason: collision with root package name */
    final AtomicBoolean f2668i = new AtomicBoolean(false);

    /* renamed from: j  reason: collision with root package name */
    final ServiceConnection f2669j;

    /* renamed from: k  reason: collision with root package name */
    final Runnable f2670k;

    /* renamed from: l  reason: collision with root package name */
    final Runnable f2671l;

    /* loaded from: classes.dex */
    class a extends j.a {

        /* renamed from: androidx.room.o$a$a  reason: collision with other inner class name */
        /* loaded from: classes.dex */
        class RunnableC0022a implements Runnable {

            /* renamed from: b  reason: collision with root package name */
            final /* synthetic */ String[] f2673b;

            RunnableC0022a(String[] strArr) {
                this.f2673b = strArr;
            }

            @Override // java.lang.Runnable
            public void run() {
                o.this.f2663d.h(this.f2673b);
            }
        }

        a() {
        }

        @Override // androidx.room.j
        public void m(String[] strArr) {
            o.this.f2666g.execute(new RunnableC0022a(strArr));
        }
    }

    /* loaded from: classes.dex */
    class b implements ServiceConnection {
        b() {
        }

        @Override // android.content.ServiceConnection
        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            o.this.f2665f = k.a.p(iBinder);
            o oVar = o.this;
            oVar.f2666g.execute(oVar.f2670k);
        }

        @Override // android.content.ServiceConnection
        public void onServiceDisconnected(ComponentName componentName) {
            o oVar = o.this;
            oVar.f2666g.execute(oVar.f2671l);
            o.this.f2665f = null;
        }
    }

    /* loaded from: classes.dex */
    class c implements Runnable {
        c() {
        }

        @Override // java.lang.Runnable
        public void run() {
            try {
                o oVar = o.this;
                k kVar = oVar.f2665f;
                if (kVar != null) {
                    oVar.f2662c = kVar.a(oVar.f2667h, oVar.f2661b);
                    o oVar2 = o.this;
                    oVar2.f2663d.a(oVar2.f2664e);
                }
            } catch (RemoteException e2) {
                Log.w("ROOM", "Cannot register multi-instance invalidation callback", e2);
            }
        }
    }

    /* loaded from: classes.dex */
    class d implements Runnable {
        d() {
        }

        @Override // java.lang.Runnable
        public void run() {
            o oVar = o.this;
            oVar.f2663d.k(oVar.f2664e);
        }
    }

    /* loaded from: classes.dex */
    class e extends n.c {
        e(String[] strArr) {
            super(strArr);
        }

        @Override // androidx.room.n.c
        boolean a() {
            return true;
        }

        @Override // androidx.room.n.c
        public void b(Set<String> set) {
            if (o.this.f2668i.get()) {
                return;
            }
            try {
                o oVar = o.this;
                k kVar = oVar.f2665f;
                if (kVar != null) {
                    kVar.k(oVar.f2662c, (String[]) set.toArray(new String[0]));
                }
            } catch (RemoteException e2) {
                Log.w("ROOM", "Cannot broadcast invalidation", e2);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public o(Context context, String str, n nVar, Executor executor) {
        b bVar = new b();
        this.f2669j = bVar;
        this.f2670k = new c();
        this.f2671l = new d();
        Context applicationContext = context.getApplicationContext();
        this.f2660a = applicationContext;
        this.f2661b = str;
        this.f2663d = nVar;
        this.f2666g = executor;
        this.f2664e = new e((String[]) nVar.f2634a.keySet().toArray(new String[0]));
        applicationContext.bindService(new Intent(applicationContext, MultiInstanceInvalidationService.class), bVar, 1);
    }
}
