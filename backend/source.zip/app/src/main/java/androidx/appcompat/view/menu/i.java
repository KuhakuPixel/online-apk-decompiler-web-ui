package androidx.appcompat.view.menu;

import android.content.Context;
import android.graphics.Point;
import android.graphics.Rect;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.widget.PopupWindow;
import androidx.appcompat.view.menu.j;
import e0.q;
/* loaded from: classes.dex */
public class i {

    /* renamed from: a  reason: collision with root package name */
    private final Context f445a;

    /* renamed from: b  reason: collision with root package name */
    private final e f446b;

    /* renamed from: c  reason: collision with root package name */
    private final boolean f447c;

    /* renamed from: d  reason: collision with root package name */
    private final int f448d;

    /* renamed from: e  reason: collision with root package name */
    private final int f449e;

    /* renamed from: f  reason: collision with root package name */
    private View f450f;

    /* renamed from: g  reason: collision with root package name */
    private int f451g;

    /* renamed from: h  reason: collision with root package name */
    private boolean f452h;

    /* renamed from: i  reason: collision with root package name */
    private j.a f453i;

    /* renamed from: j  reason: collision with root package name */
    private h f454j;

    /* renamed from: k  reason: collision with root package name */
    private PopupWindow.OnDismissListener f455k;

    /* renamed from: l  reason: collision with root package name */
    private final PopupWindow.OnDismissListener f456l;

    /* loaded from: classes.dex */
    class a implements PopupWindow.OnDismissListener {
        a() {
        }

        @Override // android.widget.PopupWindow.OnDismissListener
        public void onDismiss() {
            i.this.e();
        }
    }

    public i(Context context, e eVar, View view, boolean z2, int i2) {
        this(context, eVar, view, z2, i2, 0);
    }

    public i(Context context, e eVar, View view, boolean z2, int i2, int i3) {
        this.f451g = 8388611;
        this.f456l = new a();
        this.f445a = context;
        this.f446b = eVar;
        this.f450f = view;
        this.f447c = z2;
        this.f448d = i2;
        this.f449e = i3;
    }

    private h a() {
        Display defaultDisplay = ((WindowManager) this.f445a.getSystemService("window")).getDefaultDisplay();
        Point point = new Point();
        defaultDisplay.getRealSize(point);
        h bVar = Math.min(point.x, point.y) >= this.f445a.getResources().getDimensionPixelSize(a.d.abc_cascading_menus_min_smallest_width) ? new b(this.f445a, this.f450f, this.f448d, this.f449e, this.f447c) : new l(this.f445a, this.f446b, this.f450f, this.f448d, this.f449e, this.f447c);
        bVar.k(this.f446b);
        bVar.u(this.f456l);
        bVar.p(this.f450f);
        bVar.h(this.f453i);
        bVar.r(this.f452h);
        bVar.s(this.f451g);
        return bVar;
    }

    private void l(int i2, int i3, boolean z2, boolean z3) {
        h c2 = c();
        c2.v(z3);
        if (z2) {
            if ((e0.d.b(this.f451g, q.B(this.f450f)) & 7) == 5) {
                i2 -= this.f450f.getWidth();
            }
            c2.t(i2);
            c2.w(i3);
            int i4 = (int) ((this.f445a.getResources().getDisplayMetrics().density * 48.0f) / 2.0f);
            c2.q(new Rect(i2 - i4, i3 - i4, i2 + i4, i3 + i4));
        }
        c2.a();
    }

    public void b() {
        if (d()) {
            this.f454j.dismiss();
        }
    }

    public h c() {
        if (this.f454j == null) {
            this.f454j = a();
        }
        return this.f454j;
    }

    public boolean d() {
        h hVar = this.f454j;
        return hVar != null && hVar.c();
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public void e() {
        this.f454j = null;
        PopupWindow.OnDismissListener onDismissListener = this.f455k;
        if (onDismissListener != null) {
            onDismissListener.onDismiss();
        }
    }

    public void f(View view) {
        this.f450f = view;
    }

    public void g(boolean z2) {
        this.f452h = z2;
        h hVar = this.f454j;
        if (hVar != null) {
            hVar.r(z2);
        }
    }

    public void h(int i2) {
        this.f451g = i2;
    }

    public void i(PopupWindow.OnDismissListener onDismissListener) {
        this.f455k = onDismissListener;
    }

    public void j(j.a aVar) {
        this.f453i = aVar;
        h hVar = this.f454j;
        if (hVar != null) {
            hVar.h(aVar);
        }
    }

    public void k() {
        if (!m()) {
            throw new IllegalStateException("MenuPopupHelper cannot be used without an anchor");
        }
    }

    public boolean m() {
        if (d()) {
            return true;
        }
        if (this.f450f == null) {
            return false;
        }
        l(0, 0, false, false);
        return true;
    }

    public boolean n(int i2, int i3) {
        if (d()) {
            return true;
        }
        if (this.f450f == null) {
            return false;
        }
        l(i2, i3, true, true);
        return true;
    }
}
