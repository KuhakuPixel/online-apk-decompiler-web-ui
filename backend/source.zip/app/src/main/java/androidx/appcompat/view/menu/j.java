package androidx.appcompat.view.menu;

import android.content.Context;
/* loaded from: classes.dex */
public interface j {

    /* loaded from: classes.dex */
    public interface a {
        void b(e eVar, boolean z2);

        boolean c(e eVar);
    }

    void b(e eVar, boolean z2);

    boolean d();

    void e(Context context, e eVar);

    boolean f(e eVar, g gVar);

    boolean g(e eVar, g gVar);

    void h(a aVar);

    boolean i(m mVar);

    void j(boolean z2);
}
