package q;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
/* loaded from: classes.dex */
public class f implements d {

    /* renamed from: d  reason: collision with root package name */
    p f5010d;

    /* renamed from: f  reason: collision with root package name */
    int f5012f;

    /* renamed from: g  reason: collision with root package name */
    public int f5013g;

    /* renamed from: a  reason: collision with root package name */
    public d f5007a = null;

    /* renamed from: b  reason: collision with root package name */
    public boolean f5008b = false;

    /* renamed from: c  reason: collision with root package name */
    public boolean f5009c = false;

    /* renamed from: e  reason: collision with root package name */
    a f5011e = a.UNKNOWN;

    /* renamed from: h  reason: collision with root package name */
    int f5014h = 1;

    /* renamed from: i  reason: collision with root package name */
    g f5015i = null;

    /* renamed from: j  reason: collision with root package name */
    public boolean f5016j = false;

    /* renamed from: k  reason: collision with root package name */
    List<d> f5017k = new ArrayList();

    /* renamed from: l  reason: collision with root package name */
    List<f> f5018l = new ArrayList();

    /* loaded from: classes.dex */
    enum a {
        UNKNOWN,
        HORIZONTAL_DIMENSION,
        VERTICAL_DIMENSION,
        LEFT,
        RIGHT,
        TOP,
        BOTTOM,
        BASELINE
    }

    public f(p pVar) {
        this.f5010d = pVar;
    }

    @Override // q.d
    public void a(d dVar) {
        Iterator<f> it = this.f5018l.iterator();
        while (it.hasNext()) {
            if (!it.next().f5016j) {
                return;
            }
        }
        this.f5009c = true;
        d dVar2 = this.f5007a;
        if (dVar2 != null) {
            dVar2.a(this);
        }
        if (this.f5008b) {
            this.f5010d.a(this);
            return;
        }
        f fVar = null;
        int i2 = 0;
        for (f fVar2 : this.f5018l) {
            if (!(fVar2 instanceof g)) {
                i2++;
                fVar = fVar2;
            }
        }
        if (fVar != null && i2 == 1 && fVar.f5016j) {
            g gVar = this.f5015i;
            if (gVar != null) {
                if (!gVar.f5016j) {
                    return;
                }
                this.f5012f = this.f5014h * gVar.f5013g;
            }
            d(fVar.f5013g + this.f5012f);
        }
        d dVar3 = this.f5007a;
        if (dVar3 != null) {
            dVar3.a(this);
        }
    }

    public void b(d dVar) {
        this.f5017k.add(dVar);
        if (this.f5016j) {
            dVar.a(dVar);
        }
    }

    public void c() {
        this.f5018l.clear();
        this.f5017k.clear();
        this.f5016j = false;
        this.f5013g = 0;
        this.f5009c = false;
        this.f5008b = false;
    }

    public void d(int i2) {
        if (this.f5016j) {
            return;
        }
        this.f5016j = true;
        this.f5013g = i2;
        for (d dVar : this.f5017k) {
            dVar.a(dVar);
        }
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(this.f5010d.f5059b.r());
        sb.append(":");
        sb.append(this.f5011e);
        sb.append("(");
        sb.append(this.f5016j ? Integer.valueOf(this.f5013g) : "unresolved");
        sb.append(") <t=");
        sb.append(this.f5018l.size());
        sb.append(":d=");
        sb.append(this.f5017k.size());
        sb.append(">");
        return sb.toString();
    }
}
