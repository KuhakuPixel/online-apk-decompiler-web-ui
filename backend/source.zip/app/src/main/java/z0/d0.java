package z0;

import java.util.Arrays;
/* loaded from: classes.dex */
public final class d0 {

    /* renamed from: a  reason: collision with root package name */
    Object[] f5685a = new Object[8];

    /* renamed from: b  reason: collision with root package name */
    int f5686b = 0;

    /* renamed from: c  reason: collision with root package name */
    c0 f5687c;

    public final d0 a(Object obj, Object obj2) {
        int i2 = this.f5686b + 1;
        int i3 = i2 + i2;
        Object[] objArr = this.f5685a;
        int length = objArr.length;
        if (i3 > length) {
            int i4 = length + (length >> 1) + 1;
            if (i4 < i3) {
                int highestOneBit = Integer.highestOneBit(i3 - 1);
                i4 = highestOneBit + highestOneBit;
            }
            if (i4 < 0) {
                i4 = Integer.MAX_VALUE;
            }
            this.f5685a = Arrays.copyOf(objArr, i4);
        }
        w.a(obj, obj2);
        Object[] objArr2 = this.f5685a;
        int i5 = this.f5686b;
        int i6 = i5 + i5;
        objArr2[i6] = obj;
        objArr2[i6 + 1] = obj2;
        this.f5686b = i5 + 1;
        return this;
    }

    public final e0 b() {
        c0 c0Var = this.f5687c;
        if (c0Var == null) {
            g h2 = g.h(this.f5686b, this.f5685a, this);
            c0 c0Var2 = this.f5687c;
            if (c0Var2 == null) {
                return h2;
            }
            throw c0Var2.a();
        }
        throw c0Var.a();
    }
}
