package androidx.databinding;

import java.util.List;
/* loaded from: classes.dex */
public interface h<T> extends List<T> {

    /* loaded from: classes.dex */
    public static abstract class a<T extends h> {
    }

    void a(a<? extends h<T>> aVar);

    void b(a<? extends h<T>> aVar);
}
