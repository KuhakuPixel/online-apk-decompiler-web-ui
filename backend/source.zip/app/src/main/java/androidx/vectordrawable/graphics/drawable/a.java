package androidx.vectordrawable.graphics.drawable;
/* loaded from: classes.dex */
class a {

    /* renamed from: a  reason: collision with root package name */
    static final int[] f2712a = {16842755, 16843041, 16843093, 16843097, 16843551, 16843754, 16843771, 16843778, 16843779};

    /* renamed from: b  reason: collision with root package name */
    static final int[] f2713b = {16842755, 16843189, 16843190, 16843556, 16843557, 16843558, 16843866, 16843867};

    /* renamed from: c  reason: collision with root package name */
    static final int[] f2714c = {16842755, 16843780, 16843781, 16843782, 16843783, 16843784, 16843785, 16843786, 16843787, 16843788, 16843789, 16843979, 16843980, 16844062};

    /* renamed from: d  reason: collision with root package name */
    static final int[] f2715d = {16842755, 16843781, 16844062};

    /* renamed from: e  reason: collision with root package name */
    static final int[] f2716e = {16843161};

    /* renamed from: f  reason: collision with root package name */
    static final int[] f2717f = {16842755, 16843213};

    /* renamed from: g  reason: collision with root package name */
    public static final int[] f2718g = {16843073, 16843160, 16843198, 16843199, 16843200, 16843486, 16843487, 16843488};

    /* renamed from: h  reason: collision with root package name */
    public static final int[] f2719h = {16843490};

    /* renamed from: i  reason: collision with root package name */
    public static final int[] f2720i = {16843486, 16843487, 16843488, 16843489};

    /* renamed from: j  reason: collision with root package name */
    public static final int[] f2721j = {16842788, 16843073, 16843488, 16843992};

    /* renamed from: k  reason: collision with root package name */
    public static final int[] f2722k = {16843489, 16843781, 16843892, 16843893};

    /* renamed from: l  reason: collision with root package name */
    public static final int[] f2723l = {16843772, 16843773, 16843774, 16843775, 16843781};
}
