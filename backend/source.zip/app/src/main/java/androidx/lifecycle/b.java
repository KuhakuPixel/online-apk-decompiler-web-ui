package androidx.lifecycle;
/* loaded from: classes.dex */
interface b extends f {
    void a(g gVar);

    void b(g gVar);

    void c(g gVar);

    void g(g gVar);

    void h(g gVar);

    void j(g gVar);
}
