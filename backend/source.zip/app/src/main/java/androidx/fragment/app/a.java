package androidx.fragment.app;

import android.util.Log;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.l;
import androidx.fragment.app.s;
import java.io.PrintWriter;
import java.util.ArrayList;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes.dex */
public final class a extends s implements l.g {

    /* renamed from: t  reason: collision with root package name */
    final l f1569t;

    /* renamed from: u  reason: collision with root package name */
    boolean f1570u;

    /* renamed from: v  reason: collision with root package name */
    int f1571v;

    /* JADX INFO: Access modifiers changed from: package-private */
    /* JADX WARN: Illegal instructions before constructor call */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public a(androidx.fragment.app.l r3) {
        /*
            r2 = this;
            androidx.fragment.app.h r0 = r3.e0()
            androidx.fragment.app.i<?> r1 = r3.f1654o
            if (r1 == 0) goto L11
            android.content.Context r1 = r1.i()
            java.lang.ClassLoader r1 = r1.getClassLoader()
            goto L12
        L11:
            r1 = 0
        L12:
            r2.<init>(r0, r1)
            r0 = -1
            r2.f1571v = r0
            r2.f1569t = r3
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.fragment.app.a.<init>(androidx.fragment.app.l):void");
    }

    private static boolean D(s.a aVar) {
        Fragment fragment = aVar.f1732b;
        return (fragment == null || !fragment.f1531l || fragment.H == null || fragment.A || fragment.f1545z || !fragment.S()) ? false : true;
    }

    public String A() {
        return this.f1722k;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public boolean B(int i2) {
        int size = this.f1714c.size();
        for (int i3 = 0; i3 < size; i3++) {
            Fragment fragment = this.f1714c.get(i3).f1732b;
            int i4 = fragment != null ? fragment.f1543x : 0;
            if (i4 != 0 && i4 == i2) {
                return true;
            }
        }
        return false;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public boolean C(ArrayList<a> arrayList, int i2, int i3) {
        if (i3 == i2) {
            return false;
        }
        int size = this.f1714c.size();
        int i4 = -1;
        for (int i5 = 0; i5 < size; i5++) {
            Fragment fragment = this.f1714c.get(i5).f1732b;
            int i6 = fragment != null ? fragment.f1543x : 0;
            if (i6 != 0 && i6 != i4) {
                for (int i7 = i2; i7 < i3; i7++) {
                    a aVar = arrayList.get(i7);
                    int size2 = aVar.f1714c.size();
                    for (int i8 = 0; i8 < size2; i8++) {
                        Fragment fragment2 = aVar.f1714c.get(i8).f1732b;
                        if ((fragment2 != null ? fragment2.f1543x : 0) == i6) {
                            return true;
                        }
                    }
                }
                i4 = i6;
            }
        }
        return false;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public boolean E() {
        for (int i2 = 0; i2 < this.f1714c.size(); i2++) {
            if (D(this.f1714c.get(i2))) {
                return true;
            }
        }
        return false;
    }

    public void F() {
        if (this.f1730s != null) {
            for (int i2 = 0; i2 < this.f1730s.size(); i2++) {
                this.f1730s.get(i2).run();
            }
            this.f1730s = null;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void G(Fragment.f fVar) {
        for (int i2 = 0; i2 < this.f1714c.size(); i2++) {
            s.a aVar = this.f1714c.get(i2);
            if (D(aVar)) {
                aVar.f1732b.m1(fVar);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public Fragment H(ArrayList<Fragment> arrayList, Fragment fragment) {
        for (int size = this.f1714c.size() - 1; size >= 0; size--) {
            s.a aVar = this.f1714c.get(size);
            int i2 = aVar.f1731a;
            if (i2 != 1) {
                if (i2 != 3) {
                    switch (i2) {
                        case 8:
                            fragment = null;
                            break;
                        case 9:
                            fragment = aVar.f1732b;
                            break;
                        case 10:
                            aVar.f1738h = aVar.f1737g;
                            break;
                    }
                }
                arrayList.add(aVar.f1732b);
            }
            arrayList.remove(aVar.f1732b);
        }
        return fragment;
    }

    @Override // androidx.fragment.app.l.g
    public boolean a(ArrayList<a> arrayList, ArrayList<Boolean> arrayList2) {
        if (l.p0(2)) {
            Log.v("FragmentManager", "Run: " + this);
        }
        arrayList.add(this);
        arrayList2.add(Boolean.FALSE);
        if (this.f1720i) {
            this.f1569t.b(this);
            return true;
        }
        return true;
    }

    @Override // androidx.fragment.app.s
    public int h() {
        return u(false);
    }

    @Override // androidx.fragment.app.s
    public int i() {
        return u(true);
    }

    @Override // androidx.fragment.app.s
    public void j() {
        l();
        this.f1569t.R(this, false);
    }

    @Override // androidx.fragment.app.s
    public void k() {
        l();
        this.f1569t.R(this, true);
    }

    @Override // androidx.fragment.app.s
    void m(int i2, Fragment fragment, String str, int i3) {
        super.m(i2, fragment, str, i3);
        fragment.f1538s = this.f1569t;
    }

    @Override // androidx.fragment.app.s
    public s n(Fragment fragment) {
        l lVar = fragment.f1538s;
        if (lVar == null || lVar == this.f1569t) {
            return super.n(fragment);
        }
        throw new IllegalStateException("Cannot remove Fragment attached to a different FragmentManager. Fragment " + fragment.toString() + " is already attached to a FragmentManager.");
    }

    @Override // androidx.fragment.app.s
    public s r(Fragment fragment) {
        l lVar;
        if (fragment == null || (lVar = fragment.f1538s) == null || lVar == this.f1569t) {
            return super.r(fragment);
        }
        throw new IllegalStateException("Cannot setPrimaryNavigation for Fragment attached to a different FragmentManager. Fragment " + fragment.toString() + " is already attached to a FragmentManager.");
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void t(int i2) {
        if (this.f1720i) {
            if (l.p0(2)) {
                Log.v("FragmentManager", "Bump nesting in " + this + " by " + i2);
            }
            int size = this.f1714c.size();
            for (int i3 = 0; i3 < size; i3++) {
                s.a aVar = this.f1714c.get(i3);
                Fragment fragment = aVar.f1732b;
                if (fragment != null) {
                    fragment.f1537r += i2;
                    if (l.p0(2)) {
                        Log.v("FragmentManager", "Bump nesting of " + aVar.f1732b + " to " + aVar.f1732b.f1537r);
                    }
                }
            }
        }
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append("BackStackEntry{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        if (this.f1571v >= 0) {
            sb.append(" #");
            sb.append(this.f1571v);
        }
        if (this.f1722k != null) {
            sb.append(" ");
            sb.append(this.f1722k);
        }
        sb.append("}");
        return sb.toString();
    }

    int u(boolean z2) {
        if (this.f1570u) {
            throw new IllegalStateException("commit already called");
        }
        if (l.p0(2)) {
            Log.v("FragmentManager", "Commit: " + this);
            PrintWriter printWriter = new PrintWriter(new d0.b("FragmentManager"));
            v("  ", printWriter);
            printWriter.close();
        }
        this.f1570u = true;
        this.f1571v = this.f1720i ? this.f1569t.f() : -1;
        this.f1569t.O(this, z2);
        return this.f1571v;
    }

    public void v(String str, PrintWriter printWriter) {
        w(str, printWriter, true);
    }

    public void w(String str, PrintWriter printWriter, boolean z2) {
        String str2;
        if (z2) {
            printWriter.print(str);
            printWriter.print("mName=");
            printWriter.print(this.f1722k);
            printWriter.print(" mIndex=");
            printWriter.print(this.f1571v);
            printWriter.print(" mCommitted=");
            printWriter.println(this.f1570u);
            if (this.f1719h != 0) {
                printWriter.print(str);
                printWriter.print("mTransition=#");
                printWriter.print(Integer.toHexString(this.f1719h));
            }
            if (this.f1715d != 0 || this.f1716e != 0) {
                printWriter.print(str);
                printWriter.print("mEnterAnim=#");
                printWriter.print(Integer.toHexString(this.f1715d));
                printWriter.print(" mExitAnim=#");
                printWriter.println(Integer.toHexString(this.f1716e));
            }
            if (this.f1717f != 0 || this.f1718g != 0) {
                printWriter.print(str);
                printWriter.print("mPopEnterAnim=#");
                printWriter.print(Integer.toHexString(this.f1717f));
                printWriter.print(" mPopExitAnim=#");
                printWriter.println(Integer.toHexString(this.f1718g));
            }
            if (this.f1723l != 0 || this.f1724m != null) {
                printWriter.print(str);
                printWriter.print("mBreadCrumbTitleRes=#");
                printWriter.print(Integer.toHexString(this.f1723l));
                printWriter.print(" mBreadCrumbTitleText=");
                printWriter.println(this.f1724m);
            }
            if (this.f1725n != 0 || this.f1726o != null) {
                printWriter.print(str);
                printWriter.print("mBreadCrumbShortTitleRes=#");
                printWriter.print(Integer.toHexString(this.f1725n));
                printWriter.print(" mBreadCrumbShortTitleText=");
                printWriter.println(this.f1726o);
            }
        }
        if (this.f1714c.isEmpty()) {
            return;
        }
        printWriter.print(str);
        printWriter.println("Operations:");
        int size = this.f1714c.size();
        for (int i2 = 0; i2 < size; i2++) {
            s.a aVar = this.f1714c.get(i2);
            switch (aVar.f1731a) {
                case 0:
                    str2 = "NULL";
                    break;
                case 1:
                    str2 = "ADD";
                    break;
                case 2:
                    str2 = "REPLACE";
                    break;
                case 3:
                    str2 = "REMOVE";
                    break;
                case 4:
                    str2 = "HIDE";
                    break;
                case 5:
                    str2 = "SHOW";
                    break;
                case 6:
                    str2 = "DETACH";
                    break;
                case 7:
                    str2 = "ATTACH";
                    break;
                case 8:
                    str2 = "SET_PRIMARY_NAV";
                    break;
                case 9:
                    str2 = "UNSET_PRIMARY_NAV";
                    break;
                case 10:
                    str2 = "OP_SET_MAX_LIFECYCLE";
                    break;
                default:
                    str2 = "cmd=" + aVar.f1731a;
                    break;
            }
            printWriter.print(str);
            printWriter.print("  Op #");
            printWriter.print(i2);
            printWriter.print(": ");
            printWriter.print(str2);
            printWriter.print(" ");
            printWriter.println(aVar.f1732b);
            if (z2) {
                if (aVar.f1733c != 0 || aVar.f1734d != 0) {
                    printWriter.print(str);
                    printWriter.print("enterAnim=#");
                    printWriter.print(Integer.toHexString(aVar.f1733c));
                    printWriter.print(" exitAnim=#");
                    printWriter.println(Integer.toHexString(aVar.f1734d));
                }
                if (aVar.f1735e != 0 || aVar.f1736f != 0) {
                    printWriter.print(str);
                    printWriter.print("popEnterAnim=#");
                    printWriter.print(Integer.toHexString(aVar.f1735e));
                    printWriter.print(" popExitAnim=#");
                    printWriter.println(Integer.toHexString(aVar.f1736f));
                }
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void x() {
        int size = this.f1714c.size();
        for (int i2 = 0; i2 < size; i2++) {
            s.a aVar = this.f1714c.get(i2);
            Fragment fragment = aVar.f1732b;
            if (fragment != null) {
                fragment.l1(this.f1719h);
            }
            switch (aVar.f1731a) {
                case 1:
                    fragment.k1(aVar.f1733c);
                    this.f1569t.S0(fragment, false);
                    this.f1569t.d(fragment);
                    break;
                case 2:
                default:
                    throw new IllegalArgumentException("Unknown cmd: " + aVar.f1731a);
                case 3:
                    fragment.k1(aVar.f1734d);
                    this.f1569t.K0(fragment);
                    break;
                case 4:
                    fragment.k1(aVar.f1734d);
                    this.f1569t.n0(fragment);
                    break;
                case 5:
                    fragment.k1(aVar.f1733c);
                    this.f1569t.S0(fragment, false);
                    this.f1569t.W0(fragment);
                    break;
                case 6:
                    fragment.k1(aVar.f1734d);
                    this.f1569t.q(fragment);
                    break;
                case 7:
                    fragment.k1(aVar.f1733c);
                    this.f1569t.S0(fragment, false);
                    this.f1569t.h(fragment);
                    break;
                case 8:
                    this.f1569t.U0(fragment);
                    break;
                case 9:
                    this.f1569t.U0(null);
                    break;
                case 10:
                    this.f1569t.T0(fragment, aVar.f1738h);
                    break;
            }
            if (!this.f1729r && aVar.f1731a != 1 && fragment != null) {
                this.f1569t.x0(fragment);
            }
        }
        if (this.f1729r) {
            return;
        }
        l lVar = this.f1569t;
        lVar.y0(lVar.f1653n, true);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void y(boolean z2) {
        for (int size = this.f1714c.size() - 1; size >= 0; size--) {
            s.a aVar = this.f1714c.get(size);
            Fragment fragment = aVar.f1732b;
            if (fragment != null) {
                fragment.l1(l.P0(this.f1719h));
            }
            switch (aVar.f1731a) {
                case 1:
                    fragment.k1(aVar.f1736f);
                    this.f1569t.S0(fragment, true);
                    this.f1569t.K0(fragment);
                    break;
                case 2:
                default:
                    throw new IllegalArgumentException("Unknown cmd: " + aVar.f1731a);
                case 3:
                    fragment.k1(aVar.f1735e);
                    this.f1569t.d(fragment);
                    break;
                case 4:
                    fragment.k1(aVar.f1735e);
                    this.f1569t.W0(fragment);
                    break;
                case 5:
                    fragment.k1(aVar.f1736f);
                    this.f1569t.S0(fragment, true);
                    this.f1569t.n0(fragment);
                    break;
                case 6:
                    fragment.k1(aVar.f1735e);
                    this.f1569t.h(fragment);
                    break;
                case 7:
                    fragment.k1(aVar.f1736f);
                    this.f1569t.S0(fragment, true);
                    this.f1569t.q(fragment);
                    break;
                case 8:
                    this.f1569t.U0(null);
                    break;
                case 9:
                    this.f1569t.U0(fragment);
                    break;
                case 10:
                    this.f1569t.T0(fragment, aVar.f1737g);
                    break;
            }
            if (!this.f1729r && aVar.f1731a != 3 && fragment != null) {
                this.f1569t.x0(fragment);
            }
        }
        if (this.f1729r || !z2) {
            return;
        }
        l lVar = this.f1569t;
        lVar.y0(lVar.f1653n, true);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public Fragment z(ArrayList<Fragment> arrayList, Fragment fragment) {
        Fragment fragment2 = fragment;
        int i2 = 0;
        while (i2 < this.f1714c.size()) {
            s.a aVar = this.f1714c.get(i2);
            int i3 = aVar.f1731a;
            if (i3 != 1) {
                if (i3 == 2) {
                    Fragment fragment3 = aVar.f1732b;
                    int i4 = fragment3.f1543x;
                    boolean z2 = false;
                    for (int size = arrayList.size() - 1; size >= 0; size--) {
                        Fragment fragment4 = arrayList.get(size);
                        if (fragment4.f1543x == i4) {
                            if (fragment4 == fragment3) {
                                z2 = true;
                            } else {
                                if (fragment4 == fragment2) {
                                    this.f1714c.add(i2, new s.a(9, fragment4));
                                    i2++;
                                    fragment2 = null;
                                }
                                s.a aVar2 = new s.a(3, fragment4);
                                aVar2.f1733c = aVar.f1733c;
                                aVar2.f1735e = aVar.f1735e;
                                aVar2.f1734d = aVar.f1734d;
                                aVar2.f1736f = aVar.f1736f;
                                this.f1714c.add(i2, aVar2);
                                arrayList.remove(fragment4);
                                i2++;
                            }
                        }
                    }
                    if (z2) {
                        this.f1714c.remove(i2);
                        i2--;
                    } else {
                        aVar.f1731a = 1;
                        arrayList.add(fragment3);
                    }
                } else if (i3 == 3 || i3 == 6) {
                    arrayList.remove(aVar.f1732b);
                    Fragment fragment5 = aVar.f1732b;
                    if (fragment5 == fragment2) {
                        this.f1714c.add(i2, new s.a(9, fragment5));
                        i2++;
                        fragment2 = null;
                    }
                } else if (i3 != 7) {
                    if (i3 == 8) {
                        this.f1714c.add(i2, new s.a(9, fragment2));
                        i2++;
                        fragment2 = aVar.f1732b;
                    }
                }
                i2++;
            }
            arrayList.add(aVar.f1732b);
            i2++;
        }
        return fragment2;
    }
}
