package w1;

import android.view.View;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.databinding.ViewDataBinding;
import com.sample.android.kuhakupixelinapppurchase.ui.MakePurchaseFragment;
import u1.d;
/* loaded from: classes.dex */
public abstract class i extends ViewDataBinding {
    public final AppCompatTextView B;
    public final AppCompatImageView C;
    public final AppCompatTextView D;
    public final AppCompatTextView E;
    protected String F;
    protected d.b G;
    protected MakePurchaseFragment H;

    /* JADX INFO: Access modifiers changed from: protected */
    public i(Object obj, View view, int i2, AppCompatTextView appCompatTextView, AppCompatImageView appCompatImageView, AppCompatTextView appCompatTextView2, AppCompatTextView appCompatTextView3) {
        super(obj, view, i2);
        this.B = appCompatTextView;
        this.C = appCompatImageView;
        this.D = appCompatTextView2;
        this.E = appCompatTextView3;
    }

    public abstract void H(MakePurchaseFragment makePurchaseFragment);

    public abstract void I(String str);

    public abstract void J(d.b bVar);
}
