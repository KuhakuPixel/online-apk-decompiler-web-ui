package z0;

import java.util.Iterator;
import javax.annotation.CheckForNull;
/* loaded from: classes.dex */
final class e extends f0 {

    /* renamed from: d  reason: collision with root package name */
    private final transient e0 f5688d;

    /* renamed from: e  reason: collision with root package name */
    private final transient b0 f5689e;

    /* JADX INFO: Access modifiers changed from: package-private */
    public e(e0 e0Var, b0 b0Var) {
        this.f5688d = e0Var;
        this.f5689e = b0Var;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    @Override // z0.y
    public final int c(Object[] objArr, int i2) {
        return this.f5689e.c(objArr, 0);
    }

    @Override // z0.y, java.util.AbstractCollection, java.util.Collection, java.util.List
    public final boolean contains(@CheckForNull Object obj) {
        return this.f5688d.get(obj) != null;
    }

    @Override // z0.f0, z0.y
    public final b0 f() {
        return this.f5689e;
    }

    @Override // z0.y
    /* renamed from: g */
    public final i iterator() {
        return this.f5689e.listIterator(0);
    }

    @Override // z0.y, java.util.AbstractCollection, java.util.Collection, java.lang.Iterable, java.util.List
    public final /* synthetic */ Iterator iterator() {
        return this.f5689e.listIterator(0);
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
    public final int size() {
        return this.f5688d.size();
    }
}
