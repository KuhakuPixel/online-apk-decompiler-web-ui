package a1;
/* loaded from: classes.dex */
public final class i {

    /* renamed from: a */
    public static final int bottomsheet_action_expand_halfway = 2131820576;

    /* renamed from: b */
    public static final int character_counter_content_description = 2131820579;

    /* renamed from: c */
    public static final int character_counter_overflowed_content_description = 2131820580;

    /* renamed from: d */
    public static final int character_counter_pattern = 2131820581;

    /* renamed from: e */
    public static final int clear_text_end_icon_content_description = 2131820583;

    /* renamed from: f */
    public static final int error_icon_content_description = 2131820589;

    /* renamed from: g */
    public static final int exposed_dropdown_menu_content_description = 2131820591;

    /* renamed from: h */
    public static final int mtrl_chip_close_icon_content_description = 2131820623;

    /* renamed from: i */
    public static final int mtrl_picker_announce_current_selection = 2131820628;

    /* renamed from: j */
    public static final int mtrl_picker_day_of_week_column_header = 2131820634;

    /* renamed from: k */
    public static final int mtrl_picker_navigate_to_year_description = 2131820639;

    /* renamed from: l */
    public static final int mtrl_picker_toggle_to_calendar_input_mode = 2131820653;

    /* renamed from: m */
    public static final int mtrl_picker_toggle_to_day_selection = 2131820654;

    /* renamed from: n */
    public static final int mtrl_picker_toggle_to_text_input_mode = 2131820655;

    /* renamed from: o */
    public static final int mtrl_picker_toggle_to_year_selection = 2131820656;

    /* renamed from: p */
    public static final int password_toggle_content_description = 2131820659;
}
