package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.RectF;
import android.os.Build;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextDirectionHeuristic;
import android.text.TextDirectionHeuristics;
import android.text.TextPaint;
import android.text.method.TransformationMethod;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.widget.TextView;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.concurrent.ConcurrentHashMap;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes.dex */
public class y {

    /* renamed from: l  reason: collision with root package name */
    private static final RectF f1005l = new RectF();

    /* renamed from: m  reason: collision with root package name */
    private static ConcurrentHashMap<String, Method> f1006m = new ConcurrentHashMap<>();

    /* renamed from: n  reason: collision with root package name */
    private static ConcurrentHashMap<String, Field> f1007n = new ConcurrentHashMap<>();

    /* renamed from: a  reason: collision with root package name */
    private int f1008a = 0;

    /* renamed from: b  reason: collision with root package name */
    private boolean f1009b = false;

    /* renamed from: c  reason: collision with root package name */
    private float f1010c = -1.0f;

    /* renamed from: d  reason: collision with root package name */
    private float f1011d = -1.0f;

    /* renamed from: e  reason: collision with root package name */
    private float f1012e = -1.0f;

    /* renamed from: f  reason: collision with root package name */
    private int[] f1013f = new int[0];

    /* renamed from: g  reason: collision with root package name */
    private boolean f1014g = false;

    /* renamed from: h  reason: collision with root package name */
    private TextPaint f1015h;

    /* renamed from: i  reason: collision with root package name */
    private final TextView f1016i;

    /* renamed from: j  reason: collision with root package name */
    private final Context f1017j;

    /* renamed from: k  reason: collision with root package name */
    private final c f1018k;

    /* loaded from: classes.dex */
    private static class a extends c {
        a() {
        }

        @Override // androidx.appcompat.widget.y.c
        void a(StaticLayout.Builder builder, TextView textView) {
            builder.setTextDirection((TextDirectionHeuristic) y.o(textView, "getTextDirectionHeuristic", TextDirectionHeuristics.FIRSTSTRONG_LTR));
        }
    }

    /* loaded from: classes.dex */
    private static class b extends a {
        b() {
        }

        @Override // androidx.appcompat.widget.y.a, androidx.appcompat.widget.y.c
        void a(StaticLayout.Builder builder, TextView textView) {
            builder.setTextDirection(textView.getTextDirectionHeuristic());
        }

        @Override // androidx.appcompat.widget.y.c
        boolean b(TextView textView) {
            return textView.isHorizontallyScrollable();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public static class c {
        c() {
        }

        void a(StaticLayout.Builder builder, TextView textView) {
        }

        boolean b(TextView textView) {
            return ((Boolean) y.o(textView, "getHorizontallyScrolling", Boolean.FALSE)).booleanValue();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public y(TextView textView) {
        this.f1016i = textView;
        this.f1017j = textView.getContext();
        int i2 = Build.VERSION.SDK_INT;
        this.f1018k = i2 >= 29 ? new b() : i2 >= 23 ? new a() : new c();
    }

    private boolean A() {
        return !(this.f1016i instanceof k);
    }

    private void B(float f2, float f3, float f4) {
        if (f2 <= 0.0f) {
            throw new IllegalArgumentException("Minimum auto-size text size (" + f2 + "px) is less or equal to (0px)");
        } else if (f3 <= f2) {
            throw new IllegalArgumentException("Maximum auto-size text size (" + f3 + "px) is less or equal to minimum auto-size text size (" + f2 + "px)");
        } else if (f4 <= 0.0f) {
            throw new IllegalArgumentException("The auto-size step granularity (" + f4 + "px) is less or equal to (0px)");
        } else {
            this.f1008a = 1;
            this.f1011d = f2;
            this.f1012e = f3;
            this.f1010c = f4;
            this.f1014g = false;
        }
    }

    private int[] b(int[] iArr) {
        int length = iArr.length;
        if (length == 0) {
            return iArr;
        }
        Arrays.sort(iArr);
        ArrayList arrayList = new ArrayList();
        for (int i2 : iArr) {
            if (i2 > 0 && Collections.binarySearch(arrayList, Integer.valueOf(i2)) < 0) {
                arrayList.add(Integer.valueOf(i2));
            }
        }
        if (length == arrayList.size()) {
            return iArr;
        }
        int size = arrayList.size();
        int[] iArr2 = new int[size];
        for (int i3 = 0; i3 < size; i3++) {
            iArr2[i3] = ((Integer) arrayList.get(i3)).intValue();
        }
        return iArr2;
    }

    private void c() {
        this.f1008a = 0;
        this.f1011d = -1.0f;
        this.f1012e = -1.0f;
        this.f1010c = -1.0f;
        this.f1013f = new int[0];
        this.f1009b = false;
    }

    private StaticLayout e(CharSequence charSequence, Layout.Alignment alignment, int i2, int i3) {
        StaticLayout.Builder obtain = StaticLayout.Builder.obtain(charSequence, 0, charSequence.length(), this.f1015h, i2);
        StaticLayout.Builder hyphenationFrequency = obtain.setAlignment(alignment).setLineSpacing(this.f1016i.getLineSpacingExtra(), this.f1016i.getLineSpacingMultiplier()).setIncludePad(this.f1016i.getIncludeFontPadding()).setBreakStrategy(this.f1016i.getBreakStrategy()).setHyphenationFrequency(this.f1016i.getHyphenationFrequency());
        if (i3 == -1) {
            i3 = Integer.MAX_VALUE;
        }
        hyphenationFrequency.setMaxLines(i3);
        try {
            this.f1018k.a(obtain, this.f1016i);
        } catch (ClassCastException unused) {
            Log.w("ACTVAutoSizeHelper", "Failed to obtain TextDirectionHeuristic, auto size may be incorrect");
        }
        return obtain.build();
    }

    private StaticLayout f(CharSequence charSequence, Layout.Alignment alignment, int i2) {
        return new StaticLayout(charSequence, this.f1015h, i2, alignment, this.f1016i.getLineSpacingMultiplier(), this.f1016i.getLineSpacingExtra(), this.f1016i.getIncludeFontPadding());
    }

    private int g(RectF rectF) {
        int length = this.f1013f.length;
        if (length != 0) {
            int i2 = length - 1;
            int i3 = 1;
            int i4 = 0;
            while (i3 <= i2) {
                int i5 = (i3 + i2) / 2;
                if (z(this.f1013f[i5], rectF)) {
                    int i6 = i5 + 1;
                    i4 = i3;
                    i3 = i6;
                } else {
                    i4 = i5 - 1;
                    i2 = i4;
                }
            }
            return this.f1013f[i4];
        }
        throw new IllegalStateException("No available text sizes to choose from.");
    }

    private static Method m(String str) {
        try {
            Method method = f1006m.get(str);
            if (method == null && (method = TextView.class.getDeclaredMethod(str, new Class[0])) != null) {
                method.setAccessible(true);
                f1006m.put(str, method);
            }
            return method;
        } catch (Exception e2) {
            Log.w("ACTVAutoSizeHelper", "Failed to retrieve TextView#" + str + "() method", e2);
            return null;
        }
    }

    static <T> T o(Object obj, String str, T t2) {
        try {
            return (T) m(str).invoke(obj, new Object[0]);
        } catch (Exception e2) {
            Log.w("ACTVAutoSizeHelper", "Failed to invoke TextView#" + str + "() method", e2);
            return t2;
        }
    }

    private void u(float f2) {
        if (f2 != this.f1016i.getPaint().getTextSize()) {
            this.f1016i.getPaint().setTextSize(f2);
            boolean isInLayout = this.f1016i.isInLayout();
            if (this.f1016i.getLayout() != null) {
                this.f1009b = false;
                try {
                    Method m2 = m("nullLayouts");
                    if (m2 != null) {
                        m2.invoke(this.f1016i, new Object[0]);
                    }
                } catch (Exception e2) {
                    Log.w("ACTVAutoSizeHelper", "Failed to invoke TextView#nullLayouts() method", e2);
                }
                if (isInLayout) {
                    this.f1016i.forceLayout();
                } else {
                    this.f1016i.requestLayout();
                }
                this.f1016i.invalidate();
            }
        }
    }

    private boolean w() {
        if (A() && this.f1008a == 1) {
            if (!this.f1014g || this.f1013f.length == 0) {
                int floor = ((int) Math.floor((this.f1012e - this.f1011d) / this.f1010c)) + 1;
                int[] iArr = new int[floor];
                for (int i2 = 0; i2 < floor; i2++) {
                    iArr[i2] = Math.round(this.f1011d + (i2 * this.f1010c));
                }
                this.f1013f = b(iArr);
            }
            this.f1009b = true;
        } else {
            this.f1009b = false;
        }
        return this.f1009b;
    }

    private void x(TypedArray typedArray) {
        int length = typedArray.length();
        int[] iArr = new int[length];
        if (length > 0) {
            for (int i2 = 0; i2 < length; i2++) {
                iArr[i2] = typedArray.getDimensionPixelSize(i2, -1);
            }
            this.f1013f = b(iArr);
            y();
        }
    }

    private boolean y() {
        boolean z2 = this.f1013f.length > 0;
        this.f1014g = z2;
        if (z2) {
            this.f1008a = 1;
            this.f1011d = r0[0];
            this.f1012e = r0[r1 - 1];
            this.f1010c = -1.0f;
        }
        return z2;
    }

    private boolean z(int i2, RectF rectF) {
        CharSequence transformation;
        CharSequence text = this.f1016i.getText();
        TransformationMethod transformationMethod = this.f1016i.getTransformationMethod();
        if (transformationMethod != null && (transformation = transformationMethod.getTransformation(text, this.f1016i)) != null) {
            text = transformation;
        }
        int maxLines = this.f1016i.getMaxLines();
        n(i2);
        StaticLayout d2 = d(text, (Layout.Alignment) o(this.f1016i, "getLayoutAlignment", Layout.Alignment.ALIGN_NORMAL), Math.round(rectF.right), maxLines);
        return (maxLines == -1 || (d2.getLineCount() <= maxLines && d2.getLineEnd(d2.getLineCount() - 1) == text.length())) && ((float) d2.getHeight()) <= rectF.bottom;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void a() {
        if (p()) {
            if (this.f1009b) {
                if (this.f1016i.getMeasuredHeight() <= 0 || this.f1016i.getMeasuredWidth() <= 0) {
                    return;
                }
                int measuredWidth = this.f1018k.b(this.f1016i) ? 1048576 : (this.f1016i.getMeasuredWidth() - this.f1016i.getTotalPaddingLeft()) - this.f1016i.getTotalPaddingRight();
                int height = (this.f1016i.getHeight() - this.f1016i.getCompoundPaddingBottom()) - this.f1016i.getCompoundPaddingTop();
                if (measuredWidth <= 0 || height <= 0) {
                    return;
                }
                RectF rectF = f1005l;
                synchronized (rectF) {
                    rectF.setEmpty();
                    rectF.right = measuredWidth;
                    rectF.bottom = height;
                    float g2 = g(rectF);
                    if (g2 != this.f1016i.getTextSize()) {
                        v(0, g2);
                    }
                }
            }
            this.f1009b = true;
        }
    }

    StaticLayout d(CharSequence charSequence, Layout.Alignment alignment, int i2, int i3) {
        return Build.VERSION.SDK_INT >= 23 ? e(charSequence, alignment, i2, i3) : f(charSequence, alignment, i2);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public int h() {
        return Math.round(this.f1012e);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public int i() {
        return Math.round(this.f1011d);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public int j() {
        return Math.round(this.f1010c);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public int[] k() {
        return this.f1013f;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public int l() {
        return this.f1008a;
    }

    void n(int i2) {
        TextPaint textPaint = this.f1015h;
        if (textPaint == null) {
            this.f1015h = new TextPaint();
        } else {
            textPaint.reset();
        }
        this.f1015h.set(this.f1016i.getPaint());
        this.f1015h.setTextSize(i2);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public boolean p() {
        return A() && this.f1008a != 0;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void q(AttributeSet attributeSet, int i2) {
        int resourceId;
        Context context = this.f1017j;
        int[] iArr = a.j.f40i0;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, iArr, i2, 0);
        TextView textView = this.f1016i;
        e0.q.i0(textView, textView.getContext(), iArr, attributeSet, obtainStyledAttributes, i2, 0);
        int i3 = a.j.f55n0;
        if (obtainStyledAttributes.hasValue(i3)) {
            this.f1008a = obtainStyledAttributes.getInt(i3, 0);
        }
        int i4 = a.j.f52m0;
        float dimension = obtainStyledAttributes.hasValue(i4) ? obtainStyledAttributes.getDimension(i4, -1.0f) : -1.0f;
        int i5 = a.j.f46k0;
        float dimension2 = obtainStyledAttributes.hasValue(i5) ? obtainStyledAttributes.getDimension(i5, -1.0f) : -1.0f;
        int i6 = a.j.f43j0;
        float dimension3 = obtainStyledAttributes.hasValue(i6) ? obtainStyledAttributes.getDimension(i6, -1.0f) : -1.0f;
        int i7 = a.j.f49l0;
        if (obtainStyledAttributes.hasValue(i7) && (resourceId = obtainStyledAttributes.getResourceId(i7, 0)) > 0) {
            TypedArray obtainTypedArray = obtainStyledAttributes.getResources().obtainTypedArray(resourceId);
            x(obtainTypedArray);
            obtainTypedArray.recycle();
        }
        obtainStyledAttributes.recycle();
        if (!A()) {
            this.f1008a = 0;
        } else if (this.f1008a == 1) {
            if (!this.f1014g) {
                DisplayMetrics displayMetrics = this.f1017j.getResources().getDisplayMetrics();
                if (dimension2 == -1.0f) {
                    dimension2 = TypedValue.applyDimension(2, 12.0f, displayMetrics);
                }
                if (dimension3 == -1.0f) {
                    dimension3 = TypedValue.applyDimension(2, 112.0f, displayMetrics);
                }
                if (dimension == -1.0f) {
                    dimension = 1.0f;
                }
                B(dimension2, dimension3, dimension);
            }
            w();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void r(int i2, int i3, int i4, int i5) {
        if (A()) {
            DisplayMetrics displayMetrics = this.f1017j.getResources().getDisplayMetrics();
            B(TypedValue.applyDimension(i5, i2, displayMetrics), TypedValue.applyDimension(i5, i3, displayMetrics), TypedValue.applyDimension(i5, i4, displayMetrics));
            if (w()) {
                a();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void s(int[] iArr, int i2) {
        if (A()) {
            int length = iArr.length;
            if (length > 0) {
                int[] iArr2 = new int[length];
                if (i2 == 0) {
                    iArr2 = Arrays.copyOf(iArr, length);
                } else {
                    DisplayMetrics displayMetrics = this.f1017j.getResources().getDisplayMetrics();
                    for (int i3 = 0; i3 < length; i3++) {
                        iArr2[i3] = Math.round(TypedValue.applyDimension(i2, iArr[i3], displayMetrics));
                    }
                }
                this.f1013f = b(iArr2);
                if (!y()) {
                    throw new IllegalArgumentException("None of the preset sizes is valid: " + Arrays.toString(iArr));
                }
            } else {
                this.f1014g = false;
            }
            if (w()) {
                a();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void t(int i2) {
        if (A()) {
            if (i2 == 0) {
                c();
            } else if (i2 != 1) {
                throw new IllegalArgumentException("Unknown auto-size text type: " + i2);
            } else {
                DisplayMetrics displayMetrics = this.f1017j.getResources().getDisplayMetrics();
                B(TypedValue.applyDimension(2, 12.0f, displayMetrics), TypedValue.applyDimension(2, 112.0f, displayMetrics), 1.0f);
                if (w()) {
                    a();
                }
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void v(int i2, float f2) {
        Context context = this.f1017j;
        u(TypedValue.applyDimension(i2, f2, (context == null ? Resources.getSystem() : context.getResources()).getDisplayMetrics()));
    }
}
