package v0;

import u0.c;
/* loaded from: classes.dex */
public final class c implements c.InterfaceC0072c {
    @Override // u0.c.InterfaceC0072c
    public u0.c a(c.b bVar) {
        return new b(bVar.f5335a, bVar.f5336b, bVar.f5337c, bVar.f5338d);
    }
}
