package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.os.Parcelable;
import androidx.versionedparcelable.a;
/* loaded from: classes.dex */
public class IconCompatParcelizer {
    public static IconCompat read(a aVar) {
        IconCompat iconCompat = new IconCompat();
        iconCompat.f1393a = aVar.p(iconCompat.f1393a, 1);
        iconCompat.f1395c = aVar.j(iconCompat.f1395c, 2);
        iconCompat.f1396d = aVar.r(iconCompat.f1396d, 3);
        iconCompat.f1397e = aVar.p(iconCompat.f1397e, 4);
        iconCompat.f1398f = aVar.p(iconCompat.f1398f, 5);
        iconCompat.f1399g = (ColorStateList) aVar.r(iconCompat.f1399g, 6);
        iconCompat.f1401i = aVar.t(iconCompat.f1401i, 7);
        iconCompat.e();
        return iconCompat;
    }

    public static void write(IconCompat iconCompat, a aVar) {
        aVar.x(true, true);
        iconCompat.f(aVar.f());
        int i2 = iconCompat.f1393a;
        if (-1 != i2) {
            aVar.F(i2, 1);
        }
        byte[] bArr = iconCompat.f1395c;
        if (bArr != null) {
            aVar.B(bArr, 2);
        }
        Parcelable parcelable = iconCompat.f1396d;
        if (parcelable != null) {
            aVar.H(parcelable, 3);
        }
        int i3 = iconCompat.f1397e;
        if (i3 != 0) {
            aVar.F(i3, 4);
        }
        int i4 = iconCompat.f1398f;
        if (i4 != 0) {
            aVar.F(i4, 5);
        }
        ColorStateList colorStateList = iconCompat.f1399g;
        if (colorStateList != null) {
            aVar.H(colorStateList, 6);
        }
        String str = iconCompat.f1401i;
        if (str != null) {
            aVar.J(str, 7);
        }
    }
}
