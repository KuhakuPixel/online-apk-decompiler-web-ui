package a1;
/* loaded from: classes.dex */
public final class a {

    /* renamed from: a */
    public static final int design_fab_hide_motion_spec = 2130837505;

    /* renamed from: b */
    public static final int design_fab_show_motion_spec = 2130837506;

    /* renamed from: c */
    public static final int mtrl_fab_transformation_sheet_collapse_spec = 2130837522;

    /* renamed from: d */
    public static final int mtrl_fab_transformation_sheet_expand_spec = 2130837523;
}
