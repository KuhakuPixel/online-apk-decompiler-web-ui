package androidx.navigation;

import android.os.Bundle;
/* loaded from: classes.dex */
public final class c {

    /* renamed from: a  reason: collision with root package name */
    private final int f1911a;

    /* renamed from: b  reason: collision with root package name */
    private p f1912b;

    /* renamed from: c  reason: collision with root package name */
    private Bundle f1913c;

    public c(int i2) {
        this(i2, null);
    }

    public c(int i2, p pVar) {
        this(i2, pVar, null);
    }

    public c(int i2, p pVar, Bundle bundle) {
        this.f1911a = i2;
        this.f1912b = pVar;
        this.f1913c = bundle;
    }

    public Bundle a() {
        return this.f1913c;
    }

    public int b() {
        return this.f1911a;
    }

    public p c() {
        return this.f1912b;
    }

    public void d(Bundle bundle) {
        this.f1913c = bundle;
    }

    public void e(p pVar) {
        this.f1912b = pVar;
    }
}
