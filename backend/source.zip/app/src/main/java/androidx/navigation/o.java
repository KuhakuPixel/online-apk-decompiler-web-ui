package androidx.navigation;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.util.Xml;
import androidx.navigation.d;
import androidx.navigation.h;
import androidx.navigation.p;
import org.xmlpull.v1.XmlPullParserException;
/* loaded from: classes.dex */
public final class o {

    /* renamed from: c  reason: collision with root package name */
    private static final ThreadLocal<TypedValue> f2021c = new ThreadLocal<>();

    /* renamed from: a  reason: collision with root package name */
    private Context f2022a;

    /* renamed from: b  reason: collision with root package name */
    private t f2023b;

    public o(Context context, t tVar) {
        this.f2022a = context;
        this.f2023b = tVar;
    }

    private static q a(TypedValue typedValue, q qVar, q qVar2, String str, String str2) {
        if (qVar == null || qVar == qVar2) {
            return qVar != null ? qVar : qVar2;
        }
        throw new XmlPullParserException("Type is " + str + " but found " + str2 + ": " + typedValue.data);
    }

    private k b(Resources resources, XmlResourceParser xmlResourceParser, AttributeSet attributeSet, int i2) {
        int depth;
        k a2 = this.f2023b.e(xmlResourceParser.getName()).a();
        a2.p(this.f2022a, attributeSet);
        int depth2 = xmlResourceParser.getDepth() + 1;
        while (true) {
            int next = xmlResourceParser.next();
            if (next == 1 || ((depth = xmlResourceParser.getDepth()) < depth2 && next == 3)) {
                break;
            } else if (next == 2 && depth <= depth2) {
                String name = xmlResourceParser.getName();
                if ("argument".equals(name)) {
                    g(resources, a2, attributeSet, i2);
                } else if ("deepLink".equals(name)) {
                    h(resources, a2, attributeSet);
                } else if ("action".equals(name)) {
                    d(resources, a2, attributeSet, xmlResourceParser, i2);
                } else if ("include".equals(name) && (a2 instanceof l)) {
                    TypedArray obtainAttributes = resources.obtainAttributes(attributeSet, v.f2074r);
                    ((l) a2).v(c(obtainAttributes.getResourceId(v.f2075s, 0)));
                    obtainAttributes.recycle();
                } else if (a2 instanceof l) {
                    ((l) a2).v(b(resources, xmlResourceParser, attributeSet, i2));
                }
            }
        }
        return a2;
    }

    private void d(Resources resources, k kVar, AttributeSet attributeSet, XmlResourceParser xmlResourceParser, int i2) {
        int depth;
        TypedArray obtainAttributes = resources.obtainAttributes(attributeSet, o0.a.f4809f);
        int resourceId = obtainAttributes.getResourceId(o0.a.f4810g, 0);
        c cVar = new c(obtainAttributes.getResourceId(o0.a.f4811h, 0));
        p.a aVar = new p.a();
        aVar.d(obtainAttributes.getBoolean(o0.a.f4814k, false));
        aVar.g(obtainAttributes.getResourceId(o0.a.f4817n, -1), obtainAttributes.getBoolean(o0.a.f4818o, false));
        aVar.b(obtainAttributes.getResourceId(o0.a.f4812i, -1));
        aVar.c(obtainAttributes.getResourceId(o0.a.f4813j, -1));
        aVar.e(obtainAttributes.getResourceId(o0.a.f4815l, -1));
        aVar.f(obtainAttributes.getResourceId(o0.a.f4816m, -1));
        cVar.e(aVar.a());
        Bundle bundle = new Bundle();
        int depth2 = xmlResourceParser.getDepth() + 1;
        while (true) {
            int next = xmlResourceParser.next();
            if (next == 1 || ((depth = xmlResourceParser.getDepth()) < depth2 && next == 3)) {
                break;
            } else if (next == 2 && depth <= depth2 && "argument".equals(xmlResourceParser.getName())) {
                f(resources, bundle, attributeSet, i2);
            }
        }
        if (!bundle.isEmpty()) {
            cVar.d(bundle);
        }
        kVar.q(resourceId, cVar);
        obtainAttributes.recycle();
    }

    private d e(TypedArray typedArray, Resources resources, int i2) {
        float f2;
        int dimension;
        d.a aVar = new d.a();
        aVar.c(typedArray.getBoolean(o0.a.f4823t, false));
        ThreadLocal<TypedValue> threadLocal = f2021c;
        TypedValue typedValue = threadLocal.get();
        if (typedValue == null) {
            typedValue = new TypedValue();
            threadLocal.set(typedValue);
        }
        String string = typedArray.getString(o0.a.f4822s);
        Object obj = null;
        q<Integer> a2 = string != null ? q.a(string, resources.getResourcePackageName(i2)) : null;
        int i3 = o0.a.f4821r;
        if (typedArray.getValue(i3, typedValue)) {
            q<Integer> qVar = q.f2039c;
            if (a2 == qVar) {
                dimension = typedValue.resourceId;
                if (dimension == 0) {
                    if (typedValue.type != 16 || typedValue.data != 0) {
                        throw new XmlPullParserException("unsupported value '" + ((Object) typedValue.string) + "' for " + a2.c() + ". Must be a reference to a resource.");
                    }
                    obj = 0;
                }
                obj = Integer.valueOf(dimension);
            } else {
                int i4 = typedValue.resourceId;
                if (i4 != 0) {
                    if (a2 != null) {
                        throw new XmlPullParserException("unsupported value '" + ((Object) typedValue.string) + "' for " + a2.c() + ". You must use a \"" + qVar.c() + "\" type to reference other resources.");
                    }
                    a2 = qVar;
                    obj = Integer.valueOf(i4);
                } else if (a2 == q.f2047k) {
                    obj = typedArray.getString(i3);
                } else {
                    int i5 = typedValue.type;
                    if (i5 != 3) {
                        if (i5 != 4) {
                            if (i5 == 5) {
                                a2 = a(typedValue, a2, q.f2038b, string, "dimension");
                                dimension = (int) typedValue.getDimension(resources.getDisplayMetrics());
                            } else if (i5 == 18) {
                                a2 = a(typedValue, a2, q.f2045i, string, "boolean");
                                obj = Boolean.valueOf(typedValue.data != 0);
                            } else if (i5 < 16 || i5 > 31) {
                                throw new XmlPullParserException("unsupported argument type " + typedValue.type);
                            } else {
                                q<Float> qVar2 = q.f2043g;
                                if (a2 == qVar2) {
                                    a2 = a(typedValue, a2, qVar2, string, "float");
                                    f2 = typedValue.data;
                                } else {
                                    a2 = a(typedValue, a2, q.f2038b, string, "integer");
                                    dimension = typedValue.data;
                                }
                            }
                            obj = Integer.valueOf(dimension);
                        } else {
                            a2 = a(typedValue, a2, q.f2043g, string, "float");
                            f2 = typedValue.getFloat();
                        }
                        obj = Float.valueOf(f2);
                    } else {
                        String charSequence = typedValue.string.toString();
                        if (a2 == null) {
                            a2 = q.d(charSequence);
                        }
                        obj = a2.k(charSequence);
                    }
                }
            }
        }
        if (obj != null) {
            aVar.b(obj);
        }
        if (a2 != null) {
            aVar.d(a2);
        }
        return aVar.a();
    }

    private void f(Resources resources, Bundle bundle, AttributeSet attributeSet, int i2) {
        TypedArray obtainAttributes = resources.obtainAttributes(attributeSet, o0.a.f4819p);
        String string = obtainAttributes.getString(o0.a.f4820q);
        if (string == null) {
            throw new XmlPullParserException("Arguments must have a name");
        }
        d e2 = e(obtainAttributes, resources, i2);
        if (e2.b()) {
            e2.c(string, bundle);
        }
        obtainAttributes.recycle();
    }

    private void g(Resources resources, k kVar, AttributeSet attributeSet, int i2) {
        TypedArray obtainAttributes = resources.obtainAttributes(attributeSet, o0.a.f4819p);
        String string = obtainAttributes.getString(o0.a.f4820q);
        if (string == null) {
            throw new XmlPullParserException("Arguments must have a name");
        }
        kVar.c(string, e(obtainAttributes, resources, i2));
        obtainAttributes.recycle();
    }

    private void h(Resources resources, k kVar, AttributeSet attributeSet) {
        TypedArray obtainAttributes = resources.obtainAttributes(attributeSet, o0.a.f4824u);
        String string = obtainAttributes.getString(o0.a.f4827x);
        String string2 = obtainAttributes.getString(o0.a.f4825v);
        String string3 = obtainAttributes.getString(o0.a.f4826w);
        if (TextUtils.isEmpty(string) && TextUtils.isEmpty(string2) && TextUtils.isEmpty(string3)) {
            throw new XmlPullParserException("Every <deepLink> must include at least one of app:uri, app:action, or app:mimeType");
        }
        h.a aVar = new h.a();
        if (string != null) {
            aVar.d(string.replace("${applicationId}", this.f2022a.getPackageName()));
        }
        if (!TextUtils.isEmpty(string2)) {
            aVar.b(string2.replace("${applicationId}", this.f2022a.getPackageName()));
        }
        if (string3 != null) {
            aVar.c(string3.replace("${applicationId}", this.f2022a.getPackageName()));
        }
        kVar.d(aVar.a());
        obtainAttributes.recycle();
    }

    @SuppressLint({"ResourceType"})
    public l c(int i2) {
        int next;
        Resources resources = this.f2022a.getResources();
        XmlResourceParser xml = resources.getXml(i2);
        AttributeSet asAttributeSet = Xml.asAttributeSet(xml);
        do {
            try {
                try {
                    next = xml.next();
                    if (next == 2) {
                        break;
                    }
                } catch (Exception e2) {
                    throw new RuntimeException("Exception inflating " + resources.getResourceName(i2) + " line " + xml.getLineNumber(), e2);
                }
            } finally {
                xml.close();
            }
        } while (next != 1);
        if (next == 2) {
            String name = xml.getName();
            k b2 = b(resources, xml, asAttributeSet, i2);
            if (b2 instanceof l) {
                return (l) b2;
            }
            throw new IllegalArgumentException("Root element <" + name + "> did not inflate into a NavGraph");
        }
        throw new XmlPullParserException("No start tag found");
    }
}
