package androidx.recyclerview.widget;

import android.view.View;
import androidx.recyclerview.widget.RecyclerView;
/* loaded from: classes.dex */
class f {

    /* renamed from: b  reason: collision with root package name */
    int f2442b;

    /* renamed from: c  reason: collision with root package name */
    int f2443c;

    /* renamed from: d  reason: collision with root package name */
    int f2444d;

    /* renamed from: e  reason: collision with root package name */
    int f2445e;

    /* renamed from: h  reason: collision with root package name */
    boolean f2448h;

    /* renamed from: i  reason: collision with root package name */
    boolean f2449i;

    /* renamed from: a  reason: collision with root package name */
    boolean f2441a = true;

    /* renamed from: f  reason: collision with root package name */
    int f2446f = 0;

    /* renamed from: g  reason: collision with root package name */
    int f2447g = 0;

    /* JADX INFO: Access modifiers changed from: package-private */
    public boolean a(RecyclerView.a0 a0Var) {
        int i2 = this.f2443c;
        return i2 >= 0 && i2 < a0Var.b();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public View b(RecyclerView.v vVar) {
        View o2 = vVar.o(this.f2443c);
        this.f2443c += this.f2444d;
        return o2;
    }

    public String toString() {
        return "LayoutState{mAvailable=" + this.f2442b + ", mCurrentPosition=" + this.f2443c + ", mItemDirection=" + this.f2444d + ", mLayoutDirection=" + this.f2445e + ", mStartLine=" + this.f2446f + ", mEndLine=" + this.f2447g + '}';
    }
}
