package v0;

import android.database.sqlite.SQLiteProgram;
/* loaded from: classes.dex */
class d implements u0.d {

    /* renamed from: b  reason: collision with root package name */
    private final SQLiteProgram f5424b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public d(SQLiteProgram sQLiteProgram) {
        this.f5424b = sQLiteProgram;
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public void close() {
        this.f5424b.close();
    }

    @Override // u0.d
    public void h(int i2, String str) {
        this.f5424b.bindString(i2, str);
    }

    @Override // u0.d
    public void i(int i2, long j2) {
        this.f5424b.bindLong(i2, j2);
    }

    @Override // u0.d
    public void o(int i2, byte[] bArr) {
        this.f5424b.bindBlob(i2, bArr);
    }

    @Override // u0.d
    public void p(int i2) {
        this.f5424b.bindNull(i2);
    }

    @Override // u0.d
    public void q(int i2, double d2) {
        this.f5424b.bindDouble(i2, d2);
    }
}
