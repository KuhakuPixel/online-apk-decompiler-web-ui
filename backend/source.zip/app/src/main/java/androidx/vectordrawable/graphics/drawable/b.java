package androidx.vectordrawable.graphics.drawable;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ArgbEvaluator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.AnimatedVectorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import java.util.ArrayList;
import org.xmlpull.v1.XmlPullParser;
/* loaded from: classes.dex */
public class b extends f implements Animatable {

    /* renamed from: c  reason: collision with root package name */
    private C0023b f2724c;

    /* renamed from: d  reason: collision with root package name */
    private Context f2725d;

    /* renamed from: e  reason: collision with root package name */
    private ArgbEvaluator f2726e;

    /* renamed from: f  reason: collision with root package name */
    private Animator.AnimatorListener f2727f;

    /* renamed from: g  reason: collision with root package name */
    ArrayList<Object> f2728g;

    /* renamed from: h  reason: collision with root package name */
    final Drawable.Callback f2729h;

    /* loaded from: classes.dex */
    class a implements Drawable.Callback {
        a() {
        }

        @Override // android.graphics.drawable.Drawable.Callback
        public void invalidateDrawable(Drawable drawable) {
            b.this.invalidateSelf();
        }

        @Override // android.graphics.drawable.Drawable.Callback
        public void scheduleDrawable(Drawable drawable, Runnable runnable, long j2) {
            b.this.scheduleSelf(runnable, j2);
        }

        @Override // android.graphics.drawable.Drawable.Callback
        public void unscheduleDrawable(Drawable drawable, Runnable runnable) {
            b.this.unscheduleSelf(runnable);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* renamed from: androidx.vectordrawable.graphics.drawable.b$b  reason: collision with other inner class name */
    /* loaded from: classes.dex */
    public static class C0023b extends Drawable.ConstantState {

        /* renamed from: a  reason: collision with root package name */
        int f2731a;

        /* renamed from: b  reason: collision with root package name */
        g f2732b;

        /* renamed from: c  reason: collision with root package name */
        AnimatorSet f2733c;

        /* renamed from: d  reason: collision with root package name */
        ArrayList<Animator> f2734d;

        /* renamed from: e  reason: collision with root package name */
        l.a<Animator, String> f2735e;

        public C0023b(Context context, C0023b c0023b, Drawable.Callback callback, Resources resources) {
            if (c0023b != null) {
                this.f2731a = c0023b.f2731a;
                g gVar = c0023b.f2732b;
                if (gVar != null) {
                    Drawable.ConstantState constantState = gVar.getConstantState();
                    this.f2732b = (g) (resources != null ? constantState.newDrawable(resources) : constantState.newDrawable());
                    g gVar2 = (g) this.f2732b.mutate();
                    this.f2732b = gVar2;
                    gVar2.setCallback(callback);
                    this.f2732b.setBounds(c0023b.f2732b.getBounds());
                    this.f2732b.h(false);
                }
                ArrayList<Animator> arrayList = c0023b.f2734d;
                if (arrayList != null) {
                    int size = arrayList.size();
                    this.f2734d = new ArrayList<>(size);
                    this.f2735e = new l.a<>(size);
                    for (int i2 = 0; i2 < size; i2++) {
                        Animator animator = c0023b.f2734d.get(i2);
                        Animator clone = animator.clone();
                        String str = c0023b.f2735e.get(animator);
                        clone.setTarget(this.f2732b.d(str));
                        this.f2734d.add(clone);
                        this.f2735e.put(clone, str);
                    }
                    a();
                }
            }
        }

        public void a() {
            if (this.f2733c == null) {
                this.f2733c = new AnimatorSet();
            }
            this.f2733c.playTogether(this.f2734d);
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public int getChangingConfigurations() {
            return this.f2731a;
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public Drawable newDrawable() {
            throw new IllegalStateException("No constant state support for SDK < 24.");
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public Drawable newDrawable(Resources resources) {
            throw new IllegalStateException("No constant state support for SDK < 24.");
        }
    }

    /* loaded from: classes.dex */
    private static class c extends Drawable.ConstantState {

        /* renamed from: a  reason: collision with root package name */
        private final Drawable.ConstantState f2736a;

        public c(Drawable.ConstantState constantState) {
            this.f2736a = constantState;
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public boolean canApplyTheme() {
            return this.f2736a.canApplyTheme();
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public int getChangingConfigurations() {
            return this.f2736a.getChangingConfigurations();
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public Drawable newDrawable() {
            b bVar = new b();
            Drawable newDrawable = this.f2736a.newDrawable();
            bVar.f2739b = newDrawable;
            newDrawable.setCallback(bVar.f2729h);
            return bVar;
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public Drawable newDrawable(Resources resources) {
            b bVar = new b();
            Drawable newDrawable = this.f2736a.newDrawable(resources);
            bVar.f2739b = newDrawable;
            newDrawable.setCallback(bVar.f2729h);
            return bVar;
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public Drawable newDrawable(Resources resources, Resources.Theme theme) {
            b bVar = new b();
            Drawable newDrawable = this.f2736a.newDrawable(resources, theme);
            bVar.f2739b = newDrawable;
            newDrawable.setCallback(bVar.f2729h);
            return bVar;
        }
    }

    b() {
        this(null, null, null);
    }

    private b(Context context) {
        this(context, null, null);
    }

    private b(Context context, C0023b c0023b, Resources resources) {
        this.f2726e = null;
        this.f2727f = null;
        this.f2728g = null;
        a aVar = new a();
        this.f2729h = aVar;
        this.f2725d = context;
        if (c0023b != null) {
            this.f2724c = c0023b;
        } else {
            this.f2724c = new C0023b(context, c0023b, aVar, resources);
        }
    }

    public static b a(Context context, Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme) {
        b bVar = new b(context);
        bVar.inflate(resources, xmlPullParser, attributeSet, theme);
        return bVar;
    }

    private void b(String str, Animator animator) {
        animator.setTarget(this.f2724c.f2732b.d(str));
        C0023b c0023b = this.f2724c;
        if (c0023b.f2734d == null) {
            c0023b.f2734d = new ArrayList<>();
            this.f2724c.f2735e = new l.a<>();
        }
        this.f2724c.f2734d.add(animator);
        this.f2724c.f2735e.put(animator, str);
    }

    @Override // androidx.vectordrawable.graphics.drawable.f, android.graphics.drawable.Drawable
    public void applyTheme(Resources.Theme theme) {
        Drawable drawable = this.f2739b;
        if (drawable != null) {
            x.a.a(drawable, theme);
        }
    }

    @Override // android.graphics.drawable.Drawable
    public boolean canApplyTheme() {
        Drawable drawable = this.f2739b;
        if (drawable != null) {
            return x.a.b(drawable);
        }
        return false;
    }

    @Override // androidx.vectordrawable.graphics.drawable.f, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ void clearColorFilter() {
        super.clearColorFilter();
    }

    @Override // android.graphics.drawable.Drawable
    public void draw(Canvas canvas) {
        Drawable drawable = this.f2739b;
        if (drawable != null) {
            drawable.draw(canvas);
            return;
        }
        this.f2724c.f2732b.draw(canvas);
        if (this.f2724c.f2733c.isStarted()) {
            invalidateSelf();
        }
    }

    @Override // android.graphics.drawable.Drawable
    public int getAlpha() {
        Drawable drawable = this.f2739b;
        return drawable != null ? x.a.d(drawable) : this.f2724c.f2732b.getAlpha();
    }

    @Override // android.graphics.drawable.Drawable
    public int getChangingConfigurations() {
        Drawable drawable = this.f2739b;
        return drawable != null ? drawable.getChangingConfigurations() : super.getChangingConfigurations() | this.f2724c.f2731a;
    }

    @Override // android.graphics.drawable.Drawable
    public ColorFilter getColorFilter() {
        Drawable drawable = this.f2739b;
        return drawable != null ? x.a.e(drawable) : this.f2724c.f2732b.getColorFilter();
    }

    @Override // android.graphics.drawable.Drawable
    public Drawable.ConstantState getConstantState() {
        if (this.f2739b == null || Build.VERSION.SDK_INT < 24) {
            return null;
        }
        return new c(this.f2739b.getConstantState());
    }

    @Override // androidx.vectordrawable.graphics.drawable.f, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ Drawable getCurrent() {
        return super.getCurrent();
    }

    @Override // android.graphics.drawable.Drawable
    public int getIntrinsicHeight() {
        Drawable drawable = this.f2739b;
        return drawable != null ? drawable.getIntrinsicHeight() : this.f2724c.f2732b.getIntrinsicHeight();
    }

    @Override // android.graphics.drawable.Drawable
    public int getIntrinsicWidth() {
        Drawable drawable = this.f2739b;
        return drawable != null ? drawable.getIntrinsicWidth() : this.f2724c.f2732b.getIntrinsicWidth();
    }

    @Override // androidx.vectordrawable.graphics.drawable.f, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ int getMinimumHeight() {
        return super.getMinimumHeight();
    }

    @Override // androidx.vectordrawable.graphics.drawable.f, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ int getMinimumWidth() {
        return super.getMinimumWidth();
    }

    @Override // android.graphics.drawable.Drawable
    public int getOpacity() {
        Drawable drawable = this.f2739b;
        return drawable != null ? drawable.getOpacity() : this.f2724c.f2732b.getOpacity();
    }

    @Override // androidx.vectordrawable.graphics.drawable.f, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ boolean getPadding(Rect rect) {
        return super.getPadding(rect);
    }

    @Override // androidx.vectordrawable.graphics.drawable.f, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ int[] getState() {
        return super.getState();
    }

    @Override // androidx.vectordrawable.graphics.drawable.f, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ Region getTransparentRegion() {
        return super.getTransparentRegion();
    }

    @Override // android.graphics.drawable.Drawable
    public void inflate(Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet) {
        inflate(resources, xmlPullParser, attributeSet, null);
    }

    @Override // android.graphics.drawable.Drawable
    public void inflate(Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme) {
        TypedArray obtainAttributes;
        Drawable drawable = this.f2739b;
        if (drawable != null) {
            x.a.g(drawable, resources, xmlPullParser, attributeSet, theme);
            return;
        }
        int eventType = xmlPullParser.getEventType();
        int depth = xmlPullParser.getDepth() + 1;
        while (eventType != 1 && (xmlPullParser.getDepth() >= depth || eventType != 3)) {
            if (eventType == 2) {
                String name = xmlPullParser.getName();
                if ("animated-vector".equals(name)) {
                    obtainAttributes = v.g.k(resources, theme, attributeSet, androidx.vectordrawable.graphics.drawable.a.f2716e);
                    int resourceId = obtainAttributes.getResourceId(0, 0);
                    if (resourceId != 0) {
                        g b2 = g.b(resources, resourceId, theme);
                        b2.h(false);
                        b2.setCallback(this.f2729h);
                        g gVar = this.f2724c.f2732b;
                        if (gVar != null) {
                            gVar.setCallback(null);
                        }
                        this.f2724c.f2732b = b2;
                    }
                } else if ("target".equals(name)) {
                    obtainAttributes = resources.obtainAttributes(attributeSet, androidx.vectordrawable.graphics.drawable.a.f2717f);
                    String string = obtainAttributes.getString(0);
                    int resourceId2 = obtainAttributes.getResourceId(1, 0);
                    if (resourceId2 != 0) {
                        Context context = this.f2725d;
                        if (context == null) {
                            obtainAttributes.recycle();
                            throw new IllegalStateException("Context can't be null when inflating animators");
                        }
                        b(string, d.i(context, resourceId2));
                    }
                } else {
                    continue;
                }
                obtainAttributes.recycle();
            }
            eventType = xmlPullParser.next();
        }
        this.f2724c.a();
    }

    @Override // android.graphics.drawable.Drawable
    public boolean isAutoMirrored() {
        Drawable drawable = this.f2739b;
        return drawable != null ? x.a.h(drawable) : this.f2724c.f2732b.isAutoMirrored();
    }

    @Override // android.graphics.drawable.Animatable
    public boolean isRunning() {
        Drawable drawable = this.f2739b;
        return drawable != null ? ((AnimatedVectorDrawable) drawable).isRunning() : this.f2724c.f2733c.isRunning();
    }

    @Override // android.graphics.drawable.Drawable
    public boolean isStateful() {
        Drawable drawable = this.f2739b;
        return drawable != null ? drawable.isStateful() : this.f2724c.f2732b.isStateful();
    }

    @Override // androidx.vectordrawable.graphics.drawable.f, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ void jumpToCurrentState() {
        super.jumpToCurrentState();
    }

    @Override // android.graphics.drawable.Drawable
    public Drawable mutate() {
        Drawable drawable = this.f2739b;
        if (drawable != null) {
            drawable.mutate();
        }
        return this;
    }

    @Override // android.graphics.drawable.Drawable
    protected void onBoundsChange(Rect rect) {
        Drawable drawable = this.f2739b;
        if (drawable != null) {
            drawable.setBounds(rect);
        } else {
            this.f2724c.f2732b.setBounds(rect);
        }
    }

    @Override // androidx.vectordrawable.graphics.drawable.f, android.graphics.drawable.Drawable
    protected boolean onLevelChange(int i2) {
        Drawable drawable = this.f2739b;
        return drawable != null ? drawable.setLevel(i2) : this.f2724c.f2732b.setLevel(i2);
    }

    @Override // android.graphics.drawable.Drawable
    protected boolean onStateChange(int[] iArr) {
        Drawable drawable = this.f2739b;
        return drawable != null ? drawable.setState(iArr) : this.f2724c.f2732b.setState(iArr);
    }

    @Override // android.graphics.drawable.Drawable
    public void setAlpha(int i2) {
        Drawable drawable = this.f2739b;
        if (drawable != null) {
            drawable.setAlpha(i2);
        } else {
            this.f2724c.f2732b.setAlpha(i2);
        }
    }

    @Override // android.graphics.drawable.Drawable
    public void setAutoMirrored(boolean z2) {
        Drawable drawable = this.f2739b;
        if (drawable != null) {
            x.a.j(drawable, z2);
        } else {
            this.f2724c.f2732b.setAutoMirrored(z2);
        }
    }

    @Override // androidx.vectordrawable.graphics.drawable.f, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ void setChangingConfigurations(int i2) {
        super.setChangingConfigurations(i2);
    }

    @Override // androidx.vectordrawable.graphics.drawable.f, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ void setColorFilter(int i2, PorterDuff.Mode mode) {
        super.setColorFilter(i2, mode);
    }

    @Override // android.graphics.drawable.Drawable
    public void setColorFilter(ColorFilter colorFilter) {
        Drawable drawable = this.f2739b;
        if (drawable != null) {
            drawable.setColorFilter(colorFilter);
        } else {
            this.f2724c.f2732b.setColorFilter(colorFilter);
        }
    }

    @Override // androidx.vectordrawable.graphics.drawable.f, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ void setFilterBitmap(boolean z2) {
        super.setFilterBitmap(z2);
    }

    @Override // androidx.vectordrawable.graphics.drawable.f, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ void setHotspot(float f2, float f3) {
        super.setHotspot(f2, f3);
    }

    @Override // androidx.vectordrawable.graphics.drawable.f, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ void setHotspotBounds(int i2, int i3, int i4, int i5) {
        super.setHotspotBounds(i2, i3, i4, i5);
    }

    @Override // androidx.vectordrawable.graphics.drawable.f, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ boolean setState(int[] iArr) {
        return super.setState(iArr);
    }

    @Override // android.graphics.drawable.Drawable
    public void setTint(int i2) {
        Drawable drawable = this.f2739b;
        if (drawable != null) {
            x.a.n(drawable, i2);
        } else {
            this.f2724c.f2732b.setTint(i2);
        }
    }

    @Override // android.graphics.drawable.Drawable
    public void setTintList(ColorStateList colorStateList) {
        Drawable drawable = this.f2739b;
        if (drawable != null) {
            x.a.o(drawable, colorStateList);
        } else {
            this.f2724c.f2732b.setTintList(colorStateList);
        }
    }

    @Override // android.graphics.drawable.Drawable
    public void setTintMode(PorterDuff.Mode mode) {
        Drawable drawable = this.f2739b;
        if (drawable != null) {
            x.a.p(drawable, mode);
        } else {
            this.f2724c.f2732b.setTintMode(mode);
        }
    }

    @Override // android.graphics.drawable.Drawable
    public boolean setVisible(boolean z2, boolean z3) {
        Drawable drawable = this.f2739b;
        if (drawable != null) {
            return drawable.setVisible(z2, z3);
        }
        this.f2724c.f2732b.setVisible(z2, z3);
        return super.setVisible(z2, z3);
    }

    @Override // android.graphics.drawable.Animatable
    public void start() {
        Drawable drawable = this.f2739b;
        if (drawable != null) {
            ((AnimatedVectorDrawable) drawable).start();
        } else if (this.f2724c.f2733c.isStarted()) {
        } else {
            this.f2724c.f2733c.start();
            invalidateSelf();
        }
    }

    @Override // android.graphics.drawable.Animatable
    public void stop() {
        Drawable drawable = this.f2739b;
        if (drawable != null) {
            ((AnimatedVectorDrawable) drawable).stop();
        } else {
            this.f2724c.f2733c.end();
        }
    }
}
