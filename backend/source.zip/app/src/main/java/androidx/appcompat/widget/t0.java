package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.TypedValue;
import v.f;
/* loaded from: classes.dex */
public class t0 {

    /* renamed from: a  reason: collision with root package name */
    private final Context f911a;

    /* renamed from: b  reason: collision with root package name */
    private final TypedArray f912b;

    /* renamed from: c  reason: collision with root package name */
    private TypedValue f913c;

    private t0(Context context, TypedArray typedArray) {
        this.f911a = context;
        this.f912b = typedArray;
    }

    public static t0 t(Context context, int i2, int[] iArr) {
        return new t0(context, context.obtainStyledAttributes(i2, iArr));
    }

    public static t0 u(Context context, AttributeSet attributeSet, int[] iArr) {
        return new t0(context, context.obtainStyledAttributes(attributeSet, iArr));
    }

    public static t0 v(Context context, AttributeSet attributeSet, int[] iArr, int i2, int i3) {
        return new t0(context, context.obtainStyledAttributes(attributeSet, iArr, i2, i3));
    }

    public boolean a(int i2, boolean z2) {
        return this.f912b.getBoolean(i2, z2);
    }

    public int b(int i2, int i3) {
        return this.f912b.getColor(i2, i3);
    }

    public ColorStateList c(int i2) {
        int resourceId;
        ColorStateList c2;
        return (!this.f912b.hasValue(i2) || (resourceId = this.f912b.getResourceId(i2, 0)) == 0 || (c2 = c.a.c(this.f911a, resourceId)) == null) ? this.f912b.getColorStateList(i2) : c2;
    }

    public float d(int i2, float f2) {
        return this.f912b.getDimension(i2, f2);
    }

    public int e(int i2, int i3) {
        return this.f912b.getDimensionPixelOffset(i2, i3);
    }

    public int f(int i2, int i3) {
        return this.f912b.getDimensionPixelSize(i2, i3);
    }

    public Drawable g(int i2) {
        int resourceId;
        return (!this.f912b.hasValue(i2) || (resourceId = this.f912b.getResourceId(i2, 0)) == 0) ? this.f912b.getDrawable(i2) : c.a.d(this.f911a, resourceId);
    }

    public Drawable h(int i2) {
        int resourceId;
        if (!this.f912b.hasValue(i2) || (resourceId = this.f912b.getResourceId(i2, 0)) == 0) {
            return null;
        }
        return j.b().d(this.f911a, resourceId, true);
    }

    public float i(int i2, float f2) {
        return this.f912b.getFloat(i2, f2);
    }

    public Typeface j(int i2, int i3, f.a aVar) {
        int resourceId = this.f912b.getResourceId(i2, 0);
        if (resourceId == 0) {
            return null;
        }
        if (this.f913c == null) {
            this.f913c = new TypedValue();
        }
        return v.f.c(this.f911a, resourceId, this.f913c, i3, aVar);
    }

    public int k(int i2, int i3) {
        return this.f912b.getInt(i2, i3);
    }

    public int l(int i2, int i3) {
        return this.f912b.getInteger(i2, i3);
    }

    public int m(int i2, int i3) {
        return this.f912b.getLayoutDimension(i2, i3);
    }

    public int n(int i2, int i3) {
        return this.f912b.getResourceId(i2, i3);
    }

    public String o(int i2) {
        return this.f912b.getString(i2);
    }

    public CharSequence p(int i2) {
        return this.f912b.getText(i2);
    }

    public CharSequence[] q(int i2) {
        return this.f912b.getTextArray(i2);
    }

    public TypedArray r() {
        return this.f912b;
    }

    public boolean s(int i2) {
        return this.f912b.hasValue(i2);
    }

    public void w() {
        this.f912b.recycle();
    }
}
