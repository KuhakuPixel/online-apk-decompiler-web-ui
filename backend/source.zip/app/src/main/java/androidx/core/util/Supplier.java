package androidx.core.util;
/* loaded from: classes.dex */
public interface Supplier<T> {
    T get();
}
