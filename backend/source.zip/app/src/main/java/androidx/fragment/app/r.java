package androidx.fragment.app;

import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes.dex */
public class r {

    /* renamed from: a  reason: collision with root package name */
    private final ArrayList<Fragment> f1710a = new ArrayList<>();

    /* renamed from: b  reason: collision with root package name */
    private final HashMap<String, q> f1711b = new HashMap<>();

    /* JADX INFO: Access modifiers changed from: package-private */
    public void a(Fragment fragment) {
        if (this.f1710a.contains(fragment)) {
            throw new IllegalStateException("Fragment already added: " + fragment);
        }
        synchronized (this.f1710a) {
            this.f1710a.add(fragment);
        }
        fragment.f1531l = true;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void b() {
        this.f1711b.values().removeAll(Collections.singleton(null));
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public boolean c(String str) {
        return this.f1711b.containsKey(str);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void d(int i2) {
        Iterator<Fragment> it = this.f1710a.iterator();
        while (it.hasNext()) {
            q qVar = this.f1711b.get(it.next().f1525f);
            if (qVar != null) {
                qVar.q(i2);
            }
        }
        for (q qVar2 : this.f1711b.values()) {
            if (qVar2 != null) {
                qVar2.q(i2);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void e(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        String str2 = str + "    ";
        if (!this.f1711b.isEmpty()) {
            printWriter.print(str);
            printWriter.print("Active Fragments:");
            for (q qVar : this.f1711b.values()) {
                printWriter.print(str);
                if (qVar != null) {
                    Fragment i2 = qVar.i();
                    printWriter.println(i2);
                    i2.e(str2, fileDescriptor, printWriter, strArr);
                } else {
                    printWriter.println("null");
                }
            }
        }
        int size = this.f1710a.size();
        if (size > 0) {
            printWriter.print(str);
            printWriter.println("Added Fragments:");
            for (int i3 = 0; i3 < size; i3++) {
                Fragment fragment = this.f1710a.get(i3);
                printWriter.print(str);
                printWriter.print("  #");
                printWriter.print(i3);
                printWriter.print(": ");
                printWriter.println(fragment.toString());
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public Fragment f(String str) {
        q qVar = this.f1711b.get(str);
        if (qVar != null) {
            return qVar.i();
        }
        return null;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public Fragment g(int i2) {
        for (int size = this.f1710a.size() - 1; size >= 0; size--) {
            Fragment fragment = this.f1710a.get(size);
            if (fragment != null && fragment.f1542w == i2) {
                return fragment;
            }
        }
        for (q qVar : this.f1711b.values()) {
            if (qVar != null) {
                Fragment i3 = qVar.i();
                if (i3.f1542w == i2) {
                    return i3;
                }
            }
        }
        return null;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public Fragment h(String str) {
        if (str != null) {
            for (int size = this.f1710a.size() - 1; size >= 0; size--) {
                Fragment fragment = this.f1710a.get(size);
                if (fragment != null && str.equals(fragment.f1544y)) {
                    return fragment;
                }
            }
        }
        if (str != null) {
            for (q qVar : this.f1711b.values()) {
                if (qVar != null) {
                    Fragment i2 = qVar.i();
                    if (str.equals(i2.f1544y)) {
                        return i2;
                    }
                }
            }
            return null;
        }
        return null;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public Fragment i(String str) {
        Fragment h2;
        for (q qVar : this.f1711b.values()) {
            if (qVar != null && (h2 = qVar.i().h(str)) != null) {
                return h2;
            }
        }
        return null;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public Fragment j(Fragment fragment) {
        ViewGroup viewGroup = fragment.G;
        View view = fragment.H;
        if (viewGroup != null && view != null) {
            for (int indexOf = this.f1710a.indexOf(fragment) - 1; indexOf >= 0; indexOf--) {
                Fragment fragment2 = this.f1710a.get(indexOf);
                if (fragment2.G == viewGroup && fragment2.H != null) {
                    return fragment2;
                }
            }
        }
        return null;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public List<Fragment> k() {
        ArrayList arrayList = new ArrayList();
        Iterator<q> it = this.f1711b.values().iterator();
        while (it.hasNext()) {
            q next = it.next();
            arrayList.add(next != null ? next.i() : null);
        }
        return arrayList;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public q l(String str) {
        return this.f1711b.get(str);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public List<Fragment> m() {
        ArrayList arrayList;
        if (this.f1710a.isEmpty()) {
            return Collections.emptyList();
        }
        synchronized (this.f1710a) {
            arrayList = new ArrayList(this.f1710a);
        }
        return arrayList;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void n(q qVar) {
        this.f1711b.put(qVar.i().f1525f, qVar);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void o(q qVar) {
        Fragment i2 = qVar.i();
        for (q qVar2 : this.f1711b.values()) {
            if (qVar2 != null) {
                Fragment i3 = qVar2.i();
                if (i2.f1525f.equals(i3.f1528i)) {
                    i3.f1527h = i2;
                    i3.f1528i = null;
                }
            }
        }
        this.f1711b.put(i2.f1525f, null);
        String str = i2.f1528i;
        if (str != null) {
            i2.f1527h = f(str);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void p(Fragment fragment) {
        synchronized (this.f1710a) {
            this.f1710a.remove(fragment);
        }
        fragment.f1531l = false;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void q() {
        this.f1711b.clear();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void r(List<String> list) {
        this.f1710a.clear();
        if (list != null) {
            for (String str : list) {
                Fragment f2 = f(str);
                if (f2 == null) {
                    throw new IllegalStateException("No instantiated fragment for (" + str + ")");
                }
                if (l.p0(2)) {
                    Log.v("FragmentManager", "restoreSaveState: added (" + str + "): " + f2);
                }
                a(f2);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public ArrayList<p> s() {
        ArrayList<p> arrayList = new ArrayList<>(this.f1711b.size());
        for (q qVar : this.f1711b.values()) {
            if (qVar != null) {
                Fragment i2 = qVar.i();
                p o2 = qVar.o();
                arrayList.add(o2);
                if (l.p0(2)) {
                    Log.v("FragmentManager", "Saved state of " + i2 + ": " + o2.f1705n);
                }
            }
        }
        return arrayList;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public ArrayList<String> t() {
        synchronized (this.f1710a) {
            if (this.f1710a.isEmpty()) {
                return null;
            }
            ArrayList<String> arrayList = new ArrayList<>(this.f1710a.size());
            Iterator<Fragment> it = this.f1710a.iterator();
            while (it.hasNext()) {
                Fragment next = it.next();
                arrayList.add(next.f1525f);
                if (l.p0(2)) {
                    Log.v("FragmentManager", "saveAllState: adding fragment (" + next.f1525f + "): " + next);
                }
            }
            return arrayList;
        }
    }
}
