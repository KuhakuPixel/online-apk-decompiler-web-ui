package b1;

import android.view.View;
/* loaded from: classes.dex */
public interface k<T extends View> {
    void a(T t2);

    void b(T t2);
}
