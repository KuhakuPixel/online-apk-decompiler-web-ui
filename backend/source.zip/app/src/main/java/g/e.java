package g;

import android.widget.ListView;
/* loaded from: classes.dex */
public interface e {
    void a();

    boolean c();

    void dismiss();

    ListView l();
}
