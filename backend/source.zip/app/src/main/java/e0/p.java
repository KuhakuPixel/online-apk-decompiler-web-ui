package e0;

import android.view.View;
import android.view.ViewTreeObserver;
import java.util.Objects;
/* loaded from: classes.dex */
public final class p implements ViewTreeObserver.OnPreDrawListener, View.OnAttachStateChangeListener {

    /* renamed from: b  reason: collision with root package name */
    private final View f4299b;

    /* renamed from: c  reason: collision with root package name */
    private ViewTreeObserver f4300c;

    /* renamed from: d  reason: collision with root package name */
    private final Runnable f4301d;

    private p(View view, Runnable runnable) {
        this.f4299b = view;
        this.f4300c = view.getViewTreeObserver();
        this.f4301d = runnable;
    }

    public static p a(View view, Runnable runnable) {
        Objects.requireNonNull(view, "view == null");
        Objects.requireNonNull(runnable, "runnable == null");
        p pVar = new p(view, runnable);
        view.getViewTreeObserver().addOnPreDrawListener(pVar);
        view.addOnAttachStateChangeListener(pVar);
        return pVar;
    }

    public void b() {
        (this.f4300c.isAlive() ? this.f4300c : this.f4299b.getViewTreeObserver()).removeOnPreDrawListener(this);
        this.f4299b.removeOnAttachStateChangeListener(this);
    }

    @Override // android.view.ViewTreeObserver.OnPreDrawListener
    public boolean onPreDraw() {
        b();
        this.f4301d.run();
        return true;
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public void onViewAttachedToWindow(View view) {
        this.f4300c = view.getViewTreeObserver();
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public void onViewDetachedFromWindow(View view) {
        b();
    }
}
