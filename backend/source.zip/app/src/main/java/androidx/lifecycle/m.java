package androidx.lifecycle;
/* loaded from: classes.dex */
public class m<T> extends LiveData<T> {
    @Override // androidx.lifecycle.LiveData
    public void k(T t2) {
        super.k(t2);
    }

    @Override // androidx.lifecycle.LiveData
    public void m(T t2) {
        super.m(t2);
    }
}
