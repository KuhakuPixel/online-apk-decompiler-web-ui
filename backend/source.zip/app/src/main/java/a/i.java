package a;
/* loaded from: classes.dex */
public final class i {

    /* renamed from: a */
    public static final int Animation_AppCompat_Tooltip = 2131886085;

    /* renamed from: b */
    public static final int Base_Widget_AppCompat_DrawerArrowToggle = 2131886257;

    /* renamed from: c */
    public static final int Theme_AppCompat_CompactMenu = 2131886471;

    /* renamed from: d */
    public static final int Theme_AppCompat_Empty = 2131886483;

    /* renamed from: e */
    public static final int Theme_AppCompat_Light = 2131886484;
}
