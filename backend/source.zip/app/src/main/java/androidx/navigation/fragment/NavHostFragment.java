package androidx.navigation.fragment;

import android.app.Dialog;
import android.content.Context;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentContainerView;
import androidx.navigation.NavController;
import androidx.navigation.fragment.a;
import androidx.navigation.n;
import androidx.navigation.r;
import androidx.navigation.s;
import androidx.navigation.v;
/* loaded from: classes.dex */
public class NavHostFragment extends Fragment {
    private n Y;
    private Boolean Z = null;

    /* renamed from: a0  reason: collision with root package name */
    private View f1943a0;

    /* renamed from: b0  reason: collision with root package name */
    private int f1944b0;

    /* renamed from: c0  reason: collision with root package name */
    private boolean f1945c0;

    public static NavController q1(Fragment fragment) {
        for (Fragment fragment2 = fragment; fragment2 != null; fragment2 = fragment2.z()) {
            if (fragment2 instanceof NavHostFragment) {
                return ((NavHostFragment) fragment2).s1();
            }
            Fragment j02 = fragment2.A().j0();
            if (j02 instanceof NavHostFragment) {
                return ((NavHostFragment) j02).s1();
            }
        }
        View M = fragment.M();
        if (M != null) {
            return r.a(M);
        }
        Dialog t12 = fragment instanceof androidx.fragment.app.c ? ((androidx.fragment.app.c) fragment).t1() : null;
        if (t12 == null || t12.getWindow() == null) {
            throw new IllegalStateException("Fragment " + fragment + " does not have a NavController set");
        }
        return r.a(t12.getWindow().getDecorView());
    }

    private int r1() {
        int v2 = v();
        return (v2 == 0 || v2 == -1) ? b.nav_host_fragment_container : v2;
    }

    @Override // androidx.fragment.app.Fragment
    public void C0(View view, Bundle bundle) {
        super.C0(view, bundle);
        if (!(view instanceof ViewGroup)) {
            throw new IllegalStateException("created host view " + view + " is not a ViewGroup");
        }
        r.d(view, this.Y);
        if (view.getParent() != null) {
            View view2 = (View) view.getParent();
            this.f1943a0 = view2;
            if (view2.getId() == v()) {
                r.d(this.f1943a0, this.Y);
            }
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void a0(Context context) {
        super.a0(context);
        if (this.f1945c0) {
            A().i().r(this).h();
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void b0(Fragment fragment) {
        super.b0(fragment);
        ((DialogFragmentNavigator) this.Y.l().d(DialogFragmentNavigator.class)).h(fragment);
    }

    @Override // androidx.fragment.app.Fragment
    public void d0(Bundle bundle) {
        Bundle bundle2;
        n nVar = new n(c1());
        this.Y = nVar;
        nVar.D(this);
        this.Y.E(b1().b());
        n nVar2 = this.Y;
        Boolean bool = this.Z;
        nVar2.c(bool != null && bool.booleanValue());
        this.Z = null;
        this.Y.F(g());
        t1(this.Y);
        if (bundle != null) {
            bundle2 = bundle.getBundle("android-support-nav:fragment:navControllerState");
            if (bundle.getBoolean("android-support-nav:fragment:defaultHost", false)) {
                this.f1945c0 = true;
                A().i().r(this).h();
            }
            this.f1944b0 = bundle.getInt("android-support-nav:fragment:graphId");
        } else {
            bundle2 = null;
        }
        if (bundle2 != null) {
            this.Y.y(bundle2);
        }
        int i2 = this.f1944b0;
        if (i2 != 0) {
            this.Y.A(i2);
        } else {
            Bundle n2 = n();
            int i3 = n2 != null ? n2.getInt("android-support-nav:fragment:graphId") : 0;
            Bundle bundle3 = n2 != null ? n2.getBundle("android-support-nav:fragment:startDestinationArgs") : null;
            if (i3 != 0) {
                this.Y.B(i3, bundle3);
            }
        }
        super.d0(bundle);
    }

    @Override // androidx.fragment.app.Fragment
    public View h0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        FragmentContainerView fragmentContainerView = new FragmentContainerView(layoutInflater.getContext());
        fragmentContainerView.setId(r1());
        return fragmentContainerView;
    }

    @Override // androidx.fragment.app.Fragment
    public void k0() {
        super.k0();
        View view = this.f1943a0;
        if (view != null && r.a(view) == this.Y) {
            r.d(this.f1943a0, null);
        }
        this.f1943a0 = null;
    }

    @Override // androidx.fragment.app.Fragment
    public void p0(Context context, AttributeSet attributeSet, Bundle bundle) {
        super.p0(context, attributeSet, bundle);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, v.f2072p);
        int resourceId = obtainStyledAttributes.getResourceId(v.f2073q, 0);
        if (resourceId != 0) {
            this.f1944b0 = resourceId;
        }
        obtainStyledAttributes.recycle();
        TypedArray obtainStyledAttributes2 = context.obtainStyledAttributes(attributeSet, c.f1969r);
        if (obtainStyledAttributes2.getBoolean(c.f1970s, false)) {
            this.f1945c0 = true;
        }
        obtainStyledAttributes2.recycle();
    }

    @Deprecated
    protected s<? extends a.C0013a> p1() {
        return new a(c1(), o(), r1());
    }

    public final NavController s1() {
        n nVar = this.Y;
        if (nVar != null) {
            return nVar;
        }
        throw new IllegalStateException("NavController is not available before onCreate()");
    }

    protected void t1(NavController navController) {
        navController.l().a(new DialogFragmentNavigator(c1(), o()));
        navController.l().a(p1());
    }

    @Override // androidx.fragment.app.Fragment
    public void w0(boolean z2) {
        n nVar = this.Y;
        if (nVar != null) {
            nVar.c(z2);
        } else {
            this.Z = Boolean.valueOf(z2);
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void z0(Bundle bundle) {
        super.z0(bundle);
        Bundle z2 = this.Y.z();
        if (z2 != null) {
            bundle.putBundle("android-support-nav:fragment:navControllerState", z2);
        }
        if (this.f1945c0) {
            bundle.putBoolean("android-support-nav:fragment:defaultHost", true);
        }
        int i2 = this.f1944b0;
        if (i2 != 0) {
            bundle.putInt("android-support-nav:fragment:graphId", i2);
        }
    }
}
