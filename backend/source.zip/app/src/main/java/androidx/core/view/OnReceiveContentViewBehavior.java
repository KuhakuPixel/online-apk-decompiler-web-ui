package androidx.core.view;
/* loaded from: classes.dex */
public interface OnReceiveContentViewBehavior {
    ContentInfoCompat onReceiveContent(ContentInfoCompat contentInfoCompat);
}
