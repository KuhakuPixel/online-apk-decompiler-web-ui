package o;

import java.util.ArrayList;
import o.d;
import o.i;
/* loaded from: classes.dex */
public class b implements d.a {

    /* renamed from: e  reason: collision with root package name */
    public a f4722e;

    /* renamed from: a  reason: collision with root package name */
    i f4718a = null;

    /* renamed from: b  reason: collision with root package name */
    float f4719b = 0.0f;

    /* renamed from: c  reason: collision with root package name */
    boolean f4720c = false;

    /* renamed from: d  reason: collision with root package name */
    ArrayList<i> f4721d = new ArrayList<>();

    /* renamed from: f  reason: collision with root package name */
    boolean f4723f = false;

    /* loaded from: classes.dex */
    public interface a {
        float a(int i2);

        void b(i iVar, float f2, boolean z2);

        boolean c(i iVar);

        void clear();

        float d(b bVar, boolean z2);

        void e(i iVar, float f2);

        float f(i iVar);

        i g(int i2);

        void h(float f2);

        float i(i iVar, boolean z2);

        void j();

        int k();
    }

    public b() {
    }

    public b(c cVar) {
        this.f4722e = new o.a(this, cVar);
    }

    private boolean u(i iVar, d dVar) {
        return iVar.f4779m <= 1;
    }

    private i w(boolean[] zArr, i iVar) {
        i.a aVar;
        int k2 = this.f4722e.k();
        i iVar2 = null;
        float f2 = 0.0f;
        for (int i2 = 0; i2 < k2; i2++) {
            float a2 = this.f4722e.a(i2);
            if (a2 < 0.0f) {
                i g2 = this.f4722e.g(i2);
                if ((zArr == null || !zArr[g2.f4769c]) && g2 != iVar && (((aVar = g2.f4776j) == i.a.SLACK || aVar == i.a.ERROR) && a2 < f2)) {
                    f2 = a2;
                    iVar2 = g2;
                }
            }
        }
        return iVar2;
    }

    public void A(d dVar, i iVar, boolean z2) {
        if (iVar.f4773g) {
            this.f4719b += iVar.f4772f * this.f4722e.f(iVar);
            this.f4722e.i(iVar, z2);
            if (z2) {
                iVar.c(this);
            }
            if (d.f4730t && this.f4722e.k() == 0) {
                this.f4723f = true;
                dVar.f4736a = true;
            }
        }
    }

    public void B(d dVar, b bVar, boolean z2) {
        this.f4719b += bVar.f4719b * this.f4722e.d(bVar, z2);
        if (z2) {
            bVar.f4718a.c(this);
        }
        if (d.f4730t && this.f4718a != null && this.f4722e.k() == 0) {
            this.f4723f = true;
            dVar.f4736a = true;
        }
    }

    public void C(d dVar, i iVar, boolean z2) {
        if (iVar.f4780n) {
            float f2 = this.f4722e.f(iVar);
            this.f4719b += iVar.f4782p * f2;
            this.f4722e.i(iVar, z2);
            if (z2) {
                iVar.c(this);
            }
            this.f4722e.b(dVar.f4749n.f4727d[iVar.f4781o], f2, z2);
            if (d.f4730t && this.f4722e.k() == 0) {
                this.f4723f = true;
                dVar.f4736a = true;
            }
        }
    }

    public void D(d dVar) {
        if (dVar.f4742g.length == 0) {
            return;
        }
        boolean z2 = false;
        while (!z2) {
            int k2 = this.f4722e.k();
            for (int i2 = 0; i2 < k2; i2++) {
                i g2 = this.f4722e.g(i2);
                if (g2.f4770d != -1 || g2.f4773g || g2.f4780n) {
                    this.f4721d.add(g2);
                }
            }
            int size = this.f4721d.size();
            if (size > 0) {
                for (int i3 = 0; i3 < size; i3++) {
                    i iVar = this.f4721d.get(i3);
                    if (iVar.f4773g) {
                        A(dVar, iVar, true);
                    } else if (iVar.f4780n) {
                        C(dVar, iVar, true);
                    } else {
                        B(dVar, dVar.f4742g[iVar.f4770d], true);
                    }
                }
                this.f4721d.clear();
            } else {
                z2 = true;
            }
        }
        if (d.f4730t && this.f4718a != null && this.f4722e.k() == 0) {
            this.f4723f = true;
            dVar.f4736a = true;
        }
    }

    @Override // o.d.a
    public void a(i iVar) {
        int i2 = iVar.f4771e;
        float f2 = 1.0f;
        if (i2 != 1) {
            if (i2 == 2) {
                f2 = 1000.0f;
            } else if (i2 == 3) {
                f2 = 1000000.0f;
            } else if (i2 == 4) {
                f2 = 1.0E9f;
            } else if (i2 == 5) {
                f2 = 1.0E12f;
            }
        }
        this.f4722e.e(iVar, f2);
    }

    @Override // o.d.a
    public i b(d dVar, boolean[] zArr) {
        return w(zArr, null);
    }

    @Override // o.d.a
    public void c(d.a aVar) {
        if (aVar instanceof b) {
            b bVar = (b) aVar;
            this.f4718a = null;
            this.f4722e.clear();
            for (int i2 = 0; i2 < bVar.f4722e.k(); i2++) {
                this.f4722e.b(bVar.f4722e.g(i2), bVar.f4722e.a(i2), true);
            }
        }
    }

    @Override // o.d.a
    public void clear() {
        this.f4722e.clear();
        this.f4718a = null;
        this.f4719b = 0.0f;
    }

    public b d(d dVar, int i2) {
        this.f4722e.e(dVar.o(i2, "ep"), 1.0f);
        this.f4722e.e(dVar.o(i2, "em"), -1.0f);
        return this;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public b e(i iVar, int i2) {
        this.f4722e.e(iVar, i2);
        return this;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public boolean f(d dVar) {
        boolean z2;
        i g2 = g(dVar);
        if (g2 == null) {
            z2 = true;
        } else {
            x(g2);
            z2 = false;
        }
        if (this.f4722e.k() == 0) {
            this.f4723f = true;
        }
        return z2;
    }

    i g(d dVar) {
        int k2 = this.f4722e.k();
        i iVar = null;
        i iVar2 = null;
        boolean z2 = false;
        boolean z3 = false;
        float f2 = 0.0f;
        float f3 = 0.0f;
        for (int i2 = 0; i2 < k2; i2++) {
            float a2 = this.f4722e.a(i2);
            i g2 = this.f4722e.g(i2);
            if (g2.f4776j == i.a.UNRESTRICTED) {
                if (iVar == null || f2 > a2) {
                    z2 = u(g2, dVar);
                    f2 = a2;
                    iVar = g2;
                } else if (!z2 && u(g2, dVar)) {
                    f2 = a2;
                    iVar = g2;
                    z2 = true;
                }
            } else if (iVar == null && a2 < 0.0f) {
                if (iVar2 == null || f3 > a2) {
                    z3 = u(g2, dVar);
                    f3 = a2;
                    iVar2 = g2;
                } else if (!z3 && u(g2, dVar)) {
                    f3 = a2;
                    iVar2 = g2;
                    z3 = true;
                }
            }
        }
        return iVar != null ? iVar : iVar2;
    }

    @Override // o.d.a
    public i getKey() {
        return this.f4718a;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public b h(i iVar, i iVar2, int i2, float f2, i iVar3, i iVar4, int i3) {
        float f3;
        int i4;
        if (iVar2 == iVar3) {
            this.f4722e.e(iVar, 1.0f);
            this.f4722e.e(iVar4, 1.0f);
            this.f4722e.e(iVar2, -2.0f);
            return this;
        }
        if (f2 == 0.5f) {
            this.f4722e.e(iVar, 1.0f);
            this.f4722e.e(iVar2, -1.0f);
            this.f4722e.e(iVar3, -1.0f);
            this.f4722e.e(iVar4, 1.0f);
            if (i2 > 0 || i3 > 0) {
                i4 = (-i2) + i3;
                f3 = i4;
            }
            return this;
        } else if (f2 <= 0.0f) {
            this.f4722e.e(iVar, -1.0f);
            this.f4722e.e(iVar2, 1.0f);
            f3 = i2;
        } else if (f2 < 1.0f) {
            float f4 = 1.0f - f2;
            this.f4722e.e(iVar, f4 * 1.0f);
            this.f4722e.e(iVar2, f4 * (-1.0f));
            this.f4722e.e(iVar3, (-1.0f) * f2);
            this.f4722e.e(iVar4, 1.0f * f2);
            if (i2 > 0 || i3 > 0) {
                f3 = ((-i2) * f4) + (i3 * f2);
            }
            return this;
        } else {
            this.f4722e.e(iVar4, -1.0f);
            this.f4722e.e(iVar3, 1.0f);
            i4 = -i3;
            f3 = i4;
        }
        this.f4719b = f3;
        return this;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public b i(i iVar, int i2) {
        this.f4718a = iVar;
        float f2 = i2;
        iVar.f4772f = f2;
        this.f4719b = f2;
        this.f4723f = true;
        return this;
    }

    @Override // o.d.a
    public boolean isEmpty() {
        return this.f4718a == null && this.f4719b == 0.0f && this.f4722e.k() == 0;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public b j(i iVar, i iVar2, float f2) {
        this.f4722e.e(iVar, -1.0f);
        this.f4722e.e(iVar2, f2);
        return this;
    }

    public b k(i iVar, i iVar2, i iVar3, i iVar4, float f2) {
        this.f4722e.e(iVar, -1.0f);
        this.f4722e.e(iVar2, 1.0f);
        this.f4722e.e(iVar3, f2);
        this.f4722e.e(iVar4, -f2);
        return this;
    }

    public b l(float f2, float f3, float f4, i iVar, i iVar2, i iVar3, i iVar4) {
        this.f4719b = 0.0f;
        if (f3 == 0.0f || f2 == f4) {
            this.f4722e.e(iVar, 1.0f);
            this.f4722e.e(iVar2, -1.0f);
            this.f4722e.e(iVar4, 1.0f);
            this.f4722e.e(iVar3, -1.0f);
        } else if (f2 == 0.0f) {
            this.f4722e.e(iVar, 1.0f);
            this.f4722e.e(iVar2, -1.0f);
        } else if (f4 == 0.0f) {
            this.f4722e.e(iVar3, 1.0f);
            this.f4722e.e(iVar4, -1.0f);
        } else {
            float f5 = (f2 / f3) / (f4 / f3);
            this.f4722e.e(iVar, 1.0f);
            this.f4722e.e(iVar2, -1.0f);
            this.f4722e.e(iVar4, f5);
            this.f4722e.e(iVar3, -f5);
        }
        return this;
    }

    public b m(i iVar, int i2) {
        a aVar;
        float f2;
        if (i2 < 0) {
            this.f4719b = i2 * (-1);
            aVar = this.f4722e;
            f2 = 1.0f;
        } else {
            this.f4719b = i2;
            aVar = this.f4722e;
            f2 = -1.0f;
        }
        aVar.e(iVar, f2);
        return this;
    }

    public b n(i iVar, i iVar2, int i2) {
        boolean z2 = false;
        if (i2 != 0) {
            if (i2 < 0) {
                i2 *= -1;
                z2 = true;
            }
            this.f4719b = i2;
        }
        if (z2) {
            this.f4722e.e(iVar, 1.0f);
            this.f4722e.e(iVar2, -1.0f);
        } else {
            this.f4722e.e(iVar, -1.0f);
            this.f4722e.e(iVar2, 1.0f);
        }
        return this;
    }

    public b o(i iVar, i iVar2, i iVar3, int i2) {
        boolean z2 = false;
        if (i2 != 0) {
            if (i2 < 0) {
                i2 *= -1;
                z2 = true;
            }
            this.f4719b = i2;
        }
        if (z2) {
            this.f4722e.e(iVar, 1.0f);
            this.f4722e.e(iVar2, -1.0f);
            this.f4722e.e(iVar3, -1.0f);
        } else {
            this.f4722e.e(iVar, -1.0f);
            this.f4722e.e(iVar2, 1.0f);
            this.f4722e.e(iVar3, 1.0f);
        }
        return this;
    }

    public b p(i iVar, i iVar2, i iVar3, int i2) {
        boolean z2 = false;
        if (i2 != 0) {
            if (i2 < 0) {
                i2 *= -1;
                z2 = true;
            }
            this.f4719b = i2;
        }
        if (z2) {
            this.f4722e.e(iVar, 1.0f);
            this.f4722e.e(iVar2, -1.0f);
            this.f4722e.e(iVar3, 1.0f);
        } else {
            this.f4722e.e(iVar, -1.0f);
            this.f4722e.e(iVar2, 1.0f);
            this.f4722e.e(iVar3, -1.0f);
        }
        return this;
    }

    public b q(i iVar, i iVar2, i iVar3, i iVar4, float f2) {
        this.f4722e.e(iVar3, 0.5f);
        this.f4722e.e(iVar4, 0.5f);
        this.f4722e.e(iVar, -0.5f);
        this.f4722e.e(iVar2, -0.5f);
        this.f4719b = -f2;
        return this;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void r() {
        float f2 = this.f4719b;
        if (f2 < 0.0f) {
            this.f4719b = f2 * (-1.0f);
            this.f4722e.j();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public boolean s() {
        i iVar = this.f4718a;
        return iVar != null && (iVar.f4776j == i.a.UNRESTRICTED || this.f4719b >= 0.0f);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public boolean t(i iVar) {
        return this.f4722e.c(iVar);
    }

    public String toString() {
        return z();
    }

    public i v(i iVar) {
        return w(null, iVar);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void x(i iVar) {
        i iVar2 = this.f4718a;
        if (iVar2 != null) {
            this.f4722e.e(iVar2, -1.0f);
            this.f4718a.f4770d = -1;
            this.f4718a = null;
        }
        float i2 = this.f4722e.i(iVar, true) * (-1.0f);
        this.f4718a = iVar;
        if (i2 == 1.0f) {
            return;
        }
        this.f4719b /= i2;
        this.f4722e.h(i2);
    }

    public void y() {
        this.f4718a = null;
        this.f4722e.clear();
        this.f4719b = 0.0f;
        this.f4723f = false;
    }

    /*  JADX ERROR: JadxRuntimeException in pass: SimplifyVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't remove SSA var: r7v1 float, still in use, count: 4, list:
          (r7v1 float) from 0x00ab: PHI (r7v2 float) = (r7v1 float), (r7v3 float), (r7v1 float) binds: [B:25:0x008a, B:27:0x00a2, B:21:0x0079] A[DONT_GENERATE, DONT_INLINE]
          (r7v1 float) from 0x00a9: ARITH (r7v3 float) = (r7v1 float) * (-1.0f float)
          (r7v1 float) from 0x0077: CMP_G (r7v1 float), (0.0f float) A[WRAPPED]
          (r7v1 float) from 0x00ab: PHI (r7v2 float) = (r7v1 float), (r7v3 float), (r7v1 float) binds: [B:25:0x008a, B:27:0x00a2, B:21:0x0079] A[DONT_GENERATE, DONT_INLINE]
        	at jadx.core.utils.InsnRemover.removeSsaVar(InsnRemover.java:152)
        	at jadx.core.utils.InsnRemover.unbindResult(InsnRemover.java:117)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:81)
        	at jadx.core.utils.InsnRemover.unbindArgUsage(InsnRemover.java:164)
        	at jadx.core.utils.InsnRemover.unbindAllArgs(InsnRemover.java:96)
        	at jadx.core.utils.InsnRemover.unbindInsn(InsnRemover.java:80)
        	at jadx.core.dex.visitors.SimplifyVisitor.simplifyIf(SimplifyVisitor.java:280)
        	at jadx.core.dex.visitors.SimplifyVisitor.simplifyInsn(SimplifyVisitor.java:138)
        	at jadx.core.dex.visitors.SimplifyVisitor.simplifyBlock(SimplifyVisitor.java:86)
        	at jadx.core.dex.visitors.SimplifyVisitor.visit(SimplifyVisitor.java:71)
        */
    /* JADX WARN: Removed duplicated region for block: B:30:0x00b1  */
    /* JADX WARN: Removed duplicated region for block: B:31:0x00b7  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    java.lang.String z() {
        /*
            r10 = this;
            o.i r0 = r10.f4718a
            java.lang.String r1 = ""
            if (r0 != 0) goto L14
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>()
            r0.append(r1)
            java.lang.String r1 = "0"
            r0.append(r1)
            goto L21
        L14:
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>()
            r0.append(r1)
            o.i r1 = r10.f4718a
            r0.append(r1)
        L21:
            java.lang.String r0 = r0.toString()
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            r1.append(r0)
            java.lang.String r0 = " = "
            r1.append(r0)
            java.lang.String r0 = r1.toString()
            float r1 = r10.f4719b
            r2 = 0
            r3 = 1
            r4 = 0
            int r1 = (r1 > r4 ? 1 : (r1 == r4 ? 0 : -1))
            if (r1 == 0) goto L52
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            r1.append(r0)
            float r0 = r10.f4719b
            r1.append(r0)
            java.lang.String r0 = r1.toString()
            r1 = 1
            goto L53
        L52:
            r1 = 0
        L53:
            o.b$a r5 = r10.f4722e
            int r5 = r5.k()
        L59:
            if (r2 >= r5) goto Ld2
            o.b$a r6 = r10.f4722e
            o.i r6 = r6.g(r2)
            if (r6 != 0) goto L64
            goto Lcf
        L64:
            o.b$a r7 = r10.f4722e
            float r7 = r7.a(r2)
            int r8 = (r7 > r4 ? 1 : (r7 == r4 ? 0 : -1))
            if (r8 != 0) goto L6f
            goto Lcf
        L6f:
            java.lang.String r6 = r6.toString()
            r9 = -1082130432(0xffffffffbf800000, float:-1.0)
            if (r1 != 0) goto L86
            int r1 = (r7 > r4 ? 1 : (r7 == r4 ? 0 : -1))
            if (r1 >= 0) goto Lab
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            r1.append(r0)
            java.lang.String r0 = "- "
            goto La2
        L86:
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            if (r8 <= 0) goto L9a
            r1.<init>()
            r1.append(r0)
            java.lang.String r0 = " + "
            r1.append(r0)
            java.lang.String r0 = r1.toString()
            goto Lab
        L9a:
            r1.<init>()
            r1.append(r0)
            java.lang.String r0 = " - "
        La2:
            r1.append(r0)
            java.lang.String r0 = r1.toString()
            float r7 = r7 * r9
        Lab:
            r1 = 1065353216(0x3f800000, float:1.0)
            int r1 = (r7 > r1 ? 1 : (r7 == r1 ? 0 : -1))
            if (r1 != 0) goto Lb7
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            goto Lc4
        Lb7:
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            r1.append(r0)
            r1.append(r7)
            java.lang.String r0 = " "
        Lc4:
            r1.append(r0)
            r1.append(r6)
            java.lang.String r0 = r1.toString()
            r1 = 1
        Lcf:
            int r2 = r2 + 1
            goto L59
        Ld2:
            if (r1 != 0) goto Le5
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            r1.append(r0)
            java.lang.String r0 = "0.0"
            r1.append(r0)
            java.lang.String r0 = r1.toString()
        Le5:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: o.b.z():java.lang.String");
    }
}
