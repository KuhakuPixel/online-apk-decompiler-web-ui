package z0;

import java.io.Serializable;
import java.util.Map;
import java.util.Set;
import javax.annotation.CheckForNull;
/* loaded from: classes.dex */
public abstract class e0 implements Map, Serializable {
    @CheckForNull

    /* renamed from: b  reason: collision with root package name */
    private transient f0 f5690b;
    @CheckForNull

    /* renamed from: c  reason: collision with root package name */
    private transient f0 f5691c;
    @CheckForNull

    /* renamed from: d  reason: collision with root package name */
    private transient y f5692d;

    abstract y c();

    @Override // java.util.Map
    @Deprecated
    public final void clear() {
        throw new UnsupportedOperationException();
    }

    @Override // java.util.Map
    public final boolean containsKey(@CheckForNull Object obj) {
        return get(obj) != null;
    }

    @Override // java.util.Map
    public final boolean containsValue(@CheckForNull Object obj) {
        return values().contains(obj);
    }

    @Override // java.util.Map
    /* renamed from: d  reason: merged with bridge method [inline-methods] */
    public final y values() {
        y yVar = this.f5692d;
        if (yVar == null) {
            y c2 = c();
            this.f5692d = c2;
            return c2;
        }
        return yVar;
    }

    abstract f0 e();

    @Override // java.util.Map
    public final boolean equals(@CheckForNull Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof Map) {
            return entrySet().equals(((Map) obj).entrySet());
        }
        return false;
    }

    abstract f0 f();

    @Override // java.util.Map
    /* renamed from: g  reason: merged with bridge method [inline-methods] */
    public final f0 entrySet() {
        f0 f0Var = this.f5690b;
        if (f0Var == null) {
            f0 e2 = e();
            this.f5690b = e2;
            return e2;
        }
        return f0Var;
    }

    @Override // java.util.Map
    @CheckForNull
    public abstract Object get(@CheckForNull Object obj);

    @Override // java.util.Map
    @CheckForNull
    public final Object getOrDefault(@CheckForNull Object obj, @CheckForNull Object obj2) {
        Object obj3 = get(obj);
        return obj3 != null ? obj3 : obj2;
    }

    @Override // java.util.Map
    public final int hashCode() {
        return h.a(entrySet());
    }

    @Override // java.util.Map
    public final boolean isEmpty() {
        return size() == 0;
    }

    @Override // java.util.Map
    public final /* bridge */ /* synthetic */ Set keySet() {
        f0 f0Var = this.f5691c;
        if (f0Var == null) {
            f0 f2 = f();
            this.f5691c = f2;
            return f2;
        }
        return f0Var;
    }

    @Override // java.util.Map
    @CheckForNull
    @Deprecated
    public final Object put(Object obj, Object obj2) {
        throw new UnsupportedOperationException();
    }

    @Override // java.util.Map
    @Deprecated
    public final void putAll(Map map) {
        throw new UnsupportedOperationException();
    }

    @Override // java.util.Map
    @CheckForNull
    @Deprecated
    public final Object remove(@CheckForNull Object obj) {
        throw new UnsupportedOperationException();
    }

    public final String toString() {
        int size = size();
        if (size < 0) {
            throw new IllegalArgumentException("size cannot be negative but was: " + size);
        }
        StringBuilder sb = new StringBuilder((int) Math.min(size * 8, 1073741824L));
        sb.append('{');
        boolean z2 = true;
        for (Map.Entry entry : entrySet()) {
            if (!z2) {
                sb.append(", ");
            }
            sb.append(entry.getKey());
            sb.append('=');
            sb.append(entry.getValue());
            z2 = false;
        }
        sb.append('}');
        return sb.toString();
    }
}
