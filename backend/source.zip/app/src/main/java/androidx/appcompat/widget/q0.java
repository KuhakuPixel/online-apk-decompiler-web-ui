package androidx.appcompat.widget;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.AssetManager;
import android.content.res.Resources;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
/* loaded from: classes.dex */
public class q0 extends ContextWrapper {

    /* renamed from: c  reason: collision with root package name */
    private static final Object f897c = new Object();

    /* renamed from: d  reason: collision with root package name */
    private static ArrayList<WeakReference<q0>> f898d;

    /* renamed from: a  reason: collision with root package name */
    private final Resources f899a;

    /* renamed from: b  reason: collision with root package name */
    private final Resources.Theme f900b;

    private q0(Context context) {
        super(context);
        if (!y0.b()) {
            this.f899a = new s0(this, context.getResources());
            this.f900b = null;
            return;
        }
        y0 y0Var = new y0(this, context.getResources());
        this.f899a = y0Var;
        Resources.Theme newTheme = y0Var.newTheme();
        this.f900b = newTheme;
        newTheme.setTo(context.getTheme());
    }

    private static boolean a(Context context) {
        return ((context instanceof q0) || (context.getResources() instanceof s0) || (context.getResources() instanceof y0) || !y0.b()) ? false : true;
    }

    public static Context b(Context context) {
        if (a(context)) {
            synchronized (f897c) {
                ArrayList<WeakReference<q0>> arrayList = f898d;
                if (arrayList == null) {
                    f898d = new ArrayList<>();
                } else {
                    for (int size = arrayList.size() - 1; size >= 0; size--) {
                        WeakReference<q0> weakReference = f898d.get(size);
                        if (weakReference == null || weakReference.get() == null) {
                            f898d.remove(size);
                        }
                    }
                    for (int size2 = f898d.size() - 1; size2 >= 0; size2--) {
                        WeakReference<q0> weakReference2 = f898d.get(size2);
                        q0 q0Var = weakReference2 != null ? weakReference2.get() : null;
                        if (q0Var != null && q0Var.getBaseContext() == context) {
                            return q0Var;
                        }
                    }
                }
                q0 q0Var2 = new q0(context);
                f898d.add(new WeakReference<>(q0Var2));
                return q0Var2;
            }
        }
        return context;
    }

    @Override // android.content.ContextWrapper, android.content.Context
    public AssetManager getAssets() {
        return this.f899a.getAssets();
    }

    @Override // android.content.ContextWrapper, android.content.Context
    public Resources getResources() {
        return this.f899a;
    }

    @Override // android.content.ContextWrapper, android.content.Context
    public Resources.Theme getTheme() {
        Resources.Theme theme = this.f900b;
        return theme == null ? super.getTheme() : theme;
    }

    @Override // android.content.ContextWrapper, android.content.Context
    public void setTheme(int i2) {
        Resources.Theme theme = this.f900b;
        if (theme == null) {
            super.setTheme(i2);
        } else {
            theme.applyStyle(i2, true);
        }
    }
}
