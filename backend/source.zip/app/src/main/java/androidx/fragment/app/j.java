package androidx.fragment.app;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes.dex */
public class j implements LayoutInflater.Factory2 {

    /* renamed from: b  reason: collision with root package name */
    private final l f1636b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public j(l lVar) {
        this.f1636b = lVar;
    }

    @Override // android.view.LayoutInflater.Factory2
    public View onCreateView(View view, String str, Context context, AttributeSet attributeSet) {
        if (FragmentContainerView.class.getName().equals(str)) {
            return new FragmentContainerView(context, attributeSet, this.f1636b);
        }
        if ("fragment".equals(str)) {
            String attributeValue = attributeSet.getAttributeValue(null, "class");
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, l0.c.f4659d);
            if (attributeValue == null) {
                attributeValue = obtainStyledAttributes.getString(l0.c.f4660e);
            }
            int resourceId = obtainStyledAttributes.getResourceId(l0.c.f4661f, -1);
            String string = obtainStyledAttributes.getString(l0.c.f4662g);
            obtainStyledAttributes.recycle();
            if (attributeValue == null || !h.b(context.getClassLoader(), attributeValue)) {
                return null;
            }
            int id = view != null ? view.getId() : 0;
            if (id == -1 && resourceId == -1 && string == null) {
                throw new IllegalArgumentException(attributeSet.getPositionDescription() + ": Must specify unique android:id, android:tag, or have a parent with an id for " + attributeValue);
            }
            Fragment W = resourceId != -1 ? this.f1636b.W(resourceId) : null;
            if (W == null && string != null) {
                W = this.f1636b.X(string);
            }
            if (W == null && id != -1) {
                W = this.f1636b.W(id);
            }
            if (l.p0(2)) {
                Log.v("FragmentManager", "onCreateView: id=0x" + Integer.toHexString(resourceId) + " fname=" + attributeValue + " existing=" + W);
            }
            if (W == null) {
                W = this.f1636b.e0().a(context.getClassLoader(), attributeValue);
                W.f1533n = true;
                W.f1542w = resourceId != 0 ? resourceId : id;
                W.f1543x = id;
                W.f1544y = string;
                W.f1534o = true;
                l lVar = this.f1636b;
                W.f1538s = lVar;
                i<?> iVar = lVar.f1654o;
                W.f1539t = iVar;
                W.p0(iVar.i(), attributeSet, W.f1522c);
                this.f1636b.d(W);
                this.f1636b.z0(W);
            } else if (W.f1534o) {
                throw new IllegalArgumentException(attributeSet.getPositionDescription() + ": Duplicate id 0x" + Integer.toHexString(resourceId) + ", tag " + string + ", or parent id 0x" + Integer.toHexString(id) + " with another fragment for " + attributeValue);
            } else {
                W.f1534o = true;
                i<?> iVar2 = this.f1636b.f1654o;
                W.f1539t = iVar2;
                W.p0(iVar2.i(), attributeSet, W.f1522c);
            }
            l lVar2 = this.f1636b;
            if (lVar2.f1653n >= 1 || !W.f1533n) {
                lVar2.z0(W);
            } else {
                lVar2.A0(W, 1);
            }
            View view2 = W.H;
            if (view2 != null) {
                if (resourceId != 0) {
                    view2.setId(resourceId);
                }
                if (W.H.getTag() == null) {
                    W.H.setTag(string);
                }
                return W.H;
            }
            throw new IllegalStateException("Fragment " + attributeValue + " did not create a view.");
        }
        return null;
    }

    @Override // android.view.LayoutInflater.Factory
    public View onCreateView(String str, Context context, AttributeSet attributeSet) {
        return onCreateView(null, str, context, attributeSet);
    }
}
