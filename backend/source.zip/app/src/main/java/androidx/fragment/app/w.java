package androidx.fragment.app;

import androidx.lifecycle.d;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes.dex */
public class w implements androidx.lifecycle.g {

    /* renamed from: b  reason: collision with root package name */
    private androidx.lifecycle.h f1810b = null;

    @Override // androidx.lifecycle.g
    public androidx.lifecycle.d a() {
        e();
        return this.f1810b;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void d(d.a aVar) {
        this.f1810b.i(aVar);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void e() {
        if (this.f1810b == null) {
            this.f1810b = new androidx.lifecycle.h(this);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public boolean f() {
        return this.f1810b != null;
    }
}
