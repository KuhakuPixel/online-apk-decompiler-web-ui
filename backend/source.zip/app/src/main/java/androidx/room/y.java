package androidx.room;

import androidx.room.e0;
import java.util.concurrent.Executor;
/* loaded from: classes.dex */
final class y implements u0.c, i {

    /* renamed from: b  reason: collision with root package name */
    private final u0.c f2696b;

    /* renamed from: c  reason: collision with root package name */
    private final e0.f f2697c;

    /* renamed from: d  reason: collision with root package name */
    private final Executor f2698d;

    /* JADX INFO: Access modifiers changed from: package-private */
    public y(u0.c cVar, e0.f fVar, Executor executor) {
        this.f2696b = cVar;
        this.f2697c = fVar;
        this.f2698d = executor;
    }

    @Override // u0.c, java.io.Closeable, java.lang.AutoCloseable
    public void close() {
        this.f2696b.close();
    }

    @Override // androidx.room.i
    public u0.c e() {
        return this.f2696b;
    }

    @Override // u0.c
    public String getDatabaseName() {
        return this.f2696b.getDatabaseName();
    }

    @Override // u0.c
    public u0.b r() {
        return new x(this.f2696b.r(), this.f2697c, this.f2698d);
    }

    @Override // u0.c
    public void setWriteAheadLoggingEnabled(boolean z2) {
        this.f2696b.setWriteAheadLoggingEnabled(z2);
    }
}
