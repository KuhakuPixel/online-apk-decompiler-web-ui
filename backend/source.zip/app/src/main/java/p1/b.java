package p1;

import android.graphics.drawable.Drawable;
/* loaded from: classes.dex */
public interface b {
    void a(int i2, int i3, int i4, int i5);

    boolean b();

    void d(Drawable drawable);
}
