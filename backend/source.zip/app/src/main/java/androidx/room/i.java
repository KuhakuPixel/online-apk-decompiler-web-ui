package androidx.room;
/* loaded from: classes.dex */
interface i {
    u0.c e();
}
