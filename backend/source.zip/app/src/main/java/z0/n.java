package z0;

import android.os.Bundle;
import android.os.IInterface;
/* loaded from: classes.dex */
public interface n extends IInterface {
    Bundle b(int i2, String str, String str2, Bundle bundle, Bundle bundle2);

    int c(int i2, String str, String str2);

    int d(int i2, String str, String str2);

    int e(int i2, String str, String str2, Bundle bundle);

    Bundle f(int i2, String str, String str2, String str3);

    Bundle g(int i2, String str, String str2, Bundle bundle);

    Bundle h(int i2, String str, String str2, String str3, Bundle bundle);

    Bundle i(int i2, String str, String str2, String str3, String str4);

    Bundle j(int i2, String str, String str2, String str3, String str4, Bundle bundle);

    Bundle l(int i2, String str, String str2, Bundle bundle);

    Bundle o(int i2, String str, String str2, Bundle bundle);
}
