package androidx.room;

import android.database.Cursor;
import android.os.CancellationSignal;
import android.util.Pair;
import androidx.room.e0;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Executor;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes.dex */
public final class x implements u0.b {

    /* renamed from: b  reason: collision with root package name */
    private final u0.b f2693b;

    /* renamed from: c  reason: collision with root package name */
    private final e0.f f2694c;

    /* renamed from: d  reason: collision with root package name */
    private final Executor f2695d;

    /* JADX INFO: Access modifiers changed from: package-private */
    public x(u0.b bVar, e0.f fVar, Executor executor) {
        this.f2693b = bVar;
        this.f2694c = fVar;
        this.f2695d = executor;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void D() {
        this.f2694c.a("BEGIN EXCLUSIVE TRANSACTION", Collections.emptyList());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void E() {
        this.f2694c.a("BEGIN DEFERRED TRANSACTION", Collections.emptyList());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void F() {
        this.f2694c.a("END TRANSACTION", Collections.emptyList());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void G(String str) {
        this.f2694c.a(str, new ArrayList(0));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void H(String str) {
        this.f2694c.a(str, Collections.emptyList());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void I(u0.e eVar, a0 a0Var) {
        this.f2694c.a(eVar.e(), a0Var.e());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void J(u0.e eVar, a0 a0Var) {
        this.f2694c.a(eVar.e(), a0Var.e());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void K() {
        this.f2694c.a("TRANSACTION SUCCESSFUL", Collections.emptyList());
    }

    @Override // u0.b
    public void a() {
        this.f2695d.execute(new Runnable() { // from class: androidx.room.p
            @Override // java.lang.Runnable
            public final void run() {
                x.this.F();
            }
        });
        this.f2693b.a();
    }

    @Override // u0.b
    public void b() {
        this.f2695d.execute(new Runnable() { // from class: androidx.room.s
            @Override // java.lang.Runnable
            public final void run() {
                x.this.D();
            }
        });
        this.f2693b.b();
    }

    @Override // u0.b
    public boolean c() {
        return this.f2693b.c();
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public void close() {
        this.f2693b.close();
    }

    @Override // u0.b
    public List<Pair<String, String>> d() {
        return this.f2693b.d();
    }

    @Override // u0.b
    public boolean f() {
        return this.f2693b.f();
    }

    @Override // u0.b
    public void g(final String str) {
        this.f2695d.execute(new Runnable() { // from class: androidx.room.t
            @Override // java.lang.Runnable
            public final void run() {
                x.this.G(str);
            }
        });
        this.f2693b.g(str);
    }

    @Override // u0.b
    public Cursor j(final u0.e eVar) {
        final a0 a0Var = new a0();
        eVar.v(a0Var);
        this.f2695d.execute(new Runnable() { // from class: androidx.room.v
            @Override // java.lang.Runnable
            public final void run() {
                x.this.I(eVar, a0Var);
            }
        });
        return this.f2693b.j(eVar);
    }

    @Override // u0.b
    public void k() {
        this.f2695d.execute(new Runnable() { // from class: androidx.room.r
            @Override // java.lang.Runnable
            public final void run() {
                x.this.K();
            }
        });
        this.f2693b.k();
    }

    @Override // u0.b
    public u0.f m(String str) {
        return new c0(this.f2693b.m(str), this.f2694c, str, this.f2695d);
    }

    @Override // u0.b
    public void n() {
        this.f2695d.execute(new Runnable() { // from class: androidx.room.q
            @Override // java.lang.Runnable
            public final void run() {
                x.this.E();
            }
        });
        this.f2693b.n();
    }

    @Override // u0.b
    public Cursor s(final String str) {
        this.f2695d.execute(new Runnable() { // from class: androidx.room.u
            @Override // java.lang.Runnable
            public final void run() {
                x.this.H(str);
            }
        });
        return this.f2693b.s(str);
    }

    @Override // u0.b
    public String t() {
        return this.f2693b.t();
    }

    @Override // u0.b
    public boolean u() {
        return this.f2693b.u();
    }

    @Override // u0.b
    public Cursor w(final u0.e eVar, CancellationSignal cancellationSignal) {
        final a0 a0Var = new a0();
        eVar.v(a0Var);
        this.f2695d.execute(new Runnable() { // from class: androidx.room.w
            @Override // java.lang.Runnable
            public final void run() {
                x.this.J(eVar, a0Var);
            }
        });
        return this.f2693b.j(eVar);
    }
}
