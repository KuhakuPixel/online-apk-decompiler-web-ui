package androidx.databinding;

import android.util.Log;
import android.view.View;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
/* loaded from: classes.dex */
public class MergedDataBinderMapper extends d {

    /* renamed from: a  reason: collision with root package name */
    private Set<Class<? extends d>> f1472a = new HashSet();

    /* renamed from: b  reason: collision with root package name */
    private List<d> f1473b = new CopyOnWriteArrayList();

    /* renamed from: c  reason: collision with root package name */
    private List<String> f1474c = new CopyOnWriteArrayList();

    private boolean e() {
        StringBuilder sb;
        boolean z2 = false;
        for (String str : this.f1474c) {
            try {
                Class<?> cls = Class.forName(str);
                if (d.class.isAssignableFrom(cls)) {
                    d((d) cls.newInstance());
                    this.f1474c.remove(str);
                    z2 = true;
                }
            } catch (ClassNotFoundException unused) {
            } catch (IllegalAccessException e2) {
                e = e2;
                sb = new StringBuilder();
                sb.append("unable to add feature mapper for ");
                sb.append(str);
                Log.e("MergedDataBinderMapper", sb.toString(), e);
            } catch (InstantiationException e3) {
                e = e3;
                sb = new StringBuilder();
                sb.append("unable to add feature mapper for ");
                sb.append(str);
                Log.e("MergedDataBinderMapper", sb.toString(), e);
            }
        }
        return z2;
    }

    @Override // androidx.databinding.d
    public ViewDataBinding b(e eVar, View view, int i2) {
        Iterator<d> it = this.f1473b.iterator();
        while (it.hasNext()) {
            ViewDataBinding b2 = it.next().b(eVar, view, i2);
            if (b2 != null) {
                return b2;
            }
        }
        if (e()) {
            return b(eVar, view, i2);
        }
        return null;
    }

    @Override // androidx.databinding.d
    public ViewDataBinding c(e eVar, View[] viewArr, int i2) {
        Iterator<d> it = this.f1473b.iterator();
        while (it.hasNext()) {
            ViewDataBinding c2 = it.next().c(eVar, viewArr, i2);
            if (c2 != null) {
                return c2;
            }
        }
        if (e()) {
            return c(eVar, viewArr, i2);
        }
        return null;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public void d(d dVar) {
        if (this.f1472a.add(dVar.getClass())) {
            this.f1473b.add(dVar);
            Iterator<d> it = dVar.a().iterator();
            while (it.hasNext()) {
                d(it.next());
            }
        }
    }
}
