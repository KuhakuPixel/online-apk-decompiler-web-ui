package androidx.activity;

import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import androidx.lifecycle.d;
import androidx.lifecycle.g;
import androidx.lifecycle.h;
import androidx.lifecycle.p;
import androidx.lifecycle.t;
import androidx.lifecycle.u;
import androidx.savedstate.SavedStateRegistry;
import t.e;
/* loaded from: classes.dex */
public class ComponentActivity extends e implements u, androidx.savedstate.b, c {

    /* renamed from: f  reason: collision with root package name */
    private t f188f;

    /* renamed from: h  reason: collision with root package name */
    private int f190h;

    /* renamed from: d  reason: collision with root package name */
    private final h f186d = new h(this);

    /* renamed from: e  reason: collision with root package name */
    private final androidx.savedstate.a f187e = androidx.savedstate.a.a(this);

    /* renamed from: g  reason: collision with root package name */
    private final OnBackPressedDispatcher f189g = new OnBackPressedDispatcher(new a());

    /* loaded from: classes.dex */
    class a implements Runnable {
        a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            ComponentActivity.super.onBackPressed();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public static final class b {

        /* renamed from: a  reason: collision with root package name */
        Object f194a;

        /* renamed from: b  reason: collision with root package name */
        t f195b;

        b() {
        }
    }

    public ComponentActivity() {
        if (a() == null) {
            throw new IllegalStateException("getLifecycle() returned null in ComponentActivity's constructor. Please make sure you are lazily constructing your Lifecycle in the first call to getLifecycle() rather than relying on field initialization.");
        }
        int i2 = Build.VERSION.SDK_INT;
        a().a(new androidx.lifecycle.e() { // from class: androidx.activity.ComponentActivity.2
            @Override // androidx.lifecycle.e
            public void f(g gVar, d.a aVar) {
                if (aVar == d.a.ON_STOP) {
                    Window window = ComponentActivity.this.getWindow();
                    View peekDecorView = window != null ? window.peekDecorView() : null;
                    if (peekDecorView != null) {
                        peekDecorView.cancelPendingInputEvents();
                    }
                }
            }
        });
        a().a(new androidx.lifecycle.e() { // from class: androidx.activity.ComponentActivity.3
            @Override // androidx.lifecycle.e
            public void f(g gVar, d.a aVar) {
                if (aVar != d.a.ON_DESTROY || ComponentActivity.this.isChangingConfigurations()) {
                    return;
                }
                ComponentActivity.this.g().a();
            }
        });
        if (i2 <= 23) {
            a().a(new ImmLeaksCleaner(this));
        }
    }

    @Override // t.e, androidx.lifecycle.g
    public d a() {
        return this.f186d;
    }

    @Override // androidx.activity.c
    public final OnBackPressedDispatcher b() {
        return this.f189g;
    }

    @Override // androidx.savedstate.b
    public final SavedStateRegistry c() {
        return this.f187e.b();
    }

    @Override // androidx.lifecycle.u
    public t g() {
        if (getApplication() != null) {
            if (this.f188f == null) {
                b bVar = (b) getLastNonConfigurationInstance();
                if (bVar != null) {
                    this.f188f = bVar.f195b;
                }
                if (this.f188f == null) {
                    this.f188f = new t();
                }
            }
            return this.f188f;
        }
        throw new IllegalStateException("Your activity is not yet attached to the Application instance. You can't request ViewModel before onCreate call.");
    }

    @Deprecated
    public Object k() {
        return null;
    }

    @Override // android.app.Activity
    public void onBackPressed() {
        this.f189g.c();
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // t.e, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.f187e.c(bundle);
        p.f(this);
        int i2 = this.f190h;
        if (i2 != 0) {
            setContentView(i2);
        }
    }

    @Override // android.app.Activity
    public final Object onRetainNonConfigurationInstance() {
        b bVar;
        Object k2 = k();
        t tVar = this.f188f;
        if (tVar == null && (bVar = (b) getLastNonConfigurationInstance()) != null) {
            tVar = bVar.f195b;
        }
        if (tVar == null && k2 == null) {
            return null;
        }
        b bVar2 = new b();
        bVar2.f194a = k2;
        bVar2.f195b = tVar;
        return bVar2;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // t.e, android.app.Activity
    public void onSaveInstanceState(Bundle bundle) {
        d a2 = a();
        if (a2 instanceof h) {
            ((h) a2).p(d.b.CREATED);
        }
        super.onSaveInstanceState(bundle);
        this.f187e.d(bundle);
    }
}
