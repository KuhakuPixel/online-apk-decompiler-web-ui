package androidx.work;
/* loaded from: classes.dex */
public enum OutOfQuotaPolicy {
    RUN_AS_NON_EXPEDITED_WORK_REQUEST,
    DROP_WORK_REQUEST
}
