package androidx.recyclerview.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.view.MotionEvent;
import androidx.recyclerview.widget.RecyclerView;
import e0.q;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes.dex */
public class d extends RecyclerView.n implements RecyclerView.s {
    private static final int[] D = {16842919};
    private static final int[] E = new int[0];
    int A;
    private final Runnable B;
    private final RecyclerView.t C;

    /* renamed from: a  reason: collision with root package name */
    private final int f2395a;

    /* renamed from: b  reason: collision with root package name */
    private final int f2396b;

    /* renamed from: c  reason: collision with root package name */
    final StateListDrawable f2397c;

    /* renamed from: d  reason: collision with root package name */
    final Drawable f2398d;

    /* renamed from: e  reason: collision with root package name */
    private final int f2399e;

    /* renamed from: f  reason: collision with root package name */
    private final int f2400f;

    /* renamed from: g  reason: collision with root package name */
    private final StateListDrawable f2401g;

    /* renamed from: h  reason: collision with root package name */
    private final Drawable f2402h;

    /* renamed from: i  reason: collision with root package name */
    private final int f2403i;

    /* renamed from: j  reason: collision with root package name */
    private final int f2404j;

    /* renamed from: k  reason: collision with root package name */
    int f2405k;

    /* renamed from: l  reason: collision with root package name */
    int f2406l;

    /* renamed from: m  reason: collision with root package name */
    float f2407m;

    /* renamed from: n  reason: collision with root package name */
    int f2408n;

    /* renamed from: o  reason: collision with root package name */
    int f2409o;

    /* renamed from: p  reason: collision with root package name */
    float f2410p;

    /* renamed from: s  reason: collision with root package name */
    private RecyclerView f2413s;

    /* renamed from: z  reason: collision with root package name */
    final ValueAnimator f2420z;

    /* renamed from: q  reason: collision with root package name */
    private int f2411q = 0;

    /* renamed from: r  reason: collision with root package name */
    private int f2412r = 0;

    /* renamed from: t  reason: collision with root package name */
    private boolean f2414t = false;

    /* renamed from: u  reason: collision with root package name */
    private boolean f2415u = false;

    /* renamed from: v  reason: collision with root package name */
    private int f2416v = 0;

    /* renamed from: w  reason: collision with root package name */
    private int f2417w = 0;

    /* renamed from: x  reason: collision with root package name */
    private final int[] f2418x = new int[2];

    /* renamed from: y  reason: collision with root package name */
    private final int[] f2419y = new int[2];

    /* loaded from: classes.dex */
    class a implements Runnable {
        a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            d.this.q(500);
        }
    }

    /* loaded from: classes.dex */
    class b extends RecyclerView.t {
        b() {
        }

        @Override // androidx.recyclerview.widget.RecyclerView.t
        public void b(RecyclerView recyclerView, int i2, int i3) {
            d.this.B(recyclerView.computeHorizontalScrollOffset(), recyclerView.computeVerticalScrollOffset());
        }
    }

    /* loaded from: classes.dex */
    private class c extends AnimatorListenerAdapter {

        /* renamed from: a  reason: collision with root package name */
        private boolean f2423a = false;

        c() {
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationCancel(Animator animator) {
            this.f2423a = true;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            if (this.f2423a) {
                this.f2423a = false;
            } else if (((Float) d.this.f2420z.getAnimatedValue()).floatValue() == 0.0f) {
                d dVar = d.this;
                dVar.A = 0;
                dVar.y(0);
            } else {
                d dVar2 = d.this;
                dVar2.A = 2;
                dVar2.v();
            }
        }
    }

    /* renamed from: androidx.recyclerview.widget.d$d  reason: collision with other inner class name */
    /* loaded from: classes.dex */
    private class C0018d implements ValueAnimator.AnimatorUpdateListener {
        C0018d() {
        }

        @Override // android.animation.ValueAnimator.AnimatorUpdateListener
        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            int floatValue = (int) (((Float) valueAnimator.getAnimatedValue()).floatValue() * 255.0f);
            d.this.f2397c.setAlpha(floatValue);
            d.this.f2398d.setAlpha(floatValue);
            d.this.v();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public d(RecyclerView recyclerView, StateListDrawable stateListDrawable, Drawable drawable, StateListDrawable stateListDrawable2, Drawable drawable2, int i2, int i3, int i4) {
        ValueAnimator ofFloat = ValueAnimator.ofFloat(0.0f, 1.0f);
        this.f2420z = ofFloat;
        this.A = 0;
        this.B = new a();
        this.C = new b();
        this.f2397c = stateListDrawable;
        this.f2398d = drawable;
        this.f2401g = stateListDrawable2;
        this.f2402h = drawable2;
        this.f2399e = Math.max(i2, stateListDrawable.getIntrinsicWidth());
        this.f2400f = Math.max(i2, drawable.getIntrinsicWidth());
        this.f2403i = Math.max(i2, stateListDrawable2.getIntrinsicWidth());
        this.f2404j = Math.max(i2, drawable2.getIntrinsicWidth());
        this.f2395a = i3;
        this.f2396b = i4;
        stateListDrawable.setAlpha(255);
        drawable.setAlpha(255);
        ofFloat.addListener(new c());
        ofFloat.addUpdateListener(new C0018d());
        j(recyclerView);
    }

    private void C(float f2) {
        int[] p2 = p();
        float max = Math.max(p2[0], Math.min(p2[1], f2));
        if (Math.abs(this.f2406l - max) < 2.0f) {
            return;
        }
        int x2 = x(this.f2407m, max, p2, this.f2413s.computeVerticalScrollRange(), this.f2413s.computeVerticalScrollOffset(), this.f2412r);
        if (x2 != 0) {
            this.f2413s.scrollBy(0, x2);
        }
        this.f2407m = max;
    }

    private void k() {
        this.f2413s.removeCallbacks(this.B);
    }

    private void l() {
        this.f2413s.V0(this);
        this.f2413s.W0(this);
        this.f2413s.X0(this.C);
        k();
    }

    private void m(Canvas canvas) {
        int i2 = this.f2412r;
        int i3 = this.f2403i;
        int i4 = this.f2409o;
        int i5 = this.f2408n;
        this.f2401g.setBounds(0, 0, i5, i3);
        this.f2402h.setBounds(0, 0, this.f2411q, this.f2404j);
        canvas.translate(0.0f, i2 - i3);
        this.f2402h.draw(canvas);
        canvas.translate(i4 - (i5 / 2), 0.0f);
        this.f2401g.draw(canvas);
        canvas.translate(-r2, -r0);
    }

    private void n(Canvas canvas) {
        int i2 = this.f2411q;
        int i3 = this.f2399e;
        int i4 = i2 - i3;
        int i5 = this.f2406l;
        int i6 = this.f2405k;
        int i7 = i5 - (i6 / 2);
        this.f2397c.setBounds(0, 0, i3, i6);
        this.f2398d.setBounds(0, 0, this.f2400f, this.f2412r);
        if (s()) {
            this.f2398d.draw(canvas);
            canvas.translate(this.f2399e, i7);
            canvas.scale(-1.0f, 1.0f);
            this.f2397c.draw(canvas);
            canvas.scale(1.0f, 1.0f);
            i4 = this.f2399e;
        } else {
            canvas.translate(i4, 0.0f);
            this.f2398d.draw(canvas);
            canvas.translate(0.0f, i7);
            this.f2397c.draw(canvas);
        }
        canvas.translate(-i4, -i7);
    }

    private int[] o() {
        int[] iArr = this.f2419y;
        int i2 = this.f2396b;
        iArr[0] = i2;
        iArr[1] = this.f2411q - i2;
        return iArr;
    }

    private int[] p() {
        int[] iArr = this.f2418x;
        int i2 = this.f2396b;
        iArr[0] = i2;
        iArr[1] = this.f2412r - i2;
        return iArr;
    }

    private void r(float f2) {
        int[] o2 = o();
        float max = Math.max(o2[0], Math.min(o2[1], f2));
        if (Math.abs(this.f2409o - max) < 2.0f) {
            return;
        }
        int x2 = x(this.f2410p, max, o2, this.f2413s.computeHorizontalScrollRange(), this.f2413s.computeHorizontalScrollOffset(), this.f2411q);
        if (x2 != 0) {
            this.f2413s.scrollBy(x2, 0);
        }
        this.f2410p = max;
    }

    private boolean s() {
        return q.B(this.f2413s) == 1;
    }

    private void w(int i2) {
        k();
        this.f2413s.postDelayed(this.B, i2);
    }

    private int x(float f2, float f3, int[] iArr, int i2, int i3, int i4) {
        int i5 = iArr[1] - iArr[0];
        if (i5 == 0) {
            return 0;
        }
        int i6 = i2 - i4;
        int i7 = (int) (((f3 - f2) / i5) * i6);
        int i8 = i3 + i7;
        if (i8 >= i6 || i8 < 0) {
            return 0;
        }
        return i7;
    }

    private void z() {
        this.f2413s.h(this);
        this.f2413s.j(this);
        this.f2413s.k(this.C);
    }

    public void A() {
        int i2 = this.A;
        if (i2 != 0) {
            if (i2 != 3) {
                return;
            }
            this.f2420z.cancel();
        }
        this.A = 1;
        ValueAnimator valueAnimator = this.f2420z;
        valueAnimator.setFloatValues(((Float) valueAnimator.getAnimatedValue()).floatValue(), 1.0f);
        this.f2420z.setDuration(500L);
        this.f2420z.setStartDelay(0L);
        this.f2420z.start();
    }

    void B(int i2, int i3) {
        int computeVerticalScrollRange = this.f2413s.computeVerticalScrollRange();
        int i4 = this.f2412r;
        this.f2414t = computeVerticalScrollRange - i4 > 0 && i4 >= this.f2395a;
        int computeHorizontalScrollRange = this.f2413s.computeHorizontalScrollRange();
        int i5 = this.f2411q;
        boolean z2 = computeHorizontalScrollRange - i5 > 0 && i5 >= this.f2395a;
        this.f2415u = z2;
        boolean z3 = this.f2414t;
        if (!z3 && !z2) {
            if (this.f2416v != 0) {
                y(0);
                return;
            }
            return;
        }
        if (z3) {
            float f2 = i4;
            this.f2406l = (int) ((f2 * (i3 + (f2 / 2.0f))) / computeVerticalScrollRange);
            this.f2405k = Math.min(i4, (i4 * i4) / computeVerticalScrollRange);
        }
        if (this.f2415u) {
            float f3 = i5;
            this.f2409o = (int) ((f3 * (i2 + (f3 / 2.0f))) / computeHorizontalScrollRange);
            this.f2408n = Math.min(i5, (i5 * i5) / computeHorizontalScrollRange);
        }
        int i6 = this.f2416v;
        if (i6 == 0 || i6 == 1) {
            y(1);
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.s
    public boolean a(RecyclerView recyclerView, MotionEvent motionEvent) {
        int i2 = this.f2416v;
        if (i2 == 1) {
            boolean u2 = u(motionEvent.getX(), motionEvent.getY());
            boolean t2 = t(motionEvent.getX(), motionEvent.getY());
            if (motionEvent.getAction() != 0) {
                return false;
            }
            if (!u2 && !t2) {
                return false;
            }
            if (t2) {
                this.f2417w = 1;
                this.f2410p = (int) motionEvent.getX();
            } else if (u2) {
                this.f2417w = 2;
                this.f2407m = (int) motionEvent.getY();
            }
            y(2);
        } else if (i2 != 2) {
            return false;
        }
        return true;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.s
    public void b(RecyclerView recyclerView, MotionEvent motionEvent) {
        if (this.f2416v == 0) {
            return;
        }
        if (motionEvent.getAction() == 0) {
            boolean u2 = u(motionEvent.getX(), motionEvent.getY());
            boolean t2 = t(motionEvent.getX(), motionEvent.getY());
            if (u2 || t2) {
                if (t2) {
                    this.f2417w = 1;
                    this.f2410p = (int) motionEvent.getX();
                } else if (u2) {
                    this.f2417w = 2;
                    this.f2407m = (int) motionEvent.getY();
                }
                y(2);
            }
        } else if (motionEvent.getAction() == 1 && this.f2416v == 2) {
            this.f2407m = 0.0f;
            this.f2410p = 0.0f;
            y(1);
            this.f2417w = 0;
        } else if (motionEvent.getAction() == 2 && this.f2416v == 2) {
            A();
            if (this.f2417w == 1) {
                r(motionEvent.getX());
            }
            if (this.f2417w == 2) {
                C(motionEvent.getY());
            }
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.s
    public void c(boolean z2) {
    }

    @Override // androidx.recyclerview.widget.RecyclerView.n
    public void i(Canvas canvas, RecyclerView recyclerView, RecyclerView.a0 a0Var) {
        if (this.f2411q != this.f2413s.getWidth() || this.f2412r != this.f2413s.getHeight()) {
            this.f2411q = this.f2413s.getWidth();
            this.f2412r = this.f2413s.getHeight();
            y(0);
        } else if (this.A != 0) {
            if (this.f2414t) {
                n(canvas);
            }
            if (this.f2415u) {
                m(canvas);
            }
        }
    }

    public void j(RecyclerView recyclerView) {
        RecyclerView recyclerView2 = this.f2413s;
        if (recyclerView2 == recyclerView) {
            return;
        }
        if (recyclerView2 != null) {
            l();
        }
        this.f2413s = recyclerView;
        if (recyclerView != null) {
            z();
        }
    }

    void q(int i2) {
        int i3 = this.A;
        if (i3 == 1) {
            this.f2420z.cancel();
        } else if (i3 != 2) {
            return;
        }
        this.A = 3;
        ValueAnimator valueAnimator = this.f2420z;
        valueAnimator.setFloatValues(((Float) valueAnimator.getAnimatedValue()).floatValue(), 0.0f);
        this.f2420z.setDuration(i2);
        this.f2420z.start();
    }

    boolean t(float f2, float f3) {
        if (f3 >= this.f2412r - this.f2403i) {
            int i2 = this.f2409o;
            int i3 = this.f2408n;
            if (f2 >= i2 - (i3 / 2) && f2 <= i2 + (i3 / 2)) {
                return true;
            }
        }
        return false;
    }

    boolean u(float f2, float f3) {
        if (!s() ? f2 >= this.f2411q - this.f2399e : f2 <= this.f2399e / 2) {
            int i2 = this.f2406l;
            int i3 = this.f2405k;
            if (f3 >= i2 - (i3 / 2) && f3 <= i2 + (i3 / 2)) {
                return true;
            }
        }
        return false;
    }

    void v() {
        this.f2413s.invalidate();
    }

    void y(int i2) {
        int i3;
        if (i2 == 2 && this.f2416v != 2) {
            this.f2397c.setState(D);
            k();
        }
        if (i2 == 0) {
            v();
        } else {
            A();
        }
        if (this.f2416v != 2 || i2 == 2) {
            i3 = i2 == 1 ? 1500 : 1200;
            this.f2416v = i2;
        }
        this.f2397c.setState(E);
        w(i3);
        this.f2416v = i2;
    }
}
