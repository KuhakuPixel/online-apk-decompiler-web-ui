package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import java.lang.ref.WeakReference;
/* loaded from: classes.dex */
public class y0 extends Resources {

    /* renamed from: b  reason: collision with root package name */
    private static boolean f1019b = false;

    /* renamed from: a  reason: collision with root package name */
    private final WeakReference<Context> f1020a;

    public y0(Context context, Resources resources) {
        super(resources.getAssets(), resources.getDisplayMetrics(), resources.getConfiguration());
        this.f1020a = new WeakReference<>(context);
    }

    public static boolean a() {
        return f1019b;
    }

    public static boolean b() {
        a();
        return false;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final Drawable c(int i2) {
        return super.getDrawable(i2);
    }

    @Override // android.content.res.Resources
    public Drawable getDrawable(int i2) {
        Context context = this.f1020a.get();
        return context != null ? j0.h().t(context, this, i2) : super.getDrawable(i2);
    }
}
