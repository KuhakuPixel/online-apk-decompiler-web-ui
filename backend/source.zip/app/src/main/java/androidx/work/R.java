package androidx.work;
/* loaded from: classes.dex */
public final class R {

    /* loaded from: classes.dex */
    public static final class bool {
        public static final int enable_system_alarm_service_default = 0x7f040002;
        public static final int enable_system_foreground_service_default = 0x7f040003;
        public static final int enable_system_job_service_default = 0x7f040004;
        public static final int workmanager_test_configuration = 0x7f040005;

        private bool() {
        }
    }

    private R() {
    }
}
