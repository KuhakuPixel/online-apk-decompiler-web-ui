package androidx.navigation;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import androidx.navigation.k;
import java.util.Iterator;
import java.util.NoSuchElementException;
/* loaded from: classes.dex */
public class l extends k implements Iterable<k> {

    /* renamed from: k  reason: collision with root package name */
    final l.h<k> f2014k;

    /* renamed from: l  reason: collision with root package name */
    private int f2015l;

    /* renamed from: m  reason: collision with root package name */
    private String f2016m;

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public class a implements Iterator<k> {

        /* renamed from: b  reason: collision with root package name */
        private int f2017b = -1;

        /* renamed from: c  reason: collision with root package name */
        private boolean f2018c = false;

        a() {
        }

        @Override // java.util.Iterator
        /* renamed from: a  reason: merged with bridge method [inline-methods] */
        public k next() {
            if (hasNext()) {
                this.f2018c = true;
                l.h<k> hVar = l.this.f2014k;
                int i2 = this.f2017b + 1;
                this.f2017b = i2;
                return hVar.m(i2);
            }
            throw new NoSuchElementException();
        }

        @Override // java.util.Iterator
        public boolean hasNext() {
            return this.f2017b + 1 < l.this.f2014k.l();
        }

        @Override // java.util.Iterator
        public void remove() {
            if (!this.f2018c) {
                throw new IllegalStateException("You must call next() before you can remove an element");
            }
            l.this.f2014k.m(this.f2017b).t(null);
            l.this.f2014k.k(this.f2017b);
            this.f2017b--;
            this.f2018c = false;
        }
    }

    public l(s<? extends l> sVar) {
        super(sVar);
        this.f2014k = new l.h<>();
    }

    public final void A(int i2) {
        if (i2 != k()) {
            this.f2015l = i2;
            this.f2016m = null;
            return;
        }
        throw new IllegalArgumentException("Start destination " + i2 + " cannot use the same id as the graph " + this);
    }

    @Override // androidx.navigation.k
    public String i() {
        return k() != 0 ? super.i() : "the root navigation";
    }

    @Override // java.lang.Iterable
    public final Iterator<k> iterator() {
        return new a();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    @Override // androidx.navigation.k
    public k.a o(j jVar) {
        k.a o2 = super.o(jVar);
        Iterator<k> it = iterator();
        while (it.hasNext()) {
            k.a o3 = it.next().o(jVar);
            if (o3 != null && (o2 == null || o3.compareTo(o2) > 0)) {
                o2 = o3;
            }
        }
        return o2;
    }

    @Override // androidx.navigation.k
    public void p(Context context, AttributeSet attributeSet) {
        super.p(context, attributeSet);
        TypedArray obtainAttributes = context.getResources().obtainAttributes(attributeSet, o0.a.f4828y);
        A(obtainAttributes.getResourceId(o0.a.f4829z, 0));
        this.f2016m = k.j(context, this.f2015l);
        obtainAttributes.recycle();
    }

    @Override // androidx.navigation.k
    public String toString() {
        String str;
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append(" startDestination=");
        k w2 = w(z());
        if (w2 == null) {
            str = this.f2016m;
            if (str == null) {
                sb.append("0x");
                str = Integer.toHexString(this.f2015l);
            }
        } else {
            sb.append("{");
            sb.append(w2.toString());
            str = "}";
        }
        sb.append(str);
        return sb.toString();
    }

    public final void v(k kVar) {
        int k2 = kVar.k();
        if (k2 == 0) {
            throw new IllegalArgumentException("Destinations must have an id. Call setId() or include an android:id in your navigation XML.");
        }
        if (k2 == k()) {
            throw new IllegalArgumentException("Destination " + kVar + " cannot have the same id as graph " + this);
        }
        k e2 = this.f2014k.e(k2);
        if (e2 == kVar) {
            return;
        }
        if (kVar.n() != null) {
            throw new IllegalStateException("Destination already has a parent set. Call NavGraph.remove() to remove the previous parent.");
        }
        if (e2 != null) {
            e2.t(null);
        }
        kVar.t(this);
        this.f2014k.i(kVar.k(), kVar);
    }

    public final k w(int i2) {
        return x(i2, true);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final k x(int i2, boolean z2) {
        k e2 = this.f2014k.e(i2);
        if (e2 != null) {
            return e2;
        }
        if (!z2 || n() == null) {
            return null;
        }
        return n().w(i2);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public String y() {
        if (this.f2016m == null) {
            this.f2016m = Integer.toString(this.f2015l);
        }
        return this.f2016m;
    }

    public final int z() {
        return this.f2015l;
    }
}
