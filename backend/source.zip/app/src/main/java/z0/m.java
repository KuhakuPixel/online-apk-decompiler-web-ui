package z0;

import android.os.IBinder;
import android.os.IInterface;
/* loaded from: classes.dex */
public abstract class m extends p implements n {
    public static n p(IBinder iBinder) {
        if (iBinder == null) {
            return null;
        }
        IInterface queryLocalInterface = iBinder.queryLocalInterface("com.android.vending.billing.IInAppBillingService");
        return queryLocalInterface instanceof n ? (n) queryLocalInterface : new l(iBinder);
    }
}
