package p1;

import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Region;
import android.graphics.Shader;
/* loaded from: classes.dex */
public class a {

    /* renamed from: i  reason: collision with root package name */
    private static final int[] f4968i = new int[3];

    /* renamed from: j  reason: collision with root package name */
    private static final float[] f4969j = {0.0f, 0.5f, 1.0f};

    /* renamed from: k  reason: collision with root package name */
    private static final int[] f4970k = new int[4];

    /* renamed from: l  reason: collision with root package name */
    private static final float[] f4971l = {0.0f, 0.0f, 0.5f, 1.0f};

    /* renamed from: a  reason: collision with root package name */
    private final Paint f4972a;

    /* renamed from: b  reason: collision with root package name */
    private final Paint f4973b;

    /* renamed from: c  reason: collision with root package name */
    private final Paint f4974c;

    /* renamed from: d  reason: collision with root package name */
    private int f4975d;

    /* renamed from: e  reason: collision with root package name */
    private int f4976e;

    /* renamed from: f  reason: collision with root package name */
    private int f4977f;

    /* renamed from: g  reason: collision with root package name */
    private final Path f4978g;

    /* renamed from: h  reason: collision with root package name */
    private Paint f4979h;

    public a() {
        this(-16777216);
    }

    public a(int i2) {
        this.f4978g = new Path();
        this.f4979h = new Paint();
        this.f4972a = new Paint();
        d(i2);
        this.f4979h.setColor(0);
        Paint paint = new Paint(4);
        this.f4973b = paint;
        paint.setStyle(Paint.Style.FILL);
        this.f4974c = new Paint(paint);
    }

    public void a(Canvas canvas, Matrix matrix, RectF rectF, int i2, float f2, float f3) {
        boolean z2 = f3 < 0.0f;
        Path path = this.f4978g;
        if (z2) {
            int[] iArr = f4970k;
            iArr[0] = 0;
            iArr[1] = this.f4977f;
            iArr[2] = this.f4976e;
            iArr[3] = this.f4975d;
        } else {
            path.rewind();
            path.moveTo(rectF.centerX(), rectF.centerY());
            path.arcTo(rectF, f2, f3);
            path.close();
            float f4 = -i2;
            rectF.inset(f4, f4);
            int[] iArr2 = f4970k;
            iArr2[0] = 0;
            iArr2[1] = this.f4975d;
            iArr2[2] = this.f4976e;
            iArr2[3] = this.f4977f;
        }
        float width = rectF.width() / 2.0f;
        if (width <= 0.0f) {
            return;
        }
        float f5 = 1.0f - (i2 / width);
        float[] fArr = f4971l;
        fArr[1] = f5;
        fArr[2] = ((1.0f - f5) / 2.0f) + f5;
        this.f4973b.setShader(new RadialGradient(rectF.centerX(), rectF.centerY(), width, f4970k, fArr, Shader.TileMode.CLAMP));
        canvas.save();
        canvas.concat(matrix);
        if (!z2) {
            canvas.clipPath(path, Region.Op.DIFFERENCE);
            canvas.drawPath(path, this.f4979h);
        }
        canvas.drawArc(rectF, f2, f3, true, this.f4973b);
        canvas.restore();
    }

    public void b(Canvas canvas, Matrix matrix, RectF rectF, int i2) {
        rectF.bottom += i2;
        rectF.offset(0.0f, -i2);
        int[] iArr = f4968i;
        iArr[0] = this.f4977f;
        iArr[1] = this.f4976e;
        iArr[2] = this.f4975d;
        Paint paint = this.f4974c;
        float f2 = rectF.left;
        paint.setShader(new LinearGradient(f2, rectF.top, f2, rectF.bottom, iArr, f4969j, Shader.TileMode.CLAMP));
        canvas.save();
        canvas.concat(matrix);
        canvas.drawRect(rectF, this.f4974c);
        canvas.restore();
    }

    public Paint c() {
        return this.f4972a;
    }

    public void d(int i2) {
        this.f4975d = w.a.d(i2, 68);
        this.f4976e = w.a.d(i2, 20);
        this.f4977f = w.a.d(i2, 0);
        this.f4972a.setColor(this.f4975d);
    }
}
