package w1;

import android.util.SparseIntArray;
import android.view.View;
import androidx.appcompat.widget.LinearLayoutCompat;
import androidx.appcompat.widget.Toolbar;
import androidx.databinding.ViewDataBinding;
import androidx.fragment.app.FragmentContainerView;
import com.sample.android.kuhakupixelinapppurchase.R;
/* loaded from: classes.dex */
public class b extends a {
    private static final SparseIntArray F;
    private long E;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        F = sparseIntArray;
        sparseIntArray.put(R.id.toolbar, 1);
        sparseIntArray.put(R.id.nav_host_fragment, 2);
    }

    public b(androidx.databinding.e eVar, View view) {
        this(eVar, view, ViewDataBinding.u(eVar, view, 3, null, F));
    }

    private b(androidx.databinding.e eVar, View view, Object[] objArr) {
        super(eVar, view, 0, (LinearLayoutCompat) objArr[0], (FragmentContainerView) objArr[2], (Toolbar) objArr[1]);
        this.E = -1L;
        this.B.setTag(null);
        D(view);
        H();
    }

    public void H() {
        synchronized (this) {
            this.E = 1L;
        }
        z();
    }

    @Override // androidx.databinding.ViewDataBinding
    protected void l() {
        synchronized (this) {
            this.E = 0L;
        }
    }

    @Override // androidx.databinding.ViewDataBinding
    public boolean r() {
        synchronized (this) {
            return this.E != 0;
        }
    }

    @Override // androidx.databinding.ViewDataBinding
    protected boolean v(int i2, Object obj, int i3) {
        return false;
    }
}
