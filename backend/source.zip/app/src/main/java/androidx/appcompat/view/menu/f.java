package androidx.appcompat.view.menu;

import android.content.DialogInterface;
import android.os.IBinder;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import androidx.appcompat.app.a;
import androidx.appcompat.view.menu.j;
/* loaded from: classes.dex */
class f implements DialogInterface.OnKeyListener, DialogInterface.OnClickListener, DialogInterface.OnDismissListener, j.a {

    /* renamed from: b  reason: collision with root package name */
    private e f413b;

    /* renamed from: c  reason: collision with root package name */
    private androidx.appcompat.app.a f414c;

    /* renamed from: d  reason: collision with root package name */
    c f415d;

    /* renamed from: e  reason: collision with root package name */
    private j.a f416e;

    public f(e eVar) {
        this.f413b = eVar;
    }

    public void a() {
        androidx.appcompat.app.a aVar = this.f414c;
        if (aVar != null) {
            aVar.dismiss();
        }
    }

    @Override // androidx.appcompat.view.menu.j.a
    public void b(e eVar, boolean z2) {
        if (z2 || eVar == this.f413b) {
            a();
        }
        j.a aVar = this.f416e;
        if (aVar != null) {
            aVar.b(eVar, z2);
        }
    }

    @Override // androidx.appcompat.view.menu.j.a
    public boolean c(e eVar) {
        j.a aVar = this.f416e;
        if (aVar != null) {
            return aVar.c(eVar);
        }
        return false;
    }

    public void d(IBinder iBinder) {
        e eVar = this.f413b;
        a.C0001a c0001a = new a.C0001a(eVar.u());
        c cVar = new c(c0001a.b(), a.g.abc_list_menu_item_layout);
        this.f415d = cVar;
        cVar.h(this);
        this.f413b.b(this.f415d);
        c0001a.c(this.f415d.a(), this);
        View y2 = eVar.y();
        if (y2 != null) {
            c0001a.d(y2);
        } else {
            c0001a.e(eVar.w()).h(eVar.x());
        }
        c0001a.f(this);
        androidx.appcompat.app.a a2 = c0001a.a();
        this.f414c = a2;
        a2.setOnDismissListener(this);
        WindowManager.LayoutParams attributes = this.f414c.getWindow().getAttributes();
        attributes.type = 1003;
        if (iBinder != null) {
            attributes.token = iBinder;
        }
        attributes.flags |= 131072;
        this.f414c.show();
    }

    @Override // android.content.DialogInterface.OnClickListener
    public void onClick(DialogInterface dialogInterface, int i2) {
        this.f413b.L((g) this.f415d.a().getItem(i2), 0);
    }

    @Override // android.content.DialogInterface.OnDismissListener
    public void onDismiss(DialogInterface dialogInterface) {
        this.f415d.b(this.f413b, true);
    }

    @Override // android.content.DialogInterface.OnKeyListener
    public boolean onKey(DialogInterface dialogInterface, int i2, KeyEvent keyEvent) {
        Window window;
        View decorView;
        KeyEvent.DispatcherState keyDispatcherState;
        View decorView2;
        KeyEvent.DispatcherState keyDispatcherState2;
        if (i2 == 82 || i2 == 4) {
            if (keyEvent.getAction() == 0 && keyEvent.getRepeatCount() == 0) {
                Window window2 = this.f414c.getWindow();
                if (window2 != null && (decorView2 = window2.getDecorView()) != null && (keyDispatcherState2 = decorView2.getKeyDispatcherState()) != null) {
                    keyDispatcherState2.startTracking(keyEvent, this);
                    return true;
                }
            } else if (keyEvent.getAction() == 1 && !keyEvent.isCanceled() && (window = this.f414c.getWindow()) != null && (decorView = window.getDecorView()) != null && (keyDispatcherState = decorView.getKeyDispatcherState()) != null && keyDispatcherState.isTracking(keyEvent)) {
                this.f413b.e(true);
                dialogInterface.dismiss();
                return true;
            }
        }
        return this.f413b.performShortcut(i2, keyEvent, 0);
    }
}
