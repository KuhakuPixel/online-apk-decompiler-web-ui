package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import androidx.constraintlayout.widget.ConstraintLayout;
import java.util.Arrays;
import java.util.HashMap;
/* loaded from: classes.dex */
public abstract class b extends View {

    /* renamed from: b  reason: collision with root package name */
    protected int[] f1139b;

    /* renamed from: c  reason: collision with root package name */
    protected int f1140c;

    /* renamed from: d  reason: collision with root package name */
    protected Context f1141d;

    /* renamed from: e  reason: collision with root package name */
    protected p.h f1142e;

    /* renamed from: f  reason: collision with root package name */
    protected boolean f1143f;

    /* renamed from: g  reason: collision with root package name */
    protected String f1144g;

    /* renamed from: h  reason: collision with root package name */
    protected String f1145h;

    /* renamed from: i  reason: collision with root package name */
    private View[] f1146i;

    /* renamed from: j  reason: collision with root package name */
    private HashMap<Integer, String> f1147j;

    public b(Context context) {
        super(context);
        this.f1139b = new int[32];
        this.f1143f = false;
        this.f1146i = null;
        this.f1147j = new HashMap<>();
        this.f1141d = context;
        h(null);
    }

    public b(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f1139b = new int[32];
        this.f1143f = false;
        this.f1146i = null;
        this.f1147j = new HashMap<>();
        this.f1141d = context;
        h(attributeSet);
    }

    private void a(String str) {
        if (str == null || str.length() == 0 || this.f1141d == null) {
            return;
        }
        String trim = str.trim();
        if (getParent() instanceof ConstraintLayout) {
            ConstraintLayout constraintLayout = (ConstraintLayout) getParent();
        }
        int g2 = g(trim);
        if (g2 != 0) {
            this.f1147j.put(Integer.valueOf(g2), trim);
            b(g2);
            return;
        }
        Log.w("ConstraintHelper", "Could not find id of \"" + trim + "\"");
    }

    private void b(int i2) {
        if (i2 == getId()) {
            return;
        }
        int i3 = this.f1140c + 1;
        int[] iArr = this.f1139b;
        if (i3 > iArr.length) {
            this.f1139b = Arrays.copyOf(iArr, iArr.length * 2);
        }
        int[] iArr2 = this.f1139b;
        int i4 = this.f1140c;
        iArr2[i4] = i2;
        this.f1140c = i4 + 1;
    }

    private void c(String str) {
        if (str == null || str.length() == 0 || this.f1141d == null) {
            return;
        }
        String trim = str.trim();
        ConstraintLayout constraintLayout = getParent() instanceof ConstraintLayout ? (ConstraintLayout) getParent() : null;
        if (constraintLayout == null) {
            Log.w("ConstraintHelper", "Parent not a ConstraintLayout");
            return;
        }
        int childCount = constraintLayout.getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = constraintLayout.getChildAt(i2);
            ViewGroup.LayoutParams layoutParams = childAt.getLayoutParams();
            if ((layoutParams instanceof ConstraintLayout.b) && trim.equals(((ConstraintLayout.b) layoutParams).V)) {
                if (childAt.getId() == -1) {
                    Log.w("ConstraintHelper", "to use ConstraintTag view " + childAt.getClass().getSimpleName() + " must have an ID");
                } else {
                    b(childAt.getId());
                }
            }
        }
    }

    private int f(ConstraintLayout constraintLayout, String str) {
        Resources resources;
        if (str == null || constraintLayout == null || (resources = this.f1141d.getResources()) == null) {
            return 0;
        }
        int childCount = constraintLayout.getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = constraintLayout.getChildAt(i2);
            if (childAt.getId() != -1) {
                String str2 = null;
                try {
                    str2 = resources.getResourceEntryName(childAt.getId());
                } catch (Resources.NotFoundException unused) {
                }
                if (str.equals(str2)) {
                    return childAt.getId();
                }
            }
        }
        return 0;
    }

    private int g(String str) {
        ConstraintLayout constraintLayout = getParent() instanceof ConstraintLayout ? (ConstraintLayout) getParent() : null;
        int i2 = 0;
        if (isInEditMode() && constraintLayout != null) {
            Object g2 = constraintLayout.g(0, str);
            if (g2 instanceof Integer) {
                i2 = ((Integer) g2).intValue();
            }
        }
        if (i2 == 0 && constraintLayout != null) {
            i2 = f(constraintLayout, str);
        }
        if (i2 == 0) {
            try {
                i2 = h.class.getField(str).getInt(null);
            } catch (Exception unused) {
            }
        }
        return i2 == 0 ? this.f1141d.getResources().getIdentifier(str, "id", this.f1141d.getPackageName()) : i2;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public void d() {
        ViewParent parent = getParent();
        if (parent == null || !(parent instanceof ConstraintLayout)) {
            return;
        }
        e((ConstraintLayout) parent);
    }

    protected void e(ConstraintLayout constraintLayout) {
        int visibility = getVisibility();
        float elevation = getElevation();
        for (int i2 = 0; i2 < this.f1140c; i2++) {
            View i3 = constraintLayout.i(this.f1139b[i2]);
            if (i3 != null) {
                i3.setVisibility(visibility);
                if (elevation > 0.0f) {
                    i3.setTranslationZ(i3.getTranslationZ() + elevation);
                }
            }
        }
    }

    public int[] getReferencedIds() {
        return Arrays.copyOf(this.f1139b, this.f1140c);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public void h(AttributeSet attributeSet) {
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, i.f1255a1);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i2 = 0; i2 < indexCount; i2++) {
                int index = obtainStyledAttributes.getIndex(i2);
                if (index == i.f1291m1) {
                    String string = obtainStyledAttributes.getString(index);
                    this.f1144g = string;
                    setIds(string);
                } else if (index == i.f1294n1) {
                    String string2 = obtainStyledAttributes.getString(index);
                    this.f1145h = string2;
                    setReferenceTags(string2);
                }
            }
            obtainStyledAttributes.recycle();
        }
    }

    public void i(p.e eVar, boolean z2) {
    }

    public void j(ConstraintLayout constraintLayout) {
    }

    public void k(ConstraintLayout constraintLayout) {
    }

    public void l(ConstraintLayout constraintLayout) {
    }

    public void m(ConstraintLayout constraintLayout) {
        String str;
        int f2;
        if (isInEditMode()) {
            setIds(this.f1144g);
        }
        p.h hVar = this.f1142e;
        if (hVar == null) {
            return;
        }
        hVar.a();
        for (int i2 = 0; i2 < this.f1140c; i2++) {
            int i3 = this.f1139b[i2];
            View i4 = constraintLayout.i(i3);
            if (i4 == null && (f2 = f(constraintLayout, (str = this.f1147j.get(Integer.valueOf(i3))))) != 0) {
                this.f1139b[i2] = f2;
                this.f1147j.put(Integer.valueOf(f2), str);
                i4 = constraintLayout.i(f2);
            }
            if (i4 != null) {
                this.f1142e.c(constraintLayout.j(i4));
            }
        }
        this.f1142e.b(constraintLayout.f1051d);
    }

    public void n() {
        if (this.f1142e == null) {
            return;
        }
        ViewGroup.LayoutParams layoutParams = getLayoutParams();
        if (layoutParams instanceof ConstraintLayout.b) {
            ((ConstraintLayout.b) layoutParams).f1100n0 = (p.e) this.f1142e;
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        String str = this.f1144g;
        if (str != null) {
            setIds(str);
        }
        String str2 = this.f1145h;
        if (str2 != null) {
            setReferenceTags(str2);
        }
    }

    @Override // android.view.View
    public void onDraw(Canvas canvas) {
    }

    @Override // android.view.View
    protected void onMeasure(int i2, int i3) {
        if (this.f1143f) {
            super.onMeasure(i2, i3);
        } else {
            setMeasuredDimension(0, 0);
        }
    }

    protected void setIds(String str) {
        this.f1144g = str;
        if (str == null) {
            return;
        }
        int i2 = 0;
        this.f1140c = 0;
        while (true) {
            int indexOf = str.indexOf(44, i2);
            if (indexOf == -1) {
                a(str.substring(i2));
                return;
            } else {
                a(str.substring(i2, indexOf));
                i2 = indexOf + 1;
            }
        }
    }

    protected void setReferenceTags(String str) {
        this.f1145h = str;
        if (str == null) {
            return;
        }
        int i2 = 0;
        this.f1140c = 0;
        while (true) {
            int indexOf = str.indexOf(44, i2);
            if (indexOf == -1) {
                c(str.substring(i2));
                return;
            } else {
                c(str.substring(i2, indexOf));
                i2 = indexOf + 1;
            }
        }
    }

    public void setReferencedIds(int[] iArr) {
        this.f1144g = null;
        this.f1140c = 0;
        for (int i2 : iArr) {
            b(i2);
        }
    }

    @Override // android.view.View
    public void setTag(int i2, Object obj) {
        super.setTag(i2, obj);
        if (obj == null && this.f1144g == null) {
            b(i2);
        }
    }
}
