package androidx.documentfile;
/* loaded from: classes.dex */
public final class R {
    private R() {
    }
}
