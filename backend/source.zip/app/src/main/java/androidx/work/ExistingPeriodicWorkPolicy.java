package androidx.work;
/* loaded from: classes.dex */
public enum ExistingPeriodicWorkPolicy {
    REPLACE,
    KEEP
}
