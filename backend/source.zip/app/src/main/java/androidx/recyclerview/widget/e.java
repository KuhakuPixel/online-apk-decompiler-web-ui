package androidx.recyclerview.widget;

import android.annotation.SuppressLint;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.concurrent.TimeUnit;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes.dex */
public final class e implements Runnable {

    /* renamed from: f  reason: collision with root package name */
    static final ThreadLocal<e> f2426f = new ThreadLocal<>();

    /* renamed from: g  reason: collision with root package name */
    static Comparator<c> f2427g = new a();

    /* renamed from: c  reason: collision with root package name */
    long f2429c;

    /* renamed from: d  reason: collision with root package name */
    long f2430d;

    /* renamed from: b  reason: collision with root package name */
    ArrayList<RecyclerView> f2428b = new ArrayList<>();

    /* renamed from: e  reason: collision with root package name */
    private ArrayList<c> f2431e = new ArrayList<>();

    /* loaded from: classes.dex */
    static class a implements Comparator<c> {
        a() {
        }

        @Override // java.util.Comparator
        /* renamed from: a  reason: merged with bridge method [inline-methods] */
        public int compare(c cVar, c cVar2) {
            RecyclerView recyclerView = cVar.f2439d;
            if ((recyclerView == null) != (cVar2.f2439d == null)) {
                return recyclerView == null ? 1 : -1;
            }
            boolean z2 = cVar.f2436a;
            if (z2 != cVar2.f2436a) {
                return z2 ? -1 : 1;
            }
            int i2 = cVar2.f2437b - cVar.f2437b;
            if (i2 != 0) {
                return i2;
            }
            int i3 = cVar.f2438c - cVar2.f2438c;
            if (i3 != 0) {
                return i3;
            }
            return 0;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    @SuppressLint({"VisibleForTests"})
    /* loaded from: classes.dex */
    public static class b implements RecyclerView.o.c {

        /* renamed from: a  reason: collision with root package name */
        int f2432a;

        /* renamed from: b  reason: collision with root package name */
        int f2433b;

        /* renamed from: c  reason: collision with root package name */
        int[] f2434c;

        /* renamed from: d  reason: collision with root package name */
        int f2435d;

        @Override // androidx.recyclerview.widget.RecyclerView.o.c
        public void a(int i2, int i3) {
            if (i2 < 0) {
                throw new IllegalArgumentException("Layout positions must be non-negative");
            }
            if (i3 < 0) {
                throw new IllegalArgumentException("Pixel distance must be non-negative");
            }
            int i4 = this.f2435d * 2;
            int[] iArr = this.f2434c;
            if (iArr == null) {
                int[] iArr2 = new int[4];
                this.f2434c = iArr2;
                Arrays.fill(iArr2, -1);
            } else if (i4 >= iArr.length) {
                int[] iArr3 = new int[i4 * 2];
                this.f2434c = iArr3;
                System.arraycopy(iArr, 0, iArr3, 0, iArr.length);
            }
            int[] iArr4 = this.f2434c;
            iArr4[i4] = i2;
            iArr4[i4 + 1] = i3;
            this.f2435d++;
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public void b() {
            int[] iArr = this.f2434c;
            if (iArr != null) {
                Arrays.fill(iArr, -1);
            }
            this.f2435d = 0;
        }

        void c(RecyclerView recyclerView, boolean z2) {
            this.f2435d = 0;
            int[] iArr = this.f2434c;
            if (iArr != null) {
                Arrays.fill(iArr, -1);
            }
            RecyclerView.o oVar = recyclerView.f2142n;
            if (recyclerView.f2140m == null || oVar == null || !oVar.u0()) {
                return;
            }
            if (z2) {
                if (!recyclerView.f2124e.p()) {
                    oVar.p(recyclerView.f2140m.c(), this);
                }
            } else if (!recyclerView.l0()) {
                oVar.o(this.f2432a, this.f2433b, recyclerView.f2133i0, this);
            }
            int i2 = this.f2435d;
            if (i2 > oVar.f2240m) {
                oVar.f2240m = i2;
                oVar.f2241n = z2;
                recyclerView.f2120c.K();
            }
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public boolean d(int i2) {
            if (this.f2434c != null) {
                int i3 = this.f2435d * 2;
                for (int i4 = 0; i4 < i3; i4 += 2) {
                    if (this.f2434c[i4] == i2) {
                        return true;
                    }
                }
            }
            return false;
        }

        void e(int i2, int i3) {
            this.f2432a = i2;
            this.f2433b = i3;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public static class c {

        /* renamed from: a  reason: collision with root package name */
        public boolean f2436a;

        /* renamed from: b  reason: collision with root package name */
        public int f2437b;

        /* renamed from: c  reason: collision with root package name */
        public int f2438c;

        /* renamed from: d  reason: collision with root package name */
        public RecyclerView f2439d;

        /* renamed from: e  reason: collision with root package name */
        public int f2440e;

        c() {
        }

        public void a() {
            this.f2436a = false;
            this.f2437b = 0;
            this.f2438c = 0;
            this.f2439d = null;
            this.f2440e = 0;
        }
    }

    private void b() {
        c cVar;
        int size = this.f2428b.size();
        int i2 = 0;
        for (int i3 = 0; i3 < size; i3++) {
            RecyclerView recyclerView = this.f2428b.get(i3);
            if (recyclerView.getWindowVisibility() == 0) {
                recyclerView.f2131h0.c(recyclerView, false);
                i2 += recyclerView.f2131h0.f2435d;
            }
        }
        this.f2431e.ensureCapacity(i2);
        int i4 = 0;
        for (int i5 = 0; i5 < size; i5++) {
            RecyclerView recyclerView2 = this.f2428b.get(i5);
            if (recyclerView2.getWindowVisibility() == 0) {
                b bVar = recyclerView2.f2131h0;
                int abs = Math.abs(bVar.f2432a) + Math.abs(bVar.f2433b);
                for (int i6 = 0; i6 < bVar.f2435d * 2; i6 += 2) {
                    if (i4 >= this.f2431e.size()) {
                        cVar = new c();
                        this.f2431e.add(cVar);
                    } else {
                        cVar = this.f2431e.get(i4);
                    }
                    int[] iArr = bVar.f2434c;
                    int i7 = iArr[i6 + 1];
                    cVar.f2436a = i7 <= abs;
                    cVar.f2437b = abs;
                    cVar.f2438c = i7;
                    cVar.f2439d = recyclerView2;
                    cVar.f2440e = iArr[i6];
                    i4++;
                }
            }
        }
        Collections.sort(this.f2431e, f2427g);
    }

    private void c(c cVar, long j2) {
        RecyclerView.d0 i2 = i(cVar.f2439d, cVar.f2440e, cVar.f2436a ? Long.MAX_VALUE : j2);
        if (i2 == null || i2.f2196b == null || !i2.s() || i2.t()) {
            return;
        }
        h(i2.f2196b.get(), j2);
    }

    private void d(long j2) {
        for (int i2 = 0; i2 < this.f2431e.size(); i2++) {
            c cVar = this.f2431e.get(i2);
            if (cVar.f2439d == null) {
                return;
            }
            c(cVar, j2);
            cVar.a();
        }
    }

    static boolean e(RecyclerView recyclerView, int i2) {
        int j2 = recyclerView.f2126f.j();
        for (int i3 = 0; i3 < j2; i3++) {
            RecyclerView.d0 f02 = RecyclerView.f0(recyclerView.f2126f.i(i3));
            if (f02.f2197c == i2 && !f02.t()) {
                return true;
            }
        }
        return false;
    }

    private void h(RecyclerView recyclerView, long j2) {
        if (recyclerView == null) {
            return;
        }
        if (recyclerView.E && recyclerView.f2126f.j() != 0) {
            recyclerView.T0();
        }
        b bVar = recyclerView.f2131h0;
        bVar.c(recyclerView, true);
        if (bVar.f2435d != 0) {
            try {
                a0.b.a("RV Nested Prefetch");
                recyclerView.f2133i0.f(recyclerView.f2140m);
                for (int i2 = 0; i2 < bVar.f2435d * 2; i2 += 2) {
                    i(recyclerView, bVar.f2434c[i2], j2);
                }
            } finally {
                a0.b.b();
            }
        }
    }

    private RecyclerView.d0 i(RecyclerView recyclerView, int i2, long j2) {
        if (e(recyclerView, i2)) {
            return null;
        }
        RecyclerView.v vVar = recyclerView.f2120c;
        try {
            recyclerView.F0();
            RecyclerView.d0 I = vVar.I(i2, false, j2);
            if (I != null) {
                if (!I.s() || I.t()) {
                    vVar.a(I, false);
                } else {
                    vVar.B(I.f2195a);
                }
            }
            return I;
        } finally {
            recyclerView.H0(false);
        }
    }

    public void a(RecyclerView recyclerView) {
        this.f2428b.add(recyclerView);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void f(RecyclerView recyclerView, int i2, int i3) {
        if (recyclerView.isAttachedToWindow() && this.f2429c == 0) {
            this.f2429c = recyclerView.getNanoTime();
            recyclerView.post(this);
        }
        recyclerView.f2131h0.e(i2, i3);
    }

    void g(long j2) {
        b();
        d(j2);
    }

    public void j(RecyclerView recyclerView) {
        this.f2428b.remove(recyclerView);
    }

    @Override // java.lang.Runnable
    public void run() {
        try {
            a0.b.a("RV Prefetch");
            if (!this.f2428b.isEmpty()) {
                int size = this.f2428b.size();
                long j2 = 0;
                for (int i2 = 0; i2 < size; i2++) {
                    RecyclerView recyclerView = this.f2428b.get(i2);
                    if (recyclerView.getWindowVisibility() == 0) {
                        j2 = Math.max(recyclerView.getDrawingTime(), j2);
                    }
                }
                if (j2 != 0) {
                    g(TimeUnit.MILLISECONDS.toNanos(j2) + this.f2430d);
                }
            }
        } finally {
            this.f2429c = 0L;
            a0.b.b();
        }
    }
}
