package androidx.fragment.app;

import a0.a;
import android.animation.Animator;
import android.animation.AnimatorInflater;
import android.animation.AnimatorListenerAdapter;
import android.content.Context;
import android.content.res.Resources;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.view.animation.Transformation;
import androidx.fragment.app.t;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes.dex */
public class e {

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public static class a implements a.InterfaceC0000a {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ Fragment f1611a;

        a(Fragment fragment) {
            this.f1611a = fragment;
        }

        @Override // a0.a.InterfaceC0000a
        public void a() {
            if (this.f1611a.l() != null) {
                View l2 = this.f1611a.l();
                this.f1611a.g1(null);
                l2.clearAnimation();
            }
            this.f1611a.h1(null);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public static class b implements Animation.AnimationListener {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ ViewGroup f1612a;

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ Fragment f1613b;

        /* renamed from: c  reason: collision with root package name */
        final /* synthetic */ t.g f1614c;

        /* renamed from: d  reason: collision with root package name */
        final /* synthetic */ a0.a f1615d;

        /* loaded from: classes.dex */
        class a implements Runnable {
            a() {
            }

            @Override // java.lang.Runnable
            public void run() {
                if (b.this.f1613b.l() != null) {
                    b.this.f1613b.g1(null);
                    b bVar = b.this;
                    bVar.f1614c.a(bVar.f1613b, bVar.f1615d);
                }
            }
        }

        b(ViewGroup viewGroup, Fragment fragment, t.g gVar, a0.a aVar) {
            this.f1612a = viewGroup;
            this.f1613b = fragment;
            this.f1614c = gVar;
            this.f1615d = aVar;
        }

        @Override // android.view.animation.Animation.AnimationListener
        public void onAnimationEnd(Animation animation) {
            this.f1612a.post(new a());
        }

        @Override // android.view.animation.Animation.AnimationListener
        public void onAnimationRepeat(Animation animation) {
        }

        @Override // android.view.animation.Animation.AnimationListener
        public void onAnimationStart(Animation animation) {
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public static class c extends AnimatorListenerAdapter {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ ViewGroup f1617a;

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ View f1618b;

        /* renamed from: c  reason: collision with root package name */
        final /* synthetic */ Fragment f1619c;

        /* renamed from: d  reason: collision with root package name */
        final /* synthetic */ t.g f1620d;

        /* renamed from: e  reason: collision with root package name */
        final /* synthetic */ a0.a f1621e;

        c(ViewGroup viewGroup, View view, Fragment fragment, t.g gVar, a0.a aVar) {
            this.f1617a = viewGroup;
            this.f1618b = view;
            this.f1619c = fragment;
            this.f1620d = gVar;
            this.f1621e = aVar;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            this.f1617a.endViewTransition(this.f1618b);
            Animator m2 = this.f1619c.m();
            this.f1619c.h1(null);
            if (m2 == null || this.f1617a.indexOfChild(this.f1618b) >= 0) {
                return;
            }
            this.f1620d.a(this.f1619c, this.f1621e);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public static class d {

        /* renamed from: a  reason: collision with root package name */
        public final Animation f1622a;

        /* renamed from: b  reason: collision with root package name */
        public final Animator f1623b;

        d(Animator animator) {
            this.f1622a = null;
            this.f1623b = animator;
            if (animator == null) {
                throw new IllegalStateException("Animator cannot be null");
            }
        }

        d(Animation animation) {
            this.f1622a = animation;
            this.f1623b = null;
            if (animation == null) {
                throw new IllegalStateException("Animation cannot be null");
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* renamed from: androidx.fragment.app.e$e  reason: collision with other inner class name */
    /* loaded from: classes.dex */
    public static class RunnableC0009e extends AnimationSet implements Runnable {

        /* renamed from: b  reason: collision with root package name */
        private final ViewGroup f1624b;

        /* renamed from: c  reason: collision with root package name */
        private final View f1625c;

        /* renamed from: d  reason: collision with root package name */
        private boolean f1626d;

        /* renamed from: e  reason: collision with root package name */
        private boolean f1627e;

        /* renamed from: f  reason: collision with root package name */
        private boolean f1628f;

        RunnableC0009e(Animation animation, ViewGroup viewGroup, View view) {
            super(false);
            this.f1628f = true;
            this.f1624b = viewGroup;
            this.f1625c = view;
            addAnimation(animation);
            viewGroup.post(this);
        }

        @Override // android.view.animation.AnimationSet, android.view.animation.Animation
        public boolean getTransformation(long j2, Transformation transformation) {
            this.f1628f = true;
            if (this.f1626d) {
                return !this.f1627e;
            }
            if (!super.getTransformation(j2, transformation)) {
                this.f1626d = true;
                e0.p.a(this.f1624b, this);
            }
            return true;
        }

        @Override // android.view.animation.Animation
        public boolean getTransformation(long j2, Transformation transformation, float f2) {
            this.f1628f = true;
            if (this.f1626d) {
                return !this.f1627e;
            }
            if (!super.getTransformation(j2, transformation, f2)) {
                this.f1626d = true;
                e0.p.a(this.f1624b, this);
            }
            return true;
        }

        @Override // java.lang.Runnable
        public void run() {
            if (this.f1626d || !this.f1628f) {
                this.f1624b.endViewTransition(this.f1625c);
                this.f1627e = true;
                return;
            }
            this.f1628f = false;
            this.f1624b.post(this);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void a(Fragment fragment, d dVar, t.g gVar) {
        View view = fragment.H;
        ViewGroup viewGroup = fragment.G;
        viewGroup.startViewTransition(view);
        a0.a aVar = new a0.a();
        aVar.c(new a(fragment));
        gVar.b(fragment, aVar);
        if (dVar.f1622a != null) {
            RunnableC0009e runnableC0009e = new RunnableC0009e(dVar.f1622a, viewGroup, view);
            fragment.g1(fragment.H);
            runnableC0009e.setAnimationListener(new b(viewGroup, fragment, gVar, aVar));
            fragment.H.startAnimation(runnableC0009e);
            return;
        }
        Animator animator = dVar.f1623b;
        fragment.h1(animator);
        animator.addListener(new c(viewGroup, view, fragment, gVar, aVar));
        animator.setTarget(fragment.H);
        animator.start();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static d b(Context context, f fVar, Fragment fragment, boolean z2) {
        int c2;
        int y2 = fragment.y();
        int x2 = fragment.x();
        boolean z3 = false;
        fragment.k1(0);
        View e2 = fVar.e(fragment.f1543x);
        if (e2 != null) {
            int i2 = l0.b.visible_removing_fragment_view_tag;
            if (e2.getTag(i2) != null) {
                e2.setTag(i2, null);
            }
        }
        ViewGroup viewGroup = fragment.G;
        if (viewGroup == null || viewGroup.getLayoutTransition() == null) {
            Animation e02 = fragment.e0(y2, z2, x2);
            if (e02 != null) {
                return new d(e02);
            }
            Animator f02 = fragment.f0(y2, z2, x2);
            if (f02 != null) {
                return new d(f02);
            }
            if (x2 != 0) {
                boolean equals = "anim".equals(context.getResources().getResourceTypeName(x2));
                if (equals) {
                    try {
                        Animation loadAnimation = AnimationUtils.loadAnimation(context, x2);
                        if (loadAnimation != null) {
                            return new d(loadAnimation);
                        }
                        z3 = true;
                    } catch (Resources.NotFoundException e3) {
                        throw e3;
                    } catch (RuntimeException unused) {
                    }
                }
                if (!z3) {
                    try {
                        Animator loadAnimator = AnimatorInflater.loadAnimator(context, x2);
                        if (loadAnimator != null) {
                            return new d(loadAnimator);
                        }
                    } catch (RuntimeException e4) {
                        if (equals) {
                            throw e4;
                        }
                        Animation loadAnimation2 = AnimationUtils.loadAnimation(context, x2);
                        if (loadAnimation2 != null) {
                            return new d(loadAnimation2);
                        }
                    }
                }
            }
            if (y2 != 0 && (c2 = c(y2, z2)) >= 0) {
                return new d(AnimationUtils.loadAnimation(context, c2));
            }
            return null;
        }
        return null;
    }

    private static int c(int i2, boolean z2) {
        if (i2 == 4097) {
            return z2 ? l0.a.fragment_open_enter : l0.a.fragment_open_exit;
        } else if (i2 == 4099) {
            return z2 ? l0.a.fragment_fade_enter : l0.a.fragment_fade_exit;
        } else if (i2 != 8194) {
            return -1;
        } else {
            return z2 ? l0.a.fragment_close_enter : l0.a.fragment_close_exit;
        }
    }
}
