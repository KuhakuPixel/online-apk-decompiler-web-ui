package androidx.appcompat.view.menu;
/* loaded from: classes.dex */
public interface k {

    /* loaded from: classes.dex */
    public interface a {
        boolean d();

        void e(g gVar, int i2);

        g getItemData();
    }

    void b(e eVar);
}
