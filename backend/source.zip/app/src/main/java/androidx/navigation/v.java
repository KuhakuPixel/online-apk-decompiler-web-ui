package androidx.navigation;

import com.sample.android.kuhakupixelinapppurchase.R;
/* loaded from: classes.dex */
public final class v {

    /* renamed from: b  reason: collision with root package name */
    public static final int f2058b = 0;

    /* renamed from: c  reason: collision with root package name */
    public static final int f2059c = 1;

    /* renamed from: d  reason: collision with root package name */
    public static final int f2060d = 2;

    /* renamed from: e  reason: collision with root package name */
    public static final int f2061e = 3;

    /* renamed from: f  reason: collision with root package name */
    public static final int f2062f = 4;

    /* renamed from: q  reason: collision with root package name */
    public static final int f2073q = 0;

    /* renamed from: s  reason: collision with root package name */
    public static final int f2075s = 0;

    /* renamed from: a  reason: collision with root package name */
    public static final int[] f2057a = {16842755, R.attr.action, R.attr.data, R.attr.dataPattern, R.attr.targetPackage};

    /* renamed from: g  reason: collision with root package name */
    public static final int[] f2063g = {16843173, 16843551, R.attr.alpha};

    /* renamed from: h  reason: collision with root package name */
    public static final int[] f2064h = {R.attr.fontProviderAuthority, R.attr.fontProviderCerts, R.attr.fontProviderFetchStrategy, R.attr.fontProviderFetchTimeout, R.attr.fontProviderPackage, R.attr.fontProviderQuery};

    /* renamed from: i  reason: collision with root package name */
    public static final int[] f2065i = {16844082, 16844083, 16844095, 16844143, 16844144, R.attr.font, R.attr.fontStyle, R.attr.fontVariationSettings, R.attr.fontWeight, R.attr.ttcIndex};

    /* renamed from: j  reason: collision with root package name */
    public static final int[] f2066j = {16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 16844050, 16844051};

    /* renamed from: k  reason: collision with root package name */
    public static final int[] f2067k = {16843173, 16844052};

    /* renamed from: l  reason: collision with root package name */
    public static final int[] f2068l = {16842960, R.attr.destination, R.attr.enterAnim, R.attr.exitAnim, R.attr.launchSingleTop, R.attr.popEnterAnim, R.attr.popExitAnim, R.attr.popUpTo, R.attr.popUpToInclusive};

    /* renamed from: m  reason: collision with root package name */
    public static final int[] f2069m = {16842755, 16843245, R.attr.argType, R.attr.nullable};

    /* renamed from: n  reason: collision with root package name */
    public static final int[] f2070n = {16844014, R.attr.action, R.attr.mimeType, R.attr.uri};

    /* renamed from: o  reason: collision with root package name */
    public static final int[] f2071o = {R.attr.startDestination};

    /* renamed from: p  reason: collision with root package name */
    public static final int[] f2072p = {R.attr.navGraph};

    /* renamed from: r  reason: collision with root package name */
    public static final int[] f2074r = {R.attr.graph};

    /* renamed from: t  reason: collision with root package name */
    public static final int[] f2076t = {16842753, 16842960};
}
