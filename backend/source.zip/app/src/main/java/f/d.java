package f;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.AssetManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.view.LayoutInflater;
/* loaded from: classes.dex */
public class d extends ContextWrapper {

    /* renamed from: a  reason: collision with root package name */
    private int f4358a;

    /* renamed from: b  reason: collision with root package name */
    private Resources.Theme f4359b;

    /* renamed from: c  reason: collision with root package name */
    private LayoutInflater f4360c;

    /* renamed from: d  reason: collision with root package name */
    private Configuration f4361d;

    /* renamed from: e  reason: collision with root package name */
    private Resources f4362e;

    public d() {
        super(null);
    }

    public d(Context context, int i2) {
        super(context);
        this.f4358a = i2;
    }

    public d(Context context, Resources.Theme theme) {
        super(context);
        this.f4359b = theme;
    }

    private Resources b() {
        if (this.f4362e == null) {
            Configuration configuration = this.f4361d;
            this.f4362e = configuration == null ? super.getResources() : createConfigurationContext(configuration).getResources();
        }
        return this.f4362e;
    }

    private void d() {
        boolean z2 = this.f4359b == null;
        if (z2) {
            this.f4359b = getResources().newTheme();
            Resources.Theme theme = getBaseContext().getTheme();
            if (theme != null) {
                this.f4359b.setTo(theme);
            }
        }
        e(this.f4359b, this.f4358a, z2);
    }

    public void a(Configuration configuration) {
        if (this.f4362e != null) {
            throw new IllegalStateException("getResources() or getAssets() has already been called");
        }
        if (this.f4361d != null) {
            throw new IllegalStateException("Override configuration has already been set");
        }
        this.f4361d = new Configuration(configuration);
    }

    @Override // android.content.ContextWrapper
    protected void attachBaseContext(Context context) {
        super.attachBaseContext(context);
    }

    public int c() {
        return this.f4358a;
    }

    protected void e(Resources.Theme theme, int i2, boolean z2) {
        theme.applyStyle(i2, true);
    }

    @Override // android.content.ContextWrapper, android.content.Context
    public AssetManager getAssets() {
        return getResources().getAssets();
    }

    @Override // android.content.ContextWrapper, android.content.Context
    public Resources getResources() {
        return b();
    }

    @Override // android.content.ContextWrapper, android.content.Context
    public Object getSystemService(String str) {
        if ("layout_inflater".equals(str)) {
            if (this.f4360c == null) {
                this.f4360c = LayoutInflater.from(getBaseContext()).cloneInContext(this);
            }
            return this.f4360c;
        }
        return getBaseContext().getSystemService(str);
    }

    @Override // android.content.ContextWrapper, android.content.Context
    public Resources.Theme getTheme() {
        Resources.Theme theme = this.f4359b;
        if (theme != null) {
            return theme;
        }
        if (this.f4358a == 0) {
            this.f4358a = a.i.Theme_AppCompat_Light;
        }
        d();
        return this.f4359b;
    }

    @Override // android.content.ContextWrapper, android.content.Context
    public void setTheme(int i2) {
        if (this.f4358a != i2) {
            this.f4358a = i2;
            d();
        }
    }
}
