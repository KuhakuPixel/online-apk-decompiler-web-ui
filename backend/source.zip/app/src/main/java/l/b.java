package l;

import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
/* loaded from: classes.dex */
public final class b<E> implements Collection<E>, Set<E> {

    /* renamed from: f  reason: collision with root package name */
    private static final int[] f4602f = new int[0];

    /* renamed from: g  reason: collision with root package name */
    private static final Object[] f4603g = new Object[0];

    /* renamed from: h  reason: collision with root package name */
    private static Object[] f4604h;

    /* renamed from: i  reason: collision with root package name */
    private static int f4605i;

    /* renamed from: j  reason: collision with root package name */
    private static Object[] f4606j;

    /* renamed from: k  reason: collision with root package name */
    private static int f4607k;

    /* renamed from: b  reason: collision with root package name */
    private int[] f4608b;

    /* renamed from: c  reason: collision with root package name */
    Object[] f4609c;

    /* renamed from: d  reason: collision with root package name */
    int f4610d;

    /* renamed from: e  reason: collision with root package name */
    private f<E, E> f4611e;

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public class a extends f<E, E> {
        a() {
        }

        @Override // l.f
        protected void a() {
            b.this.clear();
        }

        @Override // l.f
        protected Object b(int i2, int i3) {
            return b.this.f4609c[i2];
        }

        @Override // l.f
        protected Map<E, E> c() {
            throw new UnsupportedOperationException("not a map");
        }

        @Override // l.f
        protected int d() {
            return b.this.f4610d;
        }

        @Override // l.f
        protected int e(Object obj) {
            return b.this.indexOf(obj);
        }

        @Override // l.f
        protected int f(Object obj) {
            return b.this.indexOf(obj);
        }

        @Override // l.f
        protected void g(E e2, E e3) {
            b.this.add(e2);
        }

        @Override // l.f
        protected void h(int i2) {
            b.this.i(i2);
        }

        @Override // l.f
        protected E i(int i2, E e2) {
            throw new UnsupportedOperationException("not a map");
        }
    }

    public b() {
        this(0);
    }

    public b(int i2) {
        if (i2 == 0) {
            this.f4608b = f4602f;
            this.f4609c = f4603g;
        } else {
            c(i2);
        }
        this.f4610d = 0;
    }

    private void c(int i2) {
        if (i2 == 8) {
            synchronized (b.class) {
                Object[] objArr = f4606j;
                if (objArr != null) {
                    this.f4609c = objArr;
                    f4606j = (Object[]) objArr[0];
                    this.f4608b = (int[]) objArr[1];
                    objArr[1] = null;
                    objArr[0] = null;
                    f4607k--;
                    return;
                }
            }
        } else if (i2 == 4) {
            synchronized (b.class) {
                Object[] objArr2 = f4604h;
                if (objArr2 != null) {
                    this.f4609c = objArr2;
                    f4604h = (Object[]) objArr2[0];
                    this.f4608b = (int[]) objArr2[1];
                    objArr2[1] = null;
                    objArr2[0] = null;
                    f4605i--;
                    return;
                }
            }
        }
        this.f4608b = new int[i2];
        this.f4609c = new Object[i2];
    }

    private static void e(int[] iArr, Object[] objArr, int i2) {
        if (iArr.length == 8) {
            synchronized (b.class) {
                if (f4607k < 10) {
                    objArr[0] = f4606j;
                    objArr[1] = iArr;
                    for (int i3 = i2 - 1; i3 >= 2; i3--) {
                        objArr[i3] = null;
                    }
                    f4606j = objArr;
                    f4607k++;
                }
            }
        } else if (iArr.length == 4) {
            synchronized (b.class) {
                if (f4605i < 10) {
                    objArr[0] = f4604h;
                    objArr[1] = iArr;
                    for (int i4 = i2 - 1; i4 >= 2; i4--) {
                        objArr[i4] = null;
                    }
                    f4604h = objArr;
                    f4605i++;
                }
            }
        }
    }

    private f<E, E> f() {
        if (this.f4611e == null) {
            this.f4611e = new a();
        }
        return this.f4611e;
    }

    private int g(Object obj, int i2) {
        int i3 = this.f4610d;
        if (i3 == 0) {
            return -1;
        }
        int a2 = c.a(this.f4608b, i3, i2);
        if (a2 >= 0 && !obj.equals(this.f4609c[a2])) {
            int i4 = a2 + 1;
            while (i4 < i3 && this.f4608b[i4] == i2) {
                if (obj.equals(this.f4609c[i4])) {
                    return i4;
                }
                i4++;
            }
            for (int i5 = a2 - 1; i5 >= 0 && this.f4608b[i5] == i2; i5--) {
                if (obj.equals(this.f4609c[i5])) {
                    return i5;
                }
            }
            return ~i4;
        }
        return a2;
    }

    private int h() {
        int i2 = this.f4610d;
        if (i2 == 0) {
            return -1;
        }
        int a2 = c.a(this.f4608b, i2, 0);
        if (a2 >= 0 && this.f4609c[a2] != null) {
            int i3 = a2 + 1;
            while (i3 < i2 && this.f4608b[i3] == 0) {
                if (this.f4609c[i3] == null) {
                    return i3;
                }
                i3++;
            }
            for (int i4 = a2 - 1; i4 >= 0 && this.f4608b[i4] == 0; i4--) {
                if (this.f4609c[i4] == null) {
                    return i4;
                }
            }
            return ~i3;
        }
        return a2;
    }

    @Override // java.util.Collection, java.util.Set
    public boolean add(E e2) {
        int i2;
        int g2;
        if (e2 == null) {
            g2 = h();
            i2 = 0;
        } else {
            int hashCode = e2.hashCode();
            i2 = hashCode;
            g2 = g(e2, hashCode);
        }
        if (g2 >= 0) {
            return false;
        }
        int i3 = ~g2;
        int i4 = this.f4610d;
        int[] iArr = this.f4608b;
        if (i4 >= iArr.length) {
            int i5 = 4;
            if (i4 >= 8) {
                i5 = (i4 >> 1) + i4;
            } else if (i4 >= 4) {
                i5 = 8;
            }
            Object[] objArr = this.f4609c;
            c(i5);
            int[] iArr2 = this.f4608b;
            if (iArr2.length > 0) {
                System.arraycopy(iArr, 0, iArr2, 0, iArr.length);
                System.arraycopy(objArr, 0, this.f4609c, 0, objArr.length);
            }
            e(iArr, objArr, this.f4610d);
        }
        int i6 = this.f4610d;
        if (i3 < i6) {
            int[] iArr3 = this.f4608b;
            int i7 = i3 + 1;
            System.arraycopy(iArr3, i3, iArr3, i7, i6 - i3);
            Object[] objArr2 = this.f4609c;
            System.arraycopy(objArr2, i3, objArr2, i7, this.f4610d - i3);
        }
        this.f4608b[i3] = i2;
        this.f4609c[i3] = e2;
        this.f4610d++;
        return true;
    }

    @Override // java.util.Collection, java.util.Set
    public boolean addAll(Collection<? extends E> collection) {
        d(this.f4610d + collection.size());
        Iterator<? extends E> it = collection.iterator();
        boolean z2 = false;
        while (it.hasNext()) {
            z2 |= add(it.next());
        }
        return z2;
    }

    @Override // java.util.Collection, java.util.Set
    public void clear() {
        int i2 = this.f4610d;
        if (i2 != 0) {
            e(this.f4608b, this.f4609c, i2);
            this.f4608b = f4602f;
            this.f4609c = f4603g;
            this.f4610d = 0;
        }
    }

    @Override // java.util.Collection, java.util.Set
    public boolean contains(Object obj) {
        return indexOf(obj) >= 0;
    }

    @Override // java.util.Collection, java.util.Set
    public boolean containsAll(Collection<?> collection) {
        Iterator<?> it = collection.iterator();
        while (it.hasNext()) {
            if (!contains(it.next())) {
                return false;
            }
        }
        return true;
    }

    public void d(int i2) {
        int[] iArr = this.f4608b;
        if (iArr.length < i2) {
            Object[] objArr = this.f4609c;
            c(i2);
            int i3 = this.f4610d;
            if (i3 > 0) {
                System.arraycopy(iArr, 0, this.f4608b, 0, i3);
                System.arraycopy(objArr, 0, this.f4609c, 0, this.f4610d);
            }
            e(iArr, objArr, this.f4610d);
        }
    }

    @Override // java.util.Collection, java.util.Set
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof Set) {
            Set set = (Set) obj;
            if (size() != set.size()) {
                return false;
            }
            for (int i2 = 0; i2 < this.f4610d; i2++) {
                try {
                    if (!set.contains(j(i2))) {
                        return false;
                    }
                } catch (ClassCastException | NullPointerException unused) {
                }
            }
            return true;
        }
        return false;
    }

    @Override // java.util.Collection, java.util.Set
    public int hashCode() {
        int[] iArr = this.f4608b;
        int i2 = this.f4610d;
        int i3 = 0;
        for (int i4 = 0; i4 < i2; i4++) {
            i3 += iArr[i4];
        }
        return i3;
    }

    public E i(int i2) {
        Object[] objArr = this.f4609c;
        E e2 = (E) objArr[i2];
        int i3 = this.f4610d;
        if (i3 <= 1) {
            e(this.f4608b, objArr, i3);
            this.f4608b = f4602f;
            this.f4609c = f4603g;
            this.f4610d = 0;
        } else {
            int[] iArr = this.f4608b;
            if (iArr.length <= 8 || i3 >= iArr.length / 3) {
                int i4 = i3 - 1;
                this.f4610d = i4;
                if (i2 < i4) {
                    int i5 = i2 + 1;
                    System.arraycopy(iArr, i5, iArr, i2, i4 - i2);
                    Object[] objArr2 = this.f4609c;
                    System.arraycopy(objArr2, i5, objArr2, i2, this.f4610d - i2);
                }
                this.f4609c[this.f4610d] = null;
            } else {
                c(i3 > 8 ? i3 + (i3 >> 1) : 8);
                this.f4610d--;
                if (i2 > 0) {
                    System.arraycopy(iArr, 0, this.f4608b, 0, i2);
                    System.arraycopy(objArr, 0, this.f4609c, 0, i2);
                }
                int i6 = this.f4610d;
                if (i2 < i6) {
                    int i7 = i2 + 1;
                    System.arraycopy(iArr, i7, this.f4608b, i2, i6 - i2);
                    System.arraycopy(objArr, i7, this.f4609c, i2, this.f4610d - i2);
                }
            }
        }
        return e2;
    }

    public int indexOf(Object obj) {
        return obj == null ? h() : g(obj, obj.hashCode());
    }

    @Override // java.util.Collection, java.util.Set
    public boolean isEmpty() {
        return this.f4610d <= 0;
    }

    @Override // java.util.Collection, java.lang.Iterable, java.util.Set
    public Iterator<E> iterator() {
        return f().m().iterator();
    }

    public E j(int i2) {
        return (E) this.f4609c[i2];
    }

    @Override // java.util.Collection, java.util.Set
    public boolean remove(Object obj) {
        int indexOf = indexOf(obj);
        if (indexOf >= 0) {
            i(indexOf);
            return true;
        }
        return false;
    }

    @Override // java.util.Collection, java.util.Set
    public boolean removeAll(Collection<?> collection) {
        Iterator<?> it = collection.iterator();
        boolean z2 = false;
        while (it.hasNext()) {
            z2 |= remove(it.next());
        }
        return z2;
    }

    @Override // java.util.Collection, java.util.Set
    public boolean retainAll(Collection<?> collection) {
        boolean z2 = false;
        for (int i2 = this.f4610d - 1; i2 >= 0; i2--) {
            if (!collection.contains(this.f4609c[i2])) {
                i(i2);
                z2 = true;
            }
        }
        return z2;
    }

    @Override // java.util.Collection, java.util.Set
    public int size() {
        return this.f4610d;
    }

    @Override // java.util.Collection, java.util.Set
    public Object[] toArray() {
        int i2 = this.f4610d;
        Object[] objArr = new Object[i2];
        System.arraycopy(this.f4609c, 0, objArr, 0, i2);
        return objArr;
    }

    @Override // java.util.Collection, java.util.Set
    public <T> T[] toArray(T[] tArr) {
        if (tArr.length < this.f4610d) {
            tArr = (T[]) ((Object[]) Array.newInstance(tArr.getClass().getComponentType(), this.f4610d));
        }
        System.arraycopy(this.f4609c, 0, tArr, 0, this.f4610d);
        int length = tArr.length;
        int i2 = this.f4610d;
        if (length > i2) {
            tArr[i2] = null;
        }
        return tArr;
    }

    public String toString() {
        if (isEmpty()) {
            return "{}";
        }
        StringBuilder sb = new StringBuilder(this.f4610d * 14);
        sb.append('{');
        for (int i2 = 0; i2 < this.f4610d; i2++) {
            if (i2 > 0) {
                sb.append(", ");
            }
            E j2 = j(i2);
            if (j2 != this) {
                sb.append(j2);
            } else {
                sb.append("(this Set)");
            }
        }
        sb.append('}');
        return sb.toString();
    }
}
