package androidx.navigation;

import android.os.Bundle;
/* loaded from: classes.dex */
public final class d {

    /* renamed from: a  reason: collision with root package name */
    private final q f1914a;

    /* renamed from: b  reason: collision with root package name */
    private final boolean f1915b;

    /* renamed from: c  reason: collision with root package name */
    private final boolean f1916c;

    /* renamed from: d  reason: collision with root package name */
    private final Object f1917d;

    /* loaded from: classes.dex */
    public static final class a {

        /* renamed from: a  reason: collision with root package name */
        private q<?> f1918a;

        /* renamed from: c  reason: collision with root package name */
        private Object f1920c;

        /* renamed from: b  reason: collision with root package name */
        private boolean f1919b = false;

        /* renamed from: d  reason: collision with root package name */
        private boolean f1921d = false;

        public d a() {
            if (this.f1918a == null) {
                this.f1918a = q.e(this.f1920c);
            }
            return new d(this.f1918a, this.f1919b, this.f1920c, this.f1921d);
        }

        public a b(Object obj) {
            this.f1920c = obj;
            this.f1921d = true;
            return this;
        }

        public a c(boolean z2) {
            this.f1919b = z2;
            return this;
        }

        public a d(q<?> qVar) {
            this.f1918a = qVar;
            return this;
        }
    }

    d(q<?> qVar, boolean z2, Object obj, boolean z3) {
        if (!qVar.f() && z2) {
            throw new IllegalArgumentException(qVar.c() + " does not allow nullable values");
        } else if (!z2 && z3 && obj == null) {
            throw new IllegalArgumentException("Argument with type " + qVar.c() + " has null value but is not nullable.");
        } else {
            this.f1914a = qVar;
            this.f1915b = z2;
            this.f1917d = obj;
            this.f1916c = z3;
        }
    }

    public q<?> a() {
        return this.f1914a;
    }

    public boolean b() {
        return this.f1916c;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void c(String str, Bundle bundle) {
        if (this.f1916c) {
            this.f1914a.i(bundle, str, this.f1917d);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public boolean d(String str, Bundle bundle) {
        if (!this.f1915b && bundle.containsKey(str) && bundle.get(str) == null) {
            return false;
        }
        try {
            this.f1914a.b(bundle, str);
            return true;
        } catch (ClassCastException unused) {
            return false;
        }
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || d.class != obj.getClass()) {
            return false;
        }
        d dVar = (d) obj;
        if (this.f1915b == dVar.f1915b && this.f1916c == dVar.f1916c && this.f1914a.equals(dVar.f1914a)) {
            Object obj2 = this.f1917d;
            Object obj3 = dVar.f1917d;
            return obj2 != null ? obj2.equals(obj3) : obj3 == null;
        }
        return false;
    }

    public int hashCode() {
        int hashCode = ((((this.f1914a.hashCode() * 31) + (this.f1915b ? 1 : 0)) * 31) + (this.f1916c ? 1 : 0)) * 31;
        Object obj = this.f1917d;
        return hashCode + (obj != null ? obj.hashCode() : 0);
    }
}
