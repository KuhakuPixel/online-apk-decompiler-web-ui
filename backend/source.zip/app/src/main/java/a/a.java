package a;
/* loaded from: classes.dex */
public final class a {

    /* renamed from: A */
    public static final int dropDownListViewStyle = 2130968870;
    public static final int B = 2130968875;

    /* renamed from: C */
    public static final int imageButtonStyle = 2130968988;

    /* renamed from: D */
    public static final int listMenuViewStyle = 2130969109;

    /* renamed from: E */
    public static final int listPopupWindowStyle = 2130969110;

    /* renamed from: F */
    public static final int panelMenuListTheme = 2130969208;
    public static final int G = 2130969244;

    /* renamed from: H */
    public static final int ratingBarStyle = 2130969246;

    /* renamed from: I */
    public static final int searchViewStyle = 2130969264;

    /* renamed from: J */
    public static final int seekBarStyle = 2130969265;

    /* renamed from: K */
    public static final int spinnerStyle = 2130969295;

    /* renamed from: L */
    public static final int textColorSearchUrl = 2130969387;

    /* renamed from: M */
    public static final int toolbarNavigationButtonStyle = 2130969425;
    public static final int N = 2130969426;

    /* renamed from: a */
    public static final int actionBarPopupTheme = 2130968579;

    /* renamed from: b */
    public static final int actionBarSize = 2130968580;

    /* renamed from: c */
    public static final int actionBarStyle = 2130968582;

    /* renamed from: d */
    public static final int actionBarTabStyle = 2130968584;

    /* renamed from: e */
    public static final int actionBarTabTextStyle = 2130968585;

    /* renamed from: f */
    public static final int actionBarTheme = 2130968586;

    /* renamed from: g */
    public static final int actionBarWidgetTheme = 2130968587;

    /* renamed from: h */
    public static final int actionDropDownStyle = 2130968589;

    /* renamed from: i */
    public static final int actionModePopupWindowStyle = 2130968600;

    /* renamed from: j */
    public static final int actionModeStyle = 2130968604;

    /* renamed from: k */
    public static final int actionOverflowButtonStyle = 2130968606;

    /* renamed from: l */
    public static final int actionOverflowMenuStyle = 2130968607;

    /* renamed from: m */
    public static final int alertDialogCenterButtons = 2130968613;

    /* renamed from: n */
    public static final int alertDialogStyle = 2130968614;

    /* renamed from: o */
    public static final int alertDialogTheme = 2130968615;

    /* renamed from: p  reason: collision with root package name */
    public static final int f0p = 2130968629;

    /* renamed from: q */
    public static final int buttonStyle = 2130968692;

    /* renamed from: r  reason: collision with root package name */
    public static final int f1r = 2130968705;

    /* renamed from: s */
    public static final int colorAccent = 2130968757;

    /* renamed from: t */
    public static final int colorButtonNormal = 2130968759;

    /* renamed from: u  reason: collision with root package name */
    public static final int f2u = 2130968760;

    /* renamed from: v  reason: collision with root package name */
    public static final int f3v = 2130968761;

    /* renamed from: w */
    public static final int colorControlNormal = 2130968762;

    /* renamed from: x */
    public static final int colorSwitchThumbNormal = 2130968777;

    /* renamed from: y */
    public static final int dialogTheme = 2130968849;

    /* renamed from: z */
    public static final int drawerArrowStyle = 2130968868;
}
