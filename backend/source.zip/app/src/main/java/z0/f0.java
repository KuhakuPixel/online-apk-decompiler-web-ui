package z0;

import java.util.Set;
import javax.annotation.CheckForNull;
/* loaded from: classes.dex */
public abstract class f0 extends y implements Set {
    @CheckForNull

    /* renamed from: c  reason: collision with root package name */
    private transient b0 f5696c;

    @Override // java.util.Collection, java.util.Set
    public final boolean equals(@CheckForNull Object obj) {
        if (obj == this || obj == this) {
            return true;
        }
        if (obj instanceof Set) {
            Set set = (Set) obj;
            try {
                if (size() == set.size()) {
                    if (containsAll(set)) {
                        return true;
                    }
                }
            } catch (ClassCastException | NullPointerException unused) {
            }
        }
        return false;
    }

    @Override // z0.y
    public b0 f() {
        b0 b0Var = this.f5696c;
        if (b0Var == null) {
            b0 j2 = j();
            this.f5696c = j2;
            return j2;
        }
        return b0Var;
    }

    @Override // java.util.Collection, java.util.Set
    public final int hashCode() {
        return h.a(this);
    }

    b0 j() {
        return b0.k(toArray());
    }
}
