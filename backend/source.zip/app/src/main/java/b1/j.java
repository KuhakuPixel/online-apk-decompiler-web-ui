package b1;
/* loaded from: classes.dex */
public class j {

    /* renamed from: a  reason: collision with root package name */
    public final int f3046a;

    /* renamed from: b  reason: collision with root package name */
    public final float f3047b;

    /* renamed from: c  reason: collision with root package name */
    public final float f3048c;

    public j(int i2, float f2, float f3) {
        this.f3046a = i2;
        this.f3047b = f2;
        this.f3048c = f3;
    }
}
