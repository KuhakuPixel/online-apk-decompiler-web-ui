package androidx.lifecycle;
/* loaded from: classes.dex */
public interface n<T> {
    void c(T t2);
}
