package androidx.room;

import androidx.room.e0;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executor;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes.dex */
public final class c0 implements u0.f {

    /* renamed from: b  reason: collision with root package name */
    private final u0.f f2512b;

    /* renamed from: c  reason: collision with root package name */
    private final e0.f f2513c;

    /* renamed from: d  reason: collision with root package name */
    private final String f2514d;

    /* renamed from: e  reason: collision with root package name */
    private final List<Object> f2515e = new ArrayList();

    /* renamed from: f  reason: collision with root package name */
    private final Executor f2516f;

    /* JADX INFO: Access modifiers changed from: package-private */
    public c0(u0.f fVar, e0.f fVar2, String str, Executor executor) {
        this.f2512b = fVar;
        this.f2513c = fVar2;
        this.f2514d = str;
        this.f2516f = executor;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void v() {
        this.f2513c.a(this.f2514d, this.f2515e);
    }

    private void x(int i2, Object obj) {
        int i3 = i2 - 1;
        if (i3 >= this.f2515e.size()) {
            for (int size = this.f2515e.size(); size <= i3; size++) {
                this.f2515e.add(null);
            }
        }
        this.f2515e.set(i3, obj);
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public void close() {
        this.f2512b.close();
    }

    @Override // u0.d
    public void h(int i2, String str) {
        x(i2, str);
        this.f2512b.h(i2, str);
    }

    @Override // u0.d
    public void i(int i2, long j2) {
        x(i2, Long.valueOf(j2));
        this.f2512b.i(i2, j2);
    }

    @Override // u0.f
    public int l() {
        this.f2516f.execute(new Runnable() { // from class: androidx.room.b0
            @Override // java.lang.Runnable
            public final void run() {
                c0.this.v();
            }
        });
        return this.f2512b.l();
    }

    @Override // u0.d
    public void o(int i2, byte[] bArr) {
        x(i2, bArr);
        this.f2512b.o(i2, bArr);
    }

    @Override // u0.d
    public void p(int i2) {
        x(i2, this.f2515e.toArray());
        this.f2512b.p(i2);
    }

    @Override // u0.d
    public void q(int i2, double d2) {
        x(i2, Double.valueOf(d2));
        this.f2512b.q(i2, d2);
    }
}
