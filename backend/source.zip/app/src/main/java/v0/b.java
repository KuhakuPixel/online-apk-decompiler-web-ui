package v0;

import android.content.Context;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;
import java.io.File;
import u0.c;
/* loaded from: classes.dex */
class b implements u0.c {

    /* renamed from: b  reason: collision with root package name */
    private final Context f5412b;

    /* renamed from: c  reason: collision with root package name */
    private final String f5413c;

    /* renamed from: d  reason: collision with root package name */
    private final c.a f5414d;

    /* renamed from: e  reason: collision with root package name */
    private final boolean f5415e;

    /* renamed from: f  reason: collision with root package name */
    private final Object f5416f = new Object();

    /* renamed from: g  reason: collision with root package name */
    private a f5417g;

    /* renamed from: h  reason: collision with root package name */
    private boolean f5418h;

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public static class a extends SQLiteOpenHelper {

        /* renamed from: b  reason: collision with root package name */
        final v0.a[] f5419b;

        /* renamed from: c  reason: collision with root package name */
        final c.a f5420c;

        /* renamed from: d  reason: collision with root package name */
        private boolean f5421d;

        /* renamed from: v0.b$a$a  reason: collision with other inner class name */
        /* loaded from: classes.dex */
        class C0077a implements DatabaseErrorHandler {

            /* renamed from: a  reason: collision with root package name */
            final /* synthetic */ c.a f5422a;

            /* renamed from: b  reason: collision with root package name */
            final /* synthetic */ v0.a[] f5423b;

            C0077a(c.a aVar, v0.a[] aVarArr) {
                this.f5422a = aVar;
                this.f5423b = aVarArr;
            }

            @Override // android.database.DatabaseErrorHandler
            public void onCorruption(SQLiteDatabase sQLiteDatabase) {
                this.f5422a.c(a.v(this.f5423b, sQLiteDatabase));
            }
        }

        a(Context context, String str, v0.a[] aVarArr, c.a aVar) {
            super(context, str, null, aVar.f5334a, new C0077a(aVar, aVarArr));
            this.f5420c = aVar;
            this.f5419b = aVarArr;
        }

        static v0.a v(v0.a[] aVarArr, SQLiteDatabase sQLiteDatabase) {
            v0.a aVar = aVarArr[0];
            if (aVar == null || !aVar.e(sQLiteDatabase)) {
                aVarArr[0] = new v0.a(sQLiteDatabase);
            }
            return aVarArr[0];
        }

        @Override // android.database.sqlite.SQLiteOpenHelper, java.lang.AutoCloseable
        public synchronized void close() {
            super.close();
            this.f5419b[0] = null;
        }

        v0.a e(SQLiteDatabase sQLiteDatabase) {
            return v(this.f5419b, sQLiteDatabase);
        }

        @Override // android.database.sqlite.SQLiteOpenHelper
        public void onConfigure(SQLiteDatabase sQLiteDatabase) {
            this.f5420c.b(e(sQLiteDatabase));
        }

        @Override // android.database.sqlite.SQLiteOpenHelper
        public void onCreate(SQLiteDatabase sQLiteDatabase) {
            this.f5420c.d(e(sQLiteDatabase));
        }

        @Override // android.database.sqlite.SQLiteOpenHelper
        public void onDowngrade(SQLiteDatabase sQLiteDatabase, int i2, int i3) {
            this.f5421d = true;
            this.f5420c.e(e(sQLiteDatabase), i2, i3);
        }

        @Override // android.database.sqlite.SQLiteOpenHelper
        public void onOpen(SQLiteDatabase sQLiteDatabase) {
            if (this.f5421d) {
                return;
            }
            this.f5420c.f(e(sQLiteDatabase));
        }

        @Override // android.database.sqlite.SQLiteOpenHelper
        public void onUpgrade(SQLiteDatabase sQLiteDatabase, int i2, int i3) {
            this.f5421d = true;
            this.f5420c.g(e(sQLiteDatabase), i2, i3);
        }

        synchronized u0.b x() {
            this.f5421d = false;
            SQLiteDatabase writableDatabase = super.getWritableDatabase();
            if (!this.f5421d) {
                return e(writableDatabase);
            }
            close();
            return x();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public b(Context context, String str, c.a aVar, boolean z2) {
        this.f5412b = context;
        this.f5413c = str;
        this.f5414d = aVar;
        this.f5415e = z2;
    }

    private a e() {
        a aVar;
        synchronized (this.f5416f) {
            if (this.f5417g == null) {
                v0.a[] aVarArr = new v0.a[1];
                if (Build.VERSION.SDK_INT < 23 || this.f5413c == null || !this.f5415e) {
                    this.f5417g = new a(this.f5412b, this.f5413c, aVarArr, this.f5414d);
                } else {
                    this.f5417g = new a(this.f5412b, new File(this.f5412b.getNoBackupFilesDir(), this.f5413c).getAbsolutePath(), aVarArr, this.f5414d);
                }
                this.f5417g.setWriteAheadLoggingEnabled(this.f5418h);
            }
            aVar = this.f5417g;
        }
        return aVar;
    }

    @Override // u0.c, java.io.Closeable, java.lang.AutoCloseable
    public void close() {
        e().close();
    }

    @Override // u0.c
    public String getDatabaseName() {
        return this.f5413c;
    }

    @Override // u0.c
    public u0.b r() {
        return e().x();
    }

    @Override // u0.c
    public void setWriteAheadLoggingEnabled(boolean z2) {
        synchronized (this.f5416f) {
            a aVar = this.f5417g;
            if (aVar != null) {
                aVar.setWriteAheadLoggingEnabled(z2);
            }
            this.f5418h = z2;
        }
    }
}
