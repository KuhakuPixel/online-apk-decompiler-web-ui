package androidx.appcompat.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
/* loaded from: classes.dex */
public class r0 {

    /* renamed from: a  reason: collision with root package name */
    public ColorStateList f904a;

    /* renamed from: b  reason: collision with root package name */
    public PorterDuff.Mode f905b;

    /* renamed from: c  reason: collision with root package name */
    public boolean f906c;

    /* renamed from: d  reason: collision with root package name */
    public boolean f907d;

    /* JADX INFO: Access modifiers changed from: package-private */
    public void a() {
        this.f904a = null;
        this.f907d = false;
        this.f905b = null;
        this.f906c = false;
    }
}
