package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;
/* loaded from: classes.dex */
class e {

    /* renamed from: a  reason: collision with root package name */
    private final View f737a;

    /* renamed from: d  reason: collision with root package name */
    private r0 f740d;

    /* renamed from: e  reason: collision with root package name */
    private r0 f741e;

    /* renamed from: f  reason: collision with root package name */
    private r0 f742f;

    /* renamed from: c  reason: collision with root package name */
    private int f739c = -1;

    /* renamed from: b  reason: collision with root package name */
    private final j f738b = j.b();

    /* JADX INFO: Access modifiers changed from: package-private */
    public e(View view) {
        this.f737a = view;
    }

    private boolean a(Drawable drawable) {
        if (this.f742f == null) {
            this.f742f = new r0();
        }
        r0 r0Var = this.f742f;
        r0Var.a();
        ColorStateList s2 = e0.q.s(this.f737a);
        if (s2 != null) {
            r0Var.f907d = true;
            r0Var.f904a = s2;
        }
        PorterDuff.Mode t2 = e0.q.t(this.f737a);
        if (t2 != null) {
            r0Var.f906c = true;
            r0Var.f905b = t2;
        }
        if (r0Var.f907d || r0Var.f906c) {
            j.i(drawable, r0Var, this.f737a.getDrawableState());
            return true;
        }
        return false;
    }

    private boolean k() {
        int i2 = Build.VERSION.SDK_INT;
        return i2 > 21 ? this.f740d != null : i2 == 21;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void b() {
        Drawable background = this.f737a.getBackground();
        if (background != null) {
            if (k() && a(background)) {
                return;
            }
            r0 r0Var = this.f741e;
            if (r0Var != null) {
                j.i(background, r0Var, this.f737a.getDrawableState());
                return;
            }
            r0 r0Var2 = this.f740d;
            if (r0Var2 != null) {
                j.i(background, r0Var2, this.f737a.getDrawableState());
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public ColorStateList c() {
        r0 r0Var = this.f741e;
        if (r0Var != null) {
            return r0Var.f904a;
        }
        return null;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public PorterDuff.Mode d() {
        r0 r0Var = this.f741e;
        if (r0Var != null) {
            return r0Var.f905b;
        }
        return null;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void e(AttributeSet attributeSet, int i2) {
        Context context = this.f737a.getContext();
        int[] iArr = a.j.L3;
        t0 v2 = t0.v(context, attributeSet, iArr, i2, 0);
        View view = this.f737a;
        e0.q.i0(view, view.getContext(), iArr, attributeSet, v2.r(), i2, 0);
        try {
            int i3 = a.j.M3;
            if (v2.s(i3)) {
                this.f739c = v2.n(i3, -1);
                ColorStateList f2 = this.f738b.f(this.f737a.getContext(), this.f739c);
                if (f2 != null) {
                    h(f2);
                }
            }
            int i4 = a.j.N3;
            if (v2.s(i4)) {
                e0.q.o0(this.f737a, v2.c(i4));
            }
            int i5 = a.j.O3;
            if (v2.s(i5)) {
                e0.q.p0(this.f737a, c0.d(v2.k(i5, -1), null));
            }
        } finally {
            v2.w();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void f(Drawable drawable) {
        this.f739c = -1;
        h(null);
        b();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void g(int i2) {
        this.f739c = i2;
        j jVar = this.f738b;
        h(jVar != null ? jVar.f(this.f737a.getContext(), i2) : null);
        b();
    }

    void h(ColorStateList colorStateList) {
        if (colorStateList != null) {
            if (this.f740d == null) {
                this.f740d = new r0();
            }
            r0 r0Var = this.f740d;
            r0Var.f904a = colorStateList;
            r0Var.f907d = true;
        } else {
            this.f740d = null;
        }
        b();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void i(ColorStateList colorStateList) {
        if (this.f741e == null) {
            this.f741e = new r0();
        }
        r0 r0Var = this.f741e;
        r0Var.f904a = colorStateList;
        r0Var.f907d = true;
        b();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void j(PorterDuff.Mode mode) {
        if (this.f741e == null) {
            this.f741e = new r0();
        }
        r0 r0Var = this.f741e;
        r0Var.f905b = mode;
        r0Var.f906c = true;
        b();
    }
}
