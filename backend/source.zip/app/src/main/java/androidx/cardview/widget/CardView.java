package androidx.cardview.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout;
/* loaded from: classes.dex */
public class CardView extends FrameLayout {

    /* renamed from: i  reason: collision with root package name */
    private static final int[] f1023i = {16842801};

    /* renamed from: j  reason: collision with root package name */
    private static final c f1024j;

    /* renamed from: b  reason: collision with root package name */
    private boolean f1025b;

    /* renamed from: c  reason: collision with root package name */
    private boolean f1026c;

    /* renamed from: d  reason: collision with root package name */
    int f1027d;

    /* renamed from: e  reason: collision with root package name */
    int f1028e;

    /* renamed from: f  reason: collision with root package name */
    final Rect f1029f;

    /* renamed from: g  reason: collision with root package name */
    final Rect f1030g;

    /* renamed from: h  reason: collision with root package name */
    private final b f1031h;

    /* loaded from: classes.dex */
    class a implements b {

        /* renamed from: a  reason: collision with root package name */
        private Drawable f1032a;

        a() {
        }

        @Override // androidx.cardview.widget.b
        public void a(int i2, int i3, int i4, int i5) {
            CardView.this.f1030g.set(i2, i3, i4, i5);
            CardView cardView = CardView.this;
            Rect rect = cardView.f1029f;
            CardView.super.setPadding(i2 + rect.left, i3 + rect.top, i4 + rect.right, i5 + rect.bottom);
        }

        @Override // androidx.cardview.widget.b
        public View b() {
            return CardView.this;
        }

        @Override // androidx.cardview.widget.b
        public boolean c() {
            return CardView.this.getUseCompatPadding();
        }

        @Override // androidx.cardview.widget.b
        public Drawable d() {
            return this.f1032a;
        }

        @Override // androidx.cardview.widget.b
        public void e(Drawable drawable) {
            this.f1032a = drawable;
            CardView.this.setBackgroundDrawable(drawable);
        }

        @Override // androidx.cardview.widget.b
        public boolean f() {
            return CardView.this.getPreventCornerOverlap();
        }
    }

    static {
        androidx.cardview.widget.a aVar = new androidx.cardview.widget.a();
        f1024j = aVar;
        aVar.n();
    }

    public CardView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, k.a.cardViewStyle);
    }

    public CardView(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        Resources resources;
        int i3;
        ColorStateList valueOf;
        Rect rect = new Rect();
        this.f1029f = rect;
        this.f1030g = new Rect();
        a aVar = new a();
        this.f1031h = aVar;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, k.d.f4586a, i2, k.c.CardView);
        int i4 = k.d.f4589d;
        if (obtainStyledAttributes.hasValue(i4)) {
            valueOf = obtainStyledAttributes.getColorStateList(i4);
        } else {
            TypedArray obtainStyledAttributes2 = getContext().obtainStyledAttributes(f1023i);
            int color = obtainStyledAttributes2.getColor(0, 0);
            obtainStyledAttributes2.recycle();
            float[] fArr = new float[3];
            Color.colorToHSV(color, fArr);
            if (fArr[2] > 0.5f) {
                resources = getResources();
                i3 = k.b.cardview_light_background;
            } else {
                resources = getResources();
                i3 = k.b.cardview_dark_background;
            }
            valueOf = ColorStateList.valueOf(resources.getColor(i3));
        }
        ColorStateList colorStateList = valueOf;
        float dimension = obtainStyledAttributes.getDimension(k.d.f4590e, 0.0f);
        float dimension2 = obtainStyledAttributes.getDimension(k.d.f4591f, 0.0f);
        float dimension3 = obtainStyledAttributes.getDimension(k.d.f4592g, 0.0f);
        this.f1025b = obtainStyledAttributes.getBoolean(k.d.f4594i, false);
        this.f1026c = obtainStyledAttributes.getBoolean(k.d.f4593h, true);
        int dimensionPixelSize = obtainStyledAttributes.getDimensionPixelSize(k.d.f4595j, 0);
        rect.left = obtainStyledAttributes.getDimensionPixelSize(k.d.f4597l, dimensionPixelSize);
        rect.top = obtainStyledAttributes.getDimensionPixelSize(k.d.f4599n, dimensionPixelSize);
        rect.right = obtainStyledAttributes.getDimensionPixelSize(k.d.f4598m, dimensionPixelSize);
        rect.bottom = obtainStyledAttributes.getDimensionPixelSize(k.d.f4596k, dimensionPixelSize);
        float f2 = dimension2 > dimension3 ? dimension2 : dimension3;
        this.f1027d = obtainStyledAttributes.getDimensionPixelSize(k.d.f4587b, 0);
        this.f1028e = obtainStyledAttributes.getDimensionPixelSize(k.d.f4588c, 0);
        obtainStyledAttributes.recycle();
        f1024j.h(aVar, context, colorStateList, dimension, dimension2, f2);
    }

    public ColorStateList getCardBackgroundColor() {
        return f1024j.f(this.f1031h);
    }

    public float getCardElevation() {
        return f1024j.l(this.f1031h);
    }

    public int getContentPaddingBottom() {
        return this.f1029f.bottom;
    }

    public int getContentPaddingLeft() {
        return this.f1029f.left;
    }

    public int getContentPaddingRight() {
        return this.f1029f.right;
    }

    public int getContentPaddingTop() {
        return this.f1029f.top;
    }

    public float getMaxCardElevation() {
        return f1024j.a(this.f1031h);
    }

    public boolean getPreventCornerOverlap() {
        return this.f1026c;
    }

    public float getRadius() {
        return f1024j.b(this.f1031h);
    }

    public boolean getUseCompatPadding() {
        return this.f1025b;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.widget.FrameLayout, android.view.View
    public void onMeasure(int i2, int i3) {
        if (!(f1024j instanceof androidx.cardview.widget.a)) {
            int mode = View.MeasureSpec.getMode(i2);
            if (mode == Integer.MIN_VALUE || mode == 1073741824) {
                i2 = View.MeasureSpec.makeMeasureSpec(Math.max((int) Math.ceil(r0.d(this.f1031h)), View.MeasureSpec.getSize(i2)), mode);
            }
            int mode2 = View.MeasureSpec.getMode(i3);
            if (mode2 == Integer.MIN_VALUE || mode2 == 1073741824) {
                i3 = View.MeasureSpec.makeMeasureSpec(Math.max((int) Math.ceil(r0.c(this.f1031h)), View.MeasureSpec.getSize(i3)), mode2);
            }
        }
        super.onMeasure(i2, i3);
    }

    public void setCardBackgroundColor(int i2) {
        f1024j.k(this.f1031h, ColorStateList.valueOf(i2));
    }

    public void setCardBackgroundColor(ColorStateList colorStateList) {
        f1024j.k(this.f1031h, colorStateList);
    }

    public void setCardElevation(float f2) {
        f1024j.g(this.f1031h, f2);
    }

    public void setMaxCardElevation(float f2) {
        f1024j.m(this.f1031h, f2);
    }

    @Override // android.view.View
    public void setMinimumHeight(int i2) {
        this.f1028e = i2;
        super.setMinimumHeight(i2);
    }

    @Override // android.view.View
    public void setMinimumWidth(int i2) {
        this.f1027d = i2;
        super.setMinimumWidth(i2);
    }

    @Override // android.view.View
    public void setPadding(int i2, int i3, int i4, int i5) {
    }

    @Override // android.view.View
    public void setPaddingRelative(int i2, int i3, int i4, int i5) {
    }

    public void setPreventCornerOverlap(boolean z2) {
        if (z2 != this.f1026c) {
            this.f1026c = z2;
            f1024j.j(this.f1031h);
        }
    }

    public void setRadius(float f2) {
        f1024j.i(this.f1031h, f2);
    }

    public void setUseCompatPadding(boolean z2) {
        if (this.f1025b != z2) {
            this.f1025b = z2;
            f1024j.e(this.f1031h);
        }
    }
}
