package androidx.appcompat.widget;
/* loaded from: classes.dex */
public interface a1 {
    CharSequence a();
}
