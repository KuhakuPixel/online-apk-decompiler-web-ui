package androidx.navigation;
/* loaded from: classes.dex */
public final class u {

    /* renamed from: a */
    public static final int nav_controller_view_tag = 2131362065;
}
