package androidx.activity;

import android.annotation.SuppressLint;
import androidx.lifecycle.d;
import androidx.lifecycle.e;
import androidx.lifecycle.g;
import java.util.ArrayDeque;
import java.util.Iterator;
/* loaded from: classes.dex */
public final class OnBackPressedDispatcher {

    /* renamed from: a  reason: collision with root package name */
    private final Runnable f201a;

    /* renamed from: b  reason: collision with root package name */
    final ArrayDeque<b> f202b = new ArrayDeque<>();

    /* loaded from: classes.dex */
    private class LifecycleOnBackPressedCancellable implements e, androidx.activity.a {

        /* renamed from: a  reason: collision with root package name */
        private final d f203a;

        /* renamed from: b  reason: collision with root package name */
        private final b f204b;

        /* renamed from: c  reason: collision with root package name */
        private androidx.activity.a f205c;

        LifecycleOnBackPressedCancellable(d dVar, b bVar) {
            this.f203a = dVar;
            this.f204b = bVar;
            dVar.a(this);
        }

        @Override // androidx.activity.a
        public void cancel() {
            this.f203a.c(this);
            this.f204b.e(this);
            androidx.activity.a aVar = this.f205c;
            if (aVar != null) {
                aVar.cancel();
                this.f205c = null;
            }
        }

        @Override // androidx.lifecycle.e
        public void f(g gVar, d.a aVar) {
            if (aVar == d.a.ON_START) {
                this.f205c = OnBackPressedDispatcher.this.b(this.f204b);
            } else if (aVar != d.a.ON_STOP) {
                if (aVar == d.a.ON_DESTROY) {
                    cancel();
                }
            } else {
                androidx.activity.a aVar2 = this.f205c;
                if (aVar2 != null) {
                    aVar2.cancel();
                }
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public class a implements androidx.activity.a {

        /* renamed from: a  reason: collision with root package name */
        private final b f207a;

        a(b bVar) {
            this.f207a = bVar;
        }

        @Override // androidx.activity.a
        public void cancel() {
            OnBackPressedDispatcher.this.f202b.remove(this.f207a);
            this.f207a.e(this);
        }
    }

    public OnBackPressedDispatcher(Runnable runnable) {
        this.f201a = runnable;
    }

    @SuppressLint({"LambdaLast"})
    public void a(g gVar, b bVar) {
        d a2 = gVar.a();
        if (a2.b() == d.b.DESTROYED) {
            return;
        }
        bVar.a(new LifecycleOnBackPressedCancellable(a2, bVar));
    }

    androidx.activity.a b(b bVar) {
        this.f202b.add(bVar);
        a aVar = new a(bVar);
        bVar.a(aVar);
        return aVar;
    }

    public void c() {
        Iterator<b> descendingIterator = this.f202b.descendingIterator();
        while (descendingIterator.hasNext()) {
            b next = descendingIterator.next();
            if (next.c()) {
                next.b();
                return;
            }
        }
        Runnable runnable = this.f201a;
        if (runnable != null) {
            runnable.run();
        }
    }
}
