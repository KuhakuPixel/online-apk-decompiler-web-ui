package u1;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.r;
import androidx.lifecycle.s;
/* loaded from: classes.dex */
public class c extends r {

    /* renamed from: d  reason: collision with root package name */
    static final String f5346d = b.class.getSimpleName();

    /* renamed from: c  reason: collision with root package name */
    private final com.sample.android.kuhakupixelinapppurchase.a f5347c;

    /* loaded from: classes.dex */
    public static class a implements s.a {

        /* renamed from: a  reason: collision with root package name */
        private final com.sample.android.kuhakupixelinapppurchase.a f5348a;

        public a(com.sample.android.kuhakupixelinapppurchase.a aVar) {
            this.f5348a = aVar;
        }

        @Override // androidx.lifecycle.s.a
        public <T extends r> T a(Class<T> cls) {
            if (cls.isAssignableFrom(c.class)) {
                return new c(this.f5348a);
            }
            throw new IllegalArgumentException("Unknown ViewModel class");
        }
    }

    public c(com.sample.android.kuhakupixelinapppurchase.a aVar) {
        this.f5347c = aVar;
    }

    public void e() {
        this.f5347c.l();
    }

    public androidx.lifecycle.f f() {
        return this.f5347c.p();
    }

    public LiveData<Integer> g() {
        return this.f5347c.q();
    }
}
