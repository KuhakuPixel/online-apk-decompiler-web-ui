package androidx.room;

import android.annotation.SuppressLint;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteException;
import android.util.Log;
import androidx.lifecycle.LiveData;
import java.lang.ref.WeakReference;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.Lock;
/* loaded from: classes.dex */
public class n {

    /* renamed from: n  reason: collision with root package name */
    private static final String[] f2633n = {"UPDATE", "DELETE", "INSERT"};

    /* renamed from: b  reason: collision with root package name */
    final String[] f2635b;

    /* renamed from: c  reason: collision with root package name */
    private Map<String, Set<String>> f2636c;

    /* renamed from: e  reason: collision with root package name */
    final e0 f2638e;

    /* renamed from: h  reason: collision with root package name */
    volatile u0.f f2641h;

    /* renamed from: i  reason: collision with root package name */
    private b f2642i;

    /* renamed from: j  reason: collision with root package name */
    private final l f2643j;

    /* renamed from: l  reason: collision with root package name */
    private o f2645l;

    /* renamed from: d  reason: collision with root package name */
    androidx.room.a f2637d = null;

    /* renamed from: f  reason: collision with root package name */
    AtomicBoolean f2639f = new AtomicBoolean(false);

    /* renamed from: g  reason: collision with root package name */
    private volatile boolean f2640g = false;
    @SuppressLint({"RestrictedApi"})

    /* renamed from: k  reason: collision with root package name */
    final i.b<c, d> f2644k = new i.b<>();

    /* renamed from: m  reason: collision with root package name */
    Runnable f2646m = new a();

    /* renamed from: a  reason: collision with root package name */
    final HashMap<String, Integer> f2634a = new HashMap<>();

    /* loaded from: classes.dex */
    class a implements Runnable {
        a() {
        }

        private Set<Integer> a() {
            HashSet hashSet = new HashSet();
            Cursor y2 = n.this.f2638e.y(new u0.a("SELECT * FROM room_table_modification_log WHERE invalidated = 1;"));
            while (y2.moveToNext()) {
                try {
                    hashSet.add(Integer.valueOf(y2.getInt(0)));
                } catch (Throwable th) {
                    y2.close();
                    throw th;
                }
            }
            y2.close();
            if (!hashSet.isEmpty()) {
                n.this.f2641h.l();
            }
            return hashSet;
        }

        /* JADX WARN: Code restructure failed: missing block: B:31:0x007f, code lost:
            if (r0 != null) goto L32;
         */
        /* JADX WARN: Code restructure failed: missing block: B:32:0x0081, code lost:
            r0.b();
         */
        /* JADX WARN: Code restructure failed: missing block: B:40:0x0098, code lost:
            if (r0 == null) goto L42;
         */
        /* JADX WARN: Code restructure failed: missing block: B:42:0x009b, code lost:
            if (r1 == null) goto L56;
         */
        /* JADX WARN: Code restructure failed: missing block: B:44:0x00a1, code lost:
            if (r1.isEmpty() != false) goto L70;
         */
        /* JADX WARN: Code restructure failed: missing block: B:45:0x00a3, code lost:
            r0 = r5.f2647b.f2644k;
         */
        /* JADX WARN: Code restructure failed: missing block: B:46:0x00a7, code lost:
            monitor-enter(r0);
         */
        /* JADX WARN: Code restructure failed: missing block: B:47:0x00a8, code lost:
            r2 = r5.f2647b.f2644k.iterator();
         */
        /* JADX WARN: Code restructure failed: missing block: B:49:0x00b4, code lost:
            if (r2.hasNext() == false) goto L66;
         */
        /* JADX WARN: Code restructure failed: missing block: B:50:0x00b6, code lost:
            r2.next().getValue().a(r1);
         */
        /* JADX WARN: Code restructure failed: missing block: B:51:0x00c6, code lost:
            monitor-exit(r0);
         */
        /* JADX WARN: Code restructure failed: missing block: B:56:0x00cb, code lost:
            return;
         */
        /* JADX WARN: Code restructure failed: missing block: B:70:?, code lost:
            return;
         */
        /* JADX WARN: Code restructure failed: missing block: B:71:?, code lost:
            return;
         */
        @Override // java.lang.Runnable
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public void run() {
            /*
                r5 = this;
                androidx.room.n r0 = androidx.room.n.this
                androidx.room.e0 r0 = r0.f2638e
                java.util.concurrent.locks.Lock r0 = r0.j()
                r0.lock()
                r1 = 0
                androidx.room.n r2 = androidx.room.n.this     // Catch: java.lang.Throwable -> L85 android.database.sqlite.SQLiteException -> L87 java.lang.IllegalStateException -> L89
                boolean r2 = r2.f()     // Catch: java.lang.Throwable -> L85 android.database.sqlite.SQLiteException -> L87 java.lang.IllegalStateException -> L89
                if (r2 != 0) goto L21
                r0.unlock()
                androidx.room.n r0 = androidx.room.n.this
                androidx.room.a r0 = r0.f2637d
                if (r0 == 0) goto L20
                r0.b()
            L20:
                return
            L21:
                androidx.room.n r2 = androidx.room.n.this     // Catch: java.lang.Throwable -> L85 android.database.sqlite.SQLiteException -> L87 java.lang.IllegalStateException -> L89
                java.util.concurrent.atomic.AtomicBoolean r2 = r2.f2639f     // Catch: java.lang.Throwable -> L85 android.database.sqlite.SQLiteException -> L87 java.lang.IllegalStateException -> L89
                r3 = 1
                r4 = 0
                boolean r2 = r2.compareAndSet(r3, r4)     // Catch: java.lang.Throwable -> L85 android.database.sqlite.SQLiteException -> L87 java.lang.IllegalStateException -> L89
                if (r2 != 0) goto L3a
                r0.unlock()
                androidx.room.n r0 = androidx.room.n.this
                androidx.room.a r0 = r0.f2637d
                if (r0 == 0) goto L39
                r0.b()
            L39:
                return
            L3a:
                androidx.room.n r2 = androidx.room.n.this     // Catch: java.lang.Throwable -> L85 android.database.sqlite.SQLiteException -> L87 java.lang.IllegalStateException -> L89
                androidx.room.e0 r2 = r2.f2638e     // Catch: java.lang.Throwable -> L85 android.database.sqlite.SQLiteException -> L87 java.lang.IllegalStateException -> L89
                boolean r2 = r2.p()     // Catch: java.lang.Throwable -> L85 android.database.sqlite.SQLiteException -> L87 java.lang.IllegalStateException -> L89
                if (r2 == 0) goto L51
                r0.unlock()
                androidx.room.n r0 = androidx.room.n.this
                androidx.room.a r0 = r0.f2637d
                if (r0 == 0) goto L50
                r0.b()
            L50:
                return
            L51:
                androidx.room.n r2 = androidx.room.n.this     // Catch: java.lang.Throwable -> L85 android.database.sqlite.SQLiteException -> L87 java.lang.IllegalStateException -> L89
                androidx.room.e0 r2 = r2.f2638e     // Catch: java.lang.Throwable -> L85 android.database.sqlite.SQLiteException -> L87 java.lang.IllegalStateException -> L89
                boolean r3 = r2.f2533g     // Catch: java.lang.Throwable -> L85 android.database.sqlite.SQLiteException -> L87 java.lang.IllegalStateException -> L89
                if (r3 == 0) goto L74
                u0.c r2 = r2.l()     // Catch: java.lang.Throwable -> L85 android.database.sqlite.SQLiteException -> L87 java.lang.IllegalStateException -> L89
                u0.b r2 = r2.r()     // Catch: java.lang.Throwable -> L85 android.database.sqlite.SQLiteException -> L87 java.lang.IllegalStateException -> L89
                r2.n()     // Catch: java.lang.Throwable -> L85 android.database.sqlite.SQLiteException -> L87 java.lang.IllegalStateException -> L89
                java.util.Set r1 = r5.a()     // Catch: java.lang.Throwable -> L6f
                r2.k()     // Catch: java.lang.Throwable -> L6f
                r2.a()     // Catch: java.lang.Throwable -> L85 android.database.sqlite.SQLiteException -> L87 java.lang.IllegalStateException -> L89
                goto L78
            L6f:
                r3 = move-exception
                r2.a()     // Catch: java.lang.Throwable -> L85 android.database.sqlite.SQLiteException -> L87 java.lang.IllegalStateException -> L89
                throw r3     // Catch: java.lang.Throwable -> L85 android.database.sqlite.SQLiteException -> L87 java.lang.IllegalStateException -> L89
            L74:
                java.util.Set r1 = r5.a()     // Catch: java.lang.Throwable -> L85 android.database.sqlite.SQLiteException -> L87 java.lang.IllegalStateException -> L89
            L78:
                r0.unlock()
                androidx.room.n r0 = androidx.room.n.this
                androidx.room.a r0 = r0.f2637d
                if (r0 == 0) goto L9b
            L81:
                r0.b()
                goto L9b
            L85:
                r1 = move-exception
                goto Lcc
            L87:
                r2 = move-exception
                goto L8a
            L89:
                r2 = move-exception
            L8a:
                java.lang.String r3 = "ROOM"
                java.lang.String r4 = "Cannot run invalidation tracker. Is the db closed?"
                android.util.Log.e(r3, r4, r2)     // Catch: java.lang.Throwable -> L85
                r0.unlock()
                androidx.room.n r0 = androidx.room.n.this
                androidx.room.a r0 = r0.f2637d
                if (r0 == 0) goto L9b
                goto L81
            L9b:
                if (r1 == 0) goto Lcb
                boolean r0 = r1.isEmpty()
                if (r0 != 0) goto Lcb
                androidx.room.n r0 = androidx.room.n.this
                i.b<androidx.room.n$c, androidx.room.n$d> r0 = r0.f2644k
                monitor-enter(r0)
                androidx.room.n r2 = androidx.room.n.this     // Catch: java.lang.Throwable -> Lc8
                i.b<androidx.room.n$c, androidx.room.n$d> r2 = r2.f2644k     // Catch: java.lang.Throwable -> Lc8
                java.util.Iterator r2 = r2.iterator()     // Catch: java.lang.Throwable -> Lc8
            Lb0:
                boolean r3 = r2.hasNext()     // Catch: java.lang.Throwable -> Lc8
                if (r3 == 0) goto Lc6
                java.lang.Object r3 = r2.next()     // Catch: java.lang.Throwable -> Lc8
                java.util.Map$Entry r3 = (java.util.Map.Entry) r3     // Catch: java.lang.Throwable -> Lc8
                java.lang.Object r3 = r3.getValue()     // Catch: java.lang.Throwable -> Lc8
                androidx.room.n$d r3 = (androidx.room.n.d) r3     // Catch: java.lang.Throwable -> Lc8
                r3.a(r1)     // Catch: java.lang.Throwable -> Lc8
                goto Lb0
            Lc6:
                monitor-exit(r0)     // Catch: java.lang.Throwable -> Lc8
                goto Lcb
            Lc8:
                r1 = move-exception
                monitor-exit(r0)     // Catch: java.lang.Throwable -> Lc8
                throw r1
            Lcb:
                return
            Lcc:
                r0.unlock()
                androidx.room.n r0 = androidx.room.n.this
                androidx.room.a r0 = r0.f2637d
                if (r0 == 0) goto Ld8
                r0.b()
            Ld8:
                throw r1
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.room.n.a.run():void");
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public static class b {

        /* renamed from: a  reason: collision with root package name */
        final long[] f2648a;

        /* renamed from: b  reason: collision with root package name */
        final boolean[] f2649b;

        /* renamed from: c  reason: collision with root package name */
        final int[] f2650c;

        /* renamed from: d  reason: collision with root package name */
        boolean f2651d;

        /* renamed from: e  reason: collision with root package name */
        boolean f2652e;

        b(int i2) {
            long[] jArr = new long[i2];
            this.f2648a = jArr;
            boolean[] zArr = new boolean[i2];
            this.f2649b = zArr;
            this.f2650c = new int[i2];
            Arrays.fill(jArr, 0L);
            Arrays.fill(zArr, false);
        }

        int[] a() {
            synchronized (this) {
                if (this.f2651d && !this.f2652e) {
                    int length = this.f2648a.length;
                    int i2 = 0;
                    while (true) {
                        int i3 = 1;
                        if (i2 >= length) {
                            this.f2652e = true;
                            this.f2651d = false;
                            return this.f2650c;
                        }
                        boolean z2 = this.f2648a[i2] > 0;
                        boolean[] zArr = this.f2649b;
                        if (z2 != zArr[i2]) {
                            int[] iArr = this.f2650c;
                            if (!z2) {
                                i3 = 2;
                            }
                            iArr[i2] = i3;
                        } else {
                            this.f2650c[i2] = 0;
                        }
                        zArr[i2] = z2;
                        i2++;
                    }
                }
                return null;
            }
        }

        boolean b(int... iArr) {
            boolean z2;
            synchronized (this) {
                z2 = false;
                for (int i2 : iArr) {
                    long[] jArr = this.f2648a;
                    long j2 = jArr[i2];
                    jArr[i2] = 1 + j2;
                    if (j2 == 0) {
                        this.f2651d = true;
                        z2 = true;
                    }
                }
            }
            return z2;
        }

        boolean c(int... iArr) {
            boolean z2;
            synchronized (this) {
                z2 = false;
                for (int i2 : iArr) {
                    long[] jArr = this.f2648a;
                    long j2 = jArr[i2];
                    jArr[i2] = j2 - 1;
                    if (j2 == 1) {
                        this.f2651d = true;
                        z2 = true;
                    }
                }
            }
            return z2;
        }

        void d() {
            synchronized (this) {
                this.f2652e = false;
            }
        }

        void e() {
            synchronized (this) {
                Arrays.fill(this.f2649b, false);
                this.f2651d = true;
            }
        }
    }

    /* loaded from: classes.dex */
    public static abstract class c {

        /* renamed from: a  reason: collision with root package name */
        final String[] f2653a;

        public c(String[] strArr) {
            this.f2653a = (String[]) Arrays.copyOf(strArr, strArr.length);
        }

        boolean a() {
            return false;
        }

        public abstract void b(Set<String> set);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public static class d {

        /* renamed from: a  reason: collision with root package name */
        final int[] f2654a;

        /* renamed from: b  reason: collision with root package name */
        private final String[] f2655b;

        /* renamed from: c  reason: collision with root package name */
        final c f2656c;

        /* renamed from: d  reason: collision with root package name */
        private final Set<String> f2657d;

        d(c cVar, int[] iArr, String[] strArr) {
            Set<String> set;
            this.f2656c = cVar;
            this.f2654a = iArr;
            this.f2655b = strArr;
            if (iArr.length == 1) {
                HashSet hashSet = new HashSet();
                hashSet.add(strArr[0]);
                set = Collections.unmodifiableSet(hashSet);
            } else {
                set = null;
            }
            this.f2657d = set;
        }

        void a(Set<Integer> set) {
            int length = this.f2654a.length;
            Set<String> set2 = null;
            for (int i2 = 0; i2 < length; i2++) {
                if (set.contains(Integer.valueOf(this.f2654a[i2]))) {
                    if (length == 1) {
                        set2 = this.f2657d;
                    } else {
                        if (set2 == null) {
                            set2 = new HashSet<>(length);
                        }
                        set2.add(this.f2655b[i2]);
                    }
                }
            }
            if (set2 != null) {
                this.f2656c.b(set2);
            }
        }

        void b(String[] strArr) {
            Set<String> set = null;
            if (this.f2655b.length == 1) {
                int length = strArr.length;
                int i2 = 0;
                while (true) {
                    if (i2 >= length) {
                        break;
                    } else if (strArr[i2].equalsIgnoreCase(this.f2655b[0])) {
                        set = this.f2657d;
                        break;
                    } else {
                        i2++;
                    }
                }
            } else {
                HashSet hashSet = new HashSet();
                for (String str : strArr) {
                    String[] strArr2 = this.f2655b;
                    int length2 = strArr2.length;
                    int i3 = 0;
                    while (true) {
                        if (i3 < length2) {
                            String str2 = strArr2[i3];
                            if (str2.equalsIgnoreCase(str)) {
                                hashSet.add(str2);
                                break;
                            }
                            i3++;
                        }
                    }
                }
                if (hashSet.size() > 0) {
                    set = hashSet;
                }
            }
            if (set != null) {
                this.f2656c.b(set);
            }
        }
    }

    /* loaded from: classes.dex */
    static class e extends c {

        /* renamed from: b  reason: collision with root package name */
        final n f2658b;

        /* renamed from: c  reason: collision with root package name */
        final WeakReference<c> f2659c;

        e(n nVar, c cVar) {
            super(cVar.f2653a);
            this.f2658b = nVar;
            this.f2659c = new WeakReference<>(cVar);
        }

        @Override // androidx.room.n.c
        public void b(Set<String> set) {
            c cVar = this.f2659c.get();
            if (cVar == null) {
                this.f2658b.k(this);
            } else {
                cVar.b(set);
            }
        }
    }

    public n(e0 e0Var, Map<String, String> map, Map<String, Set<String>> map2, String... strArr) {
        this.f2638e = e0Var;
        this.f2642i = new b(strArr.length);
        this.f2636c = map2;
        this.f2643j = new l(e0Var);
        int length = strArr.length;
        this.f2635b = new String[length];
        for (int i2 = 0; i2 < length; i2++) {
            String str = strArr[i2];
            Locale locale = Locale.US;
            String lowerCase = str.toLowerCase(locale);
            this.f2634a.put(lowerCase, Integer.valueOf(i2));
            String str2 = map.get(strArr[i2]);
            if (str2 != null) {
                this.f2635b[i2] = str2.toLowerCase(locale);
            } else {
                this.f2635b[i2] = lowerCase;
            }
        }
        for (Map.Entry<String, String> entry : map.entrySet()) {
            String value = entry.getValue();
            Locale locale2 = Locale.US;
            String lowerCase2 = value.toLowerCase(locale2);
            if (this.f2634a.containsKey(lowerCase2)) {
                String lowerCase3 = entry.getKey().toLowerCase(locale2);
                HashMap<String, Integer> hashMap = this.f2634a;
                hashMap.put(lowerCase3, hashMap.get(lowerCase2));
            }
        }
    }

    private static void c(StringBuilder sb, String str, String str2) {
        sb.append("`");
        sb.append("room_table_modification_trigger_");
        sb.append(str);
        sb.append("_");
        sb.append(str2);
        sb.append("`");
    }

    private static void d(u0.b bVar) {
        if (bVar.f()) {
            bVar.n();
        } else {
            bVar.b();
        }
    }

    private String[] l(String[] strArr) {
        HashSet hashSet = new HashSet();
        for (String str : strArr) {
            String lowerCase = str.toLowerCase(Locale.US);
            if (this.f2636c.containsKey(lowerCase)) {
                hashSet.addAll(this.f2636c.get(lowerCase));
            } else {
                hashSet.add(str);
            }
        }
        return (String[]) hashSet.toArray(new String[hashSet.size()]);
    }

    private void o(u0.b bVar, int i2) {
        bVar.g("INSERT OR IGNORE INTO room_table_modification_log VALUES(" + i2 + ", 0)");
        String str = this.f2635b[i2];
        StringBuilder sb = new StringBuilder();
        for (String str2 : f2633n) {
            sb.setLength(0);
            sb.append("CREATE TEMP TRIGGER IF NOT EXISTS ");
            c(sb, str, str2);
            sb.append(" AFTER ");
            sb.append(str2);
            sb.append(" ON `");
            sb.append(str);
            sb.append("` BEGIN UPDATE ");
            sb.append("room_table_modification_log");
            sb.append(" SET ");
            sb.append("invalidated");
            sb.append(" = 1");
            sb.append(" WHERE ");
            sb.append("table_id");
            sb.append(" = ");
            sb.append(i2);
            sb.append(" AND ");
            sb.append("invalidated");
            sb.append(" = 0");
            sb.append("; END");
            bVar.g(sb.toString());
        }
    }

    private void p(u0.b bVar, int i2) {
        String str = this.f2635b[i2];
        StringBuilder sb = new StringBuilder();
        for (String str2 : f2633n) {
            sb.setLength(0);
            sb.append("DROP TRIGGER IF EXISTS ");
            c(sb, str, str2);
            bVar.g(sb.toString());
        }
    }

    private String[] s(String[] strArr) {
        String[] l2 = l(strArr);
        for (String str : l2) {
            if (!this.f2634a.containsKey(str.toLowerCase(Locale.US))) {
                throw new IllegalArgumentException("There is no table with name " + str);
            }
        }
        return l2;
    }

    @SuppressLint({"RestrictedApi"})
    public void a(c cVar) {
        d i2;
        String[] l2 = l(cVar.f2653a);
        int[] iArr = new int[l2.length];
        int length = l2.length;
        for (int i3 = 0; i3 < length; i3++) {
            Integer num = this.f2634a.get(l2[i3].toLowerCase(Locale.US));
            if (num == null) {
                throw new IllegalArgumentException("There is no table with name " + l2[i3]);
            }
            iArr[i3] = num.intValue();
        }
        d dVar = new d(cVar, iArr, l2);
        synchronized (this.f2644k) {
            i2 = this.f2644k.i(cVar, dVar);
        }
        if (i2 == null && this.f2642i.b(iArr)) {
            q();
        }
    }

    public void b(c cVar) {
        a(new e(this, cVar));
    }

    public <T> LiveData<T> e(String[] strArr, boolean z2, Callable<T> callable) {
        return this.f2643j.a(s(strArr), z2, callable);
    }

    boolean f() {
        if (this.f2638e.v()) {
            if (!this.f2640g) {
                this.f2638e.l().r();
            }
            if (this.f2640g) {
                return true;
            }
            Log.e("ROOM", "database is not initialized even though it is open");
            return false;
        }
        return false;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void g(u0.b bVar) {
        synchronized (this) {
            if (this.f2640g) {
                Log.e("ROOM", "Invalidation tracker is initialized twice :/.");
                return;
            }
            bVar.g("PRAGMA temp_store = MEMORY;");
            bVar.g("PRAGMA recursive_triggers='ON';");
            bVar.g("CREATE TEMP TABLE room_table_modification_log(table_id INTEGER PRIMARY KEY, invalidated INTEGER NOT NULL DEFAULT 0)");
            r(bVar);
            this.f2641h = bVar.m("UPDATE room_table_modification_log SET invalidated = 0 WHERE invalidated = 1 ");
            this.f2640g = true;
        }
    }

    public void h(String... strArr) {
        synchronized (this.f2644k) {
            Iterator<Map.Entry<c, d>> it = this.f2644k.iterator();
            while (it.hasNext()) {
                Map.Entry<c, d> next = it.next();
                if (!next.getKey().a()) {
                    next.getValue().b(strArr);
                }
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void i() {
        synchronized (this) {
            this.f2640g = false;
            this.f2642i.e();
        }
    }

    public void j() {
        if (this.f2639f.compareAndSet(false, true)) {
            androidx.room.a aVar = this.f2637d;
            if (aVar != null) {
                aVar.e();
            }
            this.f2638e.m().execute(this.f2646m);
        }
    }

    @SuppressLint({"RestrictedApi"})
    public void k(c cVar) {
        d j2;
        synchronized (this.f2644k) {
            j2 = this.f2644k.j(cVar);
        }
        if (j2 == null || !this.f2642i.c(j2.f2654a)) {
            return;
        }
        q();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void m(androidx.room.a aVar) {
        this.f2637d = aVar;
        aVar.h(new Runnable() { // from class: androidx.room.m
            @Override // java.lang.Runnable
            public final void run() {
                n.this.i();
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void n(Context context, String str) {
        this.f2645l = new o(context, str, this, this.f2638e.m());
    }

    void q() {
        if (this.f2638e.v()) {
            r(this.f2638e.l().r());
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void r(u0.b bVar) {
        if (bVar.u()) {
            return;
        }
        while (true) {
            try {
                Lock j2 = this.f2638e.j();
                j2.lock();
                try {
                    int[] a2 = this.f2642i.a();
                    if (a2 == null) {
                        return;
                    }
                    int length = a2.length;
                    d(bVar);
                    for (int i2 = 0; i2 < length; i2++) {
                        int i3 = a2[i2];
                        if (i3 == 1) {
                            o(bVar, i2);
                        } else if (i3 == 2) {
                            p(bVar, i2);
                        }
                    }
                    bVar.k();
                    bVar.a();
                    this.f2642i.d();
                } finally {
                    j2.unlock();
                }
            } catch (SQLiteException | IllegalStateException e2) {
                Log.e("ROOM", "Cannot run invalidation tracker. Is the db closed?", e2);
                return;
            }
        }
    }
}
