package x0;
/* loaded from: classes.dex */
public interface a {
}
