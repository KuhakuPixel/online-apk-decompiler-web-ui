package w1;

import android.graphics.drawable.Drawable;
import android.util.SparseIntArray;
import android.view.View;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.cardview.widget.CardView;
import androidx.databinding.ViewDataBinding;
import androidx.lifecycle.LiveData;
import com.sample.android.kuhakupixelinapppurchase.R;
import com.sample.android.kuhakupixelinapppurchase.ui.MakePurchaseFragment;
import u1.d;
import y1.a;
/* loaded from: classes.dex */
public class j extends i implements a.InterfaceC0083a {
    private static final SparseIntArray L = null;
    private final CardView I;
    private final View.OnClickListener J;
    private long K;

    public j(androidx.databinding.e eVar, View view) {
        this(eVar, view, ViewDataBinding.u(eVar, view, 5, null, L));
    }

    private j(androidx.databinding.e eVar, View view, Object[] objArr) {
        super(eVar, view, 4, (AppCompatTextView) objArr[4], (AppCompatImageView) objArr[3], (AppCompatTextView) objArr[1], (AppCompatTextView) objArr[2]);
        this.K = -1L;
        CardView cardView = (CardView) objArr[0];
        this.I = cardView;
        cardView.setTag(null);
        this.B.setTag(null);
        this.C.setTag(null);
        this.D.setTag(null);
        this.E.setTag(null);
        D(view);
        this.J = new y1.a(this, 1);
        K();
    }

    private boolean L(LiveData<Boolean> liveData, int i2) {
        if (i2 == 0) {
            synchronized (this) {
                this.K |= 4;
            }
            return true;
        }
        return false;
    }

    private boolean M(LiveData<CharSequence> liveData, int i2) {
        if (i2 == 0) {
            synchronized (this) {
                this.K |= 8;
            }
            return true;
        }
        return false;
    }

    private boolean N(LiveData<String> liveData, int i2) {
        if (i2 == 0) {
            synchronized (this) {
                this.K |= 2;
            }
            return true;
        }
        return false;
    }

    private boolean O(LiveData<String> liveData, int i2) {
        if (i2 == 0) {
            synchronized (this) {
                this.K |= 1;
            }
            return true;
        }
        return false;
    }

    @Override // w1.i
    public void H(MakePurchaseFragment makePurchaseFragment) {
        this.H = makePurchaseFragment;
        synchronized (this) {
            this.K |= 16;
        }
        d(4);
        super.z();
    }

    @Override // w1.i
    public void I(String str) {
        this.F = str;
        synchronized (this) {
            this.K |= 32;
        }
        d(6);
        super.z();
    }

    @Override // w1.i
    public void J(d.b bVar) {
        this.G = bVar;
        synchronized (this) {
            this.K |= 64;
        }
        d(7);
        super.z();
    }

    public void K() {
        synchronized (this) {
            this.K = 128L;
        }
        z();
    }

    @Override // y1.a.InterfaceC0083a
    public final void b(int i2, View view) {
        d.b bVar = this.G;
        MakePurchaseFragment makePurchaseFragment = this.H;
        if (makePurchaseFragment != null) {
            if (bVar != null) {
                makePurchaseFragment.w1(bVar.f5352a);
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r10v11, types: [java.lang.CharSequence] */
    @Override // androidx.databinding.ViewDataBinding
    protected void l() {
        long j2;
        String str;
        boolean z2;
        long j3;
        String str2;
        Drawable drawable;
        String str3;
        boolean z3;
        boolean z4;
        boolean z5;
        synchronized (this) {
            j2 = this.K;
            this.K = 0L;
        }
        MakePurchaseFragment makePurchaseFragment = this.H;
        String str4 = this.F;
        d.b bVar = this.G;
        int i2 = ((j2 & 184) > 0L ? 1 : ((j2 & 184) == 0L ? 0 : -1));
        if (i2 != 0) {
            LiveData<CharSequence> x12 = makePurchaseFragment != null ? makePurchaseFragment.x1(str4) : null;
            F(3, x12);
            str = x12 != null ? x12.d() : null;
            z2 = str == null;
            if (i2 != 0) {
                j2 = z2 ? j2 | 512 : j2 | 256;
            }
        } else {
            str = null;
            z2 = false;
        }
        if ((j2 & 215) != 0) {
            int i3 = ((j2 & 193) > 0L ? 1 : ((j2 & 193) == 0L ? 0 : -1));
            if (i3 != 0) {
                LiveData<String> liveData = bVar != null ? bVar.f5355d : null;
                F(0, liveData);
                str2 = liveData != null ? liveData.d() : null;
                z4 = str2 == null;
                if (i3 != 0) {
                    j2 |= z4 ? 8192L : 4096L;
                }
            } else {
                str2 = null;
                z4 = false;
            }
            int i4 = ((j2 & 194) > 0L ? 1 : ((j2 & 194) == 0L ? 0 : -1));
            if (i4 != 0) {
                LiveData<String> liveData2 = bVar != null ? bVar.f5354c : null;
                F(1, liveData2);
                str3 = liveData2 != null ? liveData2.d() : null;
                z5 = str3 == null;
                if (i4 != 0) {
                    j2 |= z5 ? 2048L : 1024L;
                }
            } else {
                str3 = null;
                z5 = false;
            }
            if ((j2 & 192) != 0) {
                drawable = p().getContext().getDrawable(bVar != null ? bVar.f5356e : 0);
            } else {
                drawable = null;
            }
            if ((j2 & 212) != 0) {
                LiveData<Boolean> r12 = makePurchaseFragment != null ? makePurchaseFragment.r1(bVar != null ? bVar.f5352a : null) : null;
                F(2, r12);
                z3 = ViewDataBinding.B(r12 != null ? r12.d() : null);
            } else {
                z3 = false;
            }
            j3 = 512;
        } else {
            j3 = 512;
            str2 = null;
            drawable = null;
            str3 = null;
            z3 = false;
            z4 = false;
            z5 = false;
        }
        String string = (j3 & j2) != 0 ? this.E.getResources().getString(R.string.debug_title_not_found, str4) : null;
        int i5 = ((j2 & 194) > 0L ? 1 : ((j2 & 194) == 0L ? 0 : -1));
        if (i5 == 0) {
            str3 = null;
        } else if (z5) {
            str3 = this.B.getResources().getString(R.string.debug_description_not_found);
        }
        int i6 = ((j2 & 193) > 0L ? 1 : ((j2 & 193) == 0L ? 0 : -1));
        if (i6 == 0) {
            str2 = null;
        } else if (z4) {
            str2 = this.D.getResources().getString(R.string.debug_price_not_found);
        }
        int i7 = ((184 & j2) > 0L ? 1 : ((184 & j2) == 0L ? 0 : -1));
        String str5 = i7 != 0 ? z2 ? string : str : null;
        if ((j2 & 212) != 0) {
            this.I.setEnabled(z3);
            j0.c.a(this.I, this.J, z3);
        }
        if (i5 != 0) {
            j0.b.b(this.B, str3);
        }
        if ((j2 & 192) != 0) {
            j0.a.a(this.C, drawable);
        }
        if (i6 != 0) {
            j0.b.b(this.D, str2);
        }
        if (i7 != 0) {
            j0.b.b(this.E, str5);
        }
    }

    @Override // androidx.databinding.ViewDataBinding
    public boolean r() {
        synchronized (this) {
            return this.K != 0;
        }
    }

    @Override // androidx.databinding.ViewDataBinding
    protected boolean v(int i2, Object obj, int i3) {
        if (i2 != 0) {
            if (i2 != 1) {
                if (i2 != 2) {
                    if (i2 != 3) {
                        return false;
                    }
                    return M((LiveData) obj, i3);
                }
                return L((LiveData) obj, i3);
            }
            return N((LiveData) obj, i3);
        }
        return O((LiveData) obj, i3);
    }
}
