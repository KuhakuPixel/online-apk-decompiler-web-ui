package q;
/* loaded from: classes.dex */
class a extends g {
    public a(p pVar) {
        super(pVar);
    }
}
