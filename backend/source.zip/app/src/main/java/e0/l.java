package e0;

import android.view.View;
/* loaded from: classes.dex */
public interface l {
    void h(View view, View view2, int i2, int i3);

    void i(View view, int i2);

    void j(View view, int i2, int i3, int[] iArr, int i4);

    void n(View view, int i2, int i3, int i4, int i5, int i6);

    boolean o(View view, View view2, int i2, int i3);
}
