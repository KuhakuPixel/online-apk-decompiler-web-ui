package androidx.room;

import androidx.lifecycle.LiveData;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Set;
import java.util.concurrent.Callable;
/* loaded from: classes.dex */
class l {

    /* renamed from: a  reason: collision with root package name */
    final Set<LiveData> f2630a = Collections.newSetFromMap(new IdentityHashMap());

    /* renamed from: b  reason: collision with root package name */
    private final e0 f2631b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public l(e0 e0Var) {
        this.f2631b = e0Var;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public <T> LiveData<T> a(String[] strArr, boolean z2, Callable<T> callable) {
        return new g0(this.f2631b, this, z2, callable, strArr);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void b(LiveData liveData) {
        this.f2630a.add(liveData);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void c(LiveData liveData) {
        this.f2630a.remove(liveData);
    }
}
