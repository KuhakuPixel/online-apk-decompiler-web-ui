package z0;

import android.os.Binder;
import android.os.IInterface;
/* loaded from: classes.dex */
public class p extends Binder implements IInterface {
}
