package l0;

import com.sample.android.kuhakupixelinapppurchase.R;
/* loaded from: classes.dex */
public final class c {

    /* renamed from: e  reason: collision with root package name */
    public static final int f4660e = 0;

    /* renamed from: f  reason: collision with root package name */
    public static final int f4661f = 1;

    /* renamed from: g  reason: collision with root package name */
    public static final int f4662g = 2;

    /* renamed from: i  reason: collision with root package name */
    public static final int f4664i = 0;

    /* renamed from: j  reason: collision with root package name */
    public static final int f4665j = 1;

    /* renamed from: a  reason: collision with root package name */
    public static final int[] f4656a = {16843173, 16843551, R.attr.alpha};

    /* renamed from: b  reason: collision with root package name */
    public static final int[] f4657b = {R.attr.fontProviderAuthority, R.attr.fontProviderCerts, R.attr.fontProviderFetchStrategy, R.attr.fontProviderFetchTimeout, R.attr.fontProviderPackage, R.attr.fontProviderQuery};

    /* renamed from: c  reason: collision with root package name */
    public static final int[] f4658c = {16844082, 16844083, 16844095, 16844143, 16844144, R.attr.font, R.attr.fontStyle, R.attr.fontVariationSettings, R.attr.fontWeight, R.attr.ttcIndex};

    /* renamed from: d  reason: collision with root package name */
    public static final int[] f4659d = {16842755, 16842960, 16842961};

    /* renamed from: h  reason: collision with root package name */
    public static final int[] f4663h = {16842755, 16842961};

    /* renamed from: k  reason: collision with root package name */
    public static final int[] f4666k = {16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 16844050, 16844051};

    /* renamed from: l  reason: collision with root package name */
    public static final int[] f4667l = {16843173, 16844052};
}
