package androidx.lifecycle;

import androidx.lifecycle.d;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes.dex */
public class CompositeGeneratedAdaptersObserver implements e {

    /* renamed from: a  reason: collision with root package name */
    private final c[] f1811a;

    /* JADX INFO: Access modifiers changed from: package-private */
    public CompositeGeneratedAdaptersObserver(c[] cVarArr) {
        this.f1811a = cVarArr;
    }

    @Override // androidx.lifecycle.e
    public void f(g gVar, d.a aVar) {
        l lVar = new l();
        for (c cVar : this.f1811a) {
            cVar.a(gVar, aVar, false, lVar);
        }
        for (c cVar2 : this.f1811a) {
            cVar2.a(gVar, aVar, true, lVar);
        }
    }
}
