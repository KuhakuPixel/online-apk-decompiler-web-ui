package e0;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.Display;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewTreeObserver;
import android.view.WindowInsets;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import e0.a;
import f0.c;
import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;
import java.util.concurrent.atomic.AtomicInteger;
/* loaded from: classes.dex */
public class q {

    /* renamed from: c  reason: collision with root package name */
    private static Field f4304c;

    /* renamed from: e  reason: collision with root package name */
    private static ThreadLocal<Rect> f4306e;

    /* renamed from: a  reason: collision with root package name */
    private static final AtomicInteger f4302a = new AtomicInteger(1);

    /* renamed from: b  reason: collision with root package name */
    private static WeakHashMap<View, u> f4303b = null;

    /* renamed from: d  reason: collision with root package name */
    private static boolean f4305d = false;

    /* renamed from: f  reason: collision with root package name */
    private static final int[] f4307f = {s.b.accessibility_custom_action_0, s.b.accessibility_custom_action_1, s.b.accessibility_custom_action_2, s.b.accessibility_custom_action_3, s.b.accessibility_custom_action_4, s.b.accessibility_custom_action_5, s.b.accessibility_custom_action_6, s.b.accessibility_custom_action_7, s.b.accessibility_custom_action_8, s.b.accessibility_custom_action_9, s.b.accessibility_custom_action_10, s.b.accessibility_custom_action_11, s.b.accessibility_custom_action_12, s.b.accessibility_custom_action_13, s.b.accessibility_custom_action_14, s.b.accessibility_custom_action_15, s.b.accessibility_custom_action_16, s.b.accessibility_custom_action_17, s.b.accessibility_custom_action_18, s.b.accessibility_custom_action_19, s.b.accessibility_custom_action_20, s.b.accessibility_custom_action_21, s.b.accessibility_custom_action_22, s.b.accessibility_custom_action_23, s.b.accessibility_custom_action_24, s.b.accessibility_custom_action_25, s.b.accessibility_custom_action_26, s.b.accessibility_custom_action_27, s.b.accessibility_custom_action_28, s.b.accessibility_custom_action_29, s.b.accessibility_custom_action_30, s.b.accessibility_custom_action_31};

    /* renamed from: g  reason: collision with root package name */
    private static e f4308g = new e();

    /* loaded from: classes.dex */
    class a implements View.OnApplyWindowInsetsListener {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ o f4309a;

        a(o oVar) {
            this.f4309a = oVar;
        }

        @Override // android.view.View.OnApplyWindowInsetsListener
        public WindowInsets onApplyWindowInsets(View view, WindowInsets windowInsets) {
            return this.f4309a.a(view, y.o(windowInsets)).n();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public class b extends f<Boolean> {
        b(int i2, Class cls, int i3) {
            super(i2, cls, i3);
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        @Override // e0.q.f
        /* renamed from: i  reason: merged with bridge method [inline-methods] */
        public Boolean d(View view) {
            return Boolean.valueOf(view.isScreenReaderFocusable());
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        @Override // e0.q.f
        /* renamed from: j  reason: merged with bridge method [inline-methods] */
        public void e(View view, Boolean bool) {
            view.setScreenReaderFocusable(bool.booleanValue());
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        @Override // e0.q.f
        /* renamed from: k  reason: merged with bridge method [inline-methods] */
        public boolean h(Boolean bool, Boolean bool2) {
            return !a(bool, bool2);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public class c extends f<CharSequence> {
        c(int i2, Class cls, int i3, int i4) {
            super(i2, cls, i3, i4);
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        @Override // e0.q.f
        /* renamed from: i  reason: merged with bridge method [inline-methods] */
        public CharSequence d(View view) {
            return view.getAccessibilityPaneTitle();
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        @Override // e0.q.f
        /* renamed from: j  reason: merged with bridge method [inline-methods] */
        public void e(View view, CharSequence charSequence) {
            view.setAccessibilityPaneTitle(charSequence);
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        @Override // e0.q.f
        /* renamed from: k  reason: merged with bridge method [inline-methods] */
        public boolean h(CharSequence charSequence, CharSequence charSequence2) {
            return !TextUtils.equals(charSequence, charSequence2);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public class d extends f<Boolean> {
        d(int i2, Class cls, int i3) {
            super(i2, cls, i3);
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        @Override // e0.q.f
        /* renamed from: i  reason: merged with bridge method [inline-methods] */
        public Boolean d(View view) {
            return Boolean.valueOf(view.isAccessibilityHeading());
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        @Override // e0.q.f
        /* renamed from: j  reason: merged with bridge method [inline-methods] */
        public void e(View view, Boolean bool) {
            view.setAccessibilityHeading(bool.booleanValue());
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        @Override // e0.q.f
        /* renamed from: k  reason: merged with bridge method [inline-methods] */
        public boolean h(Boolean bool, Boolean bool2) {
            return !a(bool, bool2);
        }
    }

    /* loaded from: classes.dex */
    static class e implements ViewTreeObserver.OnGlobalLayoutListener, View.OnAttachStateChangeListener {

        /* renamed from: b  reason: collision with root package name */
        private WeakHashMap<View, Boolean> f4310b = new WeakHashMap<>();

        e() {
        }

        private void a(View view, boolean z2) {
            boolean z3 = view.getVisibility() == 0;
            if (z2 != z3) {
                if (z3) {
                    q.U(view, 16);
                }
                this.f4310b.put(view, Boolean.valueOf(z3));
            }
        }

        private void b(View view) {
            view.getViewTreeObserver().addOnGlobalLayoutListener(this);
        }

        @Override // android.view.ViewTreeObserver.OnGlobalLayoutListener
        public void onGlobalLayout() {
            for (Map.Entry<View, Boolean> entry : this.f4310b.entrySet()) {
                a(entry.getKey(), entry.getValue().booleanValue());
            }
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewAttachedToWindow(View view) {
            b(view);
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewDetachedFromWindow(View view) {
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public static abstract class f<T> {

        /* renamed from: a  reason: collision with root package name */
        private final int f4311a;

        /* renamed from: b  reason: collision with root package name */
        private final Class<T> f4312b;

        /* renamed from: c  reason: collision with root package name */
        private final int f4313c;

        f(int i2, Class<T> cls, int i3) {
            this(i2, cls, 0, i3);
        }

        f(int i2, Class<T> cls, int i3, int i4) {
            this.f4311a = i2;
            this.f4312b = cls;
            this.f4313c = i4;
        }

        private boolean b() {
            return true;
        }

        private boolean c() {
            return Build.VERSION.SDK_INT >= this.f4313c;
        }

        boolean a(Boolean bool, Boolean bool2) {
            return (bool == null ? false : bool.booleanValue()) == (bool2 == null ? false : bool2.booleanValue());
        }

        abstract T d(View view);

        abstract void e(View view, T t2);

        T f(View view) {
            if (c()) {
                return d(view);
            }
            if (b()) {
                T t2 = (T) view.getTag(this.f4311a);
                if (this.f4312b.isInstance(t2)) {
                    return t2;
                }
                return null;
            }
            return null;
        }

        void g(View view, T t2) {
            if (c()) {
                e(view, t2);
            } else if (b() && h(f(view), t2)) {
                q.E(view);
                view.setTag(this.f4311a, t2);
                q.U(view, 0);
            }
        }

        abstract boolean h(T t2, T t3);
    }

    /* loaded from: classes.dex */
    private static class g {
        static y a(View view, y yVar, Rect rect) {
            WindowInsets n2 = yVar.n();
            if (n2 != null) {
                return y.o(view.computeSystemWindowInsets(n2, rect));
            }
            rect.setEmpty();
            return yVar;
        }
    }

    /* loaded from: classes.dex */
    private static class h {
        public static WindowInsets a(View view) {
            return view.getRootWindowInsets();
        }
    }

    /* loaded from: classes.dex */
    private static class i {
        static void a(View view, Context context, int[] iArr, AttributeSet attributeSet, TypedArray typedArray, int i2, int i3) {
            view.saveAttributeDataForStyleable(context, iArr, attributeSet, typedArray, i2, i3);
        }
    }

    /* loaded from: classes.dex */
    public interface j {
        boolean a(View view, KeyEvent keyEvent);
    }

    /* loaded from: classes.dex */
    static class k {

        /* renamed from: d  reason: collision with root package name */
        private static final ArrayList<WeakReference<View>> f4314d = new ArrayList<>();

        /* renamed from: a  reason: collision with root package name */
        private WeakHashMap<View, Boolean> f4315a = null;

        /* renamed from: b  reason: collision with root package name */
        private SparseArray<WeakReference<View>> f4316b = null;

        /* renamed from: c  reason: collision with root package name */
        private WeakReference<KeyEvent> f4317c = null;

        k() {
        }

        static k a(View view) {
            int i2 = s.b.tag_unhandled_key_event_manager;
            k kVar = (k) view.getTag(i2);
            if (kVar == null) {
                k kVar2 = new k();
                view.setTag(i2, kVar2);
                return kVar2;
            }
            return kVar;
        }

        private View c(View view, KeyEvent keyEvent) {
            WeakHashMap<View, Boolean> weakHashMap = this.f4315a;
            if (weakHashMap != null && weakHashMap.containsKey(view)) {
                if (view instanceof ViewGroup) {
                    ViewGroup viewGroup = (ViewGroup) view;
                    for (int childCount = viewGroup.getChildCount() - 1; childCount >= 0; childCount--) {
                        View c2 = c(viewGroup.getChildAt(childCount), keyEvent);
                        if (c2 != null) {
                            return c2;
                        }
                    }
                }
                if (e(view, keyEvent)) {
                    return view;
                }
            }
            return null;
        }

        private SparseArray<WeakReference<View>> d() {
            if (this.f4316b == null) {
                this.f4316b = new SparseArray<>();
            }
            return this.f4316b;
        }

        private boolean e(View view, KeyEvent keyEvent) {
            ArrayList arrayList = (ArrayList) view.getTag(s.b.tag_unhandled_key_listeners);
            if (arrayList != null) {
                for (int size = arrayList.size() - 1; size >= 0; size--) {
                    if (((j) arrayList.get(size)).a(view, keyEvent)) {
                        return true;
                    }
                }
                return false;
            }
            return false;
        }

        private void g() {
            WeakHashMap<View, Boolean> weakHashMap = this.f4315a;
            if (weakHashMap != null) {
                weakHashMap.clear();
            }
            ArrayList<WeakReference<View>> arrayList = f4314d;
            if (arrayList.isEmpty()) {
                return;
            }
            synchronized (arrayList) {
                if (this.f4315a == null) {
                    this.f4315a = new WeakHashMap<>();
                }
                for (int size = arrayList.size() - 1; size >= 0; size--) {
                    ArrayList<WeakReference<View>> arrayList2 = f4314d;
                    View view = arrayList2.get(size).get();
                    if (view == null) {
                        arrayList2.remove(size);
                    } else {
                        this.f4315a.put(view, Boolean.TRUE);
                        for (ViewParent parent = view.getParent(); parent instanceof View; parent = parent.getParent()) {
                            this.f4315a.put((View) parent, Boolean.TRUE);
                        }
                    }
                }
            }
        }

        boolean b(View view, KeyEvent keyEvent) {
            if (keyEvent.getAction() == 0) {
                g();
            }
            View c2 = c(view, keyEvent);
            if (keyEvent.getAction() == 0) {
                int keyCode = keyEvent.getKeyCode();
                if (c2 != null && !KeyEvent.isModifierKey(keyCode)) {
                    d().put(keyCode, new WeakReference<>(c2));
                }
            }
            return c2 != null;
        }

        boolean f(KeyEvent keyEvent) {
            int indexOfKey;
            WeakReference<KeyEvent> weakReference = this.f4317c;
            if (weakReference == null || weakReference.get() != keyEvent) {
                this.f4317c = new WeakReference<>(keyEvent);
                WeakReference<View> weakReference2 = null;
                SparseArray<WeakReference<View>> d2 = d();
                if (keyEvent.getAction() == 1 && (indexOfKey = d2.indexOfKey(keyEvent.getKeyCode())) >= 0) {
                    weakReference2 = d2.valueAt(indexOfKey);
                    d2.removeAt(indexOfKey);
                }
                if (weakReference2 == null) {
                    weakReference2 = d2.get(keyEvent.getKeyCode());
                }
                if (weakReference2 != null) {
                    View view = weakReference2.get();
                    if (view != null && q.P(view)) {
                        e(view, keyEvent);
                    }
                    return true;
                }
                return false;
            }
            return false;
        }
    }

    @SuppressLint({"InlinedApi"})
    public static int A(View view) {
        if (Build.VERSION.SDK_INT >= 26) {
            return view.getImportantForAutofill();
        }
        return 0;
    }

    public static void A0(View view) {
        view.stopNestedScroll();
    }

    public static int B(View view) {
        return view.getLayoutDirection();
    }

    private static void B0(View view) {
        float translationY = view.getTranslationY();
        view.setTranslationY(1.0f + translationY);
        view.setTranslationY(translationY);
    }

    public static int C(View view) {
        return view.getMinimumHeight();
    }

    public static int D(View view) {
        return view.getMinimumWidth();
    }

    static e0.a E(View view) {
        e0.a l2 = l(view);
        if (l2 == null) {
            l2 = new e0.a();
        }
        k0(view, l2);
        return l2;
    }

    public static int F(View view) {
        return view.getPaddingEnd();
    }

    public static int G(View view) {
        return view.getPaddingStart();
    }

    public static y H(View view) {
        if (Build.VERSION.SDK_INT >= 23) {
            return y.o(h.a(view));
        }
        return null;
    }

    public static String I(View view) {
        return view.getTransitionName();
    }

    public static int J(View view) {
        return view.getWindowSystemUiVisibility();
    }

    public static float K(View view) {
        return view.getZ();
    }

    public static boolean L(View view) {
        return view.hasOnClickListeners();
    }

    public static boolean M(View view) {
        return view.hasOverlappingRendering();
    }

    public static boolean N(View view) {
        return view.hasTransientState();
    }

    public static boolean O(View view) {
        Boolean f2 = a().f(view);
        if (f2 == null) {
            return false;
        }
        return f2.booleanValue();
    }

    public static boolean P(View view) {
        return view.isAttachedToWindow();
    }

    public static boolean Q(View view) {
        return view.isLaidOut();
    }

    public static boolean R(View view) {
        return view.isNestedScrollingEnabled();
    }

    public static boolean S(View view) {
        return view.isPaddingRelative();
    }

    public static boolean T(View view) {
        Boolean f2 = j0().f(view);
        if (f2 == null) {
            return false;
        }
        return f2.booleanValue();
    }

    static void U(View view, int i2) {
        if (((AccessibilityManager) view.getContext().getSystemService("accessibility")).isEnabled()) {
            boolean z2 = p(view) != null;
            if (o(view) != 0 || (z2 && view.getVisibility() == 0)) {
                AccessibilityEvent obtain = AccessibilityEvent.obtain();
                obtain.setEventType(z2 ? 32 : 2048);
                obtain.setContentChangeTypes(i2);
                view.sendAccessibilityEventUnchecked(obtain);
            } else if (view.getParent() != null) {
                try {
                    view.getParent().notifySubtreeAccessibilityStateChanged(view, view, i2);
                } catch (AbstractMethodError e2) {
                    Log.e("ViewCompat", view.getParent().getClass().getSimpleName() + " does not fully implement ViewParent", e2);
                }
            }
        }
    }

    public static void V(View view, int i2) {
        if (Build.VERSION.SDK_INT >= 23) {
            view.offsetLeftAndRight(i2);
            return;
        }
        Rect x2 = x();
        boolean z2 = false;
        ViewParent parent = view.getParent();
        if (parent instanceof View) {
            View view2 = (View) parent;
            x2.set(view2.getLeft(), view2.getTop(), view2.getRight(), view2.getBottom());
            z2 = !x2.intersects(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
        }
        e(view, i2);
        if (z2 && x2.intersect(view.getLeft(), view.getTop(), view.getRight(), view.getBottom())) {
            ((View) parent).invalidate(x2);
        }
    }

    public static void W(View view, int i2) {
        if (Build.VERSION.SDK_INT >= 23) {
            view.offsetTopAndBottom(i2);
            return;
        }
        Rect x2 = x();
        boolean z2 = false;
        ViewParent parent = view.getParent();
        if (parent instanceof View) {
            View view2 = (View) parent;
            x2.set(view2.getLeft(), view2.getTop(), view2.getRight(), view2.getBottom());
            z2 = !x2.intersects(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
        }
        f(view, i2);
        if (z2 && x2.intersect(view.getLeft(), view.getTop(), view.getRight(), view.getBottom())) {
            ((View) parent).invalidate(x2);
        }
    }

    public static y X(View view, y yVar) {
        WindowInsets n2 = yVar.n();
        if (n2 != null) {
            WindowInsets onApplyWindowInsets = view.onApplyWindowInsets(n2);
            if (!onApplyWindowInsets.equals(n2)) {
                return y.o(onApplyWindowInsets);
            }
        }
        return yVar;
    }

    public static void Y(View view, f0.c cVar) {
        view.onInitializeAccessibilityNodeInfo(cVar.u0());
    }

    private static f<CharSequence> Z() {
        return new c(s.b.tag_accessibility_pane_title, CharSequence.class, 8, 28);
    }

    private static f<Boolean> a() {
        return new d(s.b.tag_accessibility_heading, Boolean.class, 28);
    }

    public static boolean a0(View view, int i2, Bundle bundle) {
        return view.performAccessibilityAction(i2, bundle);
    }

    public static int b(View view, CharSequence charSequence, f0.f fVar) {
        int r2 = r(view);
        if (r2 != -1) {
            c(view, new c.a(r2, charSequence, fVar));
        }
        return r2;
    }

    public static void b0(View view) {
        view.postInvalidateOnAnimation();
    }

    private static void c(View view, c.a aVar) {
        E(view);
        f0(aVar.b(), view);
        q(view).add(aVar);
        U(view, 0);
    }

    public static void c0(View view, Runnable runnable) {
        view.postOnAnimation(runnable);
    }

    public static u d(View view) {
        if (f4303b == null) {
            f4303b = new WeakHashMap<>();
        }
        u uVar = f4303b.get(view);
        if (uVar == null) {
            u uVar2 = new u(view);
            f4303b.put(view, uVar2);
            return uVar2;
        }
        return uVar;
    }

    public static void d0(View view, Runnable runnable, long j2) {
        view.postOnAnimationDelayed(runnable, j2);
    }

    private static void e(View view, int i2) {
        view.offsetLeftAndRight(i2);
        if (view.getVisibility() == 0) {
            B0(view);
            ViewParent parent = view.getParent();
            if (parent instanceof View) {
                B0((View) parent);
            }
        }
    }

    public static void e0(View view, int i2) {
        f0(i2, view);
        U(view, 0);
    }

    private static void f(View view, int i2) {
        view.offsetTopAndBottom(i2);
        if (view.getVisibility() == 0) {
            B0(view);
            ViewParent parent = view.getParent();
            if (parent instanceof View) {
                B0((View) parent);
            }
        }
    }

    private static void f0(int i2, View view) {
        List<c.a> q2 = q(view);
        for (int i3 = 0; i3 < q2.size(); i3++) {
            if (q2.get(i3).b() == i2) {
                q2.remove(i3);
                return;
            }
        }
    }

    public static y g(View view, y yVar, Rect rect) {
        return g.a(view, yVar, rect);
    }

    public static void g0(View view, c.a aVar, CharSequence charSequence, f0.f fVar) {
        if (fVar == null && charSequence == null) {
            e0(view, aVar.b());
        } else {
            c(view, aVar.a(charSequence, fVar));
        }
    }

    public static y h(View view, y yVar) {
        WindowInsets n2 = yVar.n();
        return (n2 == null || view.dispatchApplyWindowInsets(n2).equals(n2)) ? yVar : y.o(n2);
    }

    public static void h0(View view) {
        view.requestApplyInsets();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static boolean i(View view, KeyEvent keyEvent) {
        if (Build.VERSION.SDK_INT >= 28) {
            return false;
        }
        return k.a(view).b(view, keyEvent);
    }

    public static void i0(View view, @SuppressLint({"ContextFirst"}) Context context, int[] iArr, AttributeSet attributeSet, TypedArray typedArray, int i2, int i3) {
        if (Build.VERSION.SDK_INT >= 29) {
            i.a(view, context, iArr, attributeSet, typedArray, i2, i3);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static boolean j(View view, KeyEvent keyEvent) {
        if (Build.VERSION.SDK_INT >= 28) {
            return false;
        }
        return k.a(view).f(keyEvent);
    }

    private static f<Boolean> j0() {
        return new b(s.b.tag_screen_reader_focusable, Boolean.class, 28);
    }

    public static int k() {
        return View.generateViewId();
    }

    public static void k0(View view, e0.a aVar) {
        if (aVar == null && (m(view) instanceof a.C0051a)) {
            aVar = new e0.a();
        }
        view.setAccessibilityDelegate(aVar == null ? null : aVar.d());
    }

    public static e0.a l(View view) {
        View.AccessibilityDelegate m2 = m(view);
        if (m2 == null) {
            return null;
        }
        return m2 instanceof a.C0051a ? ((a.C0051a) m2).f4283a : new e0.a(m2);
    }

    public static void l0(View view, boolean z2) {
        a().g(view, Boolean.valueOf(z2));
    }

    private static View.AccessibilityDelegate m(View view) {
        return Build.VERSION.SDK_INT >= 29 ? view.getAccessibilityDelegate() : n(view);
    }

    public static void m0(View view, int i2) {
        view.setAccessibilityLiveRegion(i2);
    }

    private static View.AccessibilityDelegate n(View view) {
        if (f4305d) {
            return null;
        }
        if (f4304c == null) {
            try {
                Field declaredField = View.class.getDeclaredField("mAccessibilityDelegate");
                f4304c = declaredField;
                declaredField.setAccessible(true);
            } catch (Throwable unused) {
                f4305d = true;
                return null;
            }
        }
        try {
            Object obj = f4304c.get(view);
            if (obj instanceof View.AccessibilityDelegate) {
                return (View.AccessibilityDelegate) obj;
            }
            return null;
        } catch (Throwable unused2) {
            f4305d = true;
            return null;
        }
    }

    public static void n0(View view, Drawable drawable) {
        view.setBackground(drawable);
    }

    public static int o(View view) {
        return view.getAccessibilityLiveRegion();
    }

    public static void o0(View view, ColorStateList colorStateList) {
        int i2 = Build.VERSION.SDK_INT;
        view.setBackgroundTintList(colorStateList);
        if (i2 == 21) {
            Drawable background = view.getBackground();
            boolean z2 = (view.getBackgroundTintList() == null && view.getBackgroundTintMode() == null) ? false : true;
            if (background == null || !z2) {
                return;
            }
            if (background.isStateful()) {
                background.setState(view.getDrawableState());
            }
            view.setBackground(background);
        }
    }

    public static CharSequence p(View view) {
        return Z().f(view);
    }

    public static void p0(View view, PorterDuff.Mode mode) {
        int i2 = Build.VERSION.SDK_INT;
        view.setBackgroundTintMode(mode);
        if (i2 == 21) {
            Drawable background = view.getBackground();
            boolean z2 = (view.getBackgroundTintList() == null && view.getBackgroundTintMode() == null) ? false : true;
            if (background == null || !z2) {
                return;
            }
            if (background.isStateful()) {
                background.setState(view.getDrawableState());
            }
            view.setBackground(background);
        }
    }

    private static List<c.a> q(View view) {
        int i2 = s.b.tag_accessibility_actions;
        ArrayList arrayList = (ArrayList) view.getTag(i2);
        if (arrayList == null) {
            ArrayList arrayList2 = new ArrayList();
            view.setTag(i2, arrayList2);
            return arrayList2;
        }
        return arrayList;
    }

    public static void q0(View view, Rect rect) {
        view.setClipBounds(rect);
    }

    private static int r(View view) {
        List<c.a> q2 = q(view);
        int i2 = 0;
        int i3 = -1;
        while (true) {
            int[] iArr = f4307f;
            if (i2 >= iArr.length || i3 != -1) {
                break;
            }
            int i4 = iArr[i2];
            boolean z2 = true;
            for (int i5 = 0; i5 < q2.size(); i5++) {
                z2 &= q2.get(i5).b() != i4;
            }
            if (z2) {
                i3 = i4;
            }
            i2++;
        }
        return i3;
    }

    public static void r0(View view, float f2) {
        view.setElevation(f2);
    }

    public static ColorStateList s(View view) {
        return view.getBackgroundTintList();
    }

    @Deprecated
    public static void s0(View view, boolean z2) {
        view.setFitsSystemWindows(z2);
    }

    public static PorterDuff.Mode t(View view) {
        return view.getBackgroundTintMode();
    }

    public static void t0(View view, boolean z2) {
        view.setHasTransientState(z2);
    }

    public static Rect u(View view) {
        return view.getClipBounds();
    }

    public static void u0(View view, int i2) {
        view.setImportantForAccessibility(i2);
    }

    public static Display v(View view) {
        return view.getDisplay();
    }

    public static void v0(View view, int i2) {
        if (Build.VERSION.SDK_INT >= 26) {
            view.setImportantForAutofill(i2);
        }
    }

    public static float w(View view) {
        return view.getElevation();
    }

    public static void w0(View view, o oVar) {
        if (oVar == null) {
            view.setOnApplyWindowInsetsListener(null);
        } else {
            view.setOnApplyWindowInsetsListener(new a(oVar));
        }
    }

    private static Rect x() {
        if (f4306e == null) {
            f4306e = new ThreadLocal<>();
        }
        Rect rect = f4306e.get();
        if (rect == null) {
            rect = new Rect();
            f4306e.set(rect);
        }
        rect.setEmpty();
        return rect;
    }

    public static void x0(View view, int i2, int i3, int i4, int i5) {
        view.setPaddingRelative(i2, i3, i4, i5);
    }

    public static boolean y(View view) {
        return view.getFitsSystemWindows();
    }

    public static void y0(View view, int i2, int i3) {
        if (Build.VERSION.SDK_INT >= 23) {
            view.setScrollIndicators(i2, i3);
        }
    }

    public static int z(View view) {
        return view.getImportantForAccessibility();
    }

    public static void z0(View view, String str) {
        view.setTransitionName(str);
    }
}
