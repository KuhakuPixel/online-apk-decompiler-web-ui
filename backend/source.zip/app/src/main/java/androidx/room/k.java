package androidx.room;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import androidx.room.j;
/* loaded from: classes.dex */
public interface k extends IInterface {

    /* loaded from: classes.dex */
    public static abstract class a extends Binder implements k {

        /* JADX INFO: Access modifiers changed from: private */
        /* renamed from: androidx.room.k$a$a  reason: collision with other inner class name */
        /* loaded from: classes.dex */
        public static class C0021a implements k {

            /* renamed from: b  reason: collision with root package name */
            public static k f2628b;

            /* renamed from: a  reason: collision with root package name */
            private IBinder f2629a;

            C0021a(IBinder iBinder) {
                this.f2629a = iBinder;
            }

            @Override // androidx.room.k
            public int a(j jVar, String str) {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("androidx.room.IMultiInstanceInvalidationService");
                    obtain.writeStrongBinder(jVar != null ? jVar.asBinder() : null);
                    obtain.writeString(str);
                    if (this.f2629a.transact(1, obtain, obtain2, 0) || a.q() == null) {
                        obtain2.readException();
                        return obtain2.readInt();
                    }
                    return a.q().a(jVar, str);
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            @Override // android.os.IInterface
            public IBinder asBinder() {
                return this.f2629a;
            }

            @Override // androidx.room.k
            public void k(int i2, String[] strArr) {
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("androidx.room.IMultiInstanceInvalidationService");
                    obtain.writeInt(i2);
                    obtain.writeStringArray(strArr);
                    if (this.f2629a.transact(3, obtain, null, 1) || a.q() == null) {
                        return;
                    }
                    a.q().k(i2, strArr);
                } finally {
                    obtain.recycle();
                }
            }
        }

        public a() {
            attachInterface(this, "androidx.room.IMultiInstanceInvalidationService");
        }

        public static k p(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface queryLocalInterface = iBinder.queryLocalInterface("androidx.room.IMultiInstanceInvalidationService");
            return (queryLocalInterface == null || !(queryLocalInterface instanceof k)) ? new C0021a(iBinder) : (k) queryLocalInterface;
        }

        public static k q() {
            return C0021a.f2628b;
        }

        @Override // android.os.IInterface
        public IBinder asBinder() {
            return this;
        }

        @Override // android.os.Binder
        public boolean onTransact(int i2, Parcel parcel, Parcel parcel2, int i3) {
            if (i2 == 1) {
                parcel.enforceInterface("androidx.room.IMultiInstanceInvalidationService");
                int a2 = a(j.a.p(parcel.readStrongBinder()), parcel.readString());
                parcel2.writeNoException();
                parcel2.writeInt(a2);
                return true;
            } else if (i2 == 2) {
                parcel.enforceInterface("androidx.room.IMultiInstanceInvalidationService");
                n(j.a.p(parcel.readStrongBinder()), parcel.readInt());
                parcel2.writeNoException();
                return true;
            } else if (i2 == 3) {
                parcel.enforceInterface("androidx.room.IMultiInstanceInvalidationService");
                k(parcel.readInt(), parcel.createStringArray());
                return true;
            } else if (i2 != 1598968902) {
                return super.onTransact(i2, parcel, parcel2, i3);
            } else {
                parcel2.writeString("androidx.room.IMultiInstanceInvalidationService");
                return true;
            }
        }
    }

    int a(j jVar, String str);

    void k(int i2, String[] strArr);

    void n(j jVar, int i2);
}
