package androidx.room;

import android.annotation.SuppressLint;
import android.content.Context;
import androidx.room.e0;
import java.io.File;
import java.io.InputStream;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.Executor;
import u0.c;
/* loaded from: classes.dex */
public class h {

    /* renamed from: a  reason: collision with root package name */
    public final c.InterfaceC0072c f2592a;

    /* renamed from: b  reason: collision with root package name */
    public final Context f2593b;

    /* renamed from: c  reason: collision with root package name */
    public final String f2594c;

    /* renamed from: d  reason: collision with root package name */
    public final e0.d f2595d;

    /* renamed from: e  reason: collision with root package name */
    public final List<e0.b> f2596e;

    /* renamed from: f  reason: collision with root package name */
    public final List<Object> f2597f;

    /* renamed from: g  reason: collision with root package name */
    public final boolean f2598g;

    /* renamed from: h  reason: collision with root package name */
    public final e0.c f2599h;

    /* renamed from: i  reason: collision with root package name */
    public final Executor f2600i;

    /* renamed from: j  reason: collision with root package name */
    public final Executor f2601j;

    /* renamed from: k  reason: collision with root package name */
    public final boolean f2602k;

    /* renamed from: l  reason: collision with root package name */
    public final boolean f2603l;

    /* renamed from: m  reason: collision with root package name */
    public final boolean f2604m;

    /* renamed from: n  reason: collision with root package name */
    private final Set<Integer> f2605n;

    /* renamed from: o  reason: collision with root package name */
    public final String f2606o;

    /* renamed from: p  reason: collision with root package name */
    public final File f2607p;

    /* renamed from: q  reason: collision with root package name */
    public final Callable<InputStream> f2608q;

    @SuppressLint({"LambdaLast"})
    public h(Context context, String str, c.InterfaceC0072c interfaceC0072c, e0.d dVar, List<e0.b> list, boolean z2, e0.c cVar, Executor executor, Executor executor2, boolean z3, boolean z4, boolean z5, Set<Integer> set, String str2, File file, Callable<InputStream> callable, e0.e eVar, List<Object> list2) {
        this.f2592a = interfaceC0072c;
        this.f2593b = context;
        this.f2594c = str;
        this.f2595d = dVar;
        this.f2596e = list;
        this.f2598g = z2;
        this.f2599h = cVar;
        this.f2600i = executor;
        this.f2601j = executor2;
        this.f2602k = z3;
        this.f2603l = z4;
        this.f2604m = z5;
        this.f2605n = set;
        this.f2606o = str2;
        this.f2607p = file;
        this.f2608q = callable;
        this.f2597f = list2 == null ? Collections.emptyList() : list2;
    }

    public boolean a(int i2, int i3) {
        Set<Integer> set;
        return !((i2 > i3) && this.f2604m) && this.f2603l && ((set = this.f2605n) == null || !set.contains(Integer.valueOf(i2)));
    }
}
