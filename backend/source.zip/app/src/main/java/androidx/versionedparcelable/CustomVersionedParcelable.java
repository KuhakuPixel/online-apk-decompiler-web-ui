package androidx.versionedparcelable;
/* loaded from: classes.dex */
public abstract class CustomVersionedParcelable implements x0.a {
}
