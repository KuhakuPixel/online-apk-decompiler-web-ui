package a0;

import android.os.CancellationSignal;
/* loaded from: classes.dex */
public final class a {

    /* renamed from: a  reason: collision with root package name */
    private boolean f93a;

    /* renamed from: b  reason: collision with root package name */
    private InterfaceC0000a f94b;

    /* renamed from: c  reason: collision with root package name */
    private Object f95c;

    /* renamed from: d  reason: collision with root package name */
    private boolean f96d;

    /* renamed from: a0.a$a  reason: collision with other inner class name */
    /* loaded from: classes.dex */
    public interface InterfaceC0000a {
        void a();
    }

    private void d() {
        while (this.f96d) {
            try {
                wait();
            } catch (InterruptedException unused) {
            }
        }
    }

    public void a() {
        synchronized (this) {
            if (this.f93a) {
                return;
            }
            this.f93a = true;
            this.f96d = true;
            InterfaceC0000a interfaceC0000a = this.f94b;
            Object obj = this.f95c;
            if (interfaceC0000a != null) {
                try {
                    interfaceC0000a.a();
                } catch (Throwable th) {
                    synchronized (this) {
                        this.f96d = false;
                        notifyAll();
                        throw th;
                    }
                }
            }
            if (obj != null) {
                ((CancellationSignal) obj).cancel();
            }
            synchronized (this) {
                this.f96d = false;
                notifyAll();
            }
        }
    }

    public boolean b() {
        boolean z2;
        synchronized (this) {
            z2 = this.f93a;
        }
        return z2;
    }

    public void c(InterfaceC0000a interfaceC0000a) {
        synchronized (this) {
            d();
            if (this.f94b == interfaceC0000a) {
                return;
            }
            this.f94b = interfaceC0000a;
            if (this.f93a && interfaceC0000a != null) {
                interfaceC0000a.a();
            }
        }
    }
}
