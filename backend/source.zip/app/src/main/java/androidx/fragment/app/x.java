package androidx.fragment.app;

import android.util.AndroidRuntimeException;
/* loaded from: classes.dex */
final class x extends AndroidRuntimeException {
    public x(String str) {
        super(str);
    }
}
