package androidx.recyclerview.widget;

import android.view.View;
import android.view.ViewGroup;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes.dex */
public class b {

    /* renamed from: a  reason: collision with root package name */
    final InterfaceC0016b f2339a;

    /* renamed from: b  reason: collision with root package name */
    final a f2340b = new a();

    /* renamed from: c  reason: collision with root package name */
    final List<View> f2341c = new ArrayList();

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public static class a {

        /* renamed from: a  reason: collision with root package name */
        long f2342a = 0;

        /* renamed from: b  reason: collision with root package name */
        a f2343b;

        a() {
        }

        private void c() {
            if (this.f2343b == null) {
                this.f2343b = new a();
            }
        }

        void a(int i2) {
            if (i2 < 64) {
                this.f2342a &= ~(1 << i2);
                return;
            }
            a aVar = this.f2343b;
            if (aVar != null) {
                aVar.a(i2 - 64);
            }
        }

        int b(int i2) {
            a aVar = this.f2343b;
            return aVar == null ? i2 >= 64 ? Long.bitCount(this.f2342a) : Long.bitCount(this.f2342a & ((1 << i2) - 1)) : i2 < 64 ? Long.bitCount(this.f2342a & ((1 << i2) - 1)) : aVar.b(i2 - 64) + Long.bitCount(this.f2342a);
        }

        boolean d(int i2) {
            if (i2 < 64) {
                return (this.f2342a & (1 << i2)) != 0;
            }
            c();
            return this.f2343b.d(i2 - 64);
        }

        void e(int i2, boolean z2) {
            if (i2 >= 64) {
                c();
                this.f2343b.e(i2 - 64, z2);
                return;
            }
            long j2 = this.f2342a;
            boolean z3 = (Long.MIN_VALUE & j2) != 0;
            long j3 = (1 << i2) - 1;
            this.f2342a = ((j2 & (~j3)) << 1) | (j2 & j3);
            if (z2) {
                h(i2);
            } else {
                a(i2);
            }
            if (z3 || this.f2343b != null) {
                c();
                this.f2343b.e(0, z3);
            }
        }

        boolean f(int i2) {
            if (i2 >= 64) {
                c();
                return this.f2343b.f(i2 - 64);
            }
            long j2 = 1 << i2;
            long j3 = this.f2342a;
            boolean z2 = (j3 & j2) != 0;
            long j4 = j3 & (~j2);
            this.f2342a = j4;
            long j5 = j2 - 1;
            this.f2342a = (j4 & j5) | Long.rotateRight((~j5) & j4, 1);
            a aVar = this.f2343b;
            if (aVar != null) {
                if (aVar.d(0)) {
                    h(63);
                }
                this.f2343b.f(0);
            }
            return z2;
        }

        void g() {
            this.f2342a = 0L;
            a aVar = this.f2343b;
            if (aVar != null) {
                aVar.g();
            }
        }

        void h(int i2) {
            if (i2 < 64) {
                this.f2342a |= 1 << i2;
                return;
            }
            c();
            this.f2343b.h(i2 - 64);
        }

        public String toString() {
            if (this.f2343b == null) {
                return Long.toBinaryString(this.f2342a);
            }
            return this.f2343b.toString() + "xx" + Long.toBinaryString(this.f2342a);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: androidx.recyclerview.widget.b$b  reason: collision with other inner class name */
    /* loaded from: classes.dex */
    public interface InterfaceC0016b {
        View a(int i2);

        void b(View view);

        void c(int i2);

        void d();

        RecyclerView.d0 e(View view);

        void f(int i2);

        void g(View view);

        void h(View view, int i2, ViewGroup.LayoutParams layoutParams);

        void i(View view, int i2);

        int j(View view);

        int k();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public b(InterfaceC0016b interfaceC0016b) {
        this.f2339a = interfaceC0016b;
    }

    private int h(int i2) {
        if (i2 < 0) {
            return -1;
        }
        int k2 = this.f2339a.k();
        int i3 = i2;
        while (i3 < k2) {
            int b2 = i2 - (i3 - this.f2340b.b(i3));
            if (b2 == 0) {
                while (this.f2340b.d(i3)) {
                    i3++;
                }
                return i3;
            }
            i3 += b2;
        }
        return -1;
    }

    private void l(View view) {
        this.f2341c.add(view);
        this.f2339a.b(view);
    }

    private boolean t(View view) {
        if (this.f2341c.remove(view)) {
            this.f2339a.g(view);
            return true;
        }
        return false;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void a(View view, int i2, boolean z2) {
        int k2 = i2 < 0 ? this.f2339a.k() : h(i2);
        this.f2340b.e(k2, z2);
        if (z2) {
            l(view);
        }
        this.f2339a.i(view, k2);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void b(View view, boolean z2) {
        a(view, -1, z2);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void c(View view, int i2, ViewGroup.LayoutParams layoutParams, boolean z2) {
        int k2 = i2 < 0 ? this.f2339a.k() : h(i2);
        this.f2340b.e(k2, z2);
        if (z2) {
            l(view);
        }
        this.f2339a.h(view, k2, layoutParams);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void d(int i2) {
        int h2 = h(i2);
        this.f2340b.f(h2);
        this.f2339a.f(h2);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public View e(int i2) {
        int size = this.f2341c.size();
        for (int i3 = 0; i3 < size; i3++) {
            View view = this.f2341c.get(i3);
            RecyclerView.d0 e2 = this.f2339a.e(view);
            if (e2.m() == i2 && !e2.t() && !e2.v()) {
                return view;
            }
        }
        return null;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public View f(int i2) {
        return this.f2339a.a(h(i2));
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public int g() {
        return this.f2339a.k() - this.f2341c.size();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public View i(int i2) {
        return this.f2339a.a(i2);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public int j() {
        return this.f2339a.k();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void k(View view) {
        int j2 = this.f2339a.j(view);
        if (j2 >= 0) {
            this.f2340b.h(j2);
            l(view);
            return;
        }
        throw new IllegalArgumentException("view is not a child, cannot hide " + view);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public int m(View view) {
        int j2 = this.f2339a.j(view);
        if (j2 == -1 || this.f2340b.d(j2)) {
            return -1;
        }
        return j2 - this.f2340b.b(j2);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public boolean n(View view) {
        return this.f2341c.contains(view);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void o() {
        this.f2340b.g();
        for (int size = this.f2341c.size() - 1; size >= 0; size--) {
            this.f2339a.g(this.f2341c.get(size));
            this.f2341c.remove(size);
        }
        this.f2339a.d();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void p(View view) {
        int j2 = this.f2339a.j(view);
        if (j2 < 0) {
            return;
        }
        if (this.f2340b.f(j2)) {
            t(view);
        }
        this.f2339a.c(j2);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void q(int i2) {
        int h2 = h(i2);
        View a2 = this.f2339a.a(h2);
        if (a2 == null) {
            return;
        }
        if (this.f2340b.f(h2)) {
            t(a2);
        }
        this.f2339a.c(h2);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public boolean r(View view) {
        int j2 = this.f2339a.j(view);
        if (j2 == -1) {
            t(view);
            return true;
        } else if (this.f2340b.d(j2)) {
            this.f2340b.f(j2);
            t(view);
            this.f2339a.c(j2);
            return true;
        } else {
            return false;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void s(View view) {
        int j2 = this.f2339a.j(view);
        if (j2 < 0) {
            throw new IllegalArgumentException("view is not a child, cannot hide " + view);
        } else if (this.f2340b.d(j2)) {
            this.f2340b.a(j2);
            t(view);
        } else {
            throw new RuntimeException("trying to unhide a view that was not hidden" + view);
        }
    }

    public String toString() {
        return this.f2340b.toString() + ", hidden list:" + this.f2341c.size();
    }
}
