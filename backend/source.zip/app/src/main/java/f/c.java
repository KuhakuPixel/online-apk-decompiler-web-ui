package f;
@Deprecated
/* loaded from: classes.dex */
public interface c {
    void c();

    void f();
}
