package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.ViewGroup;
import androidx.constraintlayout.widget.ConstraintLayout;
/* loaded from: classes.dex */
public class e extends ViewGroup {

    /* renamed from: b  reason: collision with root package name */
    d f1238b;

    /* loaded from: classes.dex */
    public static class a extends ConstraintLayout.b {
        public float A0;
        public float B0;

        /* renamed from: p0  reason: collision with root package name */
        public float f1239p0;

        /* renamed from: q0  reason: collision with root package name */
        public boolean f1240q0;

        /* renamed from: r0  reason: collision with root package name */
        public float f1241r0;

        /* renamed from: s0  reason: collision with root package name */
        public float f1242s0;

        /* renamed from: t0  reason: collision with root package name */
        public float f1243t0;

        /* renamed from: u0  reason: collision with root package name */
        public float f1244u0;

        /* renamed from: v0  reason: collision with root package name */
        public float f1245v0;

        /* renamed from: w0  reason: collision with root package name */
        public float f1246w0;

        /* renamed from: x0  reason: collision with root package name */
        public float f1247x0;

        /* renamed from: y0  reason: collision with root package name */
        public float f1248y0;

        /* renamed from: z0  reason: collision with root package name */
        public float f1249z0;

        public a(int i2, int i3) {
            super(i2, i3);
            this.f1239p0 = 1.0f;
            this.f1240q0 = false;
            this.f1241r0 = 0.0f;
            this.f1242s0 = 0.0f;
            this.f1243t0 = 0.0f;
            this.f1244u0 = 0.0f;
            this.f1245v0 = 1.0f;
            this.f1246w0 = 1.0f;
            this.f1247x0 = 0.0f;
            this.f1248y0 = 0.0f;
            this.f1249z0 = 0.0f;
            this.A0 = 0.0f;
            this.B0 = 0.0f;
        }

        public a(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.f1239p0 = 1.0f;
            this.f1240q0 = false;
            this.f1241r0 = 0.0f;
            this.f1242s0 = 0.0f;
            this.f1243t0 = 0.0f;
            this.f1244u0 = 0.0f;
            this.f1245v0 = 1.0f;
            this.f1246w0 = 1.0f;
            this.f1247x0 = 0.0f;
            this.f1248y0 = 0.0f;
            this.f1249z0 = 0.0f;
            this.A0 = 0.0f;
            this.B0 = 0.0f;
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, i.p2);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i2 = 0; i2 < indexCount; i2++) {
                int index = obtainStyledAttributes.getIndex(i2);
                if (index == i.q2) {
                    this.f1239p0 = obtainStyledAttributes.getFloat(index, this.f1239p0);
                } else if (index == i.B2) {
                    this.f1241r0 = obtainStyledAttributes.getFloat(index, this.f1241r0);
                    this.f1240q0 = true;
                } else if (index == i.y2) {
                    this.f1243t0 = obtainStyledAttributes.getFloat(index, this.f1243t0);
                } else if (index == i.z2) {
                    this.f1244u0 = obtainStyledAttributes.getFloat(index, this.f1244u0);
                } else if (index == i.x2) {
                    this.f1242s0 = obtainStyledAttributes.getFloat(index, this.f1242s0);
                } else if (index == i.v2) {
                    this.f1245v0 = obtainStyledAttributes.getFloat(index, this.f1245v0);
                } else if (index == i.w2) {
                    this.f1246w0 = obtainStyledAttributes.getFloat(index, this.f1246w0);
                } else if (index == i.r2) {
                    this.f1247x0 = obtainStyledAttributes.getFloat(index, this.f1247x0);
                } else if (index == i.s2) {
                    this.f1248y0 = obtainStyledAttributes.getFloat(index, this.f1248y0);
                } else if (index == i.t2) {
                    this.f1249z0 = obtainStyledAttributes.getFloat(index, this.f1249z0);
                } else if (index == i.u2) {
                    this.A0 = obtainStyledAttributes.getFloat(index, this.A0);
                } else if (index == i.A2) {
                    this.B0 = obtainStyledAttributes.getFloat(index, this.B0);
                }
            }
            obtainStyledAttributes.recycle();
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.view.ViewGroup
    /* renamed from: a  reason: merged with bridge method [inline-methods] */
    public a generateDefaultLayoutParams() {
        return new a(-2, -2);
    }

    @Override // android.view.ViewGroup
    /* renamed from: b  reason: merged with bridge method [inline-methods] */
    public a generateLayoutParams(AttributeSet attributeSet) {
        return new a(getContext(), attributeSet);
    }

    @Override // android.view.ViewGroup
    protected ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new ConstraintLayout.b(layoutParams);
    }

    public d getConstraintSet() {
        if (this.f1238b == null) {
            this.f1238b = new d();
        }
        this.f1238b.h(this);
        return this.f1238b;
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
    }
}
