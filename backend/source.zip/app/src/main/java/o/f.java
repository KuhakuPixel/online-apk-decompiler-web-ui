package o;
/* loaded from: classes.dex */
interface f<T> {
    boolean a(T t2);

    T b();

    void c(T[] tArr, int i2);
}
