package a;
/* loaded from: classes.dex */
public final class c {

    /* renamed from: a */
    public static final int abc_decor_view_status_guard = 2131099653;

    /* renamed from: b */
    public static final int abc_decor_view_status_guard_light = 2131099654;

    /* renamed from: c */
    public static final int abc_tint_btn_checkable = 2131099667;

    /* renamed from: d */
    public static final int abc_tint_default = 2131099668;

    /* renamed from: e */
    public static final int abc_tint_edittext = 2131099669;

    /* renamed from: f */
    public static final int abc_tint_seek_thumb = 2131099670;

    /* renamed from: g */
    public static final int abc_tint_spinner = 2131099671;

    /* renamed from: h */
    public static final int abc_tint_switch_track = 2131099672;
}
