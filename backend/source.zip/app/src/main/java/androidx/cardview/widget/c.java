package androidx.cardview.widget;

import android.content.Context;
import android.content.res.ColorStateList;
/* loaded from: classes.dex */
interface c {
    float a(b bVar);

    float b(b bVar);

    float c(b bVar);

    float d(b bVar);

    void e(b bVar);

    ColorStateList f(b bVar);

    void g(b bVar, float f2);

    void h(b bVar, Context context, ColorStateList colorStateList, float f2, float f3, float f4);

    void i(b bVar, float f2);

    void j(b bVar);

    void k(b bVar, ColorStateList colorStateList);

    float l(b bVar);

    void m(b bVar, float f2);

    void n();
}
