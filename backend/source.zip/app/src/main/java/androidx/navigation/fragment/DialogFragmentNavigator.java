package androidx.navigation.fragment;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.util.AttributeSet;
import android.util.Log;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.l;
import androidx.lifecycle.d;
import androidx.lifecycle.e;
import androidx.lifecycle.g;
import androidx.navigation.k;
import androidx.navigation.p;
import androidx.navigation.s;
import java.util.HashSet;
@s.b("dialog")
/* loaded from: classes.dex */
public final class DialogFragmentNavigator extends s<a> {

    /* renamed from: a  reason: collision with root package name */
    private final Context f1936a;

    /* renamed from: b  reason: collision with root package name */
    private final l f1937b;

    /* renamed from: c  reason: collision with root package name */
    private int f1938c = 0;

    /* renamed from: d  reason: collision with root package name */
    private final HashSet<String> f1939d = new HashSet<>();

    /* renamed from: e  reason: collision with root package name */
    private e f1940e = new e() { // from class: androidx.navigation.fragment.DialogFragmentNavigator.1
        @Override // androidx.lifecycle.e
        public void f(g gVar, d.a aVar) {
            if (aVar == d.a.ON_STOP) {
                androidx.fragment.app.c cVar = (androidx.fragment.app.c) gVar;
                if (cVar.w1().isShowing()) {
                    return;
                }
                NavHostFragment.q1(cVar).u();
            }
        }
    };

    /* loaded from: classes.dex */
    public static class a extends k implements androidx.navigation.b {

        /* renamed from: k  reason: collision with root package name */
        private String f1942k;

        public a(s<? extends a> sVar) {
            super(sVar);
        }

        @Override // androidx.navigation.k
        public void p(Context context, AttributeSet attributeSet) {
            super.p(context, attributeSet);
            TypedArray obtainAttributes = context.getResources().obtainAttributes(attributeSet, c.f1954c);
            String string = obtainAttributes.getString(c.f1955d);
            if (string != null) {
                w(string);
            }
            obtainAttributes.recycle();
        }

        public final String v() {
            String str = this.f1942k;
            if (str != null) {
                return str;
            }
            throw new IllegalStateException("DialogFragment class was not set");
        }

        public final a w(String str) {
            this.f1942k = str;
            return this;
        }
    }

    public DialogFragmentNavigator(Context context, l lVar) {
        this.f1936a = context;
        this.f1937b = lVar;
    }

    @Override // androidx.navigation.s
    public void c(Bundle bundle) {
        if (bundle != null) {
            this.f1938c = bundle.getInt("androidx-nav-dialogfragment:navigator:count", 0);
            for (int i2 = 0; i2 < this.f1938c; i2++) {
                androidx.fragment.app.c cVar = (androidx.fragment.app.c) this.f1937b.X("androidx-nav-fragment:navigator:dialog:" + i2);
                if (cVar != null) {
                    cVar.a().a(this.f1940e);
                } else {
                    this.f1939d.add("androidx-nav-fragment:navigator:dialog:" + i2);
                }
            }
        }
    }

    @Override // androidx.navigation.s
    public Bundle d() {
        if (this.f1938c == 0) {
            return null;
        }
        Bundle bundle = new Bundle();
        bundle.putInt("androidx-nav-dialogfragment:navigator:count", this.f1938c);
        return bundle;
    }

    @Override // androidx.navigation.s
    public boolean e() {
        if (this.f1938c == 0) {
            return false;
        }
        if (this.f1937b.t0()) {
            Log.i("DialogFragmentNavigator", "Ignoring popBackStack() call: FragmentManager has already saved its state");
            return false;
        }
        l lVar = this.f1937b;
        StringBuilder sb = new StringBuilder();
        sb.append("androidx-nav-fragment:navigator:dialog:");
        int i2 = this.f1938c - 1;
        this.f1938c = i2;
        sb.append(i2);
        Fragment X = lVar.X(sb.toString());
        if (X != null) {
            X.a().c(this.f1940e);
            ((androidx.fragment.app.c) X).r1();
        }
        return true;
    }

    @Override // androidx.navigation.s
    /* renamed from: f  reason: merged with bridge method [inline-methods] */
    public a a() {
        return new a(this);
    }

    @Override // androidx.navigation.s
    /* renamed from: g  reason: merged with bridge method [inline-methods] */
    public k b(a aVar, Bundle bundle, p pVar, s.a aVar2) {
        if (this.f1937b.t0()) {
            Log.i("DialogFragmentNavigator", "Ignoring navigate() call: FragmentManager has already saved its state");
            return null;
        }
        String v2 = aVar.v();
        if (v2.charAt(0) == '.') {
            v2 = this.f1936a.getPackageName() + v2;
        }
        Fragment a2 = this.f1937b.e0().a(this.f1936a.getClassLoader(), v2);
        if (!androidx.fragment.app.c.class.isAssignableFrom(a2.getClass())) {
            throw new IllegalArgumentException("Dialog destination " + aVar.v() + " is not an instance of DialogFragment");
        }
        androidx.fragment.app.c cVar = (androidx.fragment.app.c) a2;
        cVar.i1(bundle);
        cVar.a().a(this.f1940e);
        l lVar = this.f1937b;
        StringBuilder sb = new StringBuilder();
        sb.append("androidx-nav-fragment:navigator:dialog:");
        int i2 = this.f1938c;
        this.f1938c = i2 + 1;
        sb.append(i2);
        cVar.y1(lVar, sb.toString());
        return aVar;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void h(Fragment fragment) {
        if (this.f1939d.remove(fragment.J())) {
            fragment.a().a(this.f1940e);
        }
    }
}
