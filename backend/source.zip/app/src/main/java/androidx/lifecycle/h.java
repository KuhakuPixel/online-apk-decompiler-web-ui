package androidx.lifecycle;

import androidx.lifecycle.d;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
/* loaded from: classes.dex */
public class h extends d {

    /* renamed from: d  reason: collision with root package name */
    private final WeakReference<g> f1856d;

    /* renamed from: b  reason: collision with root package name */
    private i.a<f, b> f1854b = new i.a<>();

    /* renamed from: e  reason: collision with root package name */
    private int f1857e = 0;

    /* renamed from: f  reason: collision with root package name */
    private boolean f1858f = false;

    /* renamed from: g  reason: collision with root package name */
    private boolean f1859g = false;

    /* renamed from: h  reason: collision with root package name */
    private ArrayList<d.b> f1860h = new ArrayList<>();

    /* renamed from: c  reason: collision with root package name */
    private d.b f1855c = d.b.INITIALIZED;

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public static /* synthetic */ class a {

        /* renamed from: a  reason: collision with root package name */
        static final /* synthetic */ int[] f1861a;

        /* renamed from: b  reason: collision with root package name */
        static final /* synthetic */ int[] f1862b;

        static {
            int[] iArr = new int[d.b.values().length];
            f1862b = iArr;
            try {
                iArr[d.b.INITIALIZED.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                f1862b[d.b.CREATED.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                f1862b[d.b.STARTED.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                f1862b[d.b.RESUMED.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                f1862b[d.b.DESTROYED.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            int[] iArr2 = new int[d.a.values().length];
            f1861a = iArr2;
            try {
                iArr2[d.a.ON_CREATE.ordinal()] = 1;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                f1861a[d.a.ON_STOP.ordinal()] = 2;
            } catch (NoSuchFieldError unused7) {
            }
            try {
                f1861a[d.a.ON_START.ordinal()] = 3;
            } catch (NoSuchFieldError unused8) {
            }
            try {
                f1861a[d.a.ON_PAUSE.ordinal()] = 4;
            } catch (NoSuchFieldError unused9) {
            }
            try {
                f1861a[d.a.ON_RESUME.ordinal()] = 5;
            } catch (NoSuchFieldError unused10) {
            }
            try {
                f1861a[d.a.ON_DESTROY.ordinal()] = 6;
            } catch (NoSuchFieldError unused11) {
            }
            try {
                f1861a[d.a.ON_ANY.ordinal()] = 7;
            } catch (NoSuchFieldError unused12) {
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public static class b {

        /* renamed from: a  reason: collision with root package name */
        d.b f1863a;

        /* renamed from: b  reason: collision with root package name */
        e f1864b;

        b(f fVar, d.b bVar) {
            this.f1864b = j.f(fVar);
            this.f1863a = bVar;
        }

        void a(g gVar, d.a aVar) {
            d.b h2 = h.h(aVar);
            this.f1863a = h.l(this.f1863a, h2);
            this.f1864b.f(gVar, aVar);
            this.f1863a = h2;
        }
    }

    public h(g gVar) {
        this.f1856d = new WeakReference<>(gVar);
    }

    private void d(g gVar) {
        Iterator<Map.Entry<f, b>> c2 = this.f1854b.c();
        while (c2.hasNext() && !this.f1859g) {
            Map.Entry<f, b> next = c2.next();
            b value = next.getValue();
            while (value.f1863a.compareTo(this.f1855c) > 0 && !this.f1859g && this.f1854b.contains(next.getKey())) {
                d.a f2 = f(value.f1863a);
                o(h(f2));
                value.a(gVar, f2);
                n();
            }
        }
    }

    private d.b e(f fVar) {
        Map.Entry<f, b> k2 = this.f1854b.k(fVar);
        d.b bVar = null;
        d.b bVar2 = k2 != null ? k2.getValue().f1863a : null;
        if (!this.f1860h.isEmpty()) {
            bVar = this.f1860h.get(r0.size() - 1);
        }
        return l(l(this.f1855c, bVar2), bVar);
    }

    private static d.a f(d.b bVar) {
        int i2 = a.f1862b[bVar.ordinal()];
        if (i2 != 1) {
            if (i2 != 2) {
                if (i2 != 3) {
                    if (i2 != 4) {
                        if (i2 != 5) {
                            throw new IllegalArgumentException("Unexpected state value " + bVar);
                        }
                        throw new IllegalArgumentException();
                    }
                    return d.a.ON_PAUSE;
                }
                return d.a.ON_STOP;
            }
            return d.a.ON_DESTROY;
        }
        throw new IllegalArgumentException();
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void g(g gVar) {
        i.b<f, b>.d f2 = this.f1854b.f();
        while (f2.hasNext() && !this.f1859g) {
            Map.Entry next = f2.next();
            b bVar = (b) next.getValue();
            while (bVar.f1863a.compareTo(this.f1855c) < 0 && !this.f1859g && this.f1854b.contains(next.getKey())) {
                o(bVar.f1863a);
                bVar.a(gVar, r(bVar.f1863a));
                n();
            }
        }
    }

    static d.b h(d.a aVar) {
        switch (a.f1861a[aVar.ordinal()]) {
            case 1:
            case 2:
                return d.b.CREATED;
            case 3:
            case 4:
                return d.b.STARTED;
            case 5:
                return d.b.RESUMED;
            case 6:
                return d.b.DESTROYED;
            default:
                throw new IllegalArgumentException("Unexpected event value " + aVar);
        }
    }

    private boolean j() {
        if (this.f1854b.size() == 0) {
            return true;
        }
        d.b bVar = this.f1854b.d().getValue().f1863a;
        d.b bVar2 = this.f1854b.g().getValue().f1863a;
        return bVar == bVar2 && this.f1855c == bVar2;
    }

    static d.b l(d.b bVar, d.b bVar2) {
        return (bVar2 == null || bVar2.compareTo(bVar) >= 0) ? bVar : bVar2;
    }

    private void m(d.b bVar) {
        if (this.f1855c == bVar) {
            return;
        }
        this.f1855c = bVar;
        if (this.f1858f || this.f1857e != 0) {
            this.f1859g = true;
            return;
        }
        this.f1858f = true;
        q();
        this.f1858f = false;
    }

    private void n() {
        this.f1860h.remove(r0.size() - 1);
    }

    private void o(d.b bVar) {
        this.f1860h.add(bVar);
    }

    private void q() {
        g gVar = this.f1856d.get();
        if (gVar == null) {
            throw new IllegalStateException("LifecycleOwner of this LifecycleRegistry is alreadygarbage collected. It is too late to change lifecycle state.");
        }
        while (true) {
            boolean j2 = j();
            this.f1859g = false;
            if (j2) {
                return;
            }
            if (this.f1855c.compareTo(this.f1854b.d().getValue().f1863a) < 0) {
                d(gVar);
            }
            Map.Entry<f, b> g2 = this.f1854b.g();
            if (!this.f1859g && g2 != null && this.f1855c.compareTo(g2.getValue().f1863a) > 0) {
                g(gVar);
            }
        }
    }

    private static d.a r(d.b bVar) {
        int i2 = a.f1862b[bVar.ordinal()];
        if (i2 != 1) {
            if (i2 == 2) {
                return d.a.ON_START;
            }
            if (i2 == 3) {
                return d.a.ON_RESUME;
            }
            if (i2 == 4) {
                throw new IllegalArgumentException();
            }
            if (i2 != 5) {
                throw new IllegalArgumentException("Unexpected state value " + bVar);
            }
        }
        return d.a.ON_CREATE;
    }

    @Override // androidx.lifecycle.d
    public void a(f fVar) {
        g gVar;
        d.b bVar = this.f1855c;
        d.b bVar2 = d.b.DESTROYED;
        if (bVar != bVar2) {
            bVar2 = d.b.INITIALIZED;
        }
        b bVar3 = new b(fVar, bVar2);
        if (this.f1854b.i(fVar, bVar3) == null && (gVar = this.f1856d.get()) != null) {
            boolean z2 = this.f1857e != 0 || this.f1858f;
            d.b e2 = e(fVar);
            this.f1857e++;
            while (bVar3.f1863a.compareTo(e2) < 0 && this.f1854b.contains(fVar)) {
                o(bVar3.f1863a);
                bVar3.a(gVar, r(bVar3.f1863a));
                n();
                e2 = e(fVar);
            }
            if (!z2) {
                q();
            }
            this.f1857e--;
        }
    }

    @Override // androidx.lifecycle.d
    public d.b b() {
        return this.f1855c;
    }

    @Override // androidx.lifecycle.d
    public void c(f fVar) {
        this.f1854b.j(fVar);
    }

    public void i(d.a aVar) {
        m(h(aVar));
    }

    @Deprecated
    public void k(d.b bVar) {
        p(bVar);
    }

    public void p(d.b bVar) {
        m(bVar);
    }
}
