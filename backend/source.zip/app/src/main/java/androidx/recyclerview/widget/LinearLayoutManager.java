package androidx.recyclerview.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.PointF;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
/* loaded from: classes.dex */
public class LinearLayoutManager extends RecyclerView.o implements RecyclerView.z.b {
    int A;
    int B;
    private boolean C;
    d D;
    final a E;
    private final b F;
    private int G;
    private int[] H;

    /* renamed from: s  reason: collision with root package name */
    int f2083s;

    /* renamed from: t  reason: collision with root package name */
    private c f2084t;

    /* renamed from: u  reason: collision with root package name */
    i f2085u;

    /* renamed from: v  reason: collision with root package name */
    private boolean f2086v;

    /* renamed from: w  reason: collision with root package name */
    private boolean f2087w;

    /* renamed from: x  reason: collision with root package name */
    boolean f2088x;

    /* renamed from: y  reason: collision with root package name */
    private boolean f2089y;

    /* renamed from: z  reason: collision with root package name */
    private boolean f2090z;

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public static class a {

        /* renamed from: a  reason: collision with root package name */
        i f2091a;

        /* renamed from: b  reason: collision with root package name */
        int f2092b;

        /* renamed from: c  reason: collision with root package name */
        int f2093c;

        /* renamed from: d  reason: collision with root package name */
        boolean f2094d;

        /* renamed from: e  reason: collision with root package name */
        boolean f2095e;

        a() {
            e();
        }

        void a() {
            this.f2093c = this.f2094d ? this.f2091a.i() : this.f2091a.m();
        }

        public void b(View view, int i2) {
            this.f2093c = this.f2094d ? this.f2091a.d(view) + this.f2091a.o() : this.f2091a.g(view);
            this.f2092b = i2;
        }

        public void c(View view, int i2) {
            int o2 = this.f2091a.o();
            if (o2 >= 0) {
                b(view, i2);
                return;
            }
            this.f2092b = i2;
            if (this.f2094d) {
                int i3 = (this.f2091a.i() - o2) - this.f2091a.d(view);
                this.f2093c = this.f2091a.i() - i3;
                if (i3 > 0) {
                    int e2 = this.f2093c - this.f2091a.e(view);
                    int m2 = this.f2091a.m();
                    int min = e2 - (m2 + Math.min(this.f2091a.g(view) - m2, 0));
                    if (min < 0) {
                        this.f2093c += Math.min(i3, -min);
                        return;
                    }
                    return;
                }
                return;
            }
            int g2 = this.f2091a.g(view);
            int m3 = g2 - this.f2091a.m();
            this.f2093c = g2;
            if (m3 > 0) {
                int i4 = (this.f2091a.i() - Math.min(0, (this.f2091a.i() - o2) - this.f2091a.d(view))) - (g2 + this.f2091a.e(view));
                if (i4 < 0) {
                    this.f2093c -= Math.min(m3, -i4);
                }
            }
        }

        boolean d(View view, RecyclerView.a0 a0Var) {
            RecyclerView.p pVar = (RecyclerView.p) view.getLayoutParams();
            return !pVar.c() && pVar.a() >= 0 && pVar.a() < a0Var.b();
        }

        void e() {
            this.f2092b = -1;
            this.f2093c = Integer.MIN_VALUE;
            this.f2094d = false;
            this.f2095e = false;
        }

        public String toString() {
            return "AnchorInfo{mPosition=" + this.f2092b + ", mCoordinate=" + this.f2093c + ", mLayoutFromEnd=" + this.f2094d + ", mValid=" + this.f2095e + '}';
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    /* loaded from: classes.dex */
    public static class b {

        /* renamed from: a  reason: collision with root package name */
        public int f2096a;

        /* renamed from: b  reason: collision with root package name */
        public boolean f2097b;

        /* renamed from: c  reason: collision with root package name */
        public boolean f2098c;

        /* renamed from: d  reason: collision with root package name */
        public boolean f2099d;

        protected b() {
        }

        void a() {
            this.f2096a = 0;
            this.f2097b = false;
            this.f2098c = false;
            this.f2099d = false;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public static class c {

        /* renamed from: b  reason: collision with root package name */
        int f2101b;

        /* renamed from: c  reason: collision with root package name */
        int f2102c;

        /* renamed from: d  reason: collision with root package name */
        int f2103d;

        /* renamed from: e  reason: collision with root package name */
        int f2104e;

        /* renamed from: f  reason: collision with root package name */
        int f2105f;

        /* renamed from: g  reason: collision with root package name */
        int f2106g;

        /* renamed from: k  reason: collision with root package name */
        int f2110k;

        /* renamed from: m  reason: collision with root package name */
        boolean f2112m;

        /* renamed from: a  reason: collision with root package name */
        boolean f2100a = true;

        /* renamed from: h  reason: collision with root package name */
        int f2107h = 0;

        /* renamed from: i  reason: collision with root package name */
        int f2108i = 0;

        /* renamed from: j  reason: collision with root package name */
        boolean f2109j = false;

        /* renamed from: l  reason: collision with root package name */
        List<RecyclerView.d0> f2111l = null;

        c() {
        }

        private View e() {
            int size = this.f2111l.size();
            for (int i2 = 0; i2 < size; i2++) {
                View view = this.f2111l.get(i2).f2195a;
                RecyclerView.p pVar = (RecyclerView.p) view.getLayoutParams();
                if (!pVar.c() && this.f2103d == pVar.a()) {
                    b(view);
                    return view;
                }
            }
            return null;
        }

        public void a() {
            b(null);
        }

        public void b(View view) {
            View f2 = f(view);
            this.f2103d = f2 == null ? -1 : ((RecyclerView.p) f2.getLayoutParams()).a();
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public boolean c(RecyclerView.a0 a0Var) {
            int i2 = this.f2103d;
            return i2 >= 0 && i2 < a0Var.b();
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public View d(RecyclerView.v vVar) {
            if (this.f2111l != null) {
                return e();
            }
            View o2 = vVar.o(this.f2103d);
            this.f2103d += this.f2104e;
            return o2;
        }

        public View f(View view) {
            int a2;
            int size = this.f2111l.size();
            View view2 = null;
            int i2 = Integer.MAX_VALUE;
            for (int i3 = 0; i3 < size; i3++) {
                View view3 = this.f2111l.get(i3).f2195a;
                RecyclerView.p pVar = (RecyclerView.p) view3.getLayoutParams();
                if (view3 != view && !pVar.c() && (a2 = (pVar.a() - this.f2103d) * this.f2104e) >= 0 && a2 < i2) {
                    view2 = view3;
                    if (a2 == 0) {
                        break;
                    }
                    i2 = a2;
                }
            }
            return view2;
        }
    }

    @SuppressLint({"BanParcelableUsage"})
    /* loaded from: classes.dex */
    public static class d implements Parcelable {
        public static final Parcelable.Creator<d> CREATOR = new a();

        /* renamed from: b  reason: collision with root package name */
        int f2113b;

        /* renamed from: c  reason: collision with root package name */
        int f2114c;

        /* renamed from: d  reason: collision with root package name */
        boolean f2115d;

        /* loaded from: classes.dex */
        static class a implements Parcelable.Creator<d> {
            a() {
            }

            @Override // android.os.Parcelable.Creator
            /* renamed from: a  reason: merged with bridge method [inline-methods] */
            public d createFromParcel(Parcel parcel) {
                return new d(parcel);
            }

            @Override // android.os.Parcelable.Creator
            /* renamed from: b  reason: merged with bridge method [inline-methods] */
            public d[] newArray(int i2) {
                return new d[i2];
            }
        }

        public d() {
        }

        d(Parcel parcel) {
            this.f2113b = parcel.readInt();
            this.f2114c = parcel.readInt();
            this.f2115d = parcel.readInt() == 1;
        }

        public d(d dVar) {
            this.f2113b = dVar.f2113b;
            this.f2114c = dVar.f2114c;
            this.f2115d = dVar.f2115d;
        }

        @Override // android.os.Parcelable
        public int describeContents() {
            return 0;
        }

        boolean j() {
            return this.f2113b >= 0;
        }

        void k() {
            this.f2113b = -1;
        }

        @Override // android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i2) {
            parcel.writeInt(this.f2113b);
            parcel.writeInt(this.f2114c);
            parcel.writeInt(this.f2115d ? 1 : 0);
        }
    }

    public LinearLayoutManager(Context context) {
        this(context, 1, false);
    }

    public LinearLayoutManager(Context context, int i2, boolean z2) {
        this.f2083s = 1;
        this.f2087w = false;
        this.f2088x = false;
        this.f2089y = false;
        this.f2090z = true;
        this.A = -1;
        this.B = Integer.MIN_VALUE;
        this.D = null;
        this.E = new a();
        this.F = new b();
        this.G = 2;
        this.H = new int[2];
        C2(i2);
        D2(z2);
    }

    public LinearLayoutManager(Context context, AttributeSet attributeSet, int i2, int i3) {
        this.f2083s = 1;
        this.f2087w = false;
        this.f2088x = false;
        this.f2089y = false;
        this.f2090z = true;
        this.A = -1;
        this.B = Integer.MIN_VALUE;
        this.D = null;
        this.E = new a();
        this.F = new b();
        this.G = 2;
        this.H = new int[2];
        RecyclerView.o.d i02 = RecyclerView.o.i0(context, attributeSet, i2, i3);
        C2(i02.f2248a);
        D2(i02.f2250c);
        E2(i02.f2251d);
    }

    private void A2() {
        this.f2088x = (this.f2083s == 1 || !q2()) ? this.f2087w : !this.f2087w;
    }

    private boolean F2(RecyclerView.v vVar, RecyclerView.a0 a0Var, a aVar) {
        if (J() == 0) {
            return false;
        }
        View V = V();
        if (V != null && aVar.d(V, a0Var)) {
            aVar.c(V, h0(V));
            return true;
        } else if (this.f2086v != this.f2089y) {
            return false;
        } else {
            View i2 = aVar.f2094d ? i2(vVar, a0Var) : j2(vVar, a0Var);
            if (i2 != null) {
                aVar.b(i2, h0(i2));
                if (!a0Var.e() && L1()) {
                    if (this.f2085u.g(i2) >= this.f2085u.i() || this.f2085u.d(i2) < this.f2085u.m()) {
                        aVar.f2093c = aVar.f2094d ? this.f2085u.i() : this.f2085u.m();
                    }
                }
                return true;
            }
            return false;
        }
    }

    private boolean G2(RecyclerView.a0 a0Var, a aVar) {
        int i2;
        if (!a0Var.e() && (i2 = this.A) != -1) {
            if (i2 >= 0 && i2 < a0Var.b()) {
                aVar.f2092b = this.A;
                d dVar = this.D;
                if (dVar != null && dVar.j()) {
                    boolean z2 = this.D.f2115d;
                    aVar.f2094d = z2;
                    aVar.f2093c = z2 ? this.f2085u.i() - this.D.f2114c : this.f2085u.m() + this.D.f2114c;
                    return true;
                } else if (this.B != Integer.MIN_VALUE) {
                    boolean z3 = this.f2088x;
                    aVar.f2094d = z3;
                    aVar.f2093c = z3 ? this.f2085u.i() - this.B : this.f2085u.m() + this.B;
                    return true;
                } else {
                    View C = C(this.A);
                    if (C == null) {
                        if (J() > 0) {
                            aVar.f2094d = (this.A < h0(I(0))) == this.f2088x;
                        }
                        aVar.a();
                    } else if (this.f2085u.e(C) > this.f2085u.n()) {
                        aVar.a();
                        return true;
                    } else if (this.f2085u.g(C) - this.f2085u.m() < 0) {
                        aVar.f2093c = this.f2085u.m();
                        aVar.f2094d = false;
                        return true;
                    } else if (this.f2085u.i() - this.f2085u.d(C) < 0) {
                        aVar.f2093c = this.f2085u.i();
                        aVar.f2094d = true;
                        return true;
                    } else {
                        aVar.f2093c = aVar.f2094d ? this.f2085u.d(C) + this.f2085u.o() : this.f2085u.g(C);
                    }
                    return true;
                }
            }
            this.A = -1;
            this.B = Integer.MIN_VALUE;
        }
        return false;
    }

    private void H2(RecyclerView.v vVar, RecyclerView.a0 a0Var, a aVar) {
        if (G2(a0Var, aVar) || F2(vVar, a0Var, aVar)) {
            return;
        }
        aVar.a();
        aVar.f2092b = this.f2089y ? a0Var.b() - 1 : 0;
    }

    private void I2(int i2, int i3, boolean z2, RecyclerView.a0 a0Var) {
        int m2;
        this.f2084t.f2112m = z2();
        this.f2084t.f2105f = i2;
        int[] iArr = this.H;
        iArr[0] = 0;
        iArr[1] = 0;
        M1(a0Var, iArr);
        int max = Math.max(0, this.H[0]);
        int max2 = Math.max(0, this.H[1]);
        boolean z3 = i2 == 1;
        c cVar = this.f2084t;
        int i4 = z3 ? max2 : max;
        cVar.f2107h = i4;
        if (!z3) {
            max = max2;
        }
        cVar.f2108i = max;
        if (z3) {
            cVar.f2107h = i4 + this.f2085u.j();
            View m22 = m2();
            c cVar2 = this.f2084t;
            cVar2.f2104e = this.f2088x ? -1 : 1;
            int h02 = h0(m22);
            c cVar3 = this.f2084t;
            cVar2.f2103d = h02 + cVar3.f2104e;
            cVar3.f2101b = this.f2085u.d(m22);
            m2 = this.f2085u.d(m22) - this.f2085u.i();
        } else {
            View n2 = n2();
            this.f2084t.f2107h += this.f2085u.m();
            c cVar4 = this.f2084t;
            cVar4.f2104e = this.f2088x ? 1 : -1;
            int h03 = h0(n2);
            c cVar5 = this.f2084t;
            cVar4.f2103d = h03 + cVar5.f2104e;
            cVar5.f2101b = this.f2085u.g(n2);
            m2 = (-this.f2085u.g(n2)) + this.f2085u.m();
        }
        c cVar6 = this.f2084t;
        cVar6.f2102c = i3;
        if (z2) {
            cVar6.f2102c = i3 - m2;
        }
        cVar6.f2106g = m2;
    }

    private void J2(int i2, int i3) {
        this.f2084t.f2102c = this.f2085u.i() - i3;
        c cVar = this.f2084t;
        cVar.f2104e = this.f2088x ? -1 : 1;
        cVar.f2103d = i2;
        cVar.f2105f = 1;
        cVar.f2101b = i3;
        cVar.f2106g = Integer.MIN_VALUE;
    }

    private void K2(a aVar) {
        J2(aVar.f2092b, aVar.f2093c);
    }

    private void L2(int i2, int i3) {
        this.f2084t.f2102c = i3 - this.f2085u.m();
        c cVar = this.f2084t;
        cVar.f2103d = i2;
        cVar.f2104e = this.f2088x ? 1 : -1;
        cVar.f2105f = -1;
        cVar.f2101b = i3;
        cVar.f2106g = Integer.MIN_VALUE;
    }

    private void M2(a aVar) {
        L2(aVar.f2092b, aVar.f2093c);
    }

    private int O1(RecyclerView.a0 a0Var) {
        if (J() == 0) {
            return 0;
        }
        T1();
        return l.a(a0Var, this.f2085u, Y1(!this.f2090z, true), X1(!this.f2090z, true), this, this.f2090z);
    }

    private int P1(RecyclerView.a0 a0Var) {
        if (J() == 0) {
            return 0;
        }
        T1();
        return l.b(a0Var, this.f2085u, Y1(!this.f2090z, true), X1(!this.f2090z, true), this, this.f2090z, this.f2088x);
    }

    private int Q1(RecyclerView.a0 a0Var) {
        if (J() == 0) {
            return 0;
        }
        T1();
        return l.c(a0Var, this.f2085u, Y1(!this.f2090z, true), X1(!this.f2090z, true), this, this.f2090z);
    }

    private View V1() {
        return d2(0, J());
    }

    private View W1(RecyclerView.v vVar, RecyclerView.a0 a0Var) {
        return h2(vVar, a0Var, 0, J(), a0Var.b());
    }

    private View a2() {
        return d2(J() - 1, -1);
    }

    private View b2(RecyclerView.v vVar, RecyclerView.a0 a0Var) {
        return h2(vVar, a0Var, J() - 1, -1, a0Var.b());
    }

    private View f2() {
        return this.f2088x ? V1() : a2();
    }

    private View g2() {
        return this.f2088x ? a2() : V1();
    }

    private View i2(RecyclerView.v vVar, RecyclerView.a0 a0Var) {
        return this.f2088x ? W1(vVar, a0Var) : b2(vVar, a0Var);
    }

    private View j2(RecyclerView.v vVar, RecyclerView.a0 a0Var) {
        return this.f2088x ? b2(vVar, a0Var) : W1(vVar, a0Var);
    }

    private int k2(int i2, RecyclerView.v vVar, RecyclerView.a0 a0Var, boolean z2) {
        int i3;
        int i4 = this.f2085u.i() - i2;
        if (i4 > 0) {
            int i5 = -B2(-i4, vVar, a0Var);
            int i6 = i2 + i5;
            if (!z2 || (i3 = this.f2085u.i() - i6) <= 0) {
                return i5;
            }
            this.f2085u.r(i3);
            return i3 + i5;
        }
        return 0;
    }

    private int l2(int i2, RecyclerView.v vVar, RecyclerView.a0 a0Var, boolean z2) {
        int m2;
        int m3 = i2 - this.f2085u.m();
        if (m3 > 0) {
            int i3 = -B2(m3, vVar, a0Var);
            int i4 = i2 + i3;
            if (!z2 || (m2 = i4 - this.f2085u.m()) <= 0) {
                return i3;
            }
            this.f2085u.r(-m2);
            return i3 - m2;
        }
        return 0;
    }

    private View m2() {
        return I(this.f2088x ? 0 : J() - 1);
    }

    private View n2() {
        return I(this.f2088x ? J() - 1 : 0);
    }

    private void t2(RecyclerView.v vVar, RecyclerView.a0 a0Var, int i2, int i3) {
        if (!a0Var.g() || J() == 0 || a0Var.e() || !L1()) {
            return;
        }
        List<RecyclerView.d0> k2 = vVar.k();
        int size = k2.size();
        int h02 = h0(I(0));
        int i4 = 0;
        int i5 = 0;
        for (int i6 = 0; i6 < size; i6++) {
            RecyclerView.d0 d0Var = k2.get(i6);
            if (!d0Var.v()) {
                char c2 = (d0Var.m() < h02) != this.f2088x ? (char) 65535 : (char) 1;
                int e2 = this.f2085u.e(d0Var.f2195a);
                if (c2 == 65535) {
                    i4 += e2;
                } else {
                    i5 += e2;
                }
            }
        }
        this.f2084t.f2111l = k2;
        if (i4 > 0) {
            L2(h0(n2()), i2);
            c cVar = this.f2084t;
            cVar.f2107h = i4;
            cVar.f2102c = 0;
            cVar.a();
            U1(vVar, this.f2084t, a0Var, false);
        }
        if (i5 > 0) {
            J2(h0(m2()), i3);
            c cVar2 = this.f2084t;
            cVar2.f2107h = i5;
            cVar2.f2102c = 0;
            cVar2.a();
            U1(vVar, this.f2084t, a0Var, false);
        }
        this.f2084t.f2111l = null;
    }

    private void v2(RecyclerView.v vVar, c cVar) {
        if (!cVar.f2100a || cVar.f2112m) {
            return;
        }
        int i2 = cVar.f2106g;
        int i3 = cVar.f2108i;
        if (cVar.f2105f == -1) {
            x2(vVar, i2, i3);
        } else {
            y2(vVar, i2, i3);
        }
    }

    private void w2(RecyclerView.v vVar, int i2, int i3) {
        if (i2 == i3) {
            return;
        }
        if (i3 <= i2) {
            while (i2 > i3) {
                n1(i2, vVar);
                i2--;
            }
            return;
        }
        for (int i4 = i3 - 1; i4 >= i2; i4--) {
            n1(i4, vVar);
        }
    }

    private void x2(RecyclerView.v vVar, int i2, int i3) {
        int J = J();
        if (i2 < 0) {
            return;
        }
        int h2 = (this.f2085u.h() - i2) + i3;
        if (this.f2088x) {
            for (int i4 = 0; i4 < J; i4++) {
                View I = I(i4);
                if (this.f2085u.g(I) < h2 || this.f2085u.q(I) < h2) {
                    w2(vVar, 0, i4);
                    return;
                }
            }
            return;
        }
        int i5 = J - 1;
        for (int i6 = i5; i6 >= 0; i6--) {
            View I2 = I(i6);
            if (this.f2085u.g(I2) < h2 || this.f2085u.q(I2) < h2) {
                w2(vVar, i5, i6);
                return;
            }
        }
    }

    private void y2(RecyclerView.v vVar, int i2, int i3) {
        if (i2 < 0) {
            return;
        }
        int i4 = i2 - i3;
        int J = J();
        if (!this.f2088x) {
            for (int i5 = 0; i5 < J; i5++) {
                View I = I(i5);
                if (this.f2085u.d(I) > i4 || this.f2085u.p(I) > i4) {
                    w2(vVar, 0, i5);
                    return;
                }
            }
            return;
        }
        int i6 = J - 1;
        for (int i7 = i6; i7 >= 0; i7--) {
            View I2 = I(i7);
            if (this.f2085u.d(I2) > i4 || this.f2085u.p(I2) > i4) {
                w2(vVar, i6, i7);
                return;
            }
        }
    }

    int B2(int i2, RecyclerView.v vVar, RecyclerView.a0 a0Var) {
        if (J() == 0 || i2 == 0) {
            return 0;
        }
        T1();
        this.f2084t.f2100a = true;
        int i3 = i2 > 0 ? 1 : -1;
        int abs = Math.abs(i2);
        I2(i3, abs, true, a0Var);
        c cVar = this.f2084t;
        int U1 = cVar.f2106g + U1(vVar, cVar, a0Var, false);
        if (U1 < 0) {
            return 0;
        }
        if (abs > U1) {
            i2 = i3 * U1;
        }
        this.f2085u.r(-i2);
        this.f2084t.f2110k = i2;
        return i2;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public View C(int i2) {
        int J = J();
        if (J == 0) {
            return null;
        }
        int h02 = i2 - h0(I(0));
        if (h02 >= 0 && h02 < J) {
            View I = I(h02);
            if (h0(I) == i2) {
                return I;
            }
        }
        return super.C(i2);
    }

    public void C2(int i2) {
        if (i2 != 0 && i2 != 1) {
            throw new IllegalArgumentException("invalid orientation:" + i2);
        }
        g(null);
        if (i2 != this.f2083s || this.f2085u == null) {
            i b2 = i.b(this, i2);
            this.f2085u = b2;
            this.E.f2091a = b2;
            this.f2083s = i2;
            t1();
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public RecyclerView.p D() {
        return new RecyclerView.p(-2, -2);
    }

    public void D2(boolean z2) {
        g(null);
        if (z2 == this.f2087w) {
            return;
        }
        this.f2087w = z2;
        t1();
    }

    public void E2(boolean z2) {
        g(null);
        if (this.f2089y == z2) {
            return;
        }
        this.f2089y = z2;
        t1();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    boolean G1() {
        return (X() == 1073741824 || p0() == 1073741824 || !q0()) ? false : true;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public void I0(RecyclerView recyclerView, RecyclerView.v vVar) {
        super.I0(recyclerView, vVar);
        if (this.C) {
            k1(vVar);
            vVar.c();
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public void I1(RecyclerView recyclerView, RecyclerView.a0 a0Var, int i2) {
        g gVar = new g(recyclerView.getContext());
        gVar.p(i2);
        J1(gVar);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public View J0(View view, int i2, RecyclerView.v vVar, RecyclerView.a0 a0Var) {
        int R1;
        A2();
        if (J() == 0 || (R1 = R1(i2)) == Integer.MIN_VALUE) {
            return null;
        }
        T1();
        I2(R1, (int) (this.f2085u.n() * 0.33333334f), false, a0Var);
        c cVar = this.f2084t;
        cVar.f2106g = Integer.MIN_VALUE;
        cVar.f2100a = false;
        U1(vVar, cVar, a0Var, true);
        View g2 = R1 == -1 ? g2() : f2();
        View n2 = R1 == -1 ? n2() : m2();
        if (n2.hasFocusable()) {
            if (g2 == null) {
                return null;
            }
            return n2;
        }
        return g2;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public void K0(AccessibilityEvent accessibilityEvent) {
        super.K0(accessibilityEvent);
        if (J() > 0) {
            accessibilityEvent.setFromIndex(Z1());
            accessibilityEvent.setToIndex(c2());
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public boolean L1() {
        return this.D == null && this.f2086v == this.f2089y;
    }

    protected void M1(RecyclerView.a0 a0Var, int[] iArr) {
        int i2;
        int o2 = o2(a0Var);
        if (this.f2084t.f2105f == -1) {
            i2 = 0;
        } else {
            i2 = o2;
            o2 = 0;
        }
        iArr[0] = o2;
        iArr[1] = i2;
    }

    void N1(RecyclerView.a0 a0Var, c cVar, RecyclerView.o.c cVar2) {
        int i2 = cVar.f2103d;
        if (i2 < 0 || i2 >= a0Var.b()) {
            return;
        }
        cVar2.a(i2, Math.max(0, cVar.f2106g));
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public int R1(int i2) {
        return i2 != 1 ? i2 != 2 ? i2 != 17 ? i2 != 33 ? i2 != 66 ? (i2 == 130 && this.f2083s == 1) ? 1 : Integer.MIN_VALUE : this.f2083s == 0 ? 1 : Integer.MIN_VALUE : this.f2083s == 1 ? -1 : Integer.MIN_VALUE : this.f2083s == 0 ? -1 : Integer.MIN_VALUE : (this.f2083s != 1 && q2()) ? -1 : 1 : (this.f2083s != 1 && q2()) ? 1 : -1;
    }

    c S1() {
        return new c();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void T1() {
        if (this.f2084t == null) {
            this.f2084t = S1();
        }
    }

    int U1(RecyclerView.v vVar, c cVar, RecyclerView.a0 a0Var, boolean z2) {
        int i2 = cVar.f2102c;
        int i3 = cVar.f2106g;
        if (i3 != Integer.MIN_VALUE) {
            if (i2 < 0) {
                cVar.f2106g = i3 + i2;
            }
            v2(vVar, cVar);
        }
        int i4 = cVar.f2102c + cVar.f2107h;
        b bVar = this.F;
        while (true) {
            if ((!cVar.f2112m && i4 <= 0) || !cVar.c(a0Var)) {
                break;
            }
            bVar.a();
            s2(vVar, a0Var, cVar, bVar);
            if (!bVar.f2097b) {
                cVar.f2101b += bVar.f2096a * cVar.f2105f;
                if (!bVar.f2098c || cVar.f2111l != null || !a0Var.e()) {
                    int i5 = cVar.f2102c;
                    int i6 = bVar.f2096a;
                    cVar.f2102c = i5 - i6;
                    i4 -= i6;
                }
                int i7 = cVar.f2106g;
                if (i7 != Integer.MIN_VALUE) {
                    int i8 = i7 + bVar.f2096a;
                    cVar.f2106g = i8;
                    int i9 = cVar.f2102c;
                    if (i9 < 0) {
                        cVar.f2106g = i8 + i9;
                    }
                    v2(vVar, cVar);
                }
                if (z2 && bVar.f2099d) {
                    break;
                }
            } else {
                break;
            }
        }
        return i2 - cVar.f2102c;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public void X0(RecyclerView.v vVar, RecyclerView.a0 a0Var) {
        int i2;
        int i3;
        int i4;
        int i5;
        int k2;
        int i6;
        View C;
        int g2;
        int i7;
        int i8 = -1;
        if (!(this.D == null && this.A == -1) && a0Var.b() == 0) {
            k1(vVar);
            return;
        }
        d dVar = this.D;
        if (dVar != null && dVar.j()) {
            this.A = this.D.f2113b;
        }
        T1();
        this.f2084t.f2100a = false;
        A2();
        View V = V();
        a aVar = this.E;
        if (!aVar.f2095e || this.A != -1 || this.D != null) {
            aVar.e();
            a aVar2 = this.E;
            aVar2.f2094d = this.f2088x ^ this.f2089y;
            H2(vVar, a0Var, aVar2);
            this.E.f2095e = true;
        } else if (V != null && (this.f2085u.g(V) >= this.f2085u.i() || this.f2085u.d(V) <= this.f2085u.m())) {
            this.E.c(V, h0(V));
        }
        c cVar = this.f2084t;
        cVar.f2105f = cVar.f2110k >= 0 ? 1 : -1;
        int[] iArr = this.H;
        iArr[0] = 0;
        iArr[1] = 0;
        M1(a0Var, iArr);
        int max = Math.max(0, this.H[0]) + this.f2085u.m();
        int max2 = Math.max(0, this.H[1]) + this.f2085u.j();
        if (a0Var.e() && (i6 = this.A) != -1 && this.B != Integer.MIN_VALUE && (C = C(i6)) != null) {
            if (this.f2088x) {
                i7 = this.f2085u.i() - this.f2085u.d(C);
                g2 = this.B;
            } else {
                g2 = this.f2085u.g(C) - this.f2085u.m();
                i7 = this.B;
            }
            int i9 = i7 - g2;
            if (i9 > 0) {
                max += i9;
            } else {
                max2 -= i9;
            }
        }
        a aVar3 = this.E;
        if (!aVar3.f2094d ? !this.f2088x : this.f2088x) {
            i8 = 1;
        }
        u2(vVar, a0Var, aVar3, i8);
        w(vVar);
        this.f2084t.f2112m = z2();
        this.f2084t.f2109j = a0Var.e();
        this.f2084t.f2108i = 0;
        a aVar4 = this.E;
        if (aVar4.f2094d) {
            M2(aVar4);
            c cVar2 = this.f2084t;
            cVar2.f2107h = max;
            U1(vVar, cVar2, a0Var, false);
            c cVar3 = this.f2084t;
            i3 = cVar3.f2101b;
            int i10 = cVar3.f2103d;
            int i11 = cVar3.f2102c;
            if (i11 > 0) {
                max2 += i11;
            }
            K2(this.E);
            c cVar4 = this.f2084t;
            cVar4.f2107h = max2;
            cVar4.f2103d += cVar4.f2104e;
            U1(vVar, cVar4, a0Var, false);
            c cVar5 = this.f2084t;
            i2 = cVar5.f2101b;
            int i12 = cVar5.f2102c;
            if (i12 > 0) {
                L2(i10, i3);
                c cVar6 = this.f2084t;
                cVar6.f2107h = i12;
                U1(vVar, cVar6, a0Var, false);
                i3 = this.f2084t.f2101b;
            }
        } else {
            K2(aVar4);
            c cVar7 = this.f2084t;
            cVar7.f2107h = max2;
            U1(vVar, cVar7, a0Var, false);
            c cVar8 = this.f2084t;
            i2 = cVar8.f2101b;
            int i13 = cVar8.f2103d;
            int i14 = cVar8.f2102c;
            if (i14 > 0) {
                max += i14;
            }
            M2(this.E);
            c cVar9 = this.f2084t;
            cVar9.f2107h = max;
            cVar9.f2103d += cVar9.f2104e;
            U1(vVar, cVar9, a0Var, false);
            c cVar10 = this.f2084t;
            i3 = cVar10.f2101b;
            int i15 = cVar10.f2102c;
            if (i15 > 0) {
                J2(i13, i2);
                c cVar11 = this.f2084t;
                cVar11.f2107h = i15;
                U1(vVar, cVar11, a0Var, false);
                i2 = this.f2084t.f2101b;
            }
        }
        if (J() > 0) {
            if (this.f2088x ^ this.f2089y) {
                int k22 = k2(i2, vVar, a0Var, true);
                i4 = i3 + k22;
                i5 = i2 + k22;
                k2 = l2(i4, vVar, a0Var, false);
            } else {
                int l2 = l2(i3, vVar, a0Var, true);
                i4 = i3 + l2;
                i5 = i2 + l2;
                k2 = k2(i5, vVar, a0Var, false);
            }
            i3 = i4 + k2;
            i2 = i5 + k2;
        }
        t2(vVar, a0Var, i3, i2);
        if (a0Var.e()) {
            this.E.e();
        } else {
            this.f2085u.s();
        }
        this.f2086v = this.f2089y;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public View X1(boolean z2, boolean z3) {
        int J;
        int i2;
        if (this.f2088x) {
            J = 0;
            i2 = J();
        } else {
            J = J() - 1;
            i2 = -1;
        }
        return e2(J, i2, z2, z3);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public void Y0(RecyclerView.a0 a0Var) {
        super.Y0(a0Var);
        this.D = null;
        this.A = -1;
        this.B = Integer.MIN_VALUE;
        this.E.e();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public View Y1(boolean z2, boolean z3) {
        int i2;
        int J;
        if (this.f2088x) {
            i2 = J() - 1;
            J = -1;
        } else {
            i2 = 0;
            J = J();
        }
        return e2(i2, J, z2, z3);
    }

    public int Z1() {
        View e2 = e2(0, J(), false, true);
        if (e2 == null) {
            return -1;
        }
        return h0(e2);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.z.b
    public PointF a(int i2) {
        if (J() == 0) {
            return null;
        }
        int i3 = (i2 < h0(I(0))) != this.f2088x ? -1 : 1;
        return this.f2083s == 0 ? new PointF(i3, 0.0f) : new PointF(0.0f, i3);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public void c1(Parcelable parcelable) {
        if (parcelable instanceof d) {
            this.D = (d) parcelable;
            t1();
        }
    }

    public int c2() {
        View e2 = e2(J() - 1, -1, false, true);
        if (e2 == null) {
            return -1;
        }
        return h0(e2);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public Parcelable d1() {
        if (this.D != null) {
            return new d(this.D);
        }
        d dVar = new d();
        if (J() > 0) {
            T1();
            boolean z2 = this.f2086v ^ this.f2088x;
            dVar.f2115d = z2;
            if (z2) {
                View m2 = m2();
                dVar.f2114c = this.f2085u.i() - this.f2085u.d(m2);
                dVar.f2113b = h0(m2);
            } else {
                View n2 = n2();
                dVar.f2113b = h0(n2);
                dVar.f2114c = this.f2085u.g(n2) - this.f2085u.m();
            }
        } else {
            dVar.k();
        }
        return dVar;
    }

    View d2(int i2, int i3) {
        int i4;
        int i5;
        T1();
        if ((i3 > i2 ? (char) 1 : i3 < i2 ? (char) 65535 : (char) 0) == 0) {
            return I(i2);
        }
        if (this.f2085u.g(I(i2)) < this.f2085u.m()) {
            i4 = 16644;
            i5 = 16388;
        } else {
            i4 = 4161;
            i5 = 4097;
        }
        return (this.f2083s == 0 ? this.f2232e : this.f2233f).a(i2, i3, i4, i5);
    }

    View e2(int i2, int i3, boolean z2, boolean z3) {
        T1();
        return (this.f2083s == 0 ? this.f2232e : this.f2233f).a(i2, i3, z2 ? 24579 : 320, z3 ? 320 : 0);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public void g(String str) {
        if (this.D == null) {
            super.g(str);
        }
    }

    View h2(RecyclerView.v vVar, RecyclerView.a0 a0Var, int i2, int i3, int i4) {
        T1();
        int m2 = this.f2085u.m();
        int i5 = this.f2085u.i();
        int i6 = i3 > i2 ? 1 : -1;
        View view = null;
        View view2 = null;
        while (i2 != i3) {
            View I = I(i2);
            int h02 = h0(I);
            if (h02 >= 0 && h02 < i4) {
                if (((RecyclerView.p) I.getLayoutParams()).c()) {
                    if (view2 == null) {
                        view2 = I;
                    }
                } else if (this.f2085u.g(I) < i5 && this.f2085u.d(I) >= m2) {
                    return I;
                } else {
                    if (view == null) {
                        view = I;
                    }
                }
            }
            i2 += i6;
        }
        return view != null ? view : view2;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public boolean k() {
        return this.f2083s == 0;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public boolean l() {
        return this.f2083s == 1;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public void o(int i2, int i3, RecyclerView.a0 a0Var, RecyclerView.o.c cVar) {
        if (this.f2083s != 0) {
            i2 = i3;
        }
        if (J() == 0 || i2 == 0) {
            return;
        }
        T1();
        I2(i2 > 0 ? 1 : -1, Math.abs(i2), true, a0Var);
        N1(a0Var, this.f2084t, cVar);
    }

    @Deprecated
    protected int o2(RecyclerView.a0 a0Var) {
        if (a0Var.d()) {
            return this.f2085u.n();
        }
        return 0;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public void p(int i2, RecyclerView.o.c cVar) {
        boolean z2;
        int i3;
        d dVar = this.D;
        if (dVar == null || !dVar.j()) {
            A2();
            z2 = this.f2088x;
            i3 = this.A;
            if (i3 == -1) {
                i3 = z2 ? i2 - 1 : 0;
            }
        } else {
            d dVar2 = this.D;
            z2 = dVar2.f2115d;
            i3 = dVar2.f2113b;
        }
        int i4 = z2 ? -1 : 1;
        for (int i5 = 0; i5 < this.G && i3 >= 0 && i3 < i2; i5++) {
            cVar.a(i3, 0);
            i3 += i4;
        }
    }

    public int p2() {
        return this.f2083s;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public int q(RecyclerView.a0 a0Var) {
        return O1(a0Var);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public boolean q2() {
        return Z() == 1;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public int r(RecyclerView.a0 a0Var) {
        return P1(a0Var);
    }

    public boolean r2() {
        return this.f2090z;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public int s(RecyclerView.a0 a0Var) {
        return Q1(a0Var);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public boolean s0() {
        return true;
    }

    void s2(RecyclerView.v vVar, RecyclerView.a0 a0Var, c cVar, b bVar) {
        int i2;
        int i3;
        int i4;
        int i5;
        int f2;
        View d2 = cVar.d(vVar);
        if (d2 == null) {
            bVar.f2097b = true;
            return;
        }
        RecyclerView.p pVar = (RecyclerView.p) d2.getLayoutParams();
        if (cVar.f2111l == null) {
            if (this.f2088x == (cVar.f2105f == -1)) {
                d(d2);
            } else {
                e(d2, 0);
            }
        } else {
            if (this.f2088x == (cVar.f2105f == -1)) {
                b(d2);
            } else {
                c(d2, 0);
            }
        }
        A0(d2, 0, 0);
        bVar.f2096a = this.f2085u.e(d2);
        if (this.f2083s == 1) {
            if (q2()) {
                f2 = o0() - f0();
                i5 = f2 - this.f2085u.f(d2);
            } else {
                i5 = e0();
                f2 = this.f2085u.f(d2) + i5;
            }
            int i6 = cVar.f2105f;
            int i7 = cVar.f2101b;
            if (i6 == -1) {
                i4 = i7;
                i3 = f2;
                i2 = i7 - bVar.f2096a;
            } else {
                i2 = i7;
                i3 = f2;
                i4 = bVar.f2096a + i7;
            }
        } else {
            int g02 = g0();
            int f3 = this.f2085u.f(d2) + g02;
            int i8 = cVar.f2105f;
            int i9 = cVar.f2101b;
            if (i8 == -1) {
                i3 = i9;
                i2 = g02;
                i4 = f3;
                i5 = i9 - bVar.f2096a;
            } else {
                i2 = g02;
                i3 = bVar.f2096a + i9;
                i4 = f3;
                i5 = i9;
            }
        }
        z0(d2, i5, i2, i3, i4);
        if (pVar.c() || pVar.b()) {
            bVar.f2098c = true;
        }
        bVar.f2099d = d2.hasFocusable();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public int t(RecyclerView.a0 a0Var) {
        return O1(a0Var);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public int u(RecyclerView.a0 a0Var) {
        return P1(a0Var);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void u2(RecyclerView.v vVar, RecyclerView.a0 a0Var, a aVar, int i2) {
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public int v(RecyclerView.a0 a0Var) {
        return Q1(a0Var);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public int w1(int i2, RecyclerView.v vVar, RecyclerView.a0 a0Var) {
        if (this.f2083s == 1) {
            return 0;
        }
        return B2(i2, vVar, a0Var);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public void x1(int i2) {
        this.A = i2;
        this.B = Integer.MIN_VALUE;
        d dVar = this.D;
        if (dVar != null) {
            dVar.k();
        }
        t1();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.o
    public int y1(int i2, RecyclerView.v vVar, RecyclerView.a0 a0Var) {
        if (this.f2083s == 0) {
            return 0;
        }
        return B2(i2, vVar, a0Var);
    }

    boolean z2() {
        return this.f2085u.k() == 0 && this.f2085u.h() == 0;
    }
}
