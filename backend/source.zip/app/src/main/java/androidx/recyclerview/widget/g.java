package androidx.recyclerview.widget;

import android.content.Context;
import android.graphics.PointF;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import androidx.recyclerview.widget.RecyclerView;
/* loaded from: classes.dex */
public class g extends RecyclerView.z {

    /* renamed from: k  reason: collision with root package name */
    protected PointF f2452k;

    /* renamed from: l  reason: collision with root package name */
    private final DisplayMetrics f2453l;

    /* renamed from: n  reason: collision with root package name */
    private float f2455n;

    /* renamed from: i  reason: collision with root package name */
    protected final LinearInterpolator f2450i = new LinearInterpolator();

    /* renamed from: j  reason: collision with root package name */
    protected final DecelerateInterpolator f2451j = new DecelerateInterpolator();

    /* renamed from: m  reason: collision with root package name */
    private boolean f2454m = false;

    /* renamed from: o  reason: collision with root package name */
    protected int f2456o = 0;

    /* renamed from: p  reason: collision with root package name */
    protected int f2457p = 0;

    public g(Context context) {
        this.f2453l = context.getResources().getDisplayMetrics();
    }

    private float A() {
        if (!this.f2454m) {
            this.f2455n = v(this.f2453l);
            this.f2454m = true;
        }
        return this.f2455n;
    }

    private int y(int i2, int i3) {
        int i4 = i2 - i3;
        if (i2 * i4 <= 0) {
            return 0;
        }
        return i4;
    }

    protected int B() {
        PointF pointF = this.f2452k;
        if (pointF != null) {
            float f2 = pointF.y;
            if (f2 != 0.0f) {
                return f2 > 0.0f ? 1 : -1;
            }
        }
        return 0;
    }

    protected void C(RecyclerView.z.a aVar) {
        PointF a2 = a(f());
        if (a2 == null || (a2.x == 0.0f && a2.y == 0.0f)) {
            aVar.b(f());
            r();
            return;
        }
        i(a2);
        this.f2452k = a2;
        this.f2456o = (int) (a2.x * 10000.0f);
        this.f2457p = (int) (a2.y * 10000.0f);
        aVar.d((int) (this.f2456o * 1.2f), (int) (this.f2457p * 1.2f), (int) (x(10000) * 1.2f), this.f2450i);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.z
    protected void l(int i2, int i3, RecyclerView.a0 a0Var, RecyclerView.z.a aVar) {
        if (c() == 0) {
            r();
            return;
        }
        this.f2456o = y(this.f2456o, i2);
        int y2 = y(this.f2457p, i3);
        this.f2457p = y2;
        if (this.f2456o == 0 && y2 == 0) {
            C(aVar);
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.z
    protected void m() {
    }

    @Override // androidx.recyclerview.widget.RecyclerView.z
    protected void n() {
        this.f2457p = 0;
        this.f2456o = 0;
        this.f2452k = null;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.z
    protected void o(View view, RecyclerView.a0 a0Var, RecyclerView.z.a aVar) {
        int t2 = t(view, z());
        int u2 = u(view, B());
        int w2 = w((int) Math.sqrt((t2 * t2) + (u2 * u2)));
        if (w2 > 0) {
            aVar.d(-t2, -u2, w2, this.f2451j);
        }
    }

    public int s(int i2, int i3, int i4, int i5, int i6) {
        if (i6 != -1) {
            if (i6 != 0) {
                if (i6 == 1) {
                    return i5 - i3;
                }
                throw new IllegalArgumentException("snap preference should be one of the constants defined in SmoothScroller, starting with SNAP_");
            }
            int i7 = i4 - i2;
            if (i7 > 0) {
                return i7;
            }
            int i8 = i5 - i3;
            if (i8 < 0) {
                return i8;
            }
            return 0;
        }
        return i4 - i2;
    }

    public int t(View view, int i2) {
        RecyclerView.o e2 = e();
        if (e2 == null || !e2.k()) {
            return 0;
        }
        RecyclerView.p pVar = (RecyclerView.p) view.getLayoutParams();
        return s(e2.Q(view) - ((ViewGroup.MarginLayoutParams) pVar).leftMargin, e2.T(view) + ((ViewGroup.MarginLayoutParams) pVar).rightMargin, e2.e0(), e2.o0() - e2.f0(), i2);
    }

    public int u(View view, int i2) {
        RecyclerView.o e2 = e();
        if (e2 == null || !e2.l()) {
            return 0;
        }
        RecyclerView.p pVar = (RecyclerView.p) view.getLayoutParams();
        return s(e2.U(view) - ((ViewGroup.MarginLayoutParams) pVar).topMargin, e2.O(view) + ((ViewGroup.MarginLayoutParams) pVar).bottomMargin, e2.g0(), e2.W() - e2.d0(), i2);
    }

    protected float v(DisplayMetrics displayMetrics) {
        return 25.0f / displayMetrics.densityDpi;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public int w(int i2) {
        return (int) Math.ceil(x(i2) / 0.3356d);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public int x(int i2) {
        return (int) Math.ceil(Math.abs(i2) * A());
    }

    protected int z() {
        PointF pointF = this.f2452k;
        if (pointF != null) {
            float f2 = pointF.x;
            if (f2 != 0.0f) {
                return f2 > 0.0f ? 1 : -1;
            }
        }
        return 0;
    }
}
