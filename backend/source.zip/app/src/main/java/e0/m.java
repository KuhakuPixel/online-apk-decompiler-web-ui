package e0;

import android.view.View;
/* loaded from: classes.dex */
public interface m extends l {
    void m(View view, int i2, int i3, int i4, int i5, int i6, int[] iArr);
}
