package androidx.core.app;

import android.app.Notification;
/* loaded from: classes.dex */
public interface NotificationBuilderWithBuilderAccessor {
    Notification.Builder getBuilder();
}
