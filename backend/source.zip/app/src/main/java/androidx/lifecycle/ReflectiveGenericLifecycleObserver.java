package androidx.lifecycle;

import androidx.lifecycle.a;
import androidx.lifecycle.d;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes.dex */
public class ReflectiveGenericLifecycleObserver implements e {

    /* renamed from: a  reason: collision with root package name */
    private final Object f1834a;

    /* renamed from: b  reason: collision with root package name */
    private final a.C0010a f1835b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public ReflectiveGenericLifecycleObserver(Object obj) {
        this.f1834a = obj;
        this.f1835b = a.f1840c.c(obj.getClass());
    }

    @Override // androidx.lifecycle.e
    public void f(g gVar, d.a aVar) {
        this.f1835b.a(gVar, aVar, this.f1834a);
    }
}
