package androidx.recyclerview.widget;

import android.view.View;
/* loaded from: classes.dex */
class o {

    /* renamed from: a  reason: collision with root package name */
    final b f2475a;

    /* renamed from: b  reason: collision with root package name */
    a f2476b = new a();

    /* loaded from: classes.dex */
    static class a {

        /* renamed from: a  reason: collision with root package name */
        int f2477a = 0;

        /* renamed from: b  reason: collision with root package name */
        int f2478b;

        /* renamed from: c  reason: collision with root package name */
        int f2479c;

        /* renamed from: d  reason: collision with root package name */
        int f2480d;

        /* renamed from: e  reason: collision with root package name */
        int f2481e;

        a() {
        }

        void a(int i2) {
            this.f2477a = i2 | this.f2477a;
        }

        boolean b() {
            int i2 = this.f2477a;
            if ((i2 & 7) == 0 || (i2 & (c(this.f2480d, this.f2478b) << 0)) != 0) {
                int i3 = this.f2477a;
                if ((i3 & 112) == 0 || (i3 & (c(this.f2480d, this.f2479c) << 4)) != 0) {
                    int i4 = this.f2477a;
                    if ((i4 & 1792) == 0 || (i4 & (c(this.f2481e, this.f2478b) << 8)) != 0) {
                        int i5 = this.f2477a;
                        return (i5 & 28672) == 0 || (i5 & (c(this.f2481e, this.f2479c) << 12)) != 0;
                    }
                    return false;
                }
                return false;
            }
            return false;
        }

        int c(int i2, int i3) {
            if (i2 > i3) {
                return 1;
            }
            return i2 == i3 ? 2 : 4;
        }

        void d() {
            this.f2477a = 0;
        }

        void e(int i2, int i3, int i4, int i5) {
            this.f2478b = i2;
            this.f2479c = i3;
            this.f2480d = i4;
            this.f2481e = i5;
        }
    }

    /* loaded from: classes.dex */
    interface b {
        View a(int i2);

        int b();

        int c();

        int d(View view);

        int e(View view);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public o(b bVar) {
        this.f2475a = bVar;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public View a(int i2, int i3, int i4, int i5) {
        int c2 = this.f2475a.c();
        int b2 = this.f2475a.b();
        int i6 = i3 > i2 ? 1 : -1;
        View view = null;
        while (i2 != i3) {
            View a2 = this.f2475a.a(i2);
            this.f2476b.e(c2, b2, this.f2475a.e(a2), this.f2475a.d(a2));
            if (i4 != 0) {
                this.f2476b.d();
                this.f2476b.a(i4);
                if (this.f2476b.b()) {
                    return a2;
                }
            }
            if (i5 != 0) {
                this.f2476b.d();
                this.f2476b.a(i5);
                if (this.f2476b.b()) {
                    view = a2;
                }
            }
            i2 += i6;
        }
        return view;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public boolean b(View view, int i2) {
        this.f2476b.e(this.f2475a.c(), this.f2475a.b(), this.f2475a.e(view), this.f2475a.d(view));
        if (i2 != 0) {
            this.f2476b.d();
            this.f2476b.a(i2);
            return this.f2476b.b();
        }
        return false;
    }
}
