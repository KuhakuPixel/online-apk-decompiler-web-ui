package d;

import a.i;
import a.j;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
/* loaded from: classes.dex */
public class d extends Drawable {

    /* renamed from: m  reason: collision with root package name */
    private static final float f4232m = (float) Math.toRadians(45.0d);

    /* renamed from: a  reason: collision with root package name */
    private final Paint f4233a;

    /* renamed from: b  reason: collision with root package name */
    private float f4234b;

    /* renamed from: c  reason: collision with root package name */
    private float f4235c;

    /* renamed from: d  reason: collision with root package name */
    private float f4236d;

    /* renamed from: e  reason: collision with root package name */
    private float f4237e;

    /* renamed from: f  reason: collision with root package name */
    private boolean f4238f;

    /* renamed from: g  reason: collision with root package name */
    private final Path f4239g;

    /* renamed from: h  reason: collision with root package name */
    private final int f4240h;

    /* renamed from: i  reason: collision with root package name */
    private boolean f4241i;

    /* renamed from: j  reason: collision with root package name */
    private float f4242j;

    /* renamed from: k  reason: collision with root package name */
    private float f4243k;

    /* renamed from: l  reason: collision with root package name */
    private int f4244l;

    public d(Context context) {
        Paint paint = new Paint();
        this.f4233a = paint;
        this.f4239g = new Path();
        this.f4241i = false;
        this.f4244l = 2;
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeJoin(Paint.Join.MITER);
        paint.setStrokeCap(Paint.Cap.BUTT);
        paint.setAntiAlias(true);
        TypedArray obtainStyledAttributes = context.getTheme().obtainStyledAttributes(null, j.W0, a.a.drawerArrowStyle, i.Base_Widget_AppCompat_DrawerArrowToggle);
        d(obtainStyledAttributes.getColor(j.f17a1, 0));
        c(obtainStyledAttributes.getDimension(j.f29e1, 0.0f));
        f(obtainStyledAttributes.getBoolean(j.f26d1, true));
        e(Math.round(obtainStyledAttributes.getDimension(j.f23c1, 0.0f)));
        this.f4240h = obtainStyledAttributes.getDimensionPixelSize(j.f20b1, 0);
        this.f4235c = Math.round(obtainStyledAttributes.getDimension(j.Z0, 0.0f));
        this.f4234b = Math.round(obtainStyledAttributes.getDimension(j.X0, 0.0f));
        this.f4236d = obtainStyledAttributes.getDimension(j.Y0, 0.0f);
        obtainStyledAttributes.recycle();
    }

    private static float b(float f2, float f3, float f4) {
        return f2 + ((f3 - f2) * f4);
    }

    public float a() {
        return this.f4242j;
    }

    public void c(float f2) {
        if (this.f4233a.getStrokeWidth() != f2) {
            this.f4233a.setStrokeWidth(f2);
            this.f4243k = (float) ((f2 / 2.0f) * Math.cos(f4232m));
            invalidateSelf();
        }
    }

    public void d(int i2) {
        if (i2 != this.f4233a.getColor()) {
            this.f4233a.setColor(i2);
            invalidateSelf();
        }
    }

    @Override // android.graphics.drawable.Drawable
    public void draw(Canvas canvas) {
        Rect bounds = getBounds();
        int i2 = this.f4244l;
        boolean z2 = false;
        if (i2 != 0 && (i2 == 1 || (i2 == 3 ? x.a.f(this) == 0 : x.a.f(this) == 1))) {
            z2 = true;
        }
        float f2 = this.f4234b;
        float b2 = b(this.f4235c, (float) Math.sqrt(f2 * f2 * 2.0f), this.f4242j);
        float b3 = b(this.f4235c, this.f4236d, this.f4242j);
        float round = Math.round(b(0.0f, this.f4243k, this.f4242j));
        float b4 = b(0.0f, f4232m, this.f4242j);
        float b5 = b(z2 ? 0.0f : -180.0f, z2 ? 180.0f : 0.0f, this.f4242j);
        double d2 = b2;
        double d3 = b4;
        boolean z3 = z2;
        float round2 = (float) Math.round(Math.cos(d3) * d2);
        float round3 = (float) Math.round(d2 * Math.sin(d3));
        this.f4239g.rewind();
        float b6 = b(this.f4237e + this.f4233a.getStrokeWidth(), -this.f4243k, this.f4242j);
        float f3 = (-b3) / 2.0f;
        this.f4239g.moveTo(f3 + round, 0.0f);
        this.f4239g.rLineTo(b3 - (round * 2.0f), 0.0f);
        this.f4239g.moveTo(f3, b6);
        this.f4239g.rLineTo(round2, round3);
        this.f4239g.moveTo(f3, -b6);
        this.f4239g.rLineTo(round2, -round3);
        this.f4239g.close();
        canvas.save();
        float strokeWidth = this.f4233a.getStrokeWidth();
        float height = bounds.height() - (3.0f * strokeWidth);
        canvas.translate(bounds.centerX(), ((((int) (height - (2.0f * r5))) / 4) * 2) + (strokeWidth * 1.5f) + this.f4237e);
        if (this.f4238f) {
            canvas.rotate(b5 * (this.f4241i ^ z3 ? -1 : 1));
        } else if (z3) {
            canvas.rotate(180.0f);
        }
        canvas.drawPath(this.f4239g, this.f4233a);
        canvas.restore();
    }

    public void e(float f2) {
        if (f2 != this.f4237e) {
            this.f4237e = f2;
            invalidateSelf();
        }
    }

    public void f(boolean z2) {
        if (this.f4238f != z2) {
            this.f4238f = z2;
            invalidateSelf();
        }
    }

    @Override // android.graphics.drawable.Drawable
    public int getIntrinsicHeight() {
        return this.f4240h;
    }

    @Override // android.graphics.drawable.Drawable
    public int getIntrinsicWidth() {
        return this.f4240h;
    }

    @Override // android.graphics.drawable.Drawable
    public int getOpacity() {
        return -3;
    }

    @Override // android.graphics.drawable.Drawable
    public void setAlpha(int i2) {
        if (i2 != this.f4233a.getAlpha()) {
            this.f4233a.setAlpha(i2);
            invalidateSelf();
        }
    }

    @Override // android.graphics.drawable.Drawable
    public void setColorFilter(ColorFilter colorFilter) {
        this.f4233a.setColorFilter(colorFilter);
        invalidateSelf();
    }

    public void setProgress(float f2) {
        if (this.f4242j != f2) {
            this.f4242j = f2;
            invalidateSelf();
        }
    }
}
