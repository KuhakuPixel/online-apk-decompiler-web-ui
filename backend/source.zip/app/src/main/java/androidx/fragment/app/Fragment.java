package androidx.fragment.app;

import android.animation.Animator;
import android.app.Activity;
import android.content.ComponentCallbacks;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Looper;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import androidx.lifecycle.d;
import androidx.savedstate.SavedStateRegistry;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.lang.reflect.InvocationTargetException;
import java.util.Objects;
import java.util.UUID;
/* loaded from: classes.dex */
public class Fragment implements ComponentCallbacks, View.OnCreateContextMenuListener, androidx.lifecycle.g, androidx.lifecycle.u, androidx.savedstate.b {
    static final Object X = new Object();
    boolean A;
    boolean B;
    boolean C;
    boolean D;
    boolean E;
    private boolean F;
    ViewGroup G;
    View H;
    boolean I;
    boolean J;
    d K;
    Runnable L;
    boolean M;
    boolean N;
    float O;
    LayoutInflater P;
    boolean Q;
    d.b R;
    androidx.lifecycle.h S;
    w T;
    androidx.lifecycle.m<androidx.lifecycle.g> U;
    androidx.savedstate.a V;
    private int W;

    /* renamed from: b  reason: collision with root package name */
    int f1521b;

    /* renamed from: c  reason: collision with root package name */
    Bundle f1522c;

    /* renamed from: d  reason: collision with root package name */
    SparseArray<Parcelable> f1523d;

    /* renamed from: e  reason: collision with root package name */
    Boolean f1524e;

    /* renamed from: f  reason: collision with root package name */
    String f1525f;

    /* renamed from: g  reason: collision with root package name */
    Bundle f1526g;

    /* renamed from: h  reason: collision with root package name */
    Fragment f1527h;

    /* renamed from: i  reason: collision with root package name */
    String f1528i;

    /* renamed from: j  reason: collision with root package name */
    int f1529j;

    /* renamed from: k  reason: collision with root package name */
    private Boolean f1530k;

    /* renamed from: l  reason: collision with root package name */
    boolean f1531l;

    /* renamed from: m  reason: collision with root package name */
    boolean f1532m;

    /* renamed from: n  reason: collision with root package name */
    boolean f1533n;

    /* renamed from: o  reason: collision with root package name */
    boolean f1534o;

    /* renamed from: p  reason: collision with root package name */
    boolean f1535p;

    /* renamed from: q  reason: collision with root package name */
    boolean f1536q;

    /* renamed from: r  reason: collision with root package name */
    int f1537r;

    /* renamed from: s  reason: collision with root package name */
    l f1538s;

    /* renamed from: t  reason: collision with root package name */
    i<?> f1539t;

    /* renamed from: u  reason: collision with root package name */
    l f1540u;

    /* renamed from: v  reason: collision with root package name */
    Fragment f1541v;

    /* renamed from: w  reason: collision with root package name */
    int f1542w;

    /* renamed from: x  reason: collision with root package name */
    int f1543x;

    /* renamed from: y  reason: collision with root package name */
    String f1544y;

    /* renamed from: z  reason: collision with root package name */
    boolean f1545z;

    /* loaded from: classes.dex */
    class a implements Runnable {
        a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            Fragment.this.o1();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public class b implements Runnable {
        b() {
        }

        @Override // java.lang.Runnable
        public void run() {
            Fragment.this.d();
        }
    }

    /* loaded from: classes.dex */
    class c extends androidx.fragment.app.f {
        c() {
        }

        @Override // androidx.fragment.app.f
        public View e(int i2) {
            View view = Fragment.this.H;
            if (view != null) {
                return view.findViewById(i2);
            }
            throw new IllegalStateException("Fragment " + this + " does not have a view");
        }

        @Override // androidx.fragment.app.f
        public boolean f() {
            return Fragment.this.H != null;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public static class d {

        /* renamed from: a  reason: collision with root package name */
        View f1550a;

        /* renamed from: b  reason: collision with root package name */
        Animator f1551b;

        /* renamed from: c  reason: collision with root package name */
        int f1552c;

        /* renamed from: d  reason: collision with root package name */
        int f1553d;

        /* renamed from: e  reason: collision with root package name */
        int f1554e;

        /* renamed from: f  reason: collision with root package name */
        Object f1555f = null;

        /* renamed from: g  reason: collision with root package name */
        Object f1556g;

        /* renamed from: h  reason: collision with root package name */
        Object f1557h;

        /* renamed from: i  reason: collision with root package name */
        Object f1558i;

        /* renamed from: j  reason: collision with root package name */
        Object f1559j;

        /* renamed from: k  reason: collision with root package name */
        Object f1560k;

        /* renamed from: l  reason: collision with root package name */
        Boolean f1561l;

        /* renamed from: m  reason: collision with root package name */
        Boolean f1562m;

        /* renamed from: n  reason: collision with root package name */
        boolean f1563n;

        /* renamed from: o  reason: collision with root package name */
        f f1564o;

        /* renamed from: p  reason: collision with root package name */
        boolean f1565p;

        d() {
            Object obj = Fragment.X;
            this.f1556g = obj;
            this.f1557h = null;
            this.f1558i = obj;
            this.f1559j = null;
            this.f1560k = obj;
        }
    }

    /* loaded from: classes.dex */
    public static class e extends RuntimeException {
        public e(String str, Exception exc) {
            super(str, exc);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public interface f {
        void a();

        void b();
    }

    public Fragment() {
        this.f1521b = -1;
        this.f1525f = UUID.randomUUID().toString();
        this.f1528i = null;
        this.f1530k = null;
        this.f1540u = new m();
        this.E = true;
        this.J = true;
        this.L = new a();
        this.R = d.b.RESUMED;
        this.U = new androidx.lifecycle.m<>();
        N();
    }

    public Fragment(int i2) {
        this();
        this.W = i2;
    }

    private void N() {
        this.S = new androidx.lifecycle.h(this);
        this.V = androidx.savedstate.a.a(this);
        this.S.a(new androidx.lifecycle.e() { // from class: androidx.fragment.app.Fragment.2
            @Override // androidx.lifecycle.e
            public void f(androidx.lifecycle.g gVar, d.a aVar) {
                View view;
                if (aVar != d.a.ON_STOP || (view = Fragment.this.H) == null) {
                    return;
                }
                view.cancelPendingInputEvents();
            }
        });
    }

    @Deprecated
    public static Fragment P(Context context, String str, Bundle bundle) {
        try {
            Fragment newInstance = h.d(context.getClassLoader(), str).getConstructor(new Class[0]).newInstance(new Object[0]);
            if (bundle != null) {
                bundle.setClassLoader(newInstance.getClass().getClassLoader());
                newInstance.i1(bundle);
            }
            return newInstance;
        } catch (IllegalAccessException e2) {
            throw new e("Unable to instantiate fragment " + str + ": make sure class name exists, is public, and has an empty constructor that is public", e2);
        } catch (InstantiationException e3) {
            throw new e("Unable to instantiate fragment " + str + ": make sure class name exists, is public, and has an empty constructor that is public", e3);
        } catch (NoSuchMethodException e4) {
            throw new e("Unable to instantiate fragment " + str + ": could not find Fragment constructor", e4);
        } catch (InvocationTargetException e5) {
            throw new e("Unable to instantiate fragment " + str + ": calling Fragment constructor caused an exception", e5);
        }
    }

    private d f() {
        if (this.K == null) {
            this.K = new d();
        }
        return this.K;
    }

    public final l A() {
        l lVar = this.f1538s;
        if (lVar != null) {
            return lVar;
        }
        throw new IllegalStateException("Fragment " + this + " not associated with a fragment manager.");
    }

    public void A0() {
        this.F = true;
    }

    public Object B() {
        d dVar = this.K;
        if (dVar == null) {
            return null;
        }
        Object obj = dVar.f1558i;
        return obj == X ? s() : obj;
    }

    public void B0() {
        this.F = true;
    }

    public final Resources C() {
        return c1().getResources();
    }

    public void C0(View view, Bundle bundle) {
    }

    public final boolean D() {
        return this.B;
    }

    public void D0(Bundle bundle) {
        this.F = true;
    }

    public Object E() {
        d dVar = this.K;
        if (dVar == null) {
            return null;
        }
        Object obj = dVar.f1556g;
        return obj == X ? q() : obj;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void E0(Bundle bundle) {
        this.f1540u.B0();
        this.f1521b = 2;
        this.F = false;
        X(bundle);
        if (this.F) {
            this.f1540u.r();
            return;
        }
        throw new x("Fragment " + this + " did not call through to super.onActivityCreated()");
    }

    public Object F() {
        d dVar = this.K;
        if (dVar == null) {
            return null;
        }
        return dVar.f1559j;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void F0() {
        this.f1540u.g(this.f1539t, new c(), this);
        this.f1521b = 0;
        this.F = false;
        a0(this.f1539t.i());
        if (this.F) {
            return;
        }
        throw new x("Fragment " + this + " did not call through to super.onAttach()");
    }

    public Object G() {
        d dVar = this.K;
        if (dVar == null) {
            return null;
        }
        Object obj = dVar.f1560k;
        return obj == X ? F() : obj;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void G0(Configuration configuration) {
        onConfigurationChanged(configuration);
        this.f1540u.s(configuration);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public int H() {
        d dVar = this.K;
        if (dVar == null) {
            return 0;
        }
        return dVar.f1552c;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public boolean H0(MenuItem menuItem) {
        if (this.f1545z) {
            return false;
        }
        return c0(menuItem) || this.f1540u.t(menuItem);
    }

    public final String I(int i2) {
        return C().getString(i2);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void I0(Bundle bundle) {
        this.f1540u.B0();
        this.f1521b = 1;
        this.F = false;
        this.V.c(bundle);
        d0(bundle);
        this.Q = true;
        if (this.F) {
            this.S.i(d.a.ON_CREATE);
            return;
        }
        throw new x("Fragment " + this + " did not call through to super.onCreate()");
    }

    public final String J() {
        return this.f1544y;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public boolean J0(Menu menu, MenuInflater menuInflater) {
        boolean z2 = false;
        if (this.f1545z) {
            return false;
        }
        if (this.D && this.E) {
            z2 = true;
            g0(menu, menuInflater);
        }
        return z2 | this.f1540u.v(menu, menuInflater);
    }

    public final Fragment K() {
        String str;
        Fragment fragment = this.f1527h;
        if (fragment != null) {
            return fragment;
        }
        l lVar = this.f1538s;
        if (lVar == null || (str = this.f1528i) == null) {
            return null;
        }
        return lVar.V(str);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void K0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.f1540u.B0();
        this.f1536q = true;
        this.T = new w();
        View h02 = h0(layoutInflater, viewGroup, bundle);
        this.H = h02;
        if (h02 != null) {
            this.T.e();
            this.U.m(this.T);
        } else if (this.T.f()) {
            throw new IllegalStateException("Called getViewLifecycleOwner() but onCreateView() returned null");
        } else {
            this.T = null;
        }
    }

    public final CharSequence L(int i2) {
        return C().getText(i2);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void L0() {
        this.f1540u.w();
        this.S.i(d.a.ON_DESTROY);
        this.f1521b = 0;
        this.F = false;
        this.Q = false;
        i0();
        if (this.F) {
            return;
        }
        throw new x("Fragment " + this + " did not call through to super.onDestroy()");
    }

    public View M() {
        return this.H;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void M0() {
        this.f1540u.x();
        if (this.H != null) {
            this.T.d(d.a.ON_DESTROY);
        }
        this.f1521b = 1;
        this.F = false;
        k0();
        if (this.F) {
            androidx.loader.app.a.b(this).c();
            this.f1536q = false;
            return;
        }
        throw new x("Fragment " + this + " did not call through to super.onDestroyView()");
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void N0() {
        this.f1521b = -1;
        this.F = false;
        l0();
        this.P = null;
        if (this.F) {
            if (this.f1540u.o0()) {
                return;
            }
            this.f1540u.w();
            this.f1540u = new m();
            return;
        }
        throw new x("Fragment " + this + " did not call through to super.onDetach()");
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void O() {
        N();
        this.f1525f = UUID.randomUUID().toString();
        this.f1531l = false;
        this.f1532m = false;
        this.f1533n = false;
        this.f1534o = false;
        this.f1535p = false;
        this.f1537r = 0;
        this.f1538s = null;
        this.f1540u = new m();
        this.f1539t = null;
        this.f1542w = 0;
        this.f1543x = 0;
        this.f1544y = null;
        this.f1545z = false;
        this.A = false;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public LayoutInflater O0(Bundle bundle) {
        LayoutInflater m02 = m0(bundle);
        this.P = m02;
        return m02;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void P0() {
        onLowMemory();
        this.f1540u.y();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public boolean Q() {
        d dVar = this.K;
        if (dVar == null) {
            return false;
        }
        return dVar.f1565p;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void Q0(boolean z2) {
        q0(z2);
        this.f1540u.z(z2);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final boolean R() {
        return this.f1537r > 0;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public boolean R0(MenuItem menuItem) {
        if (this.f1545z) {
            return false;
        }
        return (this.D && this.E && r0(menuItem)) || this.f1540u.A(menuItem);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public boolean S() {
        d dVar = this.K;
        if (dVar == null) {
            return false;
        }
        return dVar.f1563n;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void S0(Menu menu) {
        if (this.f1545z) {
            return;
        }
        if (this.D && this.E) {
            s0(menu);
        }
        this.f1540u.B(menu);
    }

    public final boolean T() {
        return this.f1532m;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void T0() {
        this.f1540u.D();
        if (this.H != null) {
            this.T.d(d.a.ON_PAUSE);
        }
        this.S.i(d.a.ON_PAUSE);
        this.f1521b = 3;
        this.F = false;
        t0();
        if (this.F) {
            return;
        }
        throw new x("Fragment " + this + " did not call through to super.onPause()");
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final boolean U() {
        Fragment z2 = z();
        return z2 != null && (z2.T() || z2.U());
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void U0(boolean z2) {
        u0(z2);
        this.f1540u.E(z2);
    }

    public final boolean V() {
        l lVar = this.f1538s;
        if (lVar == null) {
            return false;
        }
        return lVar.t0();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public boolean V0(Menu menu) {
        boolean z2 = false;
        if (this.f1545z) {
            return false;
        }
        if (this.D && this.E) {
            z2 = true;
            v0(menu);
        }
        return z2 | this.f1540u.F(menu);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void W() {
        this.f1540u.B0();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void W0() {
        boolean r02 = this.f1538s.r0(this);
        Boolean bool = this.f1530k;
        if (bool == null || bool.booleanValue() != r02) {
            this.f1530k = Boolean.valueOf(r02);
            w0(r02);
            this.f1540u.G();
        }
    }

    public void X(Bundle bundle) {
        this.F = true;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void X0() {
        this.f1540u.B0();
        this.f1540u.Q(true);
        this.f1521b = 4;
        this.F = false;
        y0();
        if (!this.F) {
            throw new x("Fragment " + this + " did not call through to super.onResume()");
        }
        androidx.lifecycle.h hVar = this.S;
        d.a aVar = d.a.ON_RESUME;
        hVar.i(aVar);
        if (this.H != null) {
            this.T.d(aVar);
        }
        this.f1540u.H();
    }

    public void Y(int i2, int i3, Intent intent) {
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void Y0(Bundle bundle) {
        z0(bundle);
        this.V.d(bundle);
        Parcelable Q0 = this.f1540u.Q0();
        if (Q0 != null) {
            bundle.putParcelable("android:support:fragments", Q0);
        }
    }

    @Deprecated
    public void Z(Activity activity) {
        this.F = true;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void Z0() {
        this.f1540u.B0();
        this.f1540u.Q(true);
        this.f1521b = 3;
        this.F = false;
        A0();
        if (!this.F) {
            throw new x("Fragment " + this + " did not call through to super.onStart()");
        }
        androidx.lifecycle.h hVar = this.S;
        d.a aVar = d.a.ON_START;
        hVar.i(aVar);
        if (this.H != null) {
            this.T.d(aVar);
        }
        this.f1540u.I();
    }

    @Override // androidx.lifecycle.g
    public androidx.lifecycle.d a() {
        return this.S;
    }

    public void a0(Context context) {
        this.F = true;
        i<?> iVar = this.f1539t;
        Activity h2 = iVar == null ? null : iVar.h();
        if (h2 != null) {
            this.F = false;
            Z(h2);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void a1() {
        this.f1540u.K();
        if (this.H != null) {
            this.T.d(d.a.ON_STOP);
        }
        this.S.i(d.a.ON_STOP);
        this.f1521b = 2;
        this.F = false;
        B0();
        if (this.F) {
            return;
        }
        throw new x("Fragment " + this + " did not call through to super.onStop()");
    }

    public void b0(Fragment fragment) {
    }

    public final androidx.fragment.app.d b1() {
        androidx.fragment.app.d i2 = i();
        if (i2 != null) {
            return i2;
        }
        throw new IllegalStateException("Fragment " + this + " not attached to an activity.");
    }

    @Override // androidx.savedstate.b
    public final SavedStateRegistry c() {
        return this.V.b();
    }

    public boolean c0(MenuItem menuItem) {
        return false;
    }

    public final Context c1() {
        Context p2 = p();
        if (p2 != null) {
            return p2;
        }
        throw new IllegalStateException("Fragment " + this + " not attached to a context.");
    }

    void d() {
        d dVar = this.K;
        f fVar = null;
        if (dVar != null) {
            dVar.f1563n = false;
            f fVar2 = dVar.f1564o;
            dVar.f1564o = null;
            fVar = fVar2;
        }
        if (fVar != null) {
            fVar.a();
        }
    }

    public void d0(Bundle bundle) {
        this.F = true;
        e1(bundle);
        if (this.f1540u.s0(1)) {
            return;
        }
        this.f1540u.u();
    }

    public final View d1() {
        View M = M();
        if (M != null) {
            return M;
        }
        throw new IllegalStateException("Fragment " + this + " did not return a View from onCreateView() or this was called before onCreateView().");
    }

    public void e(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        printWriter.print(str);
        printWriter.print("mFragmentId=#");
        printWriter.print(Integer.toHexString(this.f1542w));
        printWriter.print(" mContainerId=#");
        printWriter.print(Integer.toHexString(this.f1543x));
        printWriter.print(" mTag=");
        printWriter.println(this.f1544y);
        printWriter.print(str);
        printWriter.print("mState=");
        printWriter.print(this.f1521b);
        printWriter.print(" mWho=");
        printWriter.print(this.f1525f);
        printWriter.print(" mBackStackNesting=");
        printWriter.println(this.f1537r);
        printWriter.print(str);
        printWriter.print("mAdded=");
        printWriter.print(this.f1531l);
        printWriter.print(" mRemoving=");
        printWriter.print(this.f1532m);
        printWriter.print(" mFromLayout=");
        printWriter.print(this.f1533n);
        printWriter.print(" mInLayout=");
        printWriter.println(this.f1534o);
        printWriter.print(str);
        printWriter.print("mHidden=");
        printWriter.print(this.f1545z);
        printWriter.print(" mDetached=");
        printWriter.print(this.A);
        printWriter.print(" mMenuVisible=");
        printWriter.print(this.E);
        printWriter.print(" mHasMenu=");
        printWriter.println(this.D);
        printWriter.print(str);
        printWriter.print("mRetainInstance=");
        printWriter.print(this.B);
        printWriter.print(" mUserVisibleHint=");
        printWriter.println(this.J);
        if (this.f1538s != null) {
            printWriter.print(str);
            printWriter.print("mFragmentManager=");
            printWriter.println(this.f1538s);
        }
        if (this.f1539t != null) {
            printWriter.print(str);
            printWriter.print("mHost=");
            printWriter.println(this.f1539t);
        }
        if (this.f1541v != null) {
            printWriter.print(str);
            printWriter.print("mParentFragment=");
            printWriter.println(this.f1541v);
        }
        if (this.f1526g != null) {
            printWriter.print(str);
            printWriter.print("mArguments=");
            printWriter.println(this.f1526g);
        }
        if (this.f1522c != null) {
            printWriter.print(str);
            printWriter.print("mSavedFragmentState=");
            printWriter.println(this.f1522c);
        }
        if (this.f1523d != null) {
            printWriter.print(str);
            printWriter.print("mSavedViewState=");
            printWriter.println(this.f1523d);
        }
        Fragment K = K();
        if (K != null) {
            printWriter.print(str);
            printWriter.print("mTarget=");
            printWriter.print(K);
            printWriter.print(" mTargetRequestCode=");
            printWriter.println(this.f1529j);
        }
        if (x() != 0) {
            printWriter.print(str);
            printWriter.print("mNextAnim=");
            printWriter.println(x());
        }
        if (this.G != null) {
            printWriter.print(str);
            printWriter.print("mContainer=");
            printWriter.println(this.G);
        }
        if (this.H != null) {
            printWriter.print(str);
            printWriter.print("mView=");
            printWriter.println(this.H);
        }
        if (l() != null) {
            printWriter.print(str);
            printWriter.print("mAnimatingAway=");
            printWriter.println(l());
            printWriter.print(str);
            printWriter.print("mStateAfterAnimating=");
            printWriter.println(H());
        }
        if (p() != null) {
            androidx.loader.app.a.b(this).a(str, fileDescriptor, printWriter, strArr);
        }
        printWriter.print(str);
        printWriter.println("Child " + this.f1540u + ":");
        this.f1540u.M(str + "  ", fileDescriptor, printWriter, strArr);
    }

    public Animation e0(int i2, boolean z2, int i3) {
        return null;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void e1(Bundle bundle) {
        Parcelable parcelable;
        if (bundle == null || (parcelable = bundle.getParcelable("android:support:fragments")) == null) {
            return;
        }
        this.f1540u.O0(parcelable);
        this.f1540u.u();
    }

    public final boolean equals(Object obj) {
        return super.equals(obj);
    }

    public Animator f0(int i2, boolean z2, int i3) {
        return null;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final void f1(Bundle bundle) {
        SparseArray<Parcelable> sparseArray = this.f1523d;
        if (sparseArray != null) {
            this.H.restoreHierarchyState(sparseArray);
            this.f1523d = null;
        }
        this.F = false;
        D0(bundle);
        if (this.F) {
            if (this.H != null) {
                this.T.d(d.a.ON_CREATE);
                return;
            }
            return;
        }
        throw new x("Fragment " + this + " did not call through to super.onViewStateRestored()");
    }

    @Override // androidx.lifecycle.u
    public androidx.lifecycle.t g() {
        l lVar = this.f1538s;
        if (lVar != null) {
            return lVar.l0(this);
        }
        throw new IllegalStateException("Can't access ViewModels from detached fragment");
    }

    public void g0(Menu menu, MenuInflater menuInflater) {
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void g1(View view) {
        f().f1550a = view;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public Fragment h(String str) {
        return str.equals(this.f1525f) ? this : this.f1540u.Y(str);
    }

    public View h0(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        int i2 = this.W;
        if (i2 != 0) {
            return layoutInflater.inflate(i2, viewGroup, false);
        }
        return null;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void h1(Animator animator) {
        f().f1551b = animator;
    }

    public final int hashCode() {
        return super.hashCode();
    }

    public final androidx.fragment.app.d i() {
        i<?> iVar = this.f1539t;
        if (iVar == null) {
            return null;
        }
        return (androidx.fragment.app.d) iVar.h();
    }

    public void i0() {
        this.F = true;
    }

    public void i1(Bundle bundle) {
        if (this.f1538s != null && V()) {
            throw new IllegalStateException("Fragment already added and state has been saved");
        }
        this.f1526g = bundle;
    }

    public boolean j() {
        Boolean bool;
        d dVar = this.K;
        if (dVar == null || (bool = dVar.f1562m) == null) {
            return true;
        }
        return bool.booleanValue();
    }

    public void j0() {
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void j1(boolean z2) {
        f().f1565p = z2;
    }

    public boolean k() {
        Boolean bool;
        d dVar = this.K;
        if (dVar == null || (bool = dVar.f1561l) == null) {
            return true;
        }
        return bool.booleanValue();
    }

    public void k0() {
        this.F = true;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void k1(int i2) {
        if (this.K == null && i2 == 0) {
            return;
        }
        f().f1553d = i2;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public View l() {
        d dVar = this.K;
        if (dVar == null) {
            return null;
        }
        return dVar.f1550a;
    }

    public void l0() {
        this.F = true;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void l1(int i2) {
        if (this.K == null && i2 == 0) {
            return;
        }
        f();
        this.K.f1554e = i2;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public Animator m() {
        d dVar = this.K;
        if (dVar == null) {
            return null;
        }
        return dVar.f1551b;
    }

    public LayoutInflater m0(Bundle bundle) {
        return w(bundle);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void m1(f fVar) {
        f();
        d dVar = this.K;
        f fVar2 = dVar.f1564o;
        if (fVar == fVar2) {
            return;
        }
        if (fVar != null && fVar2 != null) {
            throw new IllegalStateException("Trying to set a replacement startPostponedEnterTransition on " + this);
        }
        if (dVar.f1563n) {
            dVar.f1564o = fVar;
        }
        if (fVar != null) {
            fVar.b();
        }
    }

    public final Bundle n() {
        return this.f1526g;
    }

    public void n0(boolean z2) {
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void n1(int i2) {
        f().f1552c = i2;
    }

    public final l o() {
        if (this.f1539t != null) {
            return this.f1540u;
        }
        throw new IllegalStateException("Fragment " + this + " has not been attached yet.");
    }

    @Deprecated
    public void o0(Activity activity, AttributeSet attributeSet, Bundle bundle) {
        this.F = true;
    }

    public void o1() {
        l lVar = this.f1538s;
        if (lVar == null || lVar.f1654o == null) {
            f().f1563n = false;
        } else if (Looper.myLooper() != this.f1538s.f1654o.j().getLooper()) {
            this.f1538s.f1654o.j().postAtFrontOfQueue(new b());
        } else {
            d();
        }
    }

    @Override // android.content.ComponentCallbacks
    public void onConfigurationChanged(Configuration configuration) {
        this.F = true;
    }

    @Override // android.view.View.OnCreateContextMenuListener
    public void onCreateContextMenu(ContextMenu contextMenu, View view, ContextMenu.ContextMenuInfo contextMenuInfo) {
        b1().onCreateContextMenu(contextMenu, view, contextMenuInfo);
    }

    @Override // android.content.ComponentCallbacks
    public void onLowMemory() {
        this.F = true;
    }

    public Context p() {
        i<?> iVar = this.f1539t;
        if (iVar == null) {
            return null;
        }
        return iVar.i();
    }

    public void p0(Context context, AttributeSet attributeSet, Bundle bundle) {
        this.F = true;
        i<?> iVar = this.f1539t;
        Activity h2 = iVar == null ? null : iVar.h();
        if (h2 != null) {
            this.F = false;
            o0(h2, attributeSet, bundle);
        }
    }

    public Object q() {
        d dVar = this.K;
        if (dVar == null) {
            return null;
        }
        return dVar.f1555f;
    }

    public void q0(boolean z2) {
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public t.g r() {
        d dVar = this.K;
        if (dVar == null) {
            return null;
        }
        Objects.requireNonNull(dVar);
        return null;
    }

    public boolean r0(MenuItem menuItem) {
        return false;
    }

    public Object s() {
        d dVar = this.K;
        if (dVar == null) {
            return null;
        }
        return dVar.f1557h;
    }

    public void s0(Menu menu) {
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public t.g t() {
        d dVar = this.K;
        if (dVar == null) {
            return null;
        }
        Objects.requireNonNull(dVar);
        return null;
    }

    public void t0() {
        this.F = true;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append(getClass().getSimpleName());
        sb.append("{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        sb.append("}");
        sb.append(" (");
        sb.append(this.f1525f);
        sb.append(")");
        if (this.f1542w != 0) {
            sb.append(" id=0x");
            sb.append(Integer.toHexString(this.f1542w));
        }
        if (this.f1544y != null) {
            sb.append(" ");
            sb.append(this.f1544y);
        }
        sb.append('}');
        return sb.toString();
    }

    public final Object u() {
        i<?> iVar = this.f1539t;
        if (iVar == null) {
            return null;
        }
        return iVar.l();
    }

    public void u0(boolean z2) {
    }

    public final int v() {
        return this.f1542w;
    }

    public void v0(Menu menu) {
    }

    @Deprecated
    public LayoutInflater w(Bundle bundle) {
        i<?> iVar = this.f1539t;
        if (iVar != null) {
            LayoutInflater m2 = iVar.m();
            e0.f.a(m2, this.f1540u.g0());
            return m2;
        }
        throw new IllegalStateException("onGetLayoutInflater() cannot be executed until the Fragment is attached to the FragmentManager.");
    }

    public void w0(boolean z2) {
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public int x() {
        d dVar = this.K;
        if (dVar == null) {
            return 0;
        }
        return dVar.f1553d;
    }

    public void x0(int i2, String[] strArr, int[] iArr) {
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public int y() {
        d dVar = this.K;
        if (dVar == null) {
            return 0;
        }
        return dVar.f1554e;
    }

    public void y0() {
        this.F = true;
    }

    public final Fragment z() {
        return this.f1541v;
    }

    public void z0(Bundle bundle) {
    }
}
