package q;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import p.e;
import q.b;
/* loaded from: classes.dex */
public class e {

    /* renamed from: a  reason: collision with root package name */
    private p.f f4998a;

    /* renamed from: d  reason: collision with root package name */
    private p.f f5001d;

    /* renamed from: b  reason: collision with root package name */
    private boolean f4999b = true;

    /* renamed from: c  reason: collision with root package name */
    private boolean f5000c = true;

    /* renamed from: e  reason: collision with root package name */
    private ArrayList<p> f5002e = new ArrayList<>();

    /* renamed from: f  reason: collision with root package name */
    private ArrayList<m> f5003f = new ArrayList<>();

    /* renamed from: g  reason: collision with root package name */
    private b.InterfaceC0068b f5004g = null;

    /* renamed from: h  reason: collision with root package name */
    private b.a f5005h = new b.a();

    /* renamed from: i  reason: collision with root package name */
    ArrayList<m> f5006i = new ArrayList<>();

    public e(p.f fVar) {
        this.f4998a = fVar;
        this.f5001d = fVar;
    }

    private void a(f fVar, int i2, int i3, f fVar2, ArrayList<m> arrayList, m mVar) {
        p pVar = fVar.f5010d;
        if (pVar.f5060c == null) {
            p.f fVar3 = this.f4998a;
            if (pVar == fVar3.f4895e || pVar == fVar3.f4897f) {
                return;
            }
            if (mVar == null) {
                mVar = new m(pVar, i3);
                arrayList.add(mVar);
            }
            pVar.f5060c = mVar;
            mVar.a(pVar);
            for (d dVar : pVar.f5065h.f5017k) {
                if (dVar instanceof f) {
                    a((f) dVar, i2, 0, fVar2, arrayList, mVar);
                }
            }
            for (d dVar2 : pVar.f5066i.f5017k) {
                if (dVar2 instanceof f) {
                    a((f) dVar2, i2, 1, fVar2, arrayList, mVar);
                }
            }
            if (i2 == 1 && (pVar instanceof n)) {
                for (d dVar3 : ((n) pVar).f5040k.f5017k) {
                    if (dVar3 instanceof f) {
                        a((f) dVar3, i2, 2, fVar2, arrayList, mVar);
                    }
                }
            }
            for (f fVar4 : pVar.f5065h.f5018l) {
                if (fVar4 == fVar2) {
                    mVar.f5034b = true;
                }
                a(fVar4, i2, 0, fVar2, arrayList, mVar);
            }
            for (f fVar5 : pVar.f5066i.f5018l) {
                if (fVar5 == fVar2) {
                    mVar.f5034b = true;
                }
                a(fVar5, i2, 1, fVar2, arrayList, mVar);
            }
            if (i2 == 1 && (pVar instanceof n)) {
                Iterator<f> it = ((n) pVar).f5040k.f5018l.iterator();
                while (it.hasNext()) {
                    a(it.next(), i2, 2, fVar2, arrayList, mVar);
                }
            }
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:39:0x0074, code lost:
        if (r2.f4919q == 0) goto L32;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private boolean b(p.f r17) {
        /*
            Method dump skipped, instructions count: 625
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: q.e.b(p.f):boolean");
    }

    private int e(p.f fVar, int i2) {
        int size = this.f5006i.size();
        long j2 = 0;
        for (int i3 = 0; i3 < size; i3++) {
            j2 = Math.max(j2, this.f5006i.get(i3).b(fVar, i2));
        }
        return (int) j2;
    }

    private void i(p pVar, int i2, ArrayList<m> arrayList) {
        for (d dVar : pVar.f5065h.f5017k) {
            if (dVar instanceof f) {
                a((f) dVar, i2, 0, pVar.f5066i, arrayList, null);
            } else if (dVar instanceof p) {
                a(((p) dVar).f5065h, i2, 0, pVar.f5066i, arrayList, null);
            }
        }
        for (d dVar2 : pVar.f5066i.f5017k) {
            if (dVar2 instanceof f) {
                a((f) dVar2, i2, 1, pVar.f5065h, arrayList, null);
            } else if (dVar2 instanceof p) {
                a(((p) dVar2).f5066i, i2, 1, pVar.f5065h, arrayList, null);
            }
        }
        if (i2 == 1) {
            for (d dVar3 : ((n) pVar).f5040k.f5017k) {
                if (dVar3 instanceof f) {
                    a((f) dVar3, i2, 2, null, arrayList, null);
                }
            }
        }
    }

    private void l(p.e eVar, e.b bVar, int i2, e.b bVar2, int i3) {
        b.a aVar = this.f5005h;
        aVar.f4986a = bVar;
        aVar.f4987b = bVar2;
        aVar.f4988c = i2;
        aVar.f4989d = i3;
        this.f5004g.b(eVar, aVar);
        eVar.U0(this.f5005h.f4990e);
        eVar.v0(this.f5005h.f4991f);
        eVar.u0(this.f5005h.f4993h);
        eVar.k0(this.f5005h.f4992g);
    }

    public void c() {
        d(this.f5002e);
        this.f5006i.clear();
        m.f5032h = 0;
        i(this.f4998a.f4895e, 0, this.f5006i);
        i(this.f4998a.f4897f, 1, this.f5006i);
        this.f4999b = false;
    }

    public void d(ArrayList<p> arrayList) {
        p jVar;
        arrayList.clear();
        this.f5001d.f4895e.f();
        this.f5001d.f4897f.f();
        arrayList.add(this.f5001d.f4895e);
        arrayList.add(this.f5001d.f4897f);
        Iterator<p.e> it = this.f5001d.D0.iterator();
        HashSet hashSet = null;
        while (it.hasNext()) {
            p.e next = it.next();
            if (next instanceof p.g) {
                jVar = new j(next);
            } else {
                if (next.Z()) {
                    if (next.f4891c == null) {
                        next.f4891c = new c(next, 0);
                    }
                    if (hashSet == null) {
                        hashSet = new HashSet();
                    }
                    hashSet.add(next.f4891c);
                } else {
                    arrayList.add(next.f4895e);
                }
                if (next.b0()) {
                    if (next.f4893d == null) {
                        next.f4893d = new c(next, 1);
                    }
                    if (hashSet == null) {
                        hashSet = new HashSet();
                    }
                    hashSet.add(next.f4893d);
                } else {
                    arrayList.add(next.f4897f);
                }
                if (next instanceof p.i) {
                    jVar = new k(next);
                }
            }
            arrayList.add(jVar);
        }
        if (hashSet != null) {
            arrayList.addAll(hashSet);
        }
        Iterator<p> it2 = arrayList.iterator();
        while (it2.hasNext()) {
            it2.next().f();
        }
        Iterator<p> it3 = arrayList.iterator();
        while (it3.hasNext()) {
            p next2 = it3.next();
            if (next2.f5059b != this.f5001d) {
                next2.d();
            }
        }
    }

    public boolean f(boolean z2) {
        boolean z3;
        boolean z4 = true;
        boolean z5 = z2 & true;
        if (this.f4999b || this.f5000c) {
            Iterator<p.e> it = this.f4998a.D0.iterator();
            while (it.hasNext()) {
                p.e next = it.next();
                next.l();
                next.f4887a = false;
                next.f4895e.r();
                next.f4897f.q();
            }
            this.f4998a.l();
            p.f fVar = this.f4998a;
            fVar.f4887a = false;
            fVar.f4895e.r();
            this.f4998a.f4897f.q();
            this.f5000c = false;
        }
        if (b(this.f5001d)) {
            return false;
        }
        this.f4998a.V0(0);
        this.f4998a.W0(0);
        e.b s2 = this.f4998a.s(0);
        e.b s3 = this.f4998a.s(1);
        if (this.f4999b) {
            c();
        }
        int S = this.f4998a.S();
        int T = this.f4998a.T();
        this.f4998a.f4895e.f5065h.d(S);
        this.f4998a.f4897f.f5065h.d(T);
        m();
        e.b bVar = e.b.WRAP_CONTENT;
        if (s2 == bVar || s3 == bVar) {
            if (z5) {
                Iterator<p> it2 = this.f5002e.iterator();
                while (true) {
                    if (!it2.hasNext()) {
                        break;
                    } else if (!it2.next().m()) {
                        z5 = false;
                        break;
                    }
                }
            }
            if (z5 && s2 == e.b.WRAP_CONTENT) {
                this.f4998a.z0(e.b.FIXED);
                p.f fVar2 = this.f4998a;
                fVar2.U0(e(fVar2, 0));
                p.f fVar3 = this.f4998a;
                fVar3.f4895e.f5062e.d(fVar3.R());
            }
            if (z5 && s3 == e.b.WRAP_CONTENT) {
                this.f4998a.Q0(e.b.FIXED);
                p.f fVar4 = this.f4998a;
                fVar4.v0(e(fVar4, 1));
                p.f fVar5 = this.f4998a;
                fVar5.f4897f.f5062e.d(fVar5.v());
            }
        }
        p.f fVar6 = this.f4998a;
        e.b[] bVarArr = fVar6.S;
        e.b bVar2 = bVarArr[0];
        e.b bVar3 = e.b.FIXED;
        if (bVar2 == bVar3 || bVarArr[0] == e.b.MATCH_PARENT) {
            int R = fVar6.R() + S;
            this.f4998a.f4895e.f5066i.d(R);
            this.f4998a.f4895e.f5062e.d(R - S);
            m();
            p.f fVar7 = this.f4998a;
            e.b[] bVarArr2 = fVar7.S;
            if (bVarArr2[1] == bVar3 || bVarArr2[1] == e.b.MATCH_PARENT) {
                int v2 = fVar7.v() + T;
                this.f4998a.f4897f.f5066i.d(v2);
                this.f4998a.f4897f.f5062e.d(v2 - T);
            }
            m();
            z3 = true;
        } else {
            z3 = false;
        }
        Iterator<p> it3 = this.f5002e.iterator();
        while (it3.hasNext()) {
            p next2 = it3.next();
            if (next2.f5059b != this.f4998a || next2.f5064g) {
                next2.e();
            }
        }
        Iterator<p> it4 = this.f5002e.iterator();
        while (it4.hasNext()) {
            p next3 = it4.next();
            if (z3 || next3.f5059b != this.f4998a) {
                if (!next3.f5065h.f5016j || ((!next3.f5066i.f5016j && !(next3 instanceof j)) || (!next3.f5062e.f5016j && !(next3 instanceof c) && !(next3 instanceof j)))) {
                    z4 = false;
                    break;
                }
            }
        }
        this.f4998a.z0(s2);
        this.f4998a.Q0(s3);
        return z4;
    }

    public boolean g(boolean z2) {
        if (this.f4999b) {
            Iterator<p.e> it = this.f4998a.D0.iterator();
            while (it.hasNext()) {
                p.e next = it.next();
                next.l();
                next.f4887a = false;
                l lVar = next.f4895e;
                lVar.f5062e.f5016j = false;
                lVar.f5064g = false;
                lVar.r();
                n nVar = next.f4897f;
                nVar.f5062e.f5016j = false;
                nVar.f5064g = false;
                nVar.q();
            }
            this.f4998a.l();
            p.f fVar = this.f4998a;
            fVar.f4887a = false;
            l lVar2 = fVar.f4895e;
            lVar2.f5062e.f5016j = false;
            lVar2.f5064g = false;
            lVar2.r();
            n nVar2 = this.f4998a.f4897f;
            nVar2.f5062e.f5016j = false;
            nVar2.f5064g = false;
            nVar2.q();
            c();
        }
        if (b(this.f5001d)) {
            return false;
        }
        this.f4998a.V0(0);
        this.f4998a.W0(0);
        this.f4998a.f4895e.f5065h.d(0);
        this.f4998a.f4897f.f5065h.d(0);
        return true;
    }

    public boolean h(boolean z2, int i2) {
        boolean z3;
        e.b bVar;
        g gVar;
        int v2;
        boolean z4 = true;
        boolean z5 = z2 & true;
        e.b s2 = this.f4998a.s(0);
        e.b s3 = this.f4998a.s(1);
        int S = this.f4998a.S();
        int T = this.f4998a.T();
        if (z5 && (s2 == (bVar = e.b.WRAP_CONTENT) || s3 == bVar)) {
            Iterator<p> it = this.f5002e.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                p next = it.next();
                if (next.f5063f == i2 && !next.m()) {
                    z5 = false;
                    break;
                }
            }
            if (i2 == 0) {
                if (z5 && s2 == e.b.WRAP_CONTENT) {
                    this.f4998a.z0(e.b.FIXED);
                    p.f fVar = this.f4998a;
                    fVar.U0(e(fVar, 0));
                    p.f fVar2 = this.f4998a;
                    gVar = fVar2.f4895e.f5062e;
                    v2 = fVar2.R();
                    gVar.d(v2);
                }
            } else if (z5 && s3 == e.b.WRAP_CONTENT) {
                this.f4998a.Q0(e.b.FIXED);
                p.f fVar3 = this.f4998a;
                fVar3.v0(e(fVar3, 1));
                p.f fVar4 = this.f4998a;
                gVar = fVar4.f4897f.f5062e;
                v2 = fVar4.v();
                gVar.d(v2);
            }
        }
        p.f fVar5 = this.f4998a;
        if (i2 == 0) {
            e.b[] bVarArr = fVar5.S;
            if (bVarArr[0] == e.b.FIXED || bVarArr[0] == e.b.MATCH_PARENT) {
                int R = fVar5.R() + S;
                this.f4998a.f4895e.f5066i.d(R);
                this.f4998a.f4895e.f5062e.d(R - S);
                z3 = true;
            }
            z3 = false;
        } else {
            e.b[] bVarArr2 = fVar5.S;
            if (bVarArr2[1] == e.b.FIXED || bVarArr2[1] == e.b.MATCH_PARENT) {
                int v3 = fVar5.v() + T;
                this.f4998a.f4897f.f5066i.d(v3);
                this.f4998a.f4897f.f5062e.d(v3 - T);
                z3 = true;
            }
            z3 = false;
        }
        m();
        Iterator<p> it2 = this.f5002e.iterator();
        while (it2.hasNext()) {
            p next2 = it2.next();
            if (next2.f5063f == i2 && (next2.f5059b != this.f4998a || next2.f5064g)) {
                next2.e();
            }
        }
        Iterator<p> it3 = this.f5002e.iterator();
        while (it3.hasNext()) {
            p next3 = it3.next();
            if (next3.f5063f == i2 && (z3 || next3.f5059b != this.f4998a)) {
                if (!next3.f5065h.f5016j || !next3.f5066i.f5016j || (!(next3 instanceof c) && !next3.f5062e.f5016j)) {
                    z4 = false;
                    break;
                }
            }
        }
        this.f4998a.z0(s2);
        this.f4998a.Q0(s3);
        return z4;
    }

    public void j() {
        this.f4999b = true;
    }

    public void k() {
        this.f5000c = true;
    }

    /* JADX WARN: Removed duplicated region for block: B:48:0x00b2 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:52:0x0008 A[ADDED_TO_REGION, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void m() {
        /*
            r12 = this;
            p.f r0 = r12.f4998a
            java.util.ArrayList<p.e> r0 = r0.D0
            java.util.Iterator r0 = r0.iterator()
        L8:
            boolean r1 = r0.hasNext()
            if (r1 == 0) goto Lc1
            java.lang.Object r1 = r0.next()
            p.e r1 = (p.e) r1
            boolean r2 = r1.f4887a
            if (r2 == 0) goto L19
            goto L8
        L19:
            p.e$b[] r2 = r1.S
            r3 = 0
            r8 = r2[r3]
            r9 = 1
            r10 = r2[r9]
            int r2 = r1.f4917p
            int r4 = r1.f4919q
            p.e$b r6 = p.e.b.WRAP_CONTENT
            if (r8 == r6) goto L32
            p.e$b r5 = p.e.b.MATCH_CONSTRAINT
            if (r8 != r5) goto L30
            if (r2 != r9) goto L30
            goto L32
        L30:
            r2 = 0
            goto L33
        L32:
            r2 = 1
        L33:
            if (r10 == r6) goto L3b
            p.e$b r5 = p.e.b.MATCH_CONSTRAINT
            if (r10 != r5) goto L3c
            if (r4 != r9) goto L3c
        L3b:
            r3 = 1
        L3c:
            q.l r4 = r1.f4895e
            q.g r4 = r4.f5062e
            boolean r5 = r4.f5016j
            q.n r7 = r1.f4897f
            q.g r7 = r7.f5062e
            boolean r11 = r7.f5016j
            if (r5 == 0) goto L5b
            if (r11 == 0) goto L5b
            p.e$b r6 = p.e.b.FIXED
            int r5 = r4.f5013g
            int r7 = r7.f5013g
            r2 = r12
            r3 = r1
            r4 = r6
            r2.l(r3, r4, r5, r6, r7)
        L58:
            r1.f4887a = r9
            goto Lae
        L5b:
            if (r5 == 0) goto L87
            if (r3 == 0) goto L87
            p.e$b r5 = p.e.b.FIXED
            int r8 = r4.f5013g
            int r7 = r7.f5013g
            r2 = r12
            r3 = r1
            r4 = r5
            r5 = r8
            r2.l(r3, r4, r5, r6, r7)
            p.e$b r2 = p.e.b.MATCH_CONSTRAINT
            if (r10 != r2) goto L7b
            q.n r2 = r1.f4897f
            q.g r2 = r2.f5062e
            int r3 = r1.v()
        L78:
            r2.f5028m = r3
            goto Lae
        L7b:
            q.n r2 = r1.f4897f
            q.g r2 = r2.f5062e
            int r3 = r1.v()
        L83:
            r2.d(r3)
            goto L58
        L87:
            if (r11 == 0) goto Lae
            if (r2 == 0) goto Lae
            int r5 = r4.f5013g
            p.e$b r10 = p.e.b.FIXED
            int r7 = r7.f5013g
            r2 = r12
            r3 = r1
            r4 = r6
            r6 = r10
            r2.l(r3, r4, r5, r6, r7)
            p.e$b r2 = p.e.b.MATCH_CONSTRAINT
            if (r8 != r2) goto La5
            q.l r2 = r1.f4895e
            q.g r2 = r2.f5062e
            int r3 = r1.R()
            goto L78
        La5:
            q.l r2 = r1.f4895e
            q.g r2 = r2.f5062e
            int r3 = r1.R()
            goto L83
        Lae:
            boolean r2 = r1.f4887a
            if (r2 == 0) goto L8
            q.n r2 = r1.f4897f
            q.g r2 = r2.f5041l
            if (r2 == 0) goto L8
            int r1 = r1.n()
            r2.d(r1)
            goto L8
        Lc1:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: q.e.m():void");
    }

    public void n(b.InterfaceC0068b interfaceC0068b) {
        this.f5004g = interfaceC0068b;
    }
}
