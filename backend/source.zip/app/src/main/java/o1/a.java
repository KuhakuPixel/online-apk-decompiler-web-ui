package o1;

import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import q1.g;
import q1.k;
import q1.n;
/* loaded from: classes.dex */
public class a extends Drawable implements n, x.b {

    /* renamed from: b  reason: collision with root package name */
    private b f4830b;

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public static final class b extends Drawable.ConstantState {

        /* renamed from: a  reason: collision with root package name */
        g f4831a;

        /* renamed from: b  reason: collision with root package name */
        boolean f4832b;

        public b(b bVar) {
            this.f4831a = (g) bVar.f4831a.getConstantState().newDrawable();
            this.f4832b = bVar.f4832b;
        }

        public b(g gVar) {
            this.f4831a = gVar;
            this.f4832b = false;
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        /* renamed from: a  reason: merged with bridge method [inline-methods] */
        public a newDrawable() {
            return new a(new b(this));
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public int getChangingConfigurations() {
            return 0;
        }
    }

    private a(b bVar) {
        this.f4830b = bVar;
    }

    public a(k kVar) {
        this(new b(new g(kVar)));
    }

    @Override // android.graphics.drawable.Drawable
    /* renamed from: a  reason: merged with bridge method [inline-methods] */
    public a mutate() {
        this.f4830b = new b(this.f4830b);
        return this;
    }

    @Override // android.graphics.drawable.Drawable
    public void draw(Canvas canvas) {
        b bVar = this.f4830b;
        if (bVar.f4832b) {
            bVar.f4831a.draw(canvas);
        }
    }

    @Override // android.graphics.drawable.Drawable
    public Drawable.ConstantState getConstantState() {
        return this.f4830b;
    }

    @Override // android.graphics.drawable.Drawable
    public int getOpacity() {
        return this.f4830b.f4831a.getOpacity();
    }

    @Override // android.graphics.drawable.Drawable
    public boolean isStateful() {
        return true;
    }

    @Override // android.graphics.drawable.Drawable
    protected void onBoundsChange(Rect rect) {
        super.onBoundsChange(rect);
        this.f4830b.f4831a.setBounds(rect);
    }

    @Override // android.graphics.drawable.Drawable
    protected boolean onStateChange(int[] iArr) {
        boolean onStateChange = super.onStateChange(iArr);
        if (this.f4830b.f4831a.setState(iArr)) {
            onStateChange = true;
        }
        boolean b2 = o1.b.b(iArr);
        b bVar = this.f4830b;
        if (bVar.f4832b != b2) {
            bVar.f4832b = b2;
            return true;
        }
        return onStateChange;
    }

    @Override // android.graphics.drawable.Drawable
    public void setAlpha(int i2) {
        this.f4830b.f4831a.setAlpha(i2);
    }

    @Override // android.graphics.drawable.Drawable
    public void setColorFilter(ColorFilter colorFilter) {
        this.f4830b.f4831a.setColorFilter(colorFilter);
    }

    @Override // q1.n
    public void setShapeAppearanceModel(k kVar) {
        this.f4830b.f4831a.setShapeAppearanceModel(kVar);
    }

    @Override // android.graphics.drawable.Drawable
    public void setTint(int i2) {
        this.f4830b.f4831a.setTint(i2);
    }

    @Override // android.graphics.drawable.Drawable
    public void setTintList(ColorStateList colorStateList) {
        this.f4830b.f4831a.setTintList(colorStateList);
    }

    @Override // android.graphics.drawable.Drawable
    public void setTintMode(PorterDuff.Mode mode) {
        this.f4830b.f4831a.setTintMode(mode);
    }
}
