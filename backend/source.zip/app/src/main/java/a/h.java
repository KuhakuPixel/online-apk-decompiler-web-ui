package a;
/* loaded from: classes.dex */
public final class h {

    /* renamed from: a */
    public static final int abc_action_bar_up_description = 2131820545;

    /* renamed from: b */
    public static final int abc_menu_alt_shortcut_label = 2131820552;

    /* renamed from: c */
    public static final int abc_menu_ctrl_shortcut_label = 2131820553;

    /* renamed from: d */
    public static final int abc_menu_delete_shortcut_label = 2131820554;

    /* renamed from: e */
    public static final int abc_menu_enter_shortcut_label = 2131820555;

    /* renamed from: f */
    public static final int abc_menu_function_shortcut_label = 2131820556;

    /* renamed from: g */
    public static final int abc_menu_meta_shortcut_label = 2131820557;

    /* renamed from: h */
    public static final int abc_menu_shift_shortcut_label = 2131820558;

    /* renamed from: i */
    public static final int abc_menu_space_shortcut_label = 2131820559;

    /* renamed from: j */
    public static final int abc_menu_sym_shortcut_label = 2131820560;

    /* renamed from: k */
    public static final int abc_prepend_shortcut_label = 2131820561;

    /* renamed from: l */
    public static final int abc_searchview_description_search = 2131820565;
}
