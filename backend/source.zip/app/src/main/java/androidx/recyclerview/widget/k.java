package androidx.recyclerview.widget;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import e0.q;
import java.util.Map;
import java.util.WeakHashMap;
/* loaded from: classes.dex */
public class k extends e0.a {

    /* renamed from: d  reason: collision with root package name */
    final RecyclerView f2465d;

    /* renamed from: e  reason: collision with root package name */
    private final a f2466e;

    /* loaded from: classes.dex */
    public static class a extends e0.a {

        /* renamed from: d  reason: collision with root package name */
        final k f2467d;

        /* renamed from: e  reason: collision with root package name */
        private Map<View, e0.a> f2468e = new WeakHashMap();

        public a(k kVar) {
            this.f2467d = kVar;
        }

        @Override // e0.a
        public boolean a(View view, AccessibilityEvent accessibilityEvent) {
            e0.a aVar = this.f2468e.get(view);
            return aVar != null ? aVar.a(view, accessibilityEvent) : super.a(view, accessibilityEvent);
        }

        @Override // e0.a
        public f0.d b(View view) {
            e0.a aVar = this.f2468e.get(view);
            return aVar != null ? aVar.b(view) : super.b(view);
        }

        @Override // e0.a
        public void f(View view, AccessibilityEvent accessibilityEvent) {
            e0.a aVar = this.f2468e.get(view);
            if (aVar != null) {
                aVar.f(view, accessibilityEvent);
            } else {
                super.f(view, accessibilityEvent);
            }
        }

        @Override // e0.a
        public void g(View view, f0.c cVar) {
            if (!this.f2467d.o() && this.f2467d.f2465d.getLayoutManager() != null) {
                this.f2467d.f2465d.getLayoutManager().O0(view, cVar);
                e0.a aVar = this.f2468e.get(view);
                if (aVar != null) {
                    aVar.g(view, cVar);
                    return;
                }
            }
            super.g(view, cVar);
        }

        @Override // e0.a
        public void h(View view, AccessibilityEvent accessibilityEvent) {
            e0.a aVar = this.f2468e.get(view);
            if (aVar != null) {
                aVar.h(view, accessibilityEvent);
            } else {
                super.h(view, accessibilityEvent);
            }
        }

        @Override // e0.a
        public boolean i(ViewGroup viewGroup, View view, AccessibilityEvent accessibilityEvent) {
            e0.a aVar = this.f2468e.get(viewGroup);
            return aVar != null ? aVar.i(viewGroup, view, accessibilityEvent) : super.i(viewGroup, view, accessibilityEvent);
        }

        @Override // e0.a
        public boolean j(View view, int i2, Bundle bundle) {
            if (this.f2467d.o() || this.f2467d.f2465d.getLayoutManager() == null) {
                return super.j(view, i2, bundle);
            }
            e0.a aVar = this.f2468e.get(view);
            if (aVar != null) {
                if (aVar.j(view, i2, bundle)) {
                    return true;
                }
            } else if (super.j(view, i2, bundle)) {
                return true;
            }
            return this.f2467d.f2465d.getLayoutManager().i1(view, i2, bundle);
        }

        @Override // e0.a
        public void l(View view, int i2) {
            e0.a aVar = this.f2468e.get(view);
            if (aVar != null) {
                aVar.l(view, i2);
            } else {
                super.l(view, i2);
            }
        }

        @Override // e0.a
        public void m(View view, AccessibilityEvent accessibilityEvent) {
            e0.a aVar = this.f2468e.get(view);
            if (aVar != null) {
                aVar.m(view, accessibilityEvent);
            } else {
                super.m(view, accessibilityEvent);
            }
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public e0.a n(View view) {
            return this.f2468e.remove(view);
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public void o(View view) {
            e0.a l2 = q.l(view);
            if (l2 == null || l2 == this) {
                return;
            }
            this.f2468e.put(view, l2);
        }
    }

    public k(RecyclerView recyclerView) {
        this.f2465d = recyclerView;
        e0.a n2 = n();
        this.f2466e = (n2 == null || !(n2 instanceof a)) ? new a(this) : (a) n2;
    }

    @Override // e0.a
    public void f(View view, AccessibilityEvent accessibilityEvent) {
        super.f(view, accessibilityEvent);
        if (!(view instanceof RecyclerView) || o()) {
            return;
        }
        RecyclerView recyclerView = (RecyclerView) view;
        if (recyclerView.getLayoutManager() != null) {
            recyclerView.getLayoutManager().K0(accessibilityEvent);
        }
    }

    @Override // e0.a
    public void g(View view, f0.c cVar) {
        super.g(view, cVar);
        if (o() || this.f2465d.getLayoutManager() == null) {
            return;
        }
        this.f2465d.getLayoutManager().N0(cVar);
    }

    @Override // e0.a
    public boolean j(View view, int i2, Bundle bundle) {
        if (super.j(view, i2, bundle)) {
            return true;
        }
        if (o() || this.f2465d.getLayoutManager() == null) {
            return false;
        }
        return this.f2465d.getLayoutManager().g1(i2, bundle);
    }

    public e0.a n() {
        return this.f2466e;
    }

    boolean o() {
        return this.f2465d.l0();
    }
}
