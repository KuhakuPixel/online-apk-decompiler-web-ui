package androidx.databinding;

import java.util.Map;
/* loaded from: classes.dex */
public interface i<K, V> extends Map<K, V> {

    /* loaded from: classes.dex */
    public static abstract class a<T extends i<K, V>, K, V> {
    }

    void a(a<? extends i<K, V>, K, V> aVar);

    void b(a<? extends i<K, V>, K, V> aVar);
}
