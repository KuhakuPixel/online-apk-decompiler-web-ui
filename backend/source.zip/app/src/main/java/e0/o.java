package e0;

import android.view.View;
/* loaded from: classes.dex */
public interface o {
    y a(View view, y yVar);
}
