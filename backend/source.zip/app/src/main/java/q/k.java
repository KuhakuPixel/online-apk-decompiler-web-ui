package q;

import java.util.Iterator;
import q.f;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes.dex */
public class k extends p {
    public k(p.e eVar) {
        super(eVar);
    }

    private void q(f fVar) {
        this.f5065h.f5017k.add(fVar);
        fVar.f5018l.add(this.f5065h);
    }

    @Override // q.p, q.d
    public void a(d dVar) {
        p.a aVar = (p.a) this.f5059b;
        int e12 = aVar.e1();
        Iterator<f> it = this.f5065h.f5018l.iterator();
        int i2 = 0;
        int i3 = -1;
        while (it.hasNext()) {
            int i4 = it.next().f5013g;
            if (i3 == -1 || i4 < i3) {
                i3 = i4;
            }
            if (i2 < i4) {
                i2 = i4;
            }
        }
        if (e12 == 0 || e12 == 2) {
            this.f5065h.d(i3 + aVar.f1());
        } else {
            this.f5065h.d(i2 + aVar.f1());
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    @Override // q.p
    public void d() {
        p pVar;
        p.e eVar = this.f5059b;
        if (eVar instanceof p.a) {
            this.f5065h.f5008b = true;
            p.a aVar = (p.a) eVar;
            int e12 = aVar.e1();
            boolean d12 = aVar.d1();
            int i2 = 0;
            if (e12 == 0) {
                this.f5065h.f5011e = f.a.LEFT;
                while (i2 < aVar.E0) {
                    p.e eVar2 = aVar.D0[i2];
                    if (d12 || eVar2.Q() != 8) {
                        f fVar = eVar2.f4895e.f5065h;
                        fVar.f5017k.add(this.f5065h);
                        this.f5065h.f5018l.add(fVar);
                    }
                    i2++;
                }
            } else if (e12 != 1) {
                if (e12 == 2) {
                    this.f5065h.f5011e = f.a.TOP;
                    while (i2 < aVar.E0) {
                        p.e eVar3 = aVar.D0[i2];
                        if (d12 || eVar3.Q() != 8) {
                            f fVar2 = eVar3.f4897f.f5065h;
                            fVar2.f5017k.add(this.f5065h);
                            this.f5065h.f5018l.add(fVar2);
                        }
                        i2++;
                    }
                } else if (e12 != 3) {
                    return;
                } else {
                    this.f5065h.f5011e = f.a.BOTTOM;
                    while (i2 < aVar.E0) {
                        p.e eVar4 = aVar.D0[i2];
                        if (d12 || eVar4.Q() != 8) {
                            f fVar3 = eVar4.f4897f.f5066i;
                            fVar3.f5017k.add(this.f5065h);
                            this.f5065h.f5018l.add(fVar3);
                        }
                        i2++;
                    }
                }
                q(this.f5059b.f4897f.f5065h);
                pVar = this.f5059b.f4897f;
                q(pVar.f5066i);
            } else {
                this.f5065h.f5011e = f.a.RIGHT;
                while (i2 < aVar.E0) {
                    p.e eVar5 = aVar.D0[i2];
                    if (d12 || eVar5.Q() != 8) {
                        f fVar4 = eVar5.f4895e.f5066i;
                        fVar4.f5017k.add(this.f5065h);
                        this.f5065h.f5018l.add(fVar4);
                    }
                    i2++;
                }
            }
            q(this.f5059b.f4895e.f5065h);
            pVar = this.f5059b.f4895e;
            q(pVar.f5066i);
        }
    }

    @Override // q.p
    public void e() {
        p.e eVar = this.f5059b;
        if (eVar instanceof p.a) {
            int e12 = ((p.a) eVar).e1();
            if (e12 == 0 || e12 == 1) {
                this.f5059b.V0(this.f5065h.f5013g);
            } else {
                this.f5059b.W0(this.f5065h.f5013g);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    @Override // q.p
    public void f() {
        this.f5060c = null;
        this.f5065h.c();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    @Override // q.p
    public boolean m() {
        return false;
    }
}
