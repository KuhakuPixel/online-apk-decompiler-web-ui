package androidx.databinding;
/* loaded from: classes.dex */
public interface e {
}
