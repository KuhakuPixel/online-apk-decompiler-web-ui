package e0;

import android.view.View;
/* loaded from: classes.dex */
public interface v {
    void a(View view);

    void b(View view);

    void c(View view);
}
