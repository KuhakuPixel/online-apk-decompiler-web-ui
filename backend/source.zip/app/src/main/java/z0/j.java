package z0;

import java.util.ListIterator;
/* loaded from: classes.dex */
public abstract class j extends i implements ListIterator {
    @Override // java.util.ListIterator
    @Deprecated
    public final void add(Object obj) {
        throw new UnsupportedOperationException();
    }

    @Override // java.util.ListIterator
    @Deprecated
    public final void set(Object obj) {
        throw new UnsupportedOperationException();
    }
}
