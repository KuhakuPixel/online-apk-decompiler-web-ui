package g;

import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.view.ActionProvider;
import android.view.ContextMenu;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
/* loaded from: classes.dex */
public class a implements y.b {

    /* renamed from: a  reason: collision with root package name */
    private final int f4459a;

    /* renamed from: b  reason: collision with root package name */
    private final int f4460b;

    /* renamed from: c  reason: collision with root package name */
    private final int f4461c;

    /* renamed from: d  reason: collision with root package name */
    private CharSequence f4462d;

    /* renamed from: e  reason: collision with root package name */
    private CharSequence f4463e;

    /* renamed from: f  reason: collision with root package name */
    private Intent f4464f;

    /* renamed from: g  reason: collision with root package name */
    private char f4465g;

    /* renamed from: i  reason: collision with root package name */
    private char f4467i;

    /* renamed from: k  reason: collision with root package name */
    private Drawable f4469k;

    /* renamed from: l  reason: collision with root package name */
    private Context f4470l;

    /* renamed from: m  reason: collision with root package name */
    private MenuItem.OnMenuItemClickListener f4471m;

    /* renamed from: n  reason: collision with root package name */
    private CharSequence f4472n;

    /* renamed from: o  reason: collision with root package name */
    private CharSequence f4473o;

    /* renamed from: h  reason: collision with root package name */
    private int f4466h = 4096;

    /* renamed from: j  reason: collision with root package name */
    private int f4468j = 4096;

    /* renamed from: p  reason: collision with root package name */
    private ColorStateList f4474p = null;

    /* renamed from: q  reason: collision with root package name */
    private PorterDuff.Mode f4475q = null;

    /* renamed from: r  reason: collision with root package name */
    private boolean f4476r = false;

    /* renamed from: s  reason: collision with root package name */
    private boolean f4477s = false;

    /* renamed from: t  reason: collision with root package name */
    private int f4478t = 16;

    public a(Context context, int i2, int i3, int i4, int i5, CharSequence charSequence) {
        this.f4470l = context;
        this.f4459a = i3;
        this.f4460b = i2;
        this.f4461c = i5;
        this.f4462d = charSequence;
    }

    private void c() {
        Drawable drawable = this.f4469k;
        if (drawable != null) {
            if (this.f4476r || this.f4477s) {
                Drawable r2 = x.a.r(drawable);
                this.f4469k = r2;
                Drawable mutate = r2.mutate();
                this.f4469k = mutate;
                if (this.f4476r) {
                    x.a.o(mutate, this.f4474p);
                }
                if (this.f4477s) {
                    x.a.p(this.f4469k, this.f4475q);
                }
            }
        }
    }

    @Override // y.b
    public y.b a(e0.b bVar) {
        throw new UnsupportedOperationException();
    }

    @Override // y.b
    public e0.b b() {
        return null;
    }

    @Override // y.b, android.view.MenuItem
    public boolean collapseActionView() {
        return false;
    }

    @Override // y.b, android.view.MenuItem
    /* renamed from: d  reason: merged with bridge method [inline-methods] */
    public y.b setActionView(int i2) {
        throw new UnsupportedOperationException();
    }

    @Override // y.b, android.view.MenuItem
    /* renamed from: e  reason: merged with bridge method [inline-methods] */
    public y.b setActionView(View view) {
        throw new UnsupportedOperationException();
    }

    @Override // y.b, android.view.MenuItem
    public boolean expandActionView() {
        return false;
    }

    @Override // y.b, android.view.MenuItem
    /* renamed from: f  reason: merged with bridge method [inline-methods] */
    public y.b setShowAsActionFlags(int i2) {
        setShowAsAction(i2);
        return this;
    }

    @Override // android.view.MenuItem
    public ActionProvider getActionProvider() {
        throw new UnsupportedOperationException();
    }

    @Override // y.b, android.view.MenuItem
    public View getActionView() {
        return null;
    }

    @Override // y.b, android.view.MenuItem
    public int getAlphabeticModifiers() {
        return this.f4468j;
    }

    @Override // android.view.MenuItem
    public char getAlphabeticShortcut() {
        return this.f4467i;
    }

    @Override // y.b, android.view.MenuItem
    public CharSequence getContentDescription() {
        return this.f4472n;
    }

    @Override // android.view.MenuItem
    public int getGroupId() {
        return this.f4460b;
    }

    @Override // android.view.MenuItem
    public Drawable getIcon() {
        return this.f4469k;
    }

    @Override // y.b, android.view.MenuItem
    public ColorStateList getIconTintList() {
        return this.f4474p;
    }

    @Override // y.b, android.view.MenuItem
    public PorterDuff.Mode getIconTintMode() {
        return this.f4475q;
    }

    @Override // android.view.MenuItem
    public Intent getIntent() {
        return this.f4464f;
    }

    @Override // android.view.MenuItem
    public int getItemId() {
        return this.f4459a;
    }

    @Override // android.view.MenuItem
    public ContextMenu.ContextMenuInfo getMenuInfo() {
        return null;
    }

    @Override // y.b, android.view.MenuItem
    public int getNumericModifiers() {
        return this.f4466h;
    }

    @Override // android.view.MenuItem
    public char getNumericShortcut() {
        return this.f4465g;
    }

    @Override // android.view.MenuItem
    public int getOrder() {
        return this.f4461c;
    }

    @Override // android.view.MenuItem
    public SubMenu getSubMenu() {
        return null;
    }

    @Override // android.view.MenuItem
    public CharSequence getTitle() {
        return this.f4462d;
    }

    @Override // android.view.MenuItem
    public CharSequence getTitleCondensed() {
        CharSequence charSequence = this.f4463e;
        return charSequence != null ? charSequence : this.f4462d;
    }

    @Override // y.b, android.view.MenuItem
    public CharSequence getTooltipText() {
        return this.f4473o;
    }

    @Override // android.view.MenuItem
    public boolean hasSubMenu() {
        return false;
    }

    @Override // y.b, android.view.MenuItem
    public boolean isActionViewExpanded() {
        return false;
    }

    @Override // android.view.MenuItem
    public boolean isCheckable() {
        return (this.f4478t & 1) != 0;
    }

    @Override // android.view.MenuItem
    public boolean isChecked() {
        return (this.f4478t & 2) != 0;
    }

    @Override // android.view.MenuItem
    public boolean isEnabled() {
        return (this.f4478t & 16) != 0;
    }

    @Override // android.view.MenuItem
    public boolean isVisible() {
        return (this.f4478t & 8) == 0;
    }

    @Override // android.view.MenuItem
    public MenuItem setActionProvider(ActionProvider actionProvider) {
        throw new UnsupportedOperationException();
    }

    @Override // android.view.MenuItem
    public MenuItem setAlphabeticShortcut(char c2) {
        this.f4467i = Character.toLowerCase(c2);
        return this;
    }

    @Override // y.b, android.view.MenuItem
    public MenuItem setAlphabeticShortcut(char c2, int i2) {
        this.f4467i = Character.toLowerCase(c2);
        this.f4468j = KeyEvent.normalizeMetaState(i2);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setCheckable(boolean z2) {
        this.f4478t = (z2 ? 1 : 0) | (this.f4478t & (-2));
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setChecked(boolean z2) {
        this.f4478t = (z2 ? 2 : 0) | (this.f4478t & (-3));
        return this;
    }

    @Override // android.view.MenuItem
    public y.b setContentDescription(CharSequence charSequence) {
        this.f4472n = charSequence;
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setEnabled(boolean z2) {
        this.f4478t = (z2 ? 16 : 0) | (this.f4478t & (-17));
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setIcon(int i2) {
        this.f4469k = u.a.c(this.f4470l, i2);
        c();
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setIcon(Drawable drawable) {
        this.f4469k = drawable;
        c();
        return this;
    }

    @Override // y.b, android.view.MenuItem
    public MenuItem setIconTintList(ColorStateList colorStateList) {
        this.f4474p = colorStateList;
        this.f4476r = true;
        c();
        return this;
    }

    @Override // y.b, android.view.MenuItem
    public MenuItem setIconTintMode(PorterDuff.Mode mode) {
        this.f4475q = mode;
        this.f4477s = true;
        c();
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setIntent(Intent intent) {
        this.f4464f = intent;
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setNumericShortcut(char c2) {
        this.f4465g = c2;
        return this;
    }

    @Override // y.b, android.view.MenuItem
    public MenuItem setNumericShortcut(char c2, int i2) {
        this.f4465g = c2;
        this.f4466h = KeyEvent.normalizeMetaState(i2);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setOnActionExpandListener(MenuItem.OnActionExpandListener onActionExpandListener) {
        throw new UnsupportedOperationException();
    }

    @Override // android.view.MenuItem
    public MenuItem setOnMenuItemClickListener(MenuItem.OnMenuItemClickListener onMenuItemClickListener) {
        this.f4471m = onMenuItemClickListener;
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setShortcut(char c2, char c3) {
        this.f4465g = c2;
        this.f4467i = Character.toLowerCase(c3);
        return this;
    }

    @Override // y.b, android.view.MenuItem
    public MenuItem setShortcut(char c2, char c3, int i2, int i3) {
        this.f4465g = c2;
        this.f4466h = KeyEvent.normalizeMetaState(i2);
        this.f4467i = Character.toLowerCase(c3);
        this.f4468j = KeyEvent.normalizeMetaState(i3);
        return this;
    }

    @Override // y.b, android.view.MenuItem
    public void setShowAsAction(int i2) {
    }

    @Override // android.view.MenuItem
    public MenuItem setTitle(int i2) {
        this.f4462d = this.f4470l.getResources().getString(i2);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setTitle(CharSequence charSequence) {
        this.f4462d = charSequence;
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setTitleCondensed(CharSequence charSequence) {
        this.f4463e = charSequence;
        return this;
    }

    @Override // android.view.MenuItem
    public y.b setTooltipText(CharSequence charSequence) {
        this.f4473o = charSequence;
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setVisible(boolean z2) {
        this.f4478t = (this.f4478t & 8) | (z2 ? 0 : 8);
        return this;
    }
}
