package androidx.fragment.app;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
/* loaded from: classes.dex */
public class c extends Fragment implements DialogInterface.OnCancelListener, DialogInterface.OnDismissListener {
    private Handler Y;
    private Runnable Z = new a();

    /* renamed from: a0  reason: collision with root package name */
    private DialogInterface.OnCancelListener f1586a0 = new b();

    /* renamed from: b0  reason: collision with root package name */
    private DialogInterface.OnDismissListener f1587b0 = new DialogInterfaceOnDismissListenerC0008c();

    /* renamed from: c0  reason: collision with root package name */
    private int f1588c0 = 0;

    /* renamed from: d0  reason: collision with root package name */
    private int f1589d0 = 0;

    /* renamed from: e0  reason: collision with root package name */
    private boolean f1590e0 = true;

    /* renamed from: f0  reason: collision with root package name */
    private boolean f1591f0 = true;

    /* renamed from: g0  reason: collision with root package name */
    private int f1592g0 = -1;

    /* renamed from: h0  reason: collision with root package name */
    private boolean f1593h0;

    /* renamed from: i0  reason: collision with root package name */
    private Dialog f1594i0;

    /* renamed from: j0  reason: collision with root package name */
    private boolean f1595j0;

    /* renamed from: k0  reason: collision with root package name */
    private boolean f1596k0;

    /* renamed from: l0  reason: collision with root package name */
    private boolean f1597l0;

    /* loaded from: classes.dex */
    class a implements Runnable {
        a() {
        }

        @Override // java.lang.Runnable
        @SuppressLint({"SyntheticAccessor"})
        public void run() {
            c.this.f1587b0.onDismiss(c.this.f1594i0);
        }
    }

    /* loaded from: classes.dex */
    class b implements DialogInterface.OnCancelListener {
        b() {
        }

        @Override // android.content.DialogInterface.OnCancelListener
        @SuppressLint({"SyntheticAccessor"})
        public void onCancel(DialogInterface dialogInterface) {
            if (c.this.f1594i0 != null) {
                c cVar = c.this;
                cVar.onCancel(cVar.f1594i0);
            }
        }
    }

    /* renamed from: androidx.fragment.app.c$c  reason: collision with other inner class name */
    /* loaded from: classes.dex */
    class DialogInterfaceOnDismissListenerC0008c implements DialogInterface.OnDismissListener {
        DialogInterfaceOnDismissListenerC0008c() {
        }

        @Override // android.content.DialogInterface.OnDismissListener
        @SuppressLint({"SyntheticAccessor"})
        public void onDismiss(DialogInterface dialogInterface) {
            if (c.this.f1594i0 != null) {
                c cVar = c.this;
                cVar.onDismiss(cVar.f1594i0);
            }
        }
    }

    private void s1(boolean z2, boolean z3) {
        if (this.f1596k0) {
            return;
        }
        this.f1596k0 = true;
        this.f1597l0 = false;
        Dialog dialog = this.f1594i0;
        if (dialog != null) {
            dialog.setOnDismissListener(null);
            this.f1594i0.dismiss();
            if (!z3) {
                if (Looper.myLooper() == this.Y.getLooper()) {
                    onDismiss(this.f1594i0);
                } else {
                    this.Y.post(this.Z);
                }
            }
        }
        this.f1595j0 = true;
        if (this.f1592g0 >= 0) {
            A().D0(this.f1592g0, 1);
            this.f1592g0 = -1;
            return;
        }
        s i2 = A().i();
        i2.n(this);
        if (z2) {
            i2.i();
        } else {
            i2.h();
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void A0() {
        super.A0();
        Dialog dialog = this.f1594i0;
        if (dialog != null) {
            this.f1595j0 = false;
            dialog.show();
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void B0() {
        super.B0();
        Dialog dialog = this.f1594i0;
        if (dialog != null) {
            dialog.hide();
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void X(Bundle bundle) {
        Bundle bundle2;
        super.X(bundle);
        if (this.f1591f0) {
            View M = M();
            if (this.f1594i0 != null) {
                if (M != null) {
                    if (M.getParent() != null) {
                        throw new IllegalStateException("DialogFragment can not be attached to a container view");
                    }
                    this.f1594i0.setContentView(M);
                }
                d i2 = i();
                if (i2 != null) {
                    this.f1594i0.setOwnerActivity(i2);
                }
                this.f1594i0.setCancelable(this.f1590e0);
                this.f1594i0.setOnCancelListener(this.f1586a0);
                this.f1594i0.setOnDismissListener(this.f1587b0);
                if (bundle == null || (bundle2 = bundle.getBundle("android:savedDialogState")) == null) {
                    return;
                }
                this.f1594i0.onRestoreInstanceState(bundle2);
            }
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void a0(Context context) {
        super.a0(context);
        if (this.f1597l0) {
            return;
        }
        this.f1596k0 = false;
    }

    @Override // androidx.fragment.app.Fragment
    public void d0(Bundle bundle) {
        super.d0(bundle);
        this.Y = new Handler();
        this.f1591f0 = this.f1543x == 0;
        if (bundle != null) {
            this.f1588c0 = bundle.getInt("android:style", 0);
            this.f1589d0 = bundle.getInt("android:theme", 0);
            this.f1590e0 = bundle.getBoolean("android:cancelable", true);
            this.f1591f0 = bundle.getBoolean("android:showsDialog", this.f1591f0);
            this.f1592g0 = bundle.getInt("android:backStackId", -1);
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void k0() {
        super.k0();
        Dialog dialog = this.f1594i0;
        if (dialog != null) {
            this.f1595j0 = true;
            dialog.setOnDismissListener(null);
            this.f1594i0.dismiss();
            if (!this.f1596k0) {
                onDismiss(this.f1594i0);
            }
            this.f1594i0 = null;
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void l0() {
        super.l0();
        if (this.f1597l0 || this.f1596k0) {
            return;
        }
        this.f1596k0 = true;
    }

    @Override // androidx.fragment.app.Fragment
    public LayoutInflater m0(Bundle bundle) {
        LayoutInflater m02 = super.m0(bundle);
        if (!this.f1591f0 || this.f1593h0) {
            return m02;
        }
        try {
            this.f1593h0 = true;
            Dialog v12 = v1(bundle);
            this.f1594i0 = v12;
            x1(v12, this.f1588c0);
            this.f1593h0 = false;
            return m02.cloneInContext(w1().getContext());
        } catch (Throwable th) {
            this.f1593h0 = false;
            throw th;
        }
    }

    @Override // android.content.DialogInterface.OnCancelListener
    public void onCancel(DialogInterface dialogInterface) {
    }

    @Override // android.content.DialogInterface.OnDismissListener
    public void onDismiss(DialogInterface dialogInterface) {
        if (this.f1595j0) {
            return;
        }
        s1(true, true);
    }

    public void r1() {
        s1(false, false);
    }

    public Dialog t1() {
        return this.f1594i0;
    }

    public int u1() {
        return this.f1589d0;
    }

    public Dialog v1(Bundle bundle) {
        return new Dialog(c1(), u1());
    }

    public final Dialog w1() {
        Dialog t12 = t1();
        if (t12 != null) {
            return t12;
        }
        throw new IllegalStateException("DialogFragment " + this + " does not have a Dialog.");
    }

    public void x1(Dialog dialog, int i2) {
        if (i2 != 1 && i2 != 2) {
            if (i2 != 3) {
                return;
            }
            Window window = dialog.getWindow();
            if (window != null) {
                window.addFlags(24);
            }
        }
        dialog.requestWindowFeature(1);
    }

    public void y1(l lVar, String str) {
        this.f1596k0 = false;
        this.f1597l0 = true;
        s i2 = lVar.i();
        i2.d(this, str);
        i2.h();
    }

    @Override // androidx.fragment.app.Fragment
    public void z0(Bundle bundle) {
        super.z0(bundle);
        Dialog dialog = this.f1594i0;
        if (dialog != null) {
            bundle.putBundle("android:savedDialogState", dialog.onSaveInstanceState());
        }
        int i2 = this.f1588c0;
        if (i2 != 0) {
            bundle.putInt("android:style", i2);
        }
        int i3 = this.f1589d0;
        if (i3 != 0) {
            bundle.putInt("android:theme", i3);
        }
        boolean z2 = this.f1590e0;
        if (!z2) {
            bundle.putBoolean("android:cancelable", z2);
        }
        boolean z3 = this.f1591f0;
        if (!z3) {
            bundle.putBoolean("android:showsDialog", z3);
        }
        int i4 = this.f1592g0;
        if (i4 != -1) {
            bundle.putInt("android:backStackId", i4);
        }
    }
}
