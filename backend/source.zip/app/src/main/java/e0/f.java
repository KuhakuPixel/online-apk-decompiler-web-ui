package e0;

import android.view.LayoutInflater;
/* loaded from: classes.dex */
public final class f {
    public static void a(LayoutInflater layoutInflater, LayoutInflater.Factory2 factory2) {
        layoutInflater.setFactory2(factory2);
    }
}
