package o;

import java.util.Arrays;
import java.util.HashSet;
/* loaded from: classes.dex */
public class i {

    /* renamed from: r  reason: collision with root package name */
    private static int f4766r = 1;

    /* renamed from: a  reason: collision with root package name */
    public boolean f4767a;

    /* renamed from: b  reason: collision with root package name */
    private String f4768b;

    /* renamed from: f  reason: collision with root package name */
    public float f4772f;

    /* renamed from: j  reason: collision with root package name */
    a f4776j;

    /* renamed from: c  reason: collision with root package name */
    public int f4769c = -1;

    /* renamed from: d  reason: collision with root package name */
    int f4770d = -1;

    /* renamed from: e  reason: collision with root package name */
    public int f4771e = 0;

    /* renamed from: g  reason: collision with root package name */
    public boolean f4773g = false;

    /* renamed from: h  reason: collision with root package name */
    float[] f4774h = new float[9];

    /* renamed from: i  reason: collision with root package name */
    float[] f4775i = new float[9];

    /* renamed from: k  reason: collision with root package name */
    b[] f4777k = new b[16];

    /* renamed from: l  reason: collision with root package name */
    int f4778l = 0;

    /* renamed from: m  reason: collision with root package name */
    public int f4779m = 0;

    /* renamed from: n  reason: collision with root package name */
    boolean f4780n = false;

    /* renamed from: o  reason: collision with root package name */
    int f4781o = -1;

    /* renamed from: p  reason: collision with root package name */
    float f4782p = 0.0f;

    /* renamed from: q  reason: collision with root package name */
    HashSet<b> f4783q = null;

    /* loaded from: classes.dex */
    public enum a {
        UNRESTRICTED,
        CONSTANT,
        SLACK,
        ERROR,
        UNKNOWN
    }

    public i(a aVar, String str) {
        this.f4776j = aVar;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void b() {
        f4766r++;
    }

    public final void a(b bVar) {
        int i2 = 0;
        while (true) {
            int i3 = this.f4778l;
            if (i2 >= i3) {
                b[] bVarArr = this.f4777k;
                if (i3 >= bVarArr.length) {
                    this.f4777k = (b[]) Arrays.copyOf(bVarArr, bVarArr.length * 2);
                }
                b[] bVarArr2 = this.f4777k;
                int i4 = this.f4778l;
                bVarArr2[i4] = bVar;
                this.f4778l = i4 + 1;
                return;
            } else if (this.f4777k[i2] == bVar) {
                return;
            } else {
                i2++;
            }
        }
    }

    public final void c(b bVar) {
        int i2 = this.f4778l;
        int i3 = 0;
        while (i3 < i2) {
            if (this.f4777k[i3] == bVar) {
                while (i3 < i2 - 1) {
                    b[] bVarArr = this.f4777k;
                    int i4 = i3 + 1;
                    bVarArr[i3] = bVarArr[i4];
                    i3 = i4;
                }
                this.f4778l--;
                return;
            }
            i3++;
        }
    }

    public void d() {
        this.f4768b = null;
        this.f4776j = a.UNKNOWN;
        this.f4771e = 0;
        this.f4769c = -1;
        this.f4770d = -1;
        this.f4772f = 0.0f;
        this.f4773g = false;
        this.f4780n = false;
        this.f4781o = -1;
        this.f4782p = 0.0f;
        int i2 = this.f4778l;
        for (int i3 = 0; i3 < i2; i3++) {
            this.f4777k[i3] = null;
        }
        this.f4778l = 0;
        this.f4779m = 0;
        this.f4767a = false;
        Arrays.fill(this.f4775i, 0.0f);
    }

    public void e(d dVar, float f2) {
        this.f4772f = f2;
        this.f4773g = true;
        this.f4780n = false;
        this.f4781o = -1;
        this.f4782p = 0.0f;
        int i2 = this.f4778l;
        this.f4770d = -1;
        for (int i3 = 0; i3 < i2; i3++) {
            this.f4777k[i3].A(dVar, this, false);
        }
        this.f4778l = 0;
    }

    public void f(a aVar, String str) {
        this.f4776j = aVar;
    }

    public final void g(d dVar, b bVar) {
        int i2 = this.f4778l;
        for (int i3 = 0; i3 < i2; i3++) {
            this.f4777k[i3].B(dVar, bVar, false);
        }
        this.f4778l = 0;
    }

    public String toString() {
        StringBuilder sb;
        if (this.f4768b != null) {
            sb = new StringBuilder();
            sb.append("");
            sb.append(this.f4768b);
        } else {
            sb = new StringBuilder();
            sb.append("");
            sb.append(this.f4769c);
        }
        return sb.toString();
    }
}
