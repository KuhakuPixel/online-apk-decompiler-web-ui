package g;

import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.ActionProvider;
import android.view.CollapsibleActionView;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.widget.FrameLayout;
import e0.b;
import java.lang.reflect.Method;
/* loaded from: classes.dex */
public class c extends g.b implements MenuItem {

    /* renamed from: d  reason: collision with root package name */
    private final y.b f4482d;

    /* renamed from: e  reason: collision with root package name */
    private Method f4483e;

    /* loaded from: classes.dex */
    private class a extends e0.b {

        /* renamed from: d  reason: collision with root package name */
        final ActionProvider f4484d;

        a(Context context, ActionProvider actionProvider) {
            super(context);
            this.f4484d = actionProvider;
        }

        @Override // e0.b
        public boolean a() {
            return this.f4484d.hasSubMenu();
        }

        @Override // e0.b
        public View c() {
            return this.f4484d.onCreateActionView();
        }

        @Override // e0.b
        public boolean e() {
            return this.f4484d.onPerformDefaultAction();
        }

        @Override // e0.b
        public void f(SubMenu subMenu) {
            this.f4484d.onPrepareSubMenu(c.this.d(subMenu));
        }
    }

    /* loaded from: classes.dex */
    private class b extends a implements ActionProvider.VisibilityListener {

        /* renamed from: f  reason: collision with root package name */
        private b.InterfaceC0052b f4486f;

        b(Context context, ActionProvider actionProvider) {
            super(context, actionProvider);
        }

        @Override // e0.b
        public boolean b() {
            return this.f4484d.isVisible();
        }

        @Override // e0.b
        public View d(MenuItem menuItem) {
            return this.f4484d.onCreateActionView(menuItem);
        }

        @Override // e0.b
        public boolean g() {
            return this.f4484d.overridesItemVisibility();
        }

        @Override // e0.b
        public void j(b.InterfaceC0052b interfaceC0052b) {
            this.f4486f = interfaceC0052b;
            this.f4484d.setVisibilityListener(interfaceC0052b != null ? this : null);
        }

        @Override // android.view.ActionProvider.VisibilityListener
        public void onActionProviderVisibilityChanged(boolean z2) {
            b.InterfaceC0052b interfaceC0052b = this.f4486f;
            if (interfaceC0052b != null) {
                interfaceC0052b.onActionProviderVisibilityChanged(z2);
            }
        }
    }

    /* renamed from: g.c$c  reason: collision with other inner class name */
    /* loaded from: classes.dex */
    static class C0057c extends FrameLayout implements f.c {

        /* renamed from: b  reason: collision with root package name */
        final CollapsibleActionView f4488b;

        C0057c(View view) {
            super(view.getContext());
            this.f4488b = (CollapsibleActionView) view;
            addView(view);
        }

        View a() {
            return (View) this.f4488b;
        }

        @Override // f.c
        public void c() {
            this.f4488b.onActionViewExpanded();
        }

        @Override // f.c
        public void f() {
            this.f4488b.onActionViewCollapsed();
        }
    }

    /* loaded from: classes.dex */
    private class d implements MenuItem.OnActionExpandListener {

        /* renamed from: a  reason: collision with root package name */
        private final MenuItem.OnActionExpandListener f4489a;

        d(MenuItem.OnActionExpandListener onActionExpandListener) {
            this.f4489a = onActionExpandListener;
        }

        @Override // android.view.MenuItem.OnActionExpandListener
        public boolean onMenuItemActionCollapse(MenuItem menuItem) {
            return this.f4489a.onMenuItemActionCollapse(c.this.c(menuItem));
        }

        @Override // android.view.MenuItem.OnActionExpandListener
        public boolean onMenuItemActionExpand(MenuItem menuItem) {
            return this.f4489a.onMenuItemActionExpand(c.this.c(menuItem));
        }
    }

    /* loaded from: classes.dex */
    private class e implements MenuItem.OnMenuItemClickListener {

        /* renamed from: a  reason: collision with root package name */
        private final MenuItem.OnMenuItemClickListener f4491a;

        e(MenuItem.OnMenuItemClickListener onMenuItemClickListener) {
            this.f4491a = onMenuItemClickListener;
        }

        @Override // android.view.MenuItem.OnMenuItemClickListener
        public boolean onMenuItemClick(MenuItem menuItem) {
            return this.f4491a.onMenuItemClick(c.this.c(menuItem));
        }
    }

    public c(Context context, y.b bVar) {
        super(context);
        if (bVar == null) {
            throw new IllegalArgumentException("Wrapped Object can not be null.");
        }
        this.f4482d = bVar;
    }

    @Override // android.view.MenuItem
    public boolean collapseActionView() {
        return this.f4482d.collapseActionView();
    }

    @Override // android.view.MenuItem
    public boolean expandActionView() {
        return this.f4482d.expandActionView();
    }

    @Override // android.view.MenuItem
    public ActionProvider getActionProvider() {
        e0.b b2 = this.f4482d.b();
        if (b2 instanceof a) {
            return ((a) b2).f4484d;
        }
        return null;
    }

    @Override // android.view.MenuItem
    public View getActionView() {
        View actionView = this.f4482d.getActionView();
        return actionView instanceof C0057c ? ((C0057c) actionView).a() : actionView;
    }

    @Override // android.view.MenuItem
    public int getAlphabeticModifiers() {
        return this.f4482d.getAlphabeticModifiers();
    }

    @Override // android.view.MenuItem
    public char getAlphabeticShortcut() {
        return this.f4482d.getAlphabeticShortcut();
    }

    @Override // android.view.MenuItem
    public CharSequence getContentDescription() {
        return this.f4482d.getContentDescription();
    }

    @Override // android.view.MenuItem
    public int getGroupId() {
        return this.f4482d.getGroupId();
    }

    @Override // android.view.MenuItem
    public Drawable getIcon() {
        return this.f4482d.getIcon();
    }

    @Override // android.view.MenuItem
    public ColorStateList getIconTintList() {
        return this.f4482d.getIconTintList();
    }

    @Override // android.view.MenuItem
    public PorterDuff.Mode getIconTintMode() {
        return this.f4482d.getIconTintMode();
    }

    @Override // android.view.MenuItem
    public Intent getIntent() {
        return this.f4482d.getIntent();
    }

    @Override // android.view.MenuItem
    public int getItemId() {
        return this.f4482d.getItemId();
    }

    @Override // android.view.MenuItem
    public ContextMenu.ContextMenuInfo getMenuInfo() {
        return this.f4482d.getMenuInfo();
    }

    @Override // android.view.MenuItem
    public int getNumericModifiers() {
        return this.f4482d.getNumericModifiers();
    }

    @Override // android.view.MenuItem
    public char getNumericShortcut() {
        return this.f4482d.getNumericShortcut();
    }

    @Override // android.view.MenuItem
    public int getOrder() {
        return this.f4482d.getOrder();
    }

    @Override // android.view.MenuItem
    public SubMenu getSubMenu() {
        return d(this.f4482d.getSubMenu());
    }

    @Override // android.view.MenuItem
    public CharSequence getTitle() {
        return this.f4482d.getTitle();
    }

    @Override // android.view.MenuItem
    public CharSequence getTitleCondensed() {
        return this.f4482d.getTitleCondensed();
    }

    @Override // android.view.MenuItem
    public CharSequence getTooltipText() {
        return this.f4482d.getTooltipText();
    }

    public void h(boolean z2) {
        try {
            if (this.f4483e == null) {
                this.f4483e = this.f4482d.getClass().getDeclaredMethod("setExclusiveCheckable", Boolean.TYPE);
            }
            this.f4483e.invoke(this.f4482d, Boolean.valueOf(z2));
        } catch (Exception e2) {
            Log.w("MenuItemWrapper", "Error while calling setExclusiveCheckable", e2);
        }
    }

    @Override // android.view.MenuItem
    public boolean hasSubMenu() {
        return this.f4482d.hasSubMenu();
    }

    @Override // android.view.MenuItem
    public boolean isActionViewExpanded() {
        return this.f4482d.isActionViewExpanded();
    }

    @Override // android.view.MenuItem
    public boolean isCheckable() {
        return this.f4482d.isCheckable();
    }

    @Override // android.view.MenuItem
    public boolean isChecked() {
        return this.f4482d.isChecked();
    }

    @Override // android.view.MenuItem
    public boolean isEnabled() {
        return this.f4482d.isEnabled();
    }

    @Override // android.view.MenuItem
    public boolean isVisible() {
        return this.f4482d.isVisible();
    }

    @Override // android.view.MenuItem
    public MenuItem setActionProvider(ActionProvider actionProvider) {
        b bVar = new b(this.f4479a, actionProvider);
        y.b bVar2 = this.f4482d;
        if (actionProvider == null) {
            bVar = null;
        }
        bVar2.a(bVar);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setActionView(int i2) {
        this.f4482d.setActionView(i2);
        View actionView = this.f4482d.getActionView();
        if (actionView instanceof CollapsibleActionView) {
            this.f4482d.setActionView(new C0057c(actionView));
        }
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setActionView(View view) {
        if (view instanceof CollapsibleActionView) {
            view = new C0057c(view);
        }
        this.f4482d.setActionView(view);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setAlphabeticShortcut(char c2) {
        this.f4482d.setAlphabeticShortcut(c2);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setAlphabeticShortcut(char c2, int i2) {
        this.f4482d.setAlphabeticShortcut(c2, i2);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setCheckable(boolean z2) {
        this.f4482d.setCheckable(z2);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setChecked(boolean z2) {
        this.f4482d.setChecked(z2);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setContentDescription(CharSequence charSequence) {
        this.f4482d.setContentDescription(charSequence);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setEnabled(boolean z2) {
        this.f4482d.setEnabled(z2);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setIcon(int i2) {
        this.f4482d.setIcon(i2);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setIcon(Drawable drawable) {
        this.f4482d.setIcon(drawable);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setIconTintList(ColorStateList colorStateList) {
        this.f4482d.setIconTintList(colorStateList);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setIconTintMode(PorterDuff.Mode mode) {
        this.f4482d.setIconTintMode(mode);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setIntent(Intent intent) {
        this.f4482d.setIntent(intent);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setNumericShortcut(char c2) {
        this.f4482d.setNumericShortcut(c2);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setNumericShortcut(char c2, int i2) {
        this.f4482d.setNumericShortcut(c2, i2);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setOnActionExpandListener(MenuItem.OnActionExpandListener onActionExpandListener) {
        this.f4482d.setOnActionExpandListener(onActionExpandListener != null ? new d(onActionExpandListener) : null);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setOnMenuItemClickListener(MenuItem.OnMenuItemClickListener onMenuItemClickListener) {
        this.f4482d.setOnMenuItemClickListener(onMenuItemClickListener != null ? new e(onMenuItemClickListener) : null);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setShortcut(char c2, char c3) {
        this.f4482d.setShortcut(c2, c3);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setShortcut(char c2, char c3, int i2, int i3) {
        this.f4482d.setShortcut(c2, c3, i2, i3);
        return this;
    }

    @Override // android.view.MenuItem
    public void setShowAsAction(int i2) {
        this.f4482d.setShowAsAction(i2);
    }

    @Override // android.view.MenuItem
    public MenuItem setShowAsActionFlags(int i2) {
        this.f4482d.setShowAsActionFlags(i2);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setTitle(int i2) {
        this.f4482d.setTitle(i2);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setTitle(CharSequence charSequence) {
        this.f4482d.setTitle(charSequence);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setTitleCondensed(CharSequence charSequence) {
        this.f4482d.setTitleCondensed(charSequence);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setTooltipText(CharSequence charSequence) {
        this.f4482d.setTooltipText(charSequence);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setVisible(boolean z2) {
        return this.f4482d.setVisible(z2);
    }
}
