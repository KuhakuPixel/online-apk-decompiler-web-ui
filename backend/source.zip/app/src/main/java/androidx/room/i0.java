package androidx.room;

import java.io.File;
import java.io.InputStream;
import java.util.concurrent.Callable;
import u0.c;
/* loaded from: classes.dex */
class i0 implements c.InterfaceC0072c {

    /* renamed from: a  reason: collision with root package name */
    private final String f2617a;

    /* renamed from: b  reason: collision with root package name */
    private final File f2618b;

    /* renamed from: c  reason: collision with root package name */
    private final Callable<InputStream> f2619c;

    /* renamed from: d  reason: collision with root package name */
    private final c.InterfaceC0072c f2620d;

    /* JADX INFO: Access modifiers changed from: package-private */
    public i0(String str, File file, Callable<InputStream> callable, c.InterfaceC0072c interfaceC0072c) {
        this.f2617a = str;
        this.f2618b = file;
        this.f2619c = callable;
        this.f2620d = interfaceC0072c;
    }

    @Override // u0.c.InterfaceC0072c
    public u0.c a(c.b bVar) {
        return new h0(bVar.f5335a, this.f2617a, this.f2618b, this.f2619c, bVar.f5337c.f5334a, this.f2620d.a(bVar));
    }
}
