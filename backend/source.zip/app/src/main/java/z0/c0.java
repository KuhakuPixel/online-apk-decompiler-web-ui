package z0;
/* loaded from: classes.dex */
final class c0 {

    /* renamed from: a  reason: collision with root package name */
    private final Object f5679a;

    /* renamed from: b  reason: collision with root package name */
    private final Object f5680b;

    /* renamed from: c  reason: collision with root package name */
    private final Object f5681c;

    /* JADX INFO: Access modifiers changed from: package-private */
    public c0(Object obj, Object obj2, Object obj3) {
        this.f5679a = obj;
        this.f5680b = obj2;
        this.f5681c = obj3;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final IllegalArgumentException a() {
        return new IllegalArgumentException("Multiple entries with same key: " + this.f5679a + "=" + this.f5680b + " and " + this.f5679a + "=" + this.f5681c);
    }
}
