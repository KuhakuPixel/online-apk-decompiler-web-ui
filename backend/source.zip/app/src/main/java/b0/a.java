package b0;

import android.util.Base64;
import d0.h;
import java.util.List;
/* loaded from: classes.dex */
public final class a {

    /* renamed from: a  reason: collision with root package name */
    private final String f2978a;

    /* renamed from: b  reason: collision with root package name */
    private final String f2979b;

    /* renamed from: c  reason: collision with root package name */
    private final String f2980c;

    /* renamed from: d  reason: collision with root package name */
    private final List<List<byte[]>> f2981d;

    /* renamed from: e  reason: collision with root package name */
    private final int f2982e;

    /* renamed from: f  reason: collision with root package name */
    private final String f2983f;

    public a(String str, String str2, String str3, List<List<byte[]>> list) {
        String str4 = (String) h.c(str);
        this.f2978a = str4;
        String str5 = (String) h.c(str2);
        this.f2979b = str5;
        String str6 = (String) h.c(str3);
        this.f2980c = str6;
        this.f2981d = (List) h.c(list);
        this.f2982e = 0;
        this.f2983f = str4 + "-" + str5 + "-" + str6;
    }

    public List<List<byte[]>> a() {
        return this.f2981d;
    }

    public int b() {
        return this.f2982e;
    }

    public String c() {
        return this.f2983f;
    }

    public String d() {
        return this.f2978a;
    }

    public String e() {
        return this.f2979b;
    }

    public String f() {
        return this.f2980c;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("FontRequest {mProviderAuthority: " + this.f2978a + ", mProviderPackage: " + this.f2979b + ", mQuery: " + this.f2980c + ", mCertificates:");
        for (int i2 = 0; i2 < this.f2981d.size(); i2++) {
            sb.append(" [");
            List<byte[]> list = this.f2981d.get(i2);
            for (int i3 = 0; i3 < list.size(); i3++) {
                sb.append(" \"");
                sb.append(Base64.encodeToString(list.get(i3), 0));
                sb.append("\"");
            }
            sb.append(" ]");
        }
        sb.append("}");
        sb.append("mCertificatesArray: " + this.f2982e);
        return sb.toString();
    }
}
