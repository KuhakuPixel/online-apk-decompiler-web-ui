package androidx.room;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
/* loaded from: classes.dex */
public interface j extends IInterface {

    /* loaded from: classes.dex */
    public static abstract class a extends Binder implements j {

        /* JADX INFO: Access modifiers changed from: private */
        /* renamed from: androidx.room.j$a$a  reason: collision with other inner class name */
        /* loaded from: classes.dex */
        public static class C0020a implements j {

            /* renamed from: b  reason: collision with root package name */
            public static j f2621b;

            /* renamed from: a  reason: collision with root package name */
            private IBinder f2622a;

            C0020a(IBinder iBinder) {
                this.f2622a = iBinder;
            }

            @Override // android.os.IInterface
            public IBinder asBinder() {
                return this.f2622a;
            }

            @Override // androidx.room.j
            public void m(String[] strArr) {
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("androidx.room.IMultiInstanceInvalidationCallback");
                    obtain.writeStringArray(strArr);
                    if (this.f2622a.transact(1, obtain, null, 1) || a.q() == null) {
                        return;
                    }
                    a.q().m(strArr);
                } finally {
                    obtain.recycle();
                }
            }
        }

        public a() {
            attachInterface(this, "androidx.room.IMultiInstanceInvalidationCallback");
        }

        public static j p(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface queryLocalInterface = iBinder.queryLocalInterface("androidx.room.IMultiInstanceInvalidationCallback");
            return (queryLocalInterface == null || !(queryLocalInterface instanceof j)) ? new C0020a(iBinder) : (j) queryLocalInterface;
        }

        public static j q() {
            return C0020a.f2621b;
        }

        @Override // android.os.IInterface
        public IBinder asBinder() {
            return this;
        }

        @Override // android.os.Binder
        public boolean onTransact(int i2, Parcel parcel, Parcel parcel2, int i3) {
            if (i2 == 1) {
                parcel.enforceInterface("androidx.room.IMultiInstanceInvalidationCallback");
                m(parcel.createStringArray());
                return true;
            } else if (i2 != 1598968902) {
                return super.onTransact(i2, parcel, parcel2, i3);
            } else {
                parcel2.writeString("androidx.room.IMultiInstanceInvalidationCallback");
                return true;
            }
        }
    }

    void m(String[] strArr);
}
