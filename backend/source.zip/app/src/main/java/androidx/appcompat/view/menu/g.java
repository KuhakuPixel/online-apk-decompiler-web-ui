package androidx.appcompat.view.menu;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.ActionProvider;
import android.view.ContextMenu;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewDebug;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import androidx.appcompat.view.menu.k;
import e0.b;
/* loaded from: classes.dex */
public final class g implements y.b {
    private View A;
    private e0.b B;
    private MenuItem.OnActionExpandListener C;
    private ContextMenu.ContextMenuInfo E;

    /* renamed from: a  reason: collision with root package name */
    private final int f417a;

    /* renamed from: b  reason: collision with root package name */
    private final int f418b;

    /* renamed from: c  reason: collision with root package name */
    private final int f419c;

    /* renamed from: d  reason: collision with root package name */
    private final int f420d;

    /* renamed from: e  reason: collision with root package name */
    private CharSequence f421e;

    /* renamed from: f  reason: collision with root package name */
    private CharSequence f422f;

    /* renamed from: g  reason: collision with root package name */
    private Intent f423g;

    /* renamed from: h  reason: collision with root package name */
    private char f424h;

    /* renamed from: j  reason: collision with root package name */
    private char f426j;

    /* renamed from: l  reason: collision with root package name */
    private Drawable f428l;

    /* renamed from: n  reason: collision with root package name */
    e f430n;

    /* renamed from: o  reason: collision with root package name */
    private m f431o;

    /* renamed from: p  reason: collision with root package name */
    private Runnable f432p;

    /* renamed from: q  reason: collision with root package name */
    private MenuItem.OnMenuItemClickListener f433q;

    /* renamed from: r  reason: collision with root package name */
    private CharSequence f434r;

    /* renamed from: s  reason: collision with root package name */
    private CharSequence f435s;

    /* renamed from: z  reason: collision with root package name */
    private int f442z;

    /* renamed from: i  reason: collision with root package name */
    private int f425i = 4096;

    /* renamed from: k  reason: collision with root package name */
    private int f427k = 4096;

    /* renamed from: m  reason: collision with root package name */
    private int f429m = 0;

    /* renamed from: t  reason: collision with root package name */
    private ColorStateList f436t = null;

    /* renamed from: u  reason: collision with root package name */
    private PorterDuff.Mode f437u = null;

    /* renamed from: v  reason: collision with root package name */
    private boolean f438v = false;

    /* renamed from: w  reason: collision with root package name */
    private boolean f439w = false;

    /* renamed from: x  reason: collision with root package name */
    private boolean f440x = false;

    /* renamed from: y  reason: collision with root package name */
    private int f441y = 16;
    private boolean D = false;

    /* loaded from: classes.dex */
    class a implements b.InterfaceC0052b {
        a() {
        }

        @Override // e0.b.InterfaceC0052b
        public void onActionProviderVisibilityChanged(boolean z2) {
            g gVar = g.this;
            gVar.f430n.J(gVar);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public g(e eVar, int i2, int i3, int i4, int i5, CharSequence charSequence, int i6) {
        this.f430n = eVar;
        this.f417a = i3;
        this.f418b = i2;
        this.f419c = i4;
        this.f420d = i5;
        this.f421e = charSequence;
        this.f442z = i6;
    }

    private static void d(StringBuilder sb, int i2, int i3, String str) {
        if ((i2 & i3) == i3) {
            sb.append(str);
        }
    }

    private Drawable e(Drawable drawable) {
        if (drawable != null && this.f440x && (this.f438v || this.f439w)) {
            drawable = x.a.r(drawable).mutate();
            if (this.f438v) {
                x.a.o(drawable, this.f436t);
            }
            if (this.f439w) {
                x.a.p(drawable, this.f437u);
            }
            this.f440x = false;
        }
        return drawable;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public boolean A() {
        return this.f430n.H() && g() != 0;
    }

    public boolean B() {
        return (this.f442z & 4) == 4;
    }

    @Override // y.b
    public y.b a(e0.b bVar) {
        e0.b bVar2 = this.B;
        if (bVar2 != null) {
            bVar2.h();
        }
        this.A = null;
        this.B = bVar;
        this.f430n.K(true);
        e0.b bVar3 = this.B;
        if (bVar3 != null) {
            bVar3.j(new a());
        }
        return this;
    }

    @Override // y.b
    public e0.b b() {
        return this.B;
    }

    public void c() {
        this.f430n.I(this);
    }

    @Override // y.b, android.view.MenuItem
    public boolean collapseActionView() {
        if ((this.f442z & 8) == 0) {
            return false;
        }
        if (this.A == null) {
            return true;
        }
        MenuItem.OnActionExpandListener onActionExpandListener = this.C;
        if (onActionExpandListener == null || onActionExpandListener.onMenuItemActionCollapse(this)) {
            return this.f430n.f(this);
        }
        return false;
    }

    @Override // y.b, android.view.MenuItem
    public boolean expandActionView() {
        if (j()) {
            MenuItem.OnActionExpandListener onActionExpandListener = this.C;
            if (onActionExpandListener == null || onActionExpandListener.onMenuItemActionExpand(this)) {
                return this.f430n.k(this);
            }
            return false;
        }
        return false;
    }

    public int f() {
        return this.f420d;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public char g() {
        return this.f430n.G() ? this.f426j : this.f424h;
    }

    @Override // android.view.MenuItem
    public ActionProvider getActionProvider() {
        throw new UnsupportedOperationException("This is not supported, use MenuItemCompat.getActionProvider()");
    }

    @Override // y.b, android.view.MenuItem
    public View getActionView() {
        View view = this.A;
        if (view != null) {
            return view;
        }
        e0.b bVar = this.B;
        if (bVar != null) {
            View d2 = bVar.d(this);
            this.A = d2;
            return d2;
        }
        return null;
    }

    @Override // y.b, android.view.MenuItem
    public int getAlphabeticModifiers() {
        return this.f427k;
    }

    @Override // android.view.MenuItem
    public char getAlphabeticShortcut() {
        return this.f426j;
    }

    @Override // y.b, android.view.MenuItem
    public CharSequence getContentDescription() {
        return this.f434r;
    }

    @Override // android.view.MenuItem
    public int getGroupId() {
        return this.f418b;
    }

    @Override // android.view.MenuItem
    public Drawable getIcon() {
        Drawable drawable = this.f428l;
        if (drawable != null) {
            return e(drawable);
        }
        if (this.f429m != 0) {
            Drawable d2 = c.a.d(this.f430n.u(), this.f429m);
            this.f429m = 0;
            this.f428l = d2;
            return e(d2);
        }
        return null;
    }

    @Override // y.b, android.view.MenuItem
    public ColorStateList getIconTintList() {
        return this.f436t;
    }

    @Override // y.b, android.view.MenuItem
    public PorterDuff.Mode getIconTintMode() {
        return this.f437u;
    }

    @Override // android.view.MenuItem
    public Intent getIntent() {
        return this.f423g;
    }

    @Override // android.view.MenuItem
    @ViewDebug.CapturedViewProperty
    public int getItemId() {
        return this.f417a;
    }

    @Override // android.view.MenuItem
    public ContextMenu.ContextMenuInfo getMenuInfo() {
        return this.E;
    }

    @Override // y.b, android.view.MenuItem
    public int getNumericModifiers() {
        return this.f425i;
    }

    @Override // android.view.MenuItem
    public char getNumericShortcut() {
        return this.f424h;
    }

    @Override // android.view.MenuItem
    public int getOrder() {
        return this.f419c;
    }

    @Override // android.view.MenuItem
    public SubMenu getSubMenu() {
        return this.f431o;
    }

    @Override // android.view.MenuItem
    @ViewDebug.CapturedViewProperty
    public CharSequence getTitle() {
        return this.f421e;
    }

    @Override // android.view.MenuItem
    public CharSequence getTitleCondensed() {
        CharSequence charSequence = this.f422f;
        return charSequence != null ? charSequence : this.f421e;
    }

    @Override // y.b, android.view.MenuItem
    public CharSequence getTooltipText() {
        return this.f435s;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public String h() {
        int i2;
        char g2 = g();
        if (g2 == 0) {
            return "";
        }
        Resources resources = this.f430n.u().getResources();
        StringBuilder sb = new StringBuilder();
        if (ViewConfiguration.get(this.f430n.u()).hasPermanentMenuKey()) {
            sb.append(resources.getString(a.h.abc_prepend_shortcut_label));
        }
        int i3 = this.f430n.G() ? this.f427k : this.f425i;
        d(sb, i3, 65536, resources.getString(a.h.abc_menu_meta_shortcut_label));
        d(sb, i3, 4096, resources.getString(a.h.abc_menu_ctrl_shortcut_label));
        d(sb, i3, 2, resources.getString(a.h.abc_menu_alt_shortcut_label));
        d(sb, i3, 1, resources.getString(a.h.abc_menu_shift_shortcut_label));
        d(sb, i3, 4, resources.getString(a.h.abc_menu_sym_shortcut_label));
        d(sb, i3, 8, resources.getString(a.h.abc_menu_function_shortcut_label));
        if (g2 == '\b') {
            i2 = a.h.abc_menu_delete_shortcut_label;
        } else if (g2 == '\n') {
            i2 = a.h.abc_menu_enter_shortcut_label;
        } else if (g2 != ' ') {
            sb.append(g2);
            return sb.toString();
        } else {
            i2 = a.h.abc_menu_space_shortcut_label;
        }
        sb.append(resources.getString(i2));
        return sb.toString();
    }

    @Override // android.view.MenuItem
    public boolean hasSubMenu() {
        return this.f431o != null;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public CharSequence i(k.a aVar) {
        return (aVar == null || !aVar.d()) ? getTitle() : getTitleCondensed();
    }

    @Override // y.b, android.view.MenuItem
    public boolean isActionViewExpanded() {
        return this.D;
    }

    @Override // android.view.MenuItem
    public boolean isCheckable() {
        return (this.f441y & 1) == 1;
    }

    @Override // android.view.MenuItem
    public boolean isChecked() {
        return (this.f441y & 2) == 2;
    }

    @Override // android.view.MenuItem
    public boolean isEnabled() {
        return (this.f441y & 16) != 0;
    }

    @Override // android.view.MenuItem
    public boolean isVisible() {
        e0.b bVar = this.B;
        return (bVar == null || !bVar.g()) ? (this.f441y & 8) == 0 : (this.f441y & 8) == 0 && this.B.b();
    }

    public boolean j() {
        e0.b bVar;
        if ((this.f442z & 8) != 0) {
            if (this.A == null && (bVar = this.B) != null) {
                this.A = bVar.d(this);
            }
            return this.A != null;
        }
        return false;
    }

    public boolean k() {
        MenuItem.OnMenuItemClickListener onMenuItemClickListener = this.f433q;
        if (onMenuItemClickListener == null || !onMenuItemClickListener.onMenuItemClick(this)) {
            e eVar = this.f430n;
            if (eVar.h(eVar, this)) {
                return true;
            }
            Runnable runnable = this.f432p;
            if (runnable != null) {
                runnable.run();
                return true;
            }
            if (this.f423g != null) {
                try {
                    this.f430n.u().startActivity(this.f423g);
                    return true;
                } catch (ActivityNotFoundException e2) {
                    Log.e("MenuItemImpl", "Can't find activity to handle intent; ignoring", e2);
                }
            }
            e0.b bVar = this.B;
            return bVar != null && bVar.e();
        }
        return true;
    }

    public boolean l() {
        return (this.f441y & 32) == 32;
    }

    public boolean m() {
        return (this.f441y & 4) != 0;
    }

    public boolean n() {
        return (this.f442z & 1) == 1;
    }

    public boolean o() {
        return (this.f442z & 2) == 2;
    }

    @Override // y.b, android.view.MenuItem
    /* renamed from: p  reason: merged with bridge method [inline-methods] */
    public y.b setActionView(int i2) {
        Context u2 = this.f430n.u();
        setActionView(LayoutInflater.from(u2).inflate(i2, (ViewGroup) new LinearLayout(u2), false));
        return this;
    }

    @Override // y.b, android.view.MenuItem
    /* renamed from: q  reason: merged with bridge method [inline-methods] */
    public y.b setActionView(View view) {
        int i2;
        this.A = view;
        this.B = null;
        if (view != null && view.getId() == -1 && (i2 = this.f417a) > 0) {
            view.setId(i2);
        }
        this.f430n.I(this);
        return this;
    }

    public void r(boolean z2) {
        this.D = z2;
        this.f430n.K(false);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void s(boolean z2) {
        int i2 = this.f441y;
        int i3 = (z2 ? 2 : 0) | (i2 & (-3));
        this.f441y = i3;
        if (i2 != i3) {
            this.f430n.K(false);
        }
    }

    @Override // android.view.MenuItem
    public MenuItem setActionProvider(ActionProvider actionProvider) {
        throw new UnsupportedOperationException("This is not supported, use MenuItemCompat.setActionProvider()");
    }

    @Override // android.view.MenuItem
    public MenuItem setAlphabeticShortcut(char c2) {
        if (this.f426j == c2) {
            return this;
        }
        this.f426j = Character.toLowerCase(c2);
        this.f430n.K(false);
        return this;
    }

    @Override // y.b, android.view.MenuItem
    public MenuItem setAlphabeticShortcut(char c2, int i2) {
        if (this.f426j == c2 && this.f427k == i2) {
            return this;
        }
        this.f426j = Character.toLowerCase(c2);
        this.f427k = KeyEvent.normalizeMetaState(i2);
        this.f430n.K(false);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setCheckable(boolean z2) {
        int i2 = this.f441y;
        int i3 = (z2 ? 1 : 0) | (i2 & (-2));
        this.f441y = i3;
        if (i2 != i3) {
            this.f430n.K(false);
        }
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setChecked(boolean z2) {
        if ((this.f441y & 4) != 0) {
            this.f430n.T(this);
        } else {
            s(z2);
        }
        return this;
    }

    @Override // android.view.MenuItem
    public y.b setContentDescription(CharSequence charSequence) {
        this.f434r = charSequence;
        this.f430n.K(false);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setEnabled(boolean z2) {
        this.f441y = z2 ? this.f441y | 16 : this.f441y & (-17);
        this.f430n.K(false);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setIcon(int i2) {
        this.f428l = null;
        this.f429m = i2;
        this.f440x = true;
        this.f430n.K(false);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setIcon(Drawable drawable) {
        this.f429m = 0;
        this.f428l = drawable;
        this.f440x = true;
        this.f430n.K(false);
        return this;
    }

    @Override // y.b, android.view.MenuItem
    public MenuItem setIconTintList(ColorStateList colorStateList) {
        this.f436t = colorStateList;
        this.f438v = true;
        this.f440x = true;
        this.f430n.K(false);
        return this;
    }

    @Override // y.b, android.view.MenuItem
    public MenuItem setIconTintMode(PorterDuff.Mode mode) {
        this.f437u = mode;
        this.f439w = true;
        this.f440x = true;
        this.f430n.K(false);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setIntent(Intent intent) {
        this.f423g = intent;
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setNumericShortcut(char c2) {
        if (this.f424h == c2) {
            return this;
        }
        this.f424h = c2;
        this.f430n.K(false);
        return this;
    }

    @Override // y.b, android.view.MenuItem
    public MenuItem setNumericShortcut(char c2, int i2) {
        if (this.f424h == c2 && this.f425i == i2) {
            return this;
        }
        this.f424h = c2;
        this.f425i = KeyEvent.normalizeMetaState(i2);
        this.f430n.K(false);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setOnActionExpandListener(MenuItem.OnActionExpandListener onActionExpandListener) {
        this.C = onActionExpandListener;
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setOnMenuItemClickListener(MenuItem.OnMenuItemClickListener onMenuItemClickListener) {
        this.f433q = onMenuItemClickListener;
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setShortcut(char c2, char c3) {
        this.f424h = c2;
        this.f426j = Character.toLowerCase(c3);
        this.f430n.K(false);
        return this;
    }

    @Override // y.b, android.view.MenuItem
    public MenuItem setShortcut(char c2, char c3, int i2, int i3) {
        this.f424h = c2;
        this.f425i = KeyEvent.normalizeMetaState(i2);
        this.f426j = Character.toLowerCase(c3);
        this.f427k = KeyEvent.normalizeMetaState(i3);
        this.f430n.K(false);
        return this;
    }

    @Override // y.b, android.view.MenuItem
    public void setShowAsAction(int i2) {
        int i3 = i2 & 3;
        if (i3 != 0 && i3 != 1 && i3 != 2) {
            throw new IllegalArgumentException("SHOW_AS_ACTION_ALWAYS, SHOW_AS_ACTION_IF_ROOM, and SHOW_AS_ACTION_NEVER are mutually exclusive.");
        }
        this.f442z = i2;
        this.f430n.I(this);
    }

    @Override // android.view.MenuItem
    public MenuItem setTitle(int i2) {
        return setTitle(this.f430n.u().getString(i2));
    }

    @Override // android.view.MenuItem
    public MenuItem setTitle(CharSequence charSequence) {
        this.f421e = charSequence;
        this.f430n.K(false);
        m mVar = this.f431o;
        if (mVar != null) {
            mVar.setHeaderTitle(charSequence);
        }
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setTitleCondensed(CharSequence charSequence) {
        this.f422f = charSequence;
        this.f430n.K(false);
        return this;
    }

    @Override // android.view.MenuItem
    public y.b setTooltipText(CharSequence charSequence) {
        this.f435s = charSequence;
        this.f430n.K(false);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setVisible(boolean z2) {
        if (y(z2)) {
            this.f430n.J(this);
        }
        return this;
    }

    public void t(boolean z2) {
        this.f441y = (z2 ? 4 : 0) | (this.f441y & (-5));
    }

    public String toString() {
        CharSequence charSequence = this.f421e;
        if (charSequence != null) {
            return charSequence.toString();
        }
        return null;
    }

    public void u(boolean z2) {
        this.f441y = z2 ? this.f441y | 32 : this.f441y & (-33);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void v(ContextMenu.ContextMenuInfo contextMenuInfo) {
        this.E = contextMenuInfo;
    }

    @Override // y.b, android.view.MenuItem
    /* renamed from: w  reason: merged with bridge method [inline-methods] */
    public y.b setShowAsActionFlags(int i2) {
        setShowAsAction(i2);
        return this;
    }

    public void x(m mVar) {
        this.f431o = mVar;
        mVar.setHeaderTitle(getTitle());
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public boolean y(boolean z2) {
        int i2 = this.f441y;
        int i3 = (z2 ? 0 : 8) | (i2 & (-9));
        this.f441y = i3;
        return i2 != i3;
    }

    public boolean z() {
        return this.f430n.A();
    }
}
