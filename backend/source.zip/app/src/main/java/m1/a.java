package m1;

import a1.b;
import a1.j;
import android.content.Context;
import android.content.res.ColorStateList;
import android.util.AttributeSet;
import androidx.appcompat.widget.r;
import androidx.core.widget.c;
/* loaded from: classes.dex */
public class a extends r {

    /* renamed from: g  reason: collision with root package name */
    private static final int f4676g = j.Widget_MaterialComponents_CompoundButton_RadioButton;

    /* renamed from: h  reason: collision with root package name */
    private static final int[][] f4677h = {new int[]{16842910, 16842912}, new int[]{16842910, -16842912}, new int[]{-16842910, 16842912}, new int[]{-16842910, -16842912}};

    /* renamed from: e  reason: collision with root package name */
    private ColorStateList f4678e;

    /* renamed from: f  reason: collision with root package name */
    private boolean f4679f;

    public a(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, b.f107v);
    }

    /* JADX WARN: Illegal instructions before constructor call */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public a(android.content.Context r8, android.util.AttributeSet r9, int r10) {
        /*
            r7 = this;
            int r4 = m1.a.f4676g
            android.content.Context r8 = s1.a.c(r8, r9, r10, r4)
            r7.<init>(r8, r9, r10)
            android.content.Context r8 = r7.getContext()
            int[] r2 = a1.k.J2
            r6 = 0
            int[] r5 = new int[r6]
            r0 = r8
            r1 = r9
            r3 = r10
            android.content.res.TypedArray r9 = com.google.android.material.internal.j.h(r0, r1, r2, r3, r4, r5)
            int r10 = a1.k.K2
            boolean r0 = r9.hasValue(r10)
            if (r0 == 0) goto L28
            android.content.res.ColorStateList r8 = n1.c.a(r8, r9, r10)
            androidx.core.widget.c.c(r7, r8)
        L28:
            int r8 = a1.k.L2
            boolean r8 = r9.getBoolean(r8, r6)
            r7.f4679f = r8
            r9.recycle()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: m1.a.<init>(android.content.Context, android.util.AttributeSet, int):void");
    }

    private ColorStateList getMaterialThemeColorsTintList() {
        if (this.f4678e == null) {
            int c2 = g1.a.c(this, b.f104f);
            int c3 = g1.a.c(this, b.colorOnSurface);
            int c4 = g1.a.c(this, b.colorSurface);
            int[][] iArr = f4677h;
            int[] iArr2 = new int[iArr.length];
            iArr2[0] = g1.a.f(c4, c2, 1.0f);
            iArr2[1] = g1.a.f(c4, c3, 0.54f);
            iArr2[2] = g1.a.f(c4, c3, 0.38f);
            iArr2[3] = g1.a.f(c4, c3, 0.38f);
            this.f4678e = new ColorStateList(iArr, iArr2);
        }
        return this.f4678e;
    }

    @Override // android.widget.TextView, android.view.View
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (this.f4679f && c.b(this) == null) {
            setUseMaterialThemeColors(true);
        }
    }

    public void setUseMaterialThemeColors(boolean z2) {
        this.f4679f = z2;
        c.c(this, z2 ? getMaterialThemeColorsTintList() : null);
    }
}
