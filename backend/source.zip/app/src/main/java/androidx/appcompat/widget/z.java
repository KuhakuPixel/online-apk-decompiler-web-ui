package androidx.appcompat.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ToggleButton;
/* loaded from: classes.dex */
public class z extends ToggleButton {

    /* renamed from: b  reason: collision with root package name */
    private final x f1021b;

    public z(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 16842827);
    }

    public z(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        o0.a(this, getContext());
        x xVar = new x(this);
        this.f1021b = xVar;
        xVar.m(attributeSet, i2);
    }
}
