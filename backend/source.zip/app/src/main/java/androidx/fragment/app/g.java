package androidx.fragment.app;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
/* loaded from: classes.dex */
public class g {

    /* renamed from: a  reason: collision with root package name */
    private final i<?> f1629a;

    private g(i<?> iVar) {
        this.f1629a = iVar;
    }

    public static g b(i<?> iVar) {
        return new g((i) d0.h.d(iVar, "callbacks == null"));
    }

    public void a(Fragment fragment) {
        i<?> iVar = this.f1629a;
        iVar.f1635f.g(iVar, iVar, fragment);
    }

    public void c() {
        this.f1629a.f1635f.r();
    }

    public void d(Configuration configuration) {
        this.f1629a.f1635f.s(configuration);
    }

    public boolean e(MenuItem menuItem) {
        return this.f1629a.f1635f.t(menuItem);
    }

    public void f() {
        this.f1629a.f1635f.u();
    }

    public boolean g(Menu menu, MenuInflater menuInflater) {
        return this.f1629a.f1635f.v(menu, menuInflater);
    }

    public void h() {
        this.f1629a.f1635f.w();
    }

    public void i() {
        this.f1629a.f1635f.y();
    }

    public void j(boolean z2) {
        this.f1629a.f1635f.z(z2);
    }

    public boolean k(MenuItem menuItem) {
        return this.f1629a.f1635f.A(menuItem);
    }

    public void l(Menu menu) {
        this.f1629a.f1635f.B(menu);
    }

    public void m() {
        this.f1629a.f1635f.D();
    }

    public void n(boolean z2) {
        this.f1629a.f1635f.E(z2);
    }

    public boolean o(Menu menu) {
        return this.f1629a.f1635f.F(menu);
    }

    public void p() {
        this.f1629a.f1635f.H();
    }

    public void q() {
        this.f1629a.f1635f.I();
    }

    public void r() {
        this.f1629a.f1635f.K();
    }

    public boolean s() {
        return this.f1629a.f1635f.Q(true);
    }

    public Fragment t(String str) {
        return this.f1629a.f1635f.Y(str);
    }

    public l u() {
        return this.f1629a.f1635f;
    }

    public void v() {
        this.f1629a.f1635f.B0();
    }

    public View w(View view, String str, Context context, AttributeSet attributeSet) {
        return this.f1629a.f1635f.g0().onCreateView(view, str, context, attributeSet);
    }

    public void x(Parcelable parcelable) {
        i<?> iVar = this.f1629a;
        if (!(iVar instanceof androidx.lifecycle.u)) {
            throw new IllegalStateException("Your FragmentHostCallback must implement ViewModelStoreOwner to call restoreSaveState(). Call restoreAllState()  if you're still using retainNestedNonConfig().");
        }
        iVar.f1635f.O0(parcelable);
    }

    public Parcelable y() {
        return this.f1629a.f1635f.Q0();
    }
}
