package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import androidx.appcompat.widget.j0;
/* loaded from: classes.dex */
public final class j {

    /* renamed from: b  reason: collision with root package name */
    private static final PorterDuff.Mode f803b = PorterDuff.Mode.SRC_IN;

    /* renamed from: c  reason: collision with root package name */
    private static j f804c;

    /* renamed from: a  reason: collision with root package name */
    private j0 f805a;

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public class a implements j0.e {

        /* renamed from: a  reason: collision with root package name */
        private final int[] f806a = {a.e.S, a.e.Q, a.e.f4a};

        /* renamed from: b  reason: collision with root package name */
        private final int[] f807b = {a.e.f6o, a.e.abc_seekbar_tick_mark_material, a.e.f11t, a.e.f7p, a.e.f8q, a.e.f10s, a.e.f9r};

        /* renamed from: c  reason: collision with root package name */
        private final int[] f808c = {a.e.P, a.e.R, a.e.f5k, a.e.abc_text_cursor_material, a.e.J, a.e.L, a.e.N, a.e.K, a.e.M, a.e.O};

        /* renamed from: d  reason: collision with root package name */
        private final int[] f809d = {a.e.f14w, a.e.abc_cab_background_internal_bg, a.e.f13v};

        /* renamed from: e  reason: collision with root package name */
        private final int[] f810e = {a.e.abc_tab_indicator_material, a.e.abc_textfield_search_material};

        /* renamed from: f  reason: collision with root package name */
        private final int[] f811f = {a.e.abc_btn_check_material, a.e.abc_btn_radio_material, a.e.abc_btn_check_material_anim, a.e.abc_btn_radio_material_anim};

        a() {
        }

        private boolean f(int[] iArr, int i2) {
            for (int i3 : iArr) {
                if (i3 == i2) {
                    return true;
                }
            }
            return false;
        }

        private ColorStateList g(Context context) {
            return h(context, 0);
        }

        private ColorStateList h(Context context, int i2) {
            int c2 = o0.c(context, a.a.f3v);
            return new ColorStateList(new int[][]{o0.f883b, o0.f886e, o0.f884c, o0.f890i}, new int[]{o0.b(context, a.a.colorButtonNormal), w.a.b(c2, i2), w.a.b(c2, i2), i2});
        }

        private ColorStateList i(Context context) {
            return h(context, o0.c(context, a.a.colorAccent));
        }

        private ColorStateList j(Context context) {
            return h(context, o0.c(context, a.a.colorButtonNormal));
        }

        private ColorStateList k(Context context) {
            int[][] iArr = new int[3];
            int[] iArr2 = new int[3];
            int i2 = a.a.colorSwitchThumbNormal;
            ColorStateList e2 = o0.e(context, i2);
            if (e2 == null || !e2.isStateful()) {
                iArr[0] = o0.f883b;
                iArr2[0] = o0.b(context, i2);
                iArr[1] = o0.f887f;
                iArr2[1] = o0.c(context, a.a.f2u);
                iArr[2] = o0.f890i;
                iArr2[2] = o0.c(context, i2);
            } else {
                iArr[0] = o0.f883b;
                iArr2[0] = e2.getColorForState(iArr[0], 0);
                iArr[1] = o0.f887f;
                iArr2[1] = o0.c(context, a.a.f2u);
                iArr[2] = o0.f890i;
                iArr2[2] = e2.getDefaultColor();
            }
            return new ColorStateList(iArr, iArr2);
        }

        private void l(Drawable drawable, int i2, PorterDuff.Mode mode) {
            if (c0.a(drawable)) {
                drawable = drawable.mutate();
            }
            if (mode == null) {
                mode = j.f803b;
            }
            drawable.setColorFilter(j.e(i2, mode));
        }

        @Override // androidx.appcompat.widget.j0.e
        public Drawable a(j0 j0Var, Context context, int i2) {
            if (i2 == a.e.abc_cab_background_top_material) {
                return new LayerDrawable(new Drawable[]{j0Var.j(context, a.e.abc_cab_background_internal_bg), j0Var.j(context, a.e.f5k)});
            }
            return null;
        }

        /* JADX WARN: Removed duplicated region for block: B:21:0x0046  */
        /* JADX WARN: Removed duplicated region for block: B:28:0x0061 A[RETURN] */
        @Override // androidx.appcompat.widget.j0.e
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public boolean b(android.content.Context r7, int r8, android.graphics.drawable.Drawable r9) {
            /*
                r6 = this;
                android.graphics.PorterDuff$Mode r0 = androidx.appcompat.widget.j.a()
                int[] r1 = r6.f806a
                boolean r1 = r6.f(r1, r8)
                r2 = 16842801(0x1010031, float:2.3693695E-38)
                r3 = -1
                r4 = 0
                r5 = 1
                if (r1 == 0) goto L17
                int r2 = a.a.colorControlNormal
            L14:
                r8 = -1
            L15:
                r1 = 1
                goto L44
            L17:
                int[] r1 = r6.f808c
                boolean r1 = r6.f(r1, r8)
                if (r1 == 0) goto L22
                int r2 = a.a.f2u
                goto L14
            L22:
                int[] r1 = r6.f809d
                boolean r1 = r6.f(r1, r8)
                if (r1 == 0) goto L2d
                android.graphics.PorterDuff$Mode r0 = android.graphics.PorterDuff.Mode.MULTIPLY
                goto L14
            L2d:
                int r1 = a.e.f12u
                if (r8 != r1) goto L3c
                r2 = 16842800(0x1010030, float:2.3693693E-38)
                r8 = 1109603123(0x42233333, float:40.8)
                int r8 = java.lang.Math.round(r8)
                goto L15
            L3c:
                int r1 = a.e.abc_dialog_material_background
                if (r8 != r1) goto L41
                goto L14
            L41:
                r8 = -1
                r1 = 0
                r2 = 0
            L44:
                if (r1 == 0) goto L61
                boolean r1 = androidx.appcompat.widget.c0.a(r9)
                if (r1 == 0) goto L50
                android.graphics.drawable.Drawable r9 = r9.mutate()
            L50:
                int r7 = androidx.appcompat.widget.o0.c(r7, r2)
                android.graphics.PorterDuffColorFilter r7 = androidx.appcompat.widget.j.e(r7, r0)
                r9.setColorFilter(r7)
                if (r8 == r3) goto L60
                r9.setAlpha(r8)
            L60:
                return r5
            L61:
                return r4
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.j.a.b(android.content.Context, int, android.graphics.drawable.Drawable):boolean");
        }

        @Override // androidx.appcompat.widget.j0.e
        public ColorStateList c(Context context, int i2) {
            if (i2 == a.e.abc_edit_text_material) {
                return c.a.c(context, a.c.abc_tint_edittext);
            }
            if (i2 == a.e.G) {
                return c.a.c(context, a.c.abc_tint_switch_track);
            }
            if (i2 == a.e.abc_switch_thumb_material) {
                return k(context);
            }
            if (i2 == a.e.abc_btn_default_mtrl_shape) {
                return j(context);
            }
            if (i2 == a.e.abc_btn_borderless_material) {
                return g(context);
            }
            if (i2 == a.e.abc_btn_colored_material) {
                return i(context);
            }
            if (i2 == a.e.D || i2 == a.e.abc_spinner_textfield_background_material) {
                return c.a.c(context, a.c.abc_tint_spinner);
            }
            if (f(this.f807b, i2)) {
                return o0.e(context, a.a.colorControlNormal);
            }
            if (f(this.f810e, i2)) {
                return c.a.c(context, a.c.abc_tint_default);
            }
            if (f(this.f811f, i2)) {
                return c.a.c(context, a.c.abc_tint_btn_checkable);
            }
            if (i2 == a.e.abc_seekbar_thumb_material) {
                return c.a.c(context, a.c.abc_tint_seek_thumb);
            }
            return null;
        }

        @Override // androidx.appcompat.widget.j0.e
        public boolean d(Context context, int i2, Drawable drawable) {
            Drawable findDrawableByLayerId;
            int c2;
            if (i2 == a.e.abc_seekbar_track_material) {
                LayerDrawable layerDrawable = (LayerDrawable) drawable;
                Drawable findDrawableByLayerId2 = layerDrawable.findDrawableByLayerId(16908288);
                int i3 = a.a.colorControlNormal;
                l(findDrawableByLayerId2, o0.c(context, i3), j.f803b);
                l(layerDrawable.findDrawableByLayerId(16908303), o0.c(context, i3), j.f803b);
                findDrawableByLayerId = layerDrawable.findDrawableByLayerId(16908301);
                c2 = o0.c(context, a.a.f2u);
            } else if (i2 != a.e.abc_ratingbar_material && i2 != a.e.abc_ratingbar_indicator_material && i2 != a.e.abc_ratingbar_small_material) {
                return false;
            } else {
                LayerDrawable layerDrawable2 = (LayerDrawable) drawable;
                l(layerDrawable2.findDrawableByLayerId(16908288), o0.b(context, a.a.colorControlNormal), j.f803b);
                Drawable findDrawableByLayerId3 = layerDrawable2.findDrawableByLayerId(16908303);
                int i4 = a.a.f2u;
                l(findDrawableByLayerId3, o0.c(context, i4), j.f803b);
                findDrawableByLayerId = layerDrawable2.findDrawableByLayerId(16908301);
                c2 = o0.c(context, i4);
            }
            l(findDrawableByLayerId, c2, j.f803b);
            return true;
        }

        @Override // androidx.appcompat.widget.j0.e
        public PorterDuff.Mode e(int i2) {
            if (i2 == a.e.abc_switch_thumb_material) {
                return PorterDuff.Mode.MULTIPLY;
            }
            return null;
        }
    }

    public static synchronized j b() {
        j jVar;
        synchronized (j.class) {
            if (f804c == null) {
                h();
            }
            jVar = f804c;
        }
        return jVar;
    }

    public static synchronized PorterDuffColorFilter e(int i2, PorterDuff.Mode mode) {
        PorterDuffColorFilter l2;
        synchronized (j.class) {
            l2 = j0.l(i2, mode);
        }
        return l2;
    }

    public static synchronized void h() {
        synchronized (j.class) {
            if (f804c == null) {
                j jVar = new j();
                f804c = jVar;
                jVar.f805a = j0.h();
                f804c.f805a.u(new a());
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void i(Drawable drawable, r0 r0Var, int[] iArr) {
        j0.w(drawable, r0Var, iArr);
    }

    public synchronized Drawable c(Context context, int i2) {
        return this.f805a.j(context, i2);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public synchronized Drawable d(Context context, int i2, boolean z2) {
        return this.f805a.k(context, i2, z2);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public synchronized ColorStateList f(Context context, int i2) {
        return this.f805a.m(context, i2);
    }

    public synchronized void g(Context context) {
        this.f805a.s(context);
    }
}
