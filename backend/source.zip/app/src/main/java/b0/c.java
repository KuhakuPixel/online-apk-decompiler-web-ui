package b0;

import android.os.Handler;
import android.os.HandlerThread;
import android.os.Message;
import java.util.concurrent.Callable;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;
/* loaded from: classes.dex */
public class c {

    /* renamed from: b  reason: collision with root package name */
    private HandlerThread f3006b;

    /* renamed from: c  reason: collision with root package name */
    private Handler f3007c;

    /* renamed from: f  reason: collision with root package name */
    private final int f3010f;

    /* renamed from: g  reason: collision with root package name */
    private final int f3011g;

    /* renamed from: h  reason: collision with root package name */
    private final String f3012h;

    /* renamed from: a  reason: collision with root package name */
    private final Object f3005a = new Object();

    /* renamed from: e  reason: collision with root package name */
    private Handler.Callback f3009e = new a();

    /* renamed from: d  reason: collision with root package name */
    private int f3008d = 0;

    /* loaded from: classes.dex */
    class a implements Handler.Callback {
        a() {
        }

        @Override // android.os.Handler.Callback
        public boolean handleMessage(Message message) {
            int i2 = message.what;
            if (i2 == 0) {
                c.this.a();
                return true;
            } else if (i2 != 1) {
                return true;
            } else {
                c.this.b((Runnable) message.obj);
                return true;
            }
        }
    }

    /* loaded from: classes.dex */
    class b implements Runnable {

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ Callable f3014b;

        /* renamed from: c  reason: collision with root package name */
        final /* synthetic */ Handler f3015c;

        /* renamed from: d  reason: collision with root package name */
        final /* synthetic */ d f3016d;

        /* loaded from: classes.dex */
        class a implements Runnable {

            /* renamed from: b  reason: collision with root package name */
            final /* synthetic */ Object f3018b;

            a(Object obj) {
                this.f3018b = obj;
            }

            @Override // java.lang.Runnable
            public void run() {
                b.this.f3016d.a(this.f3018b);
            }
        }

        b(Callable callable, Handler handler, d dVar) {
            this.f3014b = callable;
            this.f3015c = handler;
            this.f3016d = dVar;
        }

        @Override // java.lang.Runnable
        public void run() {
            Object obj;
            try {
                obj = this.f3014b.call();
            } catch (Exception unused) {
                obj = null;
            }
            this.f3015c.post(new a(obj));
        }
    }

    /* renamed from: b0.c$c  reason: collision with other inner class name */
    /* loaded from: classes.dex */
    class RunnableC0028c implements Runnable {

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ AtomicReference f3020b;

        /* renamed from: c  reason: collision with root package name */
        final /* synthetic */ Callable f3021c;

        /* renamed from: d  reason: collision with root package name */
        final /* synthetic */ ReentrantLock f3022d;

        /* renamed from: e  reason: collision with root package name */
        final /* synthetic */ AtomicBoolean f3023e;

        /* renamed from: f  reason: collision with root package name */
        final /* synthetic */ Condition f3024f;

        RunnableC0028c(AtomicReference atomicReference, Callable callable, ReentrantLock reentrantLock, AtomicBoolean atomicBoolean, Condition condition) {
            this.f3020b = atomicReference;
            this.f3021c = callable;
            this.f3022d = reentrantLock;
            this.f3023e = atomicBoolean;
            this.f3024f = condition;
        }

        @Override // java.lang.Runnable
        public void run() {
            try {
                this.f3020b.set(this.f3021c.call());
            } catch (Exception unused) {
            }
            this.f3022d.lock();
            try {
                this.f3023e.set(false);
                this.f3024f.signal();
            } finally {
                this.f3022d.unlock();
            }
        }
    }

    /* loaded from: classes.dex */
    public interface d<T> {
        void a(T t2);
    }

    public c(String str, int i2, int i3) {
        this.f3012h = str;
        this.f3011g = i2;
        this.f3010f = i3;
    }

    private void c(Runnable runnable) {
        synchronized (this.f3005a) {
            if (this.f3006b == null) {
                HandlerThread handlerThread = new HandlerThread(this.f3012h, this.f3011g);
                this.f3006b = handlerThread;
                handlerThread.start();
                this.f3007c = new Handler(this.f3006b.getLooper(), this.f3009e);
                this.f3008d++;
            }
            this.f3007c.removeMessages(0);
            Handler handler = this.f3007c;
            handler.sendMessage(handler.obtainMessage(1, runnable));
        }
    }

    void a() {
        synchronized (this.f3005a) {
            if (this.f3007c.hasMessages(1)) {
                return;
            }
            this.f3006b.quit();
            this.f3006b = null;
            this.f3007c = null;
        }
    }

    void b(Runnable runnable) {
        runnable.run();
        synchronized (this.f3005a) {
            this.f3007c.removeMessages(0);
            Handler handler = this.f3007c;
            handler.sendMessageDelayed(handler.obtainMessage(0), this.f3010f);
        }
    }

    public <T> void d(Callable<T> callable, d<T> dVar) {
        c(new b(callable, new Handler(), dVar));
    }

    public <T> T e(Callable<T> callable, int i2) {
        ReentrantLock reentrantLock = new ReentrantLock();
        Condition newCondition = reentrantLock.newCondition();
        AtomicReference atomicReference = new AtomicReference();
        AtomicBoolean atomicBoolean = new AtomicBoolean(true);
        c(new RunnableC0028c(atomicReference, callable, reentrantLock, atomicBoolean, newCondition));
        reentrantLock.lock();
        try {
            if (atomicBoolean.get()) {
                long nanos = TimeUnit.MILLISECONDS.toNanos(i2);
                do {
                    try {
                        nanos = newCondition.awaitNanos(nanos);
                    } catch (InterruptedException unused) {
                    }
                    if (!atomicBoolean.get()) {
                        return (T) atomicReference.get();
                    }
                } while (nanos > 0);
                throw new InterruptedException("timeout");
            }
            return (T) atomicReference.get();
        } finally {
            reentrantLock.unlock();
        }
    }
}
