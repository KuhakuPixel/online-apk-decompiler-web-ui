package d;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Outline;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.SparseArray;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes.dex */
public class b extends Drawable implements Drawable.Callback {

    /* renamed from: b  reason: collision with root package name */
    private c f4191b;

    /* renamed from: c  reason: collision with root package name */
    private Rect f4192c;

    /* renamed from: d  reason: collision with root package name */
    private Drawable f4193d;

    /* renamed from: e  reason: collision with root package name */
    private Drawable f4194e;

    /* renamed from: g  reason: collision with root package name */
    private boolean f4196g;

    /* renamed from: i  reason: collision with root package name */
    private boolean f4198i;

    /* renamed from: j  reason: collision with root package name */
    private Runnable f4199j;

    /* renamed from: k  reason: collision with root package name */
    private long f4200k;

    /* renamed from: l  reason: collision with root package name */
    private long f4201l;

    /* renamed from: m  reason: collision with root package name */
    private C0050b f4202m;

    /* renamed from: f  reason: collision with root package name */
    private int f4195f = 255;

    /* renamed from: h  reason: collision with root package name */
    private int f4197h = -1;

    /* loaded from: classes.dex */
    class a implements Runnable {
        a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            b.this.a(true);
            b.this.invalidateSelf();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: d.b$b  reason: collision with other inner class name */
    /* loaded from: classes.dex */
    public static class C0050b implements Drawable.Callback {

        /* renamed from: b  reason: collision with root package name */
        private Drawable.Callback f4204b;

        C0050b() {
        }

        public Drawable.Callback a() {
            Drawable.Callback callback = this.f4204b;
            this.f4204b = null;
            return callback;
        }

        public C0050b b(Drawable.Callback callback) {
            this.f4204b = callback;
            return this;
        }

        @Override // android.graphics.drawable.Drawable.Callback
        public void invalidateDrawable(Drawable drawable) {
        }

        @Override // android.graphics.drawable.Drawable.Callback
        public void scheduleDrawable(Drawable drawable, Runnable runnable, long j2) {
            Drawable.Callback callback = this.f4204b;
            if (callback != null) {
                callback.scheduleDrawable(drawable, runnable, j2);
            }
        }

        @Override // android.graphics.drawable.Drawable.Callback
        public void unscheduleDrawable(Drawable drawable, Runnable runnable) {
            Drawable.Callback callback = this.f4204b;
            if (callback != null) {
                callback.unscheduleDrawable(drawable, runnable);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public static abstract class c extends Drawable.ConstantState {
        int A;
        int B;
        boolean C;
        ColorFilter D;
        boolean E;
        ColorStateList F;
        PorterDuff.Mode G;
        boolean H;
        boolean I;

        /* renamed from: a  reason: collision with root package name */
        final b f4205a;

        /* renamed from: b  reason: collision with root package name */
        Resources f4206b;

        /* renamed from: c  reason: collision with root package name */
        int f4207c;

        /* renamed from: d  reason: collision with root package name */
        int f4208d;

        /* renamed from: e  reason: collision with root package name */
        int f4209e;

        /* renamed from: f  reason: collision with root package name */
        SparseArray<Drawable.ConstantState> f4210f;

        /* renamed from: g  reason: collision with root package name */
        Drawable[] f4211g;

        /* renamed from: h  reason: collision with root package name */
        int f4212h;

        /* renamed from: i  reason: collision with root package name */
        boolean f4213i;

        /* renamed from: j  reason: collision with root package name */
        boolean f4214j;

        /* renamed from: k  reason: collision with root package name */
        Rect f4215k;

        /* renamed from: l  reason: collision with root package name */
        boolean f4216l;

        /* renamed from: m  reason: collision with root package name */
        boolean f4217m;

        /* renamed from: n  reason: collision with root package name */
        int f4218n;

        /* renamed from: o  reason: collision with root package name */
        int f4219o;

        /* renamed from: p  reason: collision with root package name */
        int f4220p;

        /* renamed from: q  reason: collision with root package name */
        int f4221q;

        /* renamed from: r  reason: collision with root package name */
        boolean f4222r;

        /* renamed from: s  reason: collision with root package name */
        int f4223s;

        /* renamed from: t  reason: collision with root package name */
        boolean f4224t;

        /* renamed from: u  reason: collision with root package name */
        boolean f4225u;

        /* renamed from: v  reason: collision with root package name */
        boolean f4226v;

        /* renamed from: w  reason: collision with root package name */
        boolean f4227w;

        /* renamed from: x  reason: collision with root package name */
        boolean f4228x;

        /* renamed from: y  reason: collision with root package name */
        boolean f4229y;

        /* renamed from: z  reason: collision with root package name */
        int f4230z;

        /* JADX INFO: Access modifiers changed from: package-private */
        public c(c cVar, b bVar, Resources resources) {
            this.f4207c = 160;
            this.f4213i = false;
            this.f4216l = false;
            this.f4228x = true;
            this.A = 0;
            this.B = 0;
            this.f4205a = bVar;
            this.f4206b = resources != null ? resources : cVar != null ? cVar.f4206b : null;
            int f2 = b.f(resources, cVar != null ? cVar.f4207c : 0);
            this.f4207c = f2;
            if (cVar == null) {
                this.f4211g = new Drawable[10];
                this.f4212h = 0;
                return;
            }
            this.f4208d = cVar.f4208d;
            this.f4209e = cVar.f4209e;
            this.f4226v = true;
            this.f4227w = true;
            this.f4213i = cVar.f4213i;
            this.f4216l = cVar.f4216l;
            this.f4228x = cVar.f4228x;
            this.f4229y = cVar.f4229y;
            this.f4230z = cVar.f4230z;
            this.A = cVar.A;
            this.B = cVar.B;
            this.C = cVar.C;
            this.D = cVar.D;
            this.E = cVar.E;
            this.F = cVar.F;
            this.G = cVar.G;
            this.H = cVar.H;
            this.I = cVar.I;
            if (cVar.f4207c == f2) {
                if (cVar.f4214j) {
                    this.f4215k = new Rect(cVar.f4215k);
                    this.f4214j = true;
                }
                if (cVar.f4217m) {
                    this.f4218n = cVar.f4218n;
                    this.f4219o = cVar.f4219o;
                    this.f4220p = cVar.f4220p;
                    this.f4221q = cVar.f4221q;
                    this.f4217m = true;
                }
            }
            if (cVar.f4222r) {
                this.f4223s = cVar.f4223s;
                this.f4222r = true;
            }
            if (cVar.f4224t) {
                this.f4225u = cVar.f4225u;
                this.f4224t = true;
            }
            Drawable[] drawableArr = cVar.f4211g;
            this.f4211g = new Drawable[drawableArr.length];
            this.f4212h = cVar.f4212h;
            SparseArray<Drawable.ConstantState> sparseArray = cVar.f4210f;
            this.f4210f = sparseArray != null ? sparseArray.clone() : new SparseArray<>(this.f4212h);
            int i2 = this.f4212h;
            for (int i3 = 0; i3 < i2; i3++) {
                if (drawableArr[i3] != null) {
                    Drawable.ConstantState constantState = drawableArr[i3].getConstantState();
                    if (constantState != null) {
                        this.f4210f.put(i3, constantState);
                    } else {
                        this.f4211g[i3] = drawableArr[i3];
                    }
                }
            }
        }

        private void e() {
            SparseArray<Drawable.ConstantState> sparseArray = this.f4210f;
            if (sparseArray != null) {
                int size = sparseArray.size();
                for (int i2 = 0; i2 < size; i2++) {
                    this.f4211g[this.f4210f.keyAt(i2)] = s(this.f4210f.valueAt(i2).newDrawable(this.f4206b));
                }
                this.f4210f = null;
            }
        }

        private Drawable s(Drawable drawable) {
            if (Build.VERSION.SDK_INT >= 23) {
                drawable.setLayoutDirection(this.f4230z);
            }
            Drawable mutate = drawable.mutate();
            mutate.setCallback(this.f4205a);
            return mutate;
        }

        public final int a(Drawable drawable) {
            int i2 = this.f4212h;
            if (i2 >= this.f4211g.length) {
                o(i2, i2 + 10);
            }
            drawable.mutate();
            drawable.setVisible(false, true);
            drawable.setCallback(this.f4205a);
            this.f4211g[i2] = drawable;
            this.f4212h++;
            this.f4209e = drawable.getChangingConfigurations() | this.f4209e;
            p();
            this.f4215k = null;
            this.f4214j = false;
            this.f4217m = false;
            this.f4226v = false;
            return i2;
        }

        final void b(Resources.Theme theme) {
            if (theme != null) {
                e();
                int i2 = this.f4212h;
                Drawable[] drawableArr = this.f4211g;
                for (int i3 = 0; i3 < i2; i3++) {
                    if (drawableArr[i3] != null && drawableArr[i3].canApplyTheme()) {
                        drawableArr[i3].applyTheme(theme);
                        this.f4209e |= drawableArr[i3].getChangingConfigurations();
                    }
                }
                y(theme.getResources());
            }
        }

        public synchronized boolean c() {
            if (this.f4226v) {
                return this.f4227w;
            }
            e();
            this.f4226v = true;
            int i2 = this.f4212h;
            Drawable[] drawableArr = this.f4211g;
            for (int i3 = 0; i3 < i2; i3++) {
                if (drawableArr[i3].getConstantState() == null) {
                    this.f4227w = false;
                    return false;
                }
            }
            this.f4227w = true;
            return true;
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public boolean canApplyTheme() {
            int i2 = this.f4212h;
            Drawable[] drawableArr = this.f4211g;
            for (int i3 = 0; i3 < i2; i3++) {
                Drawable drawable = drawableArr[i3];
                if (drawable == null) {
                    Drawable.ConstantState constantState = this.f4210f.get(i3);
                    if (constantState != null && constantState.canApplyTheme()) {
                        return true;
                    }
                } else if (drawable.canApplyTheme()) {
                    return true;
                }
            }
            return false;
        }

        protected void d() {
            this.f4217m = true;
            e();
            int i2 = this.f4212h;
            Drawable[] drawableArr = this.f4211g;
            this.f4219o = -1;
            this.f4218n = -1;
            this.f4221q = 0;
            this.f4220p = 0;
            for (int i3 = 0; i3 < i2; i3++) {
                Drawable drawable = drawableArr[i3];
                int intrinsicWidth = drawable.getIntrinsicWidth();
                if (intrinsicWidth > this.f4218n) {
                    this.f4218n = intrinsicWidth;
                }
                int intrinsicHeight = drawable.getIntrinsicHeight();
                if (intrinsicHeight > this.f4219o) {
                    this.f4219o = intrinsicHeight;
                }
                int minimumWidth = drawable.getMinimumWidth();
                if (minimumWidth > this.f4220p) {
                    this.f4220p = minimumWidth;
                }
                int minimumHeight = drawable.getMinimumHeight();
                if (minimumHeight > this.f4221q) {
                    this.f4221q = minimumHeight;
                }
            }
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public final int f() {
            return this.f4211g.length;
        }

        public final Drawable g(int i2) {
            int indexOfKey;
            Drawable drawable = this.f4211g[i2];
            if (drawable != null) {
                return drawable;
            }
            SparseArray<Drawable.ConstantState> sparseArray = this.f4210f;
            if (sparseArray == null || (indexOfKey = sparseArray.indexOfKey(i2)) < 0) {
                return null;
            }
            Drawable s2 = s(this.f4210f.valueAt(indexOfKey).newDrawable(this.f4206b));
            this.f4211g[i2] = s2;
            this.f4210f.removeAt(indexOfKey);
            if (this.f4210f.size() == 0) {
                this.f4210f = null;
            }
            return s2;
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public int getChangingConfigurations() {
            return this.f4208d | this.f4209e;
        }

        public final int h() {
            return this.f4212h;
        }

        public final int i() {
            if (!this.f4217m) {
                d();
            }
            return this.f4219o;
        }

        public final int j() {
            if (!this.f4217m) {
                d();
            }
            return this.f4221q;
        }

        public final int k() {
            if (!this.f4217m) {
                d();
            }
            return this.f4220p;
        }

        public final Rect l() {
            Rect rect = null;
            if (this.f4213i) {
                return null;
            }
            Rect rect2 = this.f4215k;
            if (rect2 != null || this.f4214j) {
                return rect2;
            }
            e();
            Rect rect3 = new Rect();
            int i2 = this.f4212h;
            Drawable[] drawableArr = this.f4211g;
            for (int i3 = 0; i3 < i2; i3++) {
                if (drawableArr[i3].getPadding(rect3)) {
                    if (rect == null) {
                        rect = new Rect(0, 0, 0, 0);
                    }
                    int i4 = rect3.left;
                    if (i4 > rect.left) {
                        rect.left = i4;
                    }
                    int i5 = rect3.top;
                    if (i5 > rect.top) {
                        rect.top = i5;
                    }
                    int i6 = rect3.right;
                    if (i6 > rect.right) {
                        rect.right = i6;
                    }
                    int i7 = rect3.bottom;
                    if (i7 > rect.bottom) {
                        rect.bottom = i7;
                    }
                }
            }
            this.f4214j = true;
            this.f4215k = rect;
            return rect;
        }

        public final int m() {
            if (!this.f4217m) {
                d();
            }
            return this.f4218n;
        }

        public final int n() {
            if (this.f4222r) {
                return this.f4223s;
            }
            e();
            int i2 = this.f4212h;
            Drawable[] drawableArr = this.f4211g;
            int opacity = i2 > 0 ? drawableArr[0].getOpacity() : -2;
            for (int i3 = 1; i3 < i2; i3++) {
                opacity = Drawable.resolveOpacity(opacity, drawableArr[i3].getOpacity());
            }
            this.f4223s = opacity;
            this.f4222r = true;
            return opacity;
        }

        public void o(int i2, int i3) {
            Drawable[] drawableArr = new Drawable[i3];
            System.arraycopy(this.f4211g, 0, drawableArr, 0, i2);
            this.f4211g = drawableArr;
        }

        void p() {
            this.f4222r = false;
            this.f4224t = false;
        }

        public final boolean q() {
            return this.f4216l;
        }

        abstract void r();

        public final void t(boolean z2) {
            this.f4216l = z2;
        }

        public final void u(int i2) {
            this.A = i2;
        }

        public final void v(int i2) {
            this.B = i2;
        }

        final boolean w(int i2, int i3) {
            int i4 = this.f4212h;
            Drawable[] drawableArr = this.f4211g;
            boolean z2 = false;
            for (int i5 = 0; i5 < i4; i5++) {
                if (drawableArr[i5] != null) {
                    boolean layoutDirection = Build.VERSION.SDK_INT >= 23 ? drawableArr[i5].setLayoutDirection(i2) : false;
                    if (i5 == i3) {
                        z2 = layoutDirection;
                    }
                }
            }
            this.f4230z = i2;
            return z2;
        }

        public final void x(boolean z2) {
            this.f4213i = z2;
        }

        final void y(Resources resources) {
            if (resources != null) {
                this.f4206b = resources;
                int f2 = b.f(resources, this.f4207c);
                int i2 = this.f4207c;
                this.f4207c = f2;
                if (i2 != f2) {
                    this.f4217m = false;
                    this.f4214j = false;
                }
            }
        }
    }

    private void d(Drawable drawable) {
        if (this.f4202m == null) {
            this.f4202m = new C0050b();
        }
        drawable.setCallback(this.f4202m.b(drawable.getCallback()));
        try {
            if (this.f4191b.A <= 0 && this.f4196g) {
                drawable.setAlpha(this.f4195f);
            }
            c cVar = this.f4191b;
            if (cVar.E) {
                drawable.setColorFilter(cVar.D);
            } else {
                if (cVar.H) {
                    x.a.o(drawable, cVar.F);
                }
                c cVar2 = this.f4191b;
                if (cVar2.I) {
                    x.a.p(drawable, cVar2.G);
                }
            }
            drawable.setVisible(isVisible(), true);
            drawable.setDither(this.f4191b.f4228x);
            drawable.setState(getState());
            drawable.setLevel(getLevel());
            drawable.setBounds(getBounds());
            if (Build.VERSION.SDK_INT >= 23) {
                drawable.setLayoutDirection(getLayoutDirection());
            }
            drawable.setAutoMirrored(this.f4191b.C);
            Rect rect = this.f4192c;
            if (rect != null) {
                drawable.setHotspotBounds(rect.left, rect.top, rect.right, rect.bottom);
            }
        } finally {
            drawable.setCallback(this.f4202m.a());
        }
    }

    private boolean e() {
        return isAutoMirrored() && x.a.f(this) == 1;
    }

    static int f(Resources resources, int i2) {
        if (resources != null) {
            i2 = resources.getDisplayMetrics().densityDpi;
        }
        if (i2 == 0) {
            return 160;
        }
        return i2;
    }

    /* JADX WARN: Removed duplicated region for block: B:14:0x003d  */
    /* JADX WARN: Removed duplicated region for block: B:23:0x0066 A[ADDED_TO_REGION] */
    /* JADX WARN: Removed duplicated region for block: B:26:? A[ADDED_TO_REGION, RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    void a(boolean r14) {
        /*
            r13 = this;
            r0 = 1
            r13.f4196g = r0
            long r1 = android.os.SystemClock.uptimeMillis()
            android.graphics.drawable.Drawable r3 = r13.f4193d
            r4 = 255(0xff, double:1.26E-321)
            r6 = 0
            r7 = 0
            if (r3 == 0) goto L36
            long r9 = r13.f4200k
            int r11 = (r9 > r7 ? 1 : (r9 == r7 ? 0 : -1))
            if (r11 == 0) goto L38
            int r11 = (r9 > r1 ? 1 : (r9 == r1 ? 0 : -1))
            if (r11 > 0) goto L20
            int r9 = r13.f4195f
            r3.setAlpha(r9)
            goto L36
        L20:
            long r9 = r9 - r1
            long r9 = r9 * r4
            int r10 = (int) r9
            d.b$c r9 = r13.f4191b
            int r9 = r9.A
            int r10 = r10 / r9
            int r9 = 255 - r10
            int r10 = r13.f4195f
            int r9 = r9 * r10
            int r9 = r9 / 255
            r3.setAlpha(r9)
            r3 = 1
            goto L39
        L36:
            r13.f4200k = r7
        L38:
            r3 = 0
        L39:
            android.graphics.drawable.Drawable r9 = r13.f4194e
            if (r9 == 0) goto L61
            long r10 = r13.f4201l
            int r12 = (r10 > r7 ? 1 : (r10 == r7 ? 0 : -1))
            if (r12 == 0) goto L63
            int r12 = (r10 > r1 ? 1 : (r10 == r1 ? 0 : -1))
            if (r12 > 0) goto L4e
            r9.setVisible(r6, r6)
            r0 = 0
            r13.f4194e = r0
            goto L61
        L4e:
            long r10 = r10 - r1
            long r10 = r10 * r4
            int r3 = (int) r10
            d.b$c r4 = r13.f4191b
            int r4 = r4.B
            int r3 = r3 / r4
            int r4 = r13.f4195f
            int r3 = r3 * r4
            int r3 = r3 / 255
            r9.setAlpha(r3)
            goto L64
        L61:
            r13.f4201l = r7
        L63:
            r0 = r3
        L64:
            if (r14 == 0) goto L70
            if (r0 == 0) goto L70
            java.lang.Runnable r14 = r13.f4199j
            r3 = 16
            long r1 = r1 + r3
            r13.scheduleSelf(r14, r1)
        L70:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: d.b.a(boolean):void");
    }

    @Override // android.graphics.drawable.Drawable
    public void applyTheme(Resources.Theme theme) {
        this.f4191b.b(theme);
    }

    c b() {
        throw null;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public int c() {
        return this.f4197h;
    }

    @Override // android.graphics.drawable.Drawable
    public boolean canApplyTheme() {
        return this.f4191b.canApplyTheme();
    }

    @Override // android.graphics.drawable.Drawable
    public void draw(Canvas canvas) {
        Drawable drawable = this.f4193d;
        if (drawable != null) {
            drawable.draw(canvas);
        }
        Drawable drawable2 = this.f4194e;
        if (drawable2 != null) {
            drawable2.draw(canvas);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* JADX WARN: Removed duplicated region for block: B:33:0x006b  */
    /* JADX WARN: Removed duplicated region for block: B:34:0x0073  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public boolean g(int r10) {
        /*
            r9 = this;
            int r0 = r9.f4197h
            r1 = 0
            if (r10 != r0) goto L6
            return r1
        L6:
            long r2 = android.os.SystemClock.uptimeMillis()
            d.b$c r0 = r9.f4191b
            int r0 = r0.B
            r4 = 0
            r5 = 0
            if (r0 <= 0) goto L2e
            android.graphics.drawable.Drawable r0 = r9.f4194e
            if (r0 == 0) goto L1a
            r0.setVisible(r1, r1)
        L1a:
            android.graphics.drawable.Drawable r0 = r9.f4193d
            if (r0 == 0) goto L29
            r9.f4194e = r0
            d.b$c r0 = r9.f4191b
            int r0 = r0.B
            long r0 = (long) r0
            long r0 = r0 + r2
            r9.f4201l = r0
            goto L35
        L29:
            r9.f4194e = r4
            r9.f4201l = r5
            goto L35
        L2e:
            android.graphics.drawable.Drawable r0 = r9.f4193d
            if (r0 == 0) goto L35
            r0.setVisible(r1, r1)
        L35:
            if (r10 < 0) goto L55
            d.b$c r0 = r9.f4191b
            int r1 = r0.f4212h
            if (r10 >= r1) goto L55
            android.graphics.drawable.Drawable r0 = r0.g(r10)
            r9.f4193d = r0
            r9.f4197h = r10
            if (r0 == 0) goto L5a
            d.b$c r10 = r9.f4191b
            int r10 = r10.A
            if (r10 <= 0) goto L51
            long r7 = (long) r10
            long r2 = r2 + r7
            r9.f4200k = r2
        L51:
            r9.d(r0)
            goto L5a
        L55:
            r9.f4193d = r4
            r10 = -1
            r9.f4197h = r10
        L5a:
            long r0 = r9.f4200k
            r10 = 1
            int r2 = (r0 > r5 ? 1 : (r0 == r5 ? 0 : -1))
            if (r2 != 0) goto L67
            long r0 = r9.f4201l
            int r2 = (r0 > r5 ? 1 : (r0 == r5 ? 0 : -1))
            if (r2 == 0) goto L79
        L67:
            java.lang.Runnable r0 = r9.f4199j
            if (r0 != 0) goto L73
            d.b$a r0 = new d.b$a
            r0.<init>()
            r9.f4199j = r0
            goto L76
        L73:
            r9.unscheduleSelf(r0)
        L76:
            r9.a(r10)
        L79:
            r9.invalidateSelf()
            return r10
        */
        throw new UnsupportedOperationException("Method not decompiled: d.b.g(int):boolean");
    }

    @Override // android.graphics.drawable.Drawable
    public int getAlpha() {
        return this.f4195f;
    }

    @Override // android.graphics.drawable.Drawable
    public int getChangingConfigurations() {
        return super.getChangingConfigurations() | this.f4191b.getChangingConfigurations();
    }

    @Override // android.graphics.drawable.Drawable
    public final Drawable.ConstantState getConstantState() {
        if (this.f4191b.c()) {
            this.f4191b.f4208d = getChangingConfigurations();
            return this.f4191b;
        }
        return null;
    }

    @Override // android.graphics.drawable.Drawable
    public Drawable getCurrent() {
        return this.f4193d;
    }

    @Override // android.graphics.drawable.Drawable
    public void getHotspotBounds(Rect rect) {
        Rect rect2 = this.f4192c;
        if (rect2 != null) {
            rect.set(rect2);
        } else {
            super.getHotspotBounds(rect);
        }
    }

    @Override // android.graphics.drawable.Drawable
    public int getIntrinsicHeight() {
        if (this.f4191b.q()) {
            return this.f4191b.i();
        }
        Drawable drawable = this.f4193d;
        if (drawable != null) {
            return drawable.getIntrinsicHeight();
        }
        return -1;
    }

    @Override // android.graphics.drawable.Drawable
    public int getIntrinsicWidth() {
        if (this.f4191b.q()) {
            return this.f4191b.m();
        }
        Drawable drawable = this.f4193d;
        if (drawable != null) {
            return drawable.getIntrinsicWidth();
        }
        return -1;
    }

    @Override // android.graphics.drawable.Drawable
    public int getMinimumHeight() {
        if (this.f4191b.q()) {
            return this.f4191b.j();
        }
        Drawable drawable = this.f4193d;
        if (drawable != null) {
            return drawable.getMinimumHeight();
        }
        return 0;
    }

    @Override // android.graphics.drawable.Drawable
    public int getMinimumWidth() {
        if (this.f4191b.q()) {
            return this.f4191b.k();
        }
        Drawable drawable = this.f4193d;
        if (drawable != null) {
            return drawable.getMinimumWidth();
        }
        return 0;
    }

    @Override // android.graphics.drawable.Drawable
    public int getOpacity() {
        Drawable drawable = this.f4193d;
        if (drawable == null || !drawable.isVisible()) {
            return -2;
        }
        return this.f4191b.n();
    }

    @Override // android.graphics.drawable.Drawable
    public void getOutline(Outline outline) {
        Drawable drawable = this.f4193d;
        if (drawable != null) {
            drawable.getOutline(outline);
        }
    }

    @Override // android.graphics.drawable.Drawable
    public boolean getPadding(Rect rect) {
        boolean padding;
        Rect l2 = this.f4191b.l();
        if (l2 != null) {
            rect.set(l2);
            padding = (l2.right | ((l2.left | l2.top) | l2.bottom)) != 0;
        } else {
            Drawable drawable = this.f4193d;
            padding = drawable != null ? drawable.getPadding(rect) : super.getPadding(rect);
        }
        if (e()) {
            int i2 = rect.left;
            rect.left = rect.right;
            rect.right = i2;
        }
        return padding;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void h(c cVar) {
        this.f4191b = cVar;
        int i2 = this.f4197h;
        if (i2 >= 0) {
            Drawable g2 = cVar.g(i2);
            this.f4193d = g2;
            if (g2 != null) {
                d(g2);
            }
        }
        this.f4194e = null;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public final void i(Resources resources) {
        this.f4191b.y(resources);
    }

    public void invalidateDrawable(Drawable drawable) {
        c cVar = this.f4191b;
        if (cVar != null) {
            cVar.p();
        }
        if (drawable != this.f4193d || getCallback() == null) {
            return;
        }
        getCallback().invalidateDrawable(this);
    }

    @Override // android.graphics.drawable.Drawable
    public boolean isAutoMirrored() {
        return this.f4191b.C;
    }

    @Override // android.graphics.drawable.Drawable
    public void jumpToCurrentState() {
        boolean z2;
        Drawable drawable = this.f4194e;
        boolean z3 = true;
        if (drawable != null) {
            drawable.jumpToCurrentState();
            this.f4194e = null;
            z2 = true;
        } else {
            z2 = false;
        }
        Drawable drawable2 = this.f4193d;
        if (drawable2 != null) {
            drawable2.jumpToCurrentState();
            if (this.f4196g) {
                this.f4193d.setAlpha(this.f4195f);
            }
        }
        if (this.f4201l != 0) {
            this.f4201l = 0L;
            z2 = true;
        }
        if (this.f4200k != 0) {
            this.f4200k = 0L;
        } else {
            z3 = z2;
        }
        if (z3) {
            invalidateSelf();
        }
    }

    @Override // android.graphics.drawable.Drawable
    public Drawable mutate() {
        if (!this.f4198i && super.mutate() == this) {
            c b2 = b();
            b2.r();
            h(b2);
            this.f4198i = true;
        }
        return this;
    }

    @Override // android.graphics.drawable.Drawable
    protected void onBoundsChange(Rect rect) {
        Drawable drawable = this.f4194e;
        if (drawable != null) {
            drawable.setBounds(rect);
        }
        Drawable drawable2 = this.f4193d;
        if (drawable2 != null) {
            drawable2.setBounds(rect);
        }
    }

    @Override // android.graphics.drawable.Drawable
    public boolean onLayoutDirectionChanged(int i2) {
        return this.f4191b.w(i2, c());
    }

    @Override // android.graphics.drawable.Drawable
    protected boolean onLevelChange(int i2) {
        Drawable drawable = this.f4194e;
        if (drawable != null) {
            return drawable.setLevel(i2);
        }
        Drawable drawable2 = this.f4193d;
        if (drawable2 != null) {
            return drawable2.setLevel(i2);
        }
        return false;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.graphics.drawable.Drawable
    public boolean onStateChange(int[] iArr) {
        Drawable drawable = this.f4194e;
        if (drawable != null) {
            return drawable.setState(iArr);
        }
        Drawable drawable2 = this.f4193d;
        if (drawable2 != null) {
            return drawable2.setState(iArr);
        }
        return false;
    }

    public void scheduleDrawable(Drawable drawable, Runnable runnable, long j2) {
        if (drawable != this.f4193d || getCallback() == null) {
            return;
        }
        getCallback().scheduleDrawable(this, runnable, j2);
    }

    @Override // android.graphics.drawable.Drawable
    public void setAlpha(int i2) {
        if (this.f4196g && this.f4195f == i2) {
            return;
        }
        this.f4196g = true;
        this.f4195f = i2;
        Drawable drawable = this.f4193d;
        if (drawable != null) {
            if (this.f4200k == 0) {
                drawable.setAlpha(i2);
            } else {
                a(false);
            }
        }
    }

    @Override // android.graphics.drawable.Drawable
    public void setAutoMirrored(boolean z2) {
        c cVar = this.f4191b;
        if (cVar.C != z2) {
            cVar.C = z2;
            Drawable drawable = this.f4193d;
            if (drawable != null) {
                x.a.j(drawable, z2);
            }
        }
    }

    @Override // android.graphics.drawable.Drawable
    public void setColorFilter(ColorFilter colorFilter) {
        c cVar = this.f4191b;
        cVar.E = true;
        if (cVar.D != colorFilter) {
            cVar.D = colorFilter;
            Drawable drawable = this.f4193d;
            if (drawable != null) {
                drawable.setColorFilter(colorFilter);
            }
        }
    }

    @Override // android.graphics.drawable.Drawable
    public void setDither(boolean z2) {
        c cVar = this.f4191b;
        if (cVar.f4228x != z2) {
            cVar.f4228x = z2;
            Drawable drawable = this.f4193d;
            if (drawable != null) {
                drawable.setDither(z2);
            }
        }
    }

    @Override // android.graphics.drawable.Drawable
    public void setHotspot(float f2, float f3) {
        Drawable drawable = this.f4193d;
        if (drawable != null) {
            x.a.k(drawable, f2, f3);
        }
    }

    @Override // android.graphics.drawable.Drawable
    public void setHotspotBounds(int i2, int i3, int i4, int i5) {
        Rect rect = this.f4192c;
        if (rect == null) {
            this.f4192c = new Rect(i2, i3, i4, i5);
        } else {
            rect.set(i2, i3, i4, i5);
        }
        Drawable drawable = this.f4193d;
        if (drawable != null) {
            x.a.l(drawable, i2, i3, i4, i5);
        }
    }

    @Override // android.graphics.drawable.Drawable
    public void setTintList(ColorStateList colorStateList) {
        c cVar = this.f4191b;
        cVar.H = true;
        if (cVar.F != colorStateList) {
            cVar.F = colorStateList;
            x.a.o(this.f4193d, colorStateList);
        }
    }

    @Override // android.graphics.drawable.Drawable
    public void setTintMode(PorterDuff.Mode mode) {
        c cVar = this.f4191b;
        cVar.I = true;
        if (cVar.G != mode) {
            cVar.G = mode;
            x.a.p(this.f4193d, mode);
        }
    }

    @Override // android.graphics.drawable.Drawable
    public boolean setVisible(boolean z2, boolean z3) {
        boolean visible = super.setVisible(z2, z3);
        Drawable drawable = this.f4194e;
        if (drawable != null) {
            drawable.setVisible(z2, z3);
        }
        Drawable drawable2 = this.f4193d;
        if (drawable2 != null) {
            drawable2.setVisible(z2, z3);
        }
        return visible;
    }

    public void unscheduleDrawable(Drawable drawable, Runnable runnable) {
        if (drawable != this.f4193d || getCallback() == null) {
            return;
        }
        getCallback().unscheduleDrawable(this, runnable);
    }
}
