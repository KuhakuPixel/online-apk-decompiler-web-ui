package androidx.navigation;

import android.net.Uri;
import android.os.Bundle;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
/* loaded from: classes.dex */
public final class h {

    /* renamed from: j  reason: collision with root package name */
    private static final Pattern f1975j = Pattern.compile("^[a-zA-Z]+[+\\w\\-.]*:");

    /* renamed from: a  reason: collision with root package name */
    private final ArrayList<String> f1976a = new ArrayList<>();

    /* renamed from: b  reason: collision with root package name */
    private final Map<String, c> f1977b = new HashMap();

    /* renamed from: c  reason: collision with root package name */
    private Pattern f1978c;

    /* renamed from: d  reason: collision with root package name */
    private boolean f1979d;

    /* renamed from: e  reason: collision with root package name */
    private boolean f1980e;

    /* renamed from: f  reason: collision with root package name */
    private final String f1981f;

    /* renamed from: g  reason: collision with root package name */
    private final String f1982g;

    /* renamed from: h  reason: collision with root package name */
    private Pattern f1983h;

    /* renamed from: i  reason: collision with root package name */
    private final String f1984i;

    /* loaded from: classes.dex */
    public static final class a {

        /* renamed from: a  reason: collision with root package name */
        private String f1985a;

        /* renamed from: b  reason: collision with root package name */
        private String f1986b;

        /* renamed from: c  reason: collision with root package name */
        private String f1987c;

        public h a() {
            return new h(this.f1985a, this.f1986b, this.f1987c);
        }

        public a b(String str) {
            if (str.isEmpty()) {
                throw new IllegalArgumentException("The NavDeepLink cannot have an empty action.");
            }
            this.f1986b = str;
            return this;
        }

        public a c(String str) {
            this.f1987c = str;
            return this;
        }

        public a d(String str) {
            this.f1985a = str;
            return this;
        }
    }

    /* loaded from: classes.dex */
    private static class b implements Comparable<b> {

        /* renamed from: b  reason: collision with root package name */
        String f1988b;

        /* renamed from: c  reason: collision with root package name */
        String f1989c;

        b(String str) {
            String[] split = str.split("/", -1);
            this.f1988b = split[0];
            this.f1989c = split[1];
        }

        @Override // java.lang.Comparable
        /* renamed from: a  reason: merged with bridge method [inline-methods] */
        public int compareTo(b bVar) {
            int i2 = this.f1988b.equals(bVar.f1988b) ? 2 : 0;
            return this.f1989c.equals(bVar.f1989c) ? i2 + 1 : i2;
        }
    }

    /* loaded from: classes.dex */
    private static class c {

        /* renamed from: a  reason: collision with root package name */
        private String f1990a;

        /* renamed from: b  reason: collision with root package name */
        private ArrayList<String> f1991b = new ArrayList<>();

        c() {
        }

        void a(String str) {
            this.f1991b.add(str);
        }

        String b(int i2) {
            return this.f1991b.get(i2);
        }

        String c() {
            return this.f1990a;
        }

        void d(String str) {
            this.f1990a = str;
        }

        public int e() {
            return this.f1991b.size();
        }
    }

    h(String str, String str2, String str3) {
        this.f1978c = null;
        this.f1979d = false;
        this.f1980e = false;
        this.f1983h = null;
        this.f1981f = str;
        this.f1982g = str2;
        this.f1984i = str3;
        if (str != null) {
            Uri parse = Uri.parse(str);
            this.f1980e = parse.getQuery() != null;
            StringBuilder sb = new StringBuilder("^");
            if (!f1975j.matcher(str).find()) {
                sb.append("http[s]?://");
            }
            Pattern compile = Pattern.compile("\\{(.+?)\\}");
            if (this.f1980e) {
                Matcher matcher = Pattern.compile("(\\?)").matcher(str);
                if (matcher.find()) {
                    a(str.substring(0, matcher.start()), sb, compile);
                }
                this.f1979d = false;
                for (String str4 : parse.getQueryParameterNames()) {
                    StringBuilder sb2 = new StringBuilder();
                    String queryParameter = parse.getQueryParameter(str4);
                    Matcher matcher2 = compile.matcher(queryParameter);
                    c cVar = new c();
                    int i2 = 0;
                    while (matcher2.find()) {
                        cVar.a(matcher2.group(1));
                        sb2.append(Pattern.quote(queryParameter.substring(i2, matcher2.start())));
                        sb2.append("(.+?)?");
                        i2 = matcher2.end();
                    }
                    if (i2 < queryParameter.length()) {
                        sb2.append(Pattern.quote(queryParameter.substring(i2)));
                    }
                    cVar.d(sb2.toString().replace(".*", "\\E.*\\Q"));
                    this.f1977b.put(str4, cVar);
                }
            } else {
                this.f1979d = a(str, sb, compile);
            }
            this.f1978c = Pattern.compile(sb.toString().replace(".*", "\\E.*\\Q"), 2);
        }
        if (str3 != null) {
            if (!Pattern.compile("^[\\s\\S]+/[\\s\\S]+$").matcher(str3).matches()) {
                throw new IllegalArgumentException("The given mimeType " + str3 + " does not match to required \"type/subtype\" format");
            }
            b bVar = new b(str3);
            this.f1983h = Pattern.compile(("^(" + bVar.f1988b + "|[*]+)/(" + bVar.f1989c + "|[*]+)$").replace("*|[*]", "[\\s\\S]"));
        }
    }

    private boolean a(String str, StringBuilder sb, Pattern pattern) {
        Matcher matcher = pattern.matcher(str);
        boolean z2 = !str.contains(".*");
        int i2 = 0;
        while (matcher.find()) {
            this.f1976a.add(matcher.group(1));
            sb.append(Pattern.quote(str.substring(i2, matcher.start())));
            sb.append("(.+?)");
            i2 = matcher.end();
            z2 = false;
        }
        if (i2 < str.length()) {
            sb.append(Pattern.quote(str.substring(i2)));
        }
        sb.append("($|(\\?(.)*))");
        return z2;
    }

    private boolean f(Bundle bundle, String str, String str2, d dVar) {
        if (dVar == null) {
            bundle.putString(str, str2);
            return false;
        }
        try {
            dVar.a().g(bundle, str, str2);
            return false;
        } catch (IllegalArgumentException unused) {
            return true;
        }
    }

    public String b() {
        return this.f1982g;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public Bundle c(Uri uri, Map<String, d> map) {
        Matcher matcher;
        Matcher matcher2 = this.f1978c.matcher(uri.toString());
        if (matcher2.matches()) {
            Bundle bundle = new Bundle();
            int size = this.f1976a.size();
            int i2 = 0;
            while (i2 < size) {
                String str = this.f1976a.get(i2);
                i2++;
                if (f(bundle, str, Uri.decode(matcher2.group(i2)), map.get(str))) {
                    return null;
                }
            }
            if (this.f1980e) {
                for (String str2 : this.f1977b.keySet()) {
                    c cVar = this.f1977b.get(str2);
                    String queryParameter = uri.getQueryParameter(str2);
                    if (queryParameter != null) {
                        matcher = Pattern.compile(cVar.c()).matcher(queryParameter);
                        if (!matcher.matches()) {
                            return null;
                        }
                    } else {
                        matcher = null;
                    }
                    for (int i3 = 0; i3 < cVar.e(); i3++) {
                        String decode = matcher != null ? Uri.decode(matcher.group(i3 + 1)) : null;
                        String b2 = cVar.b(i3);
                        d dVar = map.get(b2);
                        if (decode != null && !decode.replaceAll("[{}]", "").equals(b2) && f(bundle, b2, decode, dVar)) {
                            return null;
                        }
                    }
                }
            }
            return bundle;
        }
        return null;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public int d(String str) {
        if (this.f1984i == null || !this.f1983h.matcher(str).matches()) {
            return -1;
        }
        return new b(this.f1984i).compareTo(new b(str));
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public boolean e() {
        return this.f1979d;
    }
}
