package androidx.fragment.app;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import androidx.activity.ComponentActivity;
import androidx.activity.OnBackPressedDispatcher;
import androidx.lifecycle.d;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import t.a;
/* loaded from: classes.dex */
public class d extends ComponentActivity {

    /* renamed from: k  reason: collision with root package name */
    boolean f1603k;

    /* renamed from: l  reason: collision with root package name */
    boolean f1604l;

    /* renamed from: n  reason: collision with root package name */
    boolean f1606n;

    /* renamed from: o  reason: collision with root package name */
    boolean f1607o;

    /* renamed from: p  reason: collision with root package name */
    int f1608p;

    /* renamed from: q  reason: collision with root package name */
    l.h<String> f1609q;

    /* renamed from: i  reason: collision with root package name */
    final g f1601i = g.b(new a());

    /* renamed from: j  reason: collision with root package name */
    final androidx.lifecycle.h f1602j = new androidx.lifecycle.h(this);

    /* renamed from: m  reason: collision with root package name */
    boolean f1605m = true;

    /* loaded from: classes.dex */
    class a extends i<d> implements androidx.lifecycle.u, androidx.activity.c {
        public a() {
            super(d.this);
        }

        @Override // androidx.lifecycle.g
        public androidx.lifecycle.d a() {
            return d.this.f1602j;
        }

        @Override // androidx.activity.c
        public OnBackPressedDispatcher b() {
            return d.this.b();
        }

        @Override // androidx.fragment.app.i, androidx.fragment.app.f
        public View e(int i2) {
            return d.this.findViewById(i2);
        }

        @Override // androidx.fragment.app.i, androidx.fragment.app.f
        public boolean f() {
            Window window = d.this.getWindow();
            return (window == null || window.peekDecorView() == null) ? false : true;
        }

        @Override // androidx.lifecycle.u
        public androidx.lifecycle.t g() {
            return d.this.g();
        }

        @Override // androidx.fragment.app.i
        public void k(Fragment fragment) {
            d.this.q(fragment);
        }

        @Override // androidx.fragment.app.i
        public LayoutInflater m() {
            return d.this.getLayoutInflater().cloneInContext(d.this);
        }

        @Override // androidx.fragment.app.i
        public boolean n(Fragment fragment) {
            return !d.this.isFinishing();
        }

        @Override // androidx.fragment.app.i
        public void o() {
            d.this.t();
        }

        @Override // androidx.fragment.app.i
        /* renamed from: p  reason: merged with bridge method [inline-methods] */
        public d l() {
            return d.this;
        }
    }

    static void l(int i2) {
        if ((i2 & (-65536)) != 0) {
            throw new IllegalArgumentException("Can only use lower 16 bits for requestCode");
        }
    }

    private void o() {
        do {
        } while (p(n(), d.b.CREATED));
    }

    private static boolean p(l lVar, d.b bVar) {
        boolean z2 = false;
        for (Fragment fragment : lVar.f0()) {
            if (fragment != null) {
                if (fragment.u() != null) {
                    z2 |= p(fragment.o(), bVar);
                }
                if (fragment.a().b().a(d.b.STARTED)) {
                    fragment.S.p(bVar);
                    z2 = true;
                }
            }
        }
        return z2;
    }

    @Override // android.app.Activity
    public void dump(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        super.dump(str, fileDescriptor, printWriter, strArr);
        printWriter.print(str);
        printWriter.print("Local FragmentActivity ");
        printWriter.print(Integer.toHexString(System.identityHashCode(this)));
        printWriter.println(" State:");
        String str2 = str + "  ";
        printWriter.print(str2);
        printWriter.print("mCreated=");
        printWriter.print(this.f1603k);
        printWriter.print(" mResumed=");
        printWriter.print(this.f1604l);
        printWriter.print(" mStopped=");
        printWriter.print(this.f1605m);
        if (getApplication() != null) {
            androidx.loader.app.a.b(this).a(str2, fileDescriptor, printWriter, strArr);
        }
        this.f1601i.u().M(str, fileDescriptor, printWriter, strArr);
    }

    final View m(View view, String str, Context context, AttributeSet attributeSet) {
        return this.f1601i.w(view, str, context, attributeSet);
    }

    public l n() {
        return this.f1601i.u();
    }

    @Override // android.app.Activity
    protected void onActivityResult(int i2, int i3, Intent intent) {
        this.f1601i.v();
        int i4 = i2 >> 16;
        if (i4 == 0) {
            a.InterfaceC0070a f2 = t.a.f();
            if (f2 == null || !f2.a(this, i2, i3, intent)) {
                super.onActivityResult(i2, i3, intent);
                return;
            }
            return;
        }
        int i5 = i4 - 1;
        String e2 = this.f1609q.e(i5);
        this.f1609q.j(i5);
        if (e2 == null) {
            Log.w("FragmentActivity", "Activity result delivered for unknown Fragment.");
            return;
        }
        Fragment t2 = this.f1601i.t(e2);
        if (t2 != null) {
            t2.Y(i2 & 65535, i3, intent);
            return;
        }
        Log.w("FragmentActivity", "Activity result no fragment exists for who: " + e2);
    }

    @Override // android.app.Activity, android.content.ComponentCallbacks
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        this.f1601i.v();
        this.f1601i.d(configuration);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.activity.ComponentActivity, t.e, android.app.Activity
    public void onCreate(Bundle bundle) {
        this.f1601i.a(null);
        if (bundle != null) {
            this.f1601i.x(bundle.getParcelable("android:support:fragments"));
            if (bundle.containsKey("android:support:next_request_index")) {
                this.f1608p = bundle.getInt("android:support:next_request_index");
                int[] intArray = bundle.getIntArray("android:support:request_indicies");
                String[] stringArray = bundle.getStringArray("android:support:request_fragment_who");
                if (intArray == null || stringArray == null || intArray.length != stringArray.length) {
                    Log.w("FragmentActivity", "Invalid requestCode mapping in savedInstanceState.");
                } else {
                    this.f1609q = new l.h<>(intArray.length);
                    for (int i2 = 0; i2 < intArray.length; i2++) {
                        this.f1609q.i(intArray[i2], stringArray[i2]);
                    }
                }
            }
        }
        if (this.f1609q == null) {
            this.f1609q = new l.h<>();
            this.f1608p = 0;
        }
        super.onCreate(bundle);
        this.f1602j.i(d.a.ON_CREATE);
        this.f1601i.f();
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public boolean onCreatePanelMenu(int i2, Menu menu) {
        return i2 == 0 ? super.onCreatePanelMenu(i2, menu) | this.f1601i.g(menu, getMenuInflater()) : super.onCreatePanelMenu(i2, menu);
    }

    @Override // android.app.Activity, android.view.LayoutInflater.Factory2
    public View onCreateView(View view, String str, Context context, AttributeSet attributeSet) {
        View m2 = m(view, str, context, attributeSet);
        return m2 == null ? super.onCreateView(view, str, context, attributeSet) : m2;
    }

    @Override // android.app.Activity, android.view.LayoutInflater.Factory
    public View onCreateView(String str, Context context, AttributeSet attributeSet) {
        View m2 = m(null, str, context, attributeSet);
        return m2 == null ? super.onCreateView(str, context, attributeSet) : m2;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.app.Activity
    public void onDestroy() {
        super.onDestroy();
        this.f1601i.h();
        this.f1602j.i(d.a.ON_DESTROY);
    }

    @Override // android.app.Activity, android.content.ComponentCallbacks
    public void onLowMemory() {
        super.onLowMemory();
        this.f1601i.i();
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public boolean onMenuItemSelected(int i2, MenuItem menuItem) {
        if (super.onMenuItemSelected(i2, menuItem)) {
            return true;
        }
        if (i2 != 0) {
            if (i2 != 6) {
                return false;
            }
            return this.f1601i.e(menuItem);
        }
        return this.f1601i.k(menuItem);
    }

    @Override // android.app.Activity
    public void onMultiWindowModeChanged(boolean z2) {
        this.f1601i.j(z2);
    }

    @Override // android.app.Activity
    protected void onNewIntent(@SuppressLint({"UnknownNullness"}) Intent intent) {
        super.onNewIntent(intent);
        this.f1601i.v();
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public void onPanelClosed(int i2, Menu menu) {
        if (i2 == 0) {
            this.f1601i.l(menu);
        }
        super.onPanelClosed(i2, menu);
    }

    @Override // android.app.Activity
    protected void onPause() {
        super.onPause();
        this.f1604l = false;
        this.f1601i.m();
        this.f1602j.i(d.a.ON_PAUSE);
    }

    @Override // android.app.Activity
    public void onPictureInPictureModeChanged(boolean z2) {
        this.f1601i.n(z2);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.app.Activity
    public void onPostResume() {
        super.onPostResume();
        s();
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public boolean onPreparePanel(int i2, View view, Menu menu) {
        return i2 == 0 ? r(view, menu) | this.f1601i.o(menu) : super.onPreparePanel(i2, view, menu);
    }

    @Override // android.app.Activity
    public void onRequestPermissionsResult(int i2, String[] strArr, int[] iArr) {
        this.f1601i.v();
        int i3 = (i2 >> 16) & 65535;
        if (i3 != 0) {
            int i4 = i3 - 1;
            String e2 = this.f1609q.e(i4);
            this.f1609q.j(i4);
            if (e2 == null) {
                Log.w("FragmentActivity", "Activity result delivered for unknown Fragment.");
                return;
            }
            Fragment t2 = this.f1601i.t(e2);
            if (t2 != null) {
                t2.x0(i2 & 65535, strArr, iArr);
                return;
            }
            Log.w("FragmentActivity", "Activity result no fragment exists for who: " + e2);
        }
    }

    @Override // android.app.Activity
    protected void onResume() {
        super.onResume();
        this.f1604l = true;
        this.f1601i.v();
        this.f1601i.s();
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.activity.ComponentActivity, t.e, android.app.Activity
    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        o();
        this.f1602j.i(d.a.ON_STOP);
        Parcelable y2 = this.f1601i.y();
        if (y2 != null) {
            bundle.putParcelable("android:support:fragments", y2);
        }
        if (this.f1609q.l() > 0) {
            bundle.putInt("android:support:next_request_index", this.f1608p);
            int[] iArr = new int[this.f1609q.l()];
            String[] strArr = new String[this.f1609q.l()];
            for (int i2 = 0; i2 < this.f1609q.l(); i2++) {
                iArr[i2] = this.f1609q.h(i2);
                strArr[i2] = this.f1609q.m(i2);
            }
            bundle.putIntArray("android:support:request_indicies", iArr);
            bundle.putStringArray("android:support:request_fragment_who", strArr);
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.app.Activity
    public void onStart() {
        super.onStart();
        this.f1605m = false;
        if (!this.f1603k) {
            this.f1603k = true;
            this.f1601i.c();
        }
        this.f1601i.v();
        this.f1601i.s();
        this.f1602j.i(d.a.ON_START);
        this.f1601i.q();
    }

    @Override // android.app.Activity
    public void onStateNotSaved() {
        this.f1601i.v();
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.app.Activity
    public void onStop() {
        super.onStop();
        this.f1605m = true;
        o();
        this.f1601i.r();
        this.f1602j.i(d.a.ON_STOP);
    }

    public void q(Fragment fragment) {
    }

    @Deprecated
    protected boolean r(View view, Menu menu) {
        return super.onPreparePanel(0, view, menu);
    }

    protected void s() {
        this.f1602j.i(d.a.ON_RESUME);
        this.f1601i.p();
    }

    @Override // android.app.Activity
    public void startActivityForResult(@SuppressLint({"UnknownNullness"}) Intent intent, int i2) {
        if (!this.f1607o && i2 != -1) {
            l(i2);
        }
        super.startActivityForResult(intent, i2);
    }

    @Override // android.app.Activity
    public void startActivityForResult(@SuppressLint({"UnknownNullness"}) Intent intent, int i2, Bundle bundle) {
        if (!this.f1607o && i2 != -1) {
            l(i2);
        }
        super.startActivityForResult(intent, i2, bundle);
    }

    @Override // android.app.Activity
    public void startIntentSenderForResult(@SuppressLint({"UnknownNullness"}) IntentSender intentSender, int i2, Intent intent, int i3, int i4, int i5) {
        if (!this.f1606n && i2 != -1) {
            l(i2);
        }
        super.startIntentSenderForResult(intentSender, i2, intent, i3, i4, i5);
    }

    @Override // android.app.Activity
    public void startIntentSenderForResult(@SuppressLint({"UnknownNullness"}) IntentSender intentSender, int i2, Intent intent, int i3, int i4, int i5, Bundle bundle) {
        if (!this.f1606n && i2 != -1) {
            l(i2);
        }
        super.startIntentSenderForResult(intentSender, i2, intent, i3, i4, i5, bundle);
    }

    @Deprecated
    public void t() {
        invalidateOptionsMenu();
    }
}
