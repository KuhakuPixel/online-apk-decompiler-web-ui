package androidx.versionedparcelable;

import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.SparseIntArray;
import java.lang.reflect.Method;
/* loaded from: classes.dex */
class b extends a {

    /* renamed from: d  reason: collision with root package name */
    private final SparseIntArray f2813d;

    /* renamed from: e  reason: collision with root package name */
    private final Parcel f2814e;

    /* renamed from: f  reason: collision with root package name */
    private final int f2815f;

    /* renamed from: g  reason: collision with root package name */
    private final int f2816g;

    /* renamed from: h  reason: collision with root package name */
    private final String f2817h;

    /* renamed from: i  reason: collision with root package name */
    private int f2818i;

    /* renamed from: j  reason: collision with root package name */
    private int f2819j;

    /* renamed from: k  reason: collision with root package name */
    private int f2820k;

    /* JADX INFO: Access modifiers changed from: package-private */
    public b(Parcel parcel) {
        this(parcel, parcel.dataPosition(), parcel.dataSize(), "", new l.a(), new l.a(), new l.a());
    }

    private b(Parcel parcel, int i2, int i3, String str, l.a<String, Method> aVar, l.a<String, Method> aVar2, l.a<String, Class> aVar3) {
        super(aVar, aVar2, aVar3);
        this.f2813d = new SparseIntArray();
        this.f2818i = -1;
        this.f2820k = -1;
        this.f2814e = parcel;
        this.f2815f = i2;
        this.f2816g = i3;
        this.f2819j = i2;
        this.f2817h = str;
    }

    @Override // androidx.versionedparcelable.a
    public void A(byte[] bArr) {
        if (bArr == null) {
            this.f2814e.writeInt(-1);
            return;
        }
        this.f2814e.writeInt(bArr.length);
        this.f2814e.writeByteArray(bArr);
    }

    @Override // androidx.versionedparcelable.a
    protected void C(CharSequence charSequence) {
        TextUtils.writeToParcel(charSequence, this.f2814e, 0);
    }

    @Override // androidx.versionedparcelable.a
    public void E(int i2) {
        this.f2814e.writeInt(i2);
    }

    @Override // androidx.versionedparcelable.a
    public void G(Parcelable parcelable) {
        this.f2814e.writeParcelable(parcelable, 0);
    }

    @Override // androidx.versionedparcelable.a
    public void I(String str) {
        this.f2814e.writeString(str);
    }

    @Override // androidx.versionedparcelable.a
    public void a() {
        int i2 = this.f2818i;
        if (i2 >= 0) {
            int i3 = this.f2813d.get(i2);
            int dataPosition = this.f2814e.dataPosition();
            this.f2814e.setDataPosition(i3);
            this.f2814e.writeInt(dataPosition - i3);
            this.f2814e.setDataPosition(dataPosition);
        }
    }

    @Override // androidx.versionedparcelable.a
    protected a b() {
        Parcel parcel = this.f2814e;
        int dataPosition = parcel.dataPosition();
        int i2 = this.f2819j;
        if (i2 == this.f2815f) {
            i2 = this.f2816g;
        }
        return new b(parcel, dataPosition, i2, this.f2817h + "  ", this.f2810a, this.f2811b, this.f2812c);
    }

    @Override // androidx.versionedparcelable.a
    public boolean g() {
        return this.f2814e.readInt() != 0;
    }

    @Override // androidx.versionedparcelable.a
    public byte[] i() {
        int readInt = this.f2814e.readInt();
        if (readInt < 0) {
            return null;
        }
        byte[] bArr = new byte[readInt];
        this.f2814e.readByteArray(bArr);
        return bArr;
    }

    @Override // androidx.versionedparcelable.a
    protected CharSequence k() {
        return (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(this.f2814e);
    }

    @Override // androidx.versionedparcelable.a
    public boolean m(int i2) {
        while (this.f2819j < this.f2816g) {
            int i3 = this.f2820k;
            if (i3 == i2) {
                return true;
            }
            if (String.valueOf(i3).compareTo(String.valueOf(i2)) > 0) {
                return false;
            }
            this.f2814e.setDataPosition(this.f2819j);
            int readInt = this.f2814e.readInt();
            this.f2820k = this.f2814e.readInt();
            this.f2819j += readInt;
        }
        return this.f2820k == i2;
    }

    @Override // androidx.versionedparcelable.a
    public int o() {
        return this.f2814e.readInt();
    }

    @Override // androidx.versionedparcelable.a
    public <T extends Parcelable> T q() {
        return (T) this.f2814e.readParcelable(getClass().getClassLoader());
    }

    @Override // androidx.versionedparcelable.a
    public String s() {
        return this.f2814e.readString();
    }

    @Override // androidx.versionedparcelable.a
    public void w(int i2) {
        a();
        this.f2818i = i2;
        this.f2813d.put(i2, this.f2814e.dataPosition());
        E(0);
        E(i2);
    }

    @Override // androidx.versionedparcelable.a
    public void y(boolean z2) {
        this.f2814e.writeInt(z2 ? 1 : 0);
    }
}
