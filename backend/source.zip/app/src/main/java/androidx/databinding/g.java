package androidx.databinding;
/* loaded from: classes.dex */
public interface g {

    /* loaded from: classes.dex */
    public static abstract class a {
        public abstract void c(g gVar, int i2);
    }

    void a(a aVar);

    void c(a aVar);
}
