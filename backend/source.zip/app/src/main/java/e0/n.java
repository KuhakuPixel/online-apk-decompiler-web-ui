package e0;

import android.view.View;
import android.view.ViewGroup;
/* loaded from: classes.dex */
public class n {

    /* renamed from: a  reason: collision with root package name */
    private int f4297a;

    /* renamed from: b  reason: collision with root package name */
    private int f4298b;

    public n(ViewGroup viewGroup) {
    }

    public int a() {
        return this.f4297a | this.f4298b;
    }

    public void b(View view, View view2, int i2) {
        c(view, view2, i2, 0);
    }

    public void c(View view, View view2, int i2, int i3) {
        if (i3 == 1) {
            this.f4298b = i2;
        } else {
            this.f4297a = i2;
        }
    }

    public void d(View view, int i2) {
        if (i2 == 1) {
            this.f4298b = 0;
        } else {
            this.f4297a = 0;
        }
    }
}
