package androidx.room;

import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.content.Context;
import android.database.Cursor;
import android.os.CancellationSignal;
import android.os.Looper;
import androidx.room.e0;
import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.Callable;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import u0.c;
/* loaded from: classes.dex */
public abstract class e0 {
    @Deprecated

    /* renamed from: a  reason: collision with root package name */
    protected volatile u0.b f2527a;

    /* renamed from: b  reason: collision with root package name */
    private Executor f2528b;

    /* renamed from: c  reason: collision with root package name */
    private Executor f2529c;

    /* renamed from: d  reason: collision with root package name */
    private u0.c f2530d;

    /* renamed from: f  reason: collision with root package name */
    private boolean f2532f;

    /* renamed from: g  reason: collision with root package name */
    boolean f2533g;
    @Deprecated

    /* renamed from: h  reason: collision with root package name */
    protected List<b> f2534h;

    /* renamed from: j  reason: collision with root package name */
    private androidx.room.a f2536j;

    /* renamed from: i  reason: collision with root package name */
    private final ReentrantReadWriteLock f2535i = new ReentrantReadWriteLock();

    /* renamed from: k  reason: collision with root package name */
    private final ThreadLocal<Integer> f2537k = new ThreadLocal<>();

    /* renamed from: l  reason: collision with root package name */
    private final Map<String, Object> f2538l = Collections.synchronizedMap(new HashMap());

    /* renamed from: e  reason: collision with root package name */
    private final n f2531e = g();

    /* renamed from: m  reason: collision with root package name */
    private final Map<Class<?>, Object> f2539m = new HashMap();

    /* loaded from: classes.dex */
    public static class a<T extends e0> {

        /* renamed from: a  reason: collision with root package name */
        private final Class<T> f2540a;

        /* renamed from: b  reason: collision with root package name */
        private final String f2541b;

        /* renamed from: c  reason: collision with root package name */
        private final Context f2542c;

        /* renamed from: d  reason: collision with root package name */
        private ArrayList<b> f2543d;

        /* renamed from: e  reason: collision with root package name */
        private f f2544e;

        /* renamed from: f  reason: collision with root package name */
        private Executor f2545f;

        /* renamed from: g  reason: collision with root package name */
        private List<Object> f2546g;

        /* renamed from: h  reason: collision with root package name */
        private Executor f2547h;

        /* renamed from: i  reason: collision with root package name */
        private Executor f2548i;

        /* renamed from: j  reason: collision with root package name */
        private c.InterfaceC0072c f2549j;

        /* renamed from: k  reason: collision with root package name */
        private boolean f2550k;

        /* renamed from: m  reason: collision with root package name */
        private boolean f2552m;

        /* renamed from: o  reason: collision with root package name */
        private boolean f2554o;

        /* renamed from: q  reason: collision with root package name */
        private TimeUnit f2556q;

        /* renamed from: s  reason: collision with root package name */
        private Set<Integer> f2558s;

        /* renamed from: t  reason: collision with root package name */
        private Set<Integer> f2559t;

        /* renamed from: u  reason: collision with root package name */
        private String f2560u;

        /* renamed from: v  reason: collision with root package name */
        private File f2561v;

        /* renamed from: w  reason: collision with root package name */
        private Callable<InputStream> f2562w;

        /* renamed from: p  reason: collision with root package name */
        private long f2555p = -1;

        /* renamed from: l  reason: collision with root package name */
        private c f2551l = c.AUTOMATIC;

        /* renamed from: n  reason: collision with root package name */
        private boolean f2553n = true;

        /* renamed from: r  reason: collision with root package name */
        private final d f2557r = new d();

        /* JADX INFO: Access modifiers changed from: package-private */
        public a(Context context, Class<T> cls, String str) {
            this.f2542c = context;
            this.f2540a = cls;
            this.f2541b = str;
        }

        /* JADX WARN: Code restructure failed: missing block: B:18:0x0028, code lost:
            if (r1 != null) goto L11;
         */
        /* JADX WARN: Removed duplicated region for block: B:27:0x003d  */
        /* JADX WARN: Removed duplicated region for block: B:34:0x0067  */
        /* JADX WARN: Removed duplicated region for block: B:37:0x0074  */
        /* JADX WARN: Removed duplicated region for block: B:50:0x00a0  */
        /* JADX WARN: Removed duplicated region for block: B:73:0x011d  */
        @android.annotation.SuppressLint({"RestrictedApi"})
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public T a() {
            /*
                Method dump skipped, instructions count: 309
                To view this dump add '--comments-level debug' option
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.room.e0.a.a():androidx.room.e0");
        }

        public a<T> b(String str) {
            this.f2560u = str;
            return this;
        }
    }

    /* loaded from: classes.dex */
    public static abstract class b {
        public void a(u0.b bVar) {
        }

        public void b(u0.b bVar) {
        }

        public void c(u0.b bVar) {
        }
    }

    /* loaded from: classes.dex */
    public enum c {
        AUTOMATIC,
        TRUNCATE,
        WRITE_AHEAD_LOGGING;

        private static boolean a(ActivityManager activityManager) {
            return activityManager.isLowRamDevice();
        }

        @SuppressLint({"NewApi"})
        c b(Context context) {
            if (this != AUTOMATIC) {
                return this;
            }
            ActivityManager activityManager = (ActivityManager) context.getSystemService("activity");
            return (activityManager == null || a(activityManager)) ? TRUNCATE : WRITE_AHEAD_LOGGING;
        }
    }

    /* loaded from: classes.dex */
    public static class d {

        /* renamed from: a  reason: collision with root package name */
        private HashMap<Integer, TreeMap<Integer, s0.a>> f2567a = new HashMap<>();

        /* JADX WARN: Removed duplicated region for block: B:31:0x0016 A[SYNTHETIC] */
        /* JADX WARN: Removed duplicated region for block: B:9:0x0017  */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        private java.util.List<s0.a> b(java.util.List<s0.a> r7, boolean r8, int r9, int r10) {
            /*
                r6 = this;
            L0:
                if (r8 == 0) goto L5
                if (r9 >= r10) goto L5a
                goto L7
            L5:
                if (r9 <= r10) goto L5a
            L7:
                java.util.HashMap<java.lang.Integer, java.util.TreeMap<java.lang.Integer, s0.a>> r0 = r6.f2567a
                java.lang.Integer r1 = java.lang.Integer.valueOf(r9)
                java.lang.Object r0 = r0.get(r1)
                java.util.TreeMap r0 = (java.util.TreeMap) r0
                r1 = 0
                if (r0 != 0) goto L17
                return r1
            L17:
                if (r8 == 0) goto L1e
                java.util.NavigableSet r2 = r0.descendingKeySet()
                goto L22
            L1e:
                java.util.Set r2 = r0.keySet()
            L22:
                java.util.Iterator r2 = r2.iterator()
            L26:
                boolean r3 = r2.hasNext()
                r4 = 1
                r5 = 0
                if (r3 == 0) goto L56
                java.lang.Object r3 = r2.next()
                java.lang.Integer r3 = (java.lang.Integer) r3
                int r3 = r3.intValue()
                if (r8 == 0) goto L40
                if (r3 > r10) goto L45
                if (r3 <= r9) goto L45
            L3e:
                r5 = 1
                goto L45
            L40:
                if (r3 < r10) goto L45
                if (r3 >= r9) goto L45
                goto L3e
            L45:
                if (r5 == 0) goto L26
                java.lang.Integer r9 = java.lang.Integer.valueOf(r3)
                java.lang.Object r9 = r0.get(r9)
                s0.a r9 = (s0.a) r9
                r7.add(r9)
                r9 = r3
                goto L57
            L56:
                r4 = 0
            L57:
                if (r4 != 0) goto L0
                return r1
            L5a:
                return r7
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.room.e0.d.b(java.util.List, boolean, int, int):java.util.List");
        }

        public List<s0.a> a(int i2, int i3) {
            if (i2 == i3) {
                return Collections.emptyList();
            }
            return b(new ArrayList(), i3 > i2, i2, i3);
        }
    }

    /* loaded from: classes.dex */
    public static abstract class e {
    }

    /* loaded from: classes.dex */
    public interface f {
        void a(String str, List<Object> list);
    }

    /* JADX WARN: Multi-variable type inference failed */
    private <T> T B(Class<T> cls, u0.c cVar) {
        if (cls.isInstance(cVar)) {
            return cVar;
        }
        if (cVar instanceof i) {
            return (T) B(cls, ((i) cVar).e());
        }
        return null;
    }

    private void r() {
        c();
        u0.b r2 = this.f2530d.r();
        this.f2531e.r(r2);
        if (r2.f()) {
            r2.n();
        } else {
            r2.b();
        }
    }

    private void s() {
        this.f2530d.r().a();
        if (p()) {
            return;
        }
        this.f2531e.j();
    }

    private static boolean u() {
        return Looper.getMainLooper().getThread() == Thread.currentThread();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ Object w(u0.b bVar) {
        r();
        return null;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ Object x(u0.b bVar) {
        s();
        return null;
    }

    @Deprecated
    public void A() {
        this.f2530d.r().k();
    }

    public void c() {
        if (!this.f2532f && u()) {
            throw new IllegalStateException("Cannot access database on the main thread since it may potentially lock the UI for a long period of time.");
        }
    }

    public void d() {
        if (!p() && this.f2537k.get() != null) {
            throw new IllegalStateException("Cannot access database on a different coroutine context inherited from a suspending transaction.");
        }
    }

    @Deprecated
    public void e() {
        c();
        androidx.room.a aVar = this.f2536j;
        if (aVar == null) {
            r();
        } else {
            aVar.c(new j.a() { // from class: r0.e
                @Override // j.a
                public final Object a(Object obj) {
                    Object w2;
                    w2 = e0.this.w((u0.b) obj);
                    return w2;
                }
            });
        }
    }

    public u0.f f(String str) {
        c();
        d();
        return this.f2530d.r().m(str);
    }

    protected abstract n g();

    protected abstract u0.c h(h hVar);

    @Deprecated
    public void i() {
        androidx.room.a aVar = this.f2536j;
        if (aVar == null) {
            s();
        } else {
            aVar.c(new j.a() { // from class: r0.f
                @Override // j.a
                public final Object a(Object obj) {
                    Object x2;
                    x2 = e0.this.x((u0.b) obj);
                    return x2;
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public Lock j() {
        return this.f2535i.readLock();
    }

    public n k() {
        return this.f2531e;
    }

    public u0.c l() {
        return this.f2530d;
    }

    public Executor m() {
        return this.f2528b;
    }

    protected Map<Class<?>, List<Class<?>>> n() {
        return Collections.emptyMap();
    }

    public Executor o() {
        return this.f2529c;
    }

    public boolean p() {
        return this.f2530d.r().u();
    }

    public void q(h hVar) {
        u0.c h2 = h(hVar);
        this.f2530d = h2;
        h0 h0Var = (h0) B(h0.class, h2);
        if (h0Var != null) {
            h0Var.y(hVar);
        }
        androidx.room.e eVar = (androidx.room.e) B(androidx.room.e.class, this.f2530d);
        if (eVar != null) {
            androidx.room.a v2 = eVar.v();
            this.f2536j = v2;
            this.f2531e.m(v2);
        }
        boolean z2 = hVar.f2599h == c.WRITE_AHEAD_LOGGING;
        this.f2530d.setWriteAheadLoggingEnabled(z2);
        this.f2534h = hVar.f2596e;
        this.f2528b = hVar.f2600i;
        this.f2529c = new j0(hVar.f2601j);
        this.f2532f = hVar.f2598g;
        this.f2533g = z2;
        if (hVar.f2602k) {
            this.f2531e.n(hVar.f2593b, hVar.f2594c);
        }
        Map<Class<?>, List<Class<?>>> n2 = n();
        BitSet bitSet = new BitSet();
        for (Map.Entry<Class<?>, List<Class<?>>> entry : n2.entrySet()) {
            Class<?> key = entry.getKey();
            for (Class<?> cls : entry.getValue()) {
                int size = hVar.f2597f.size() - 1;
                while (true) {
                    if (size < 0) {
                        size = -1;
                        break;
                    } else if (cls.isAssignableFrom(hVar.f2597f.get(size).getClass())) {
                        bitSet.set(size);
                        break;
                    } else {
                        size--;
                    }
                }
                if (size < 0) {
                    throw new IllegalArgumentException("A required type converter (" + cls + ") for " + key.getCanonicalName() + " is missing in the database configuration.");
                }
                this.f2539m.put(cls, hVar.f2597f.get(size));
            }
        }
        for (int size2 = hVar.f2597f.size() - 1; size2 >= 0; size2--) {
            if (!bitSet.get(size2)) {
                throw new IllegalArgumentException("Unexpected type converter " + hVar.f2597f.get(size2) + ". Annotate TypeConverter class with @ProvidedTypeConverter annotation or remove this converter from the builder.");
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public void t(u0.b bVar) {
        this.f2531e.g(bVar);
    }

    public boolean v() {
        androidx.room.a aVar = this.f2536j;
        if (aVar != null) {
            return aVar.g();
        }
        u0.b bVar = this.f2527a;
        return bVar != null && bVar.c();
    }

    public Cursor y(u0.e eVar) {
        return z(eVar, null);
    }

    public Cursor z(u0.e eVar, CancellationSignal cancellationSignal) {
        c();
        d();
        return cancellationSignal != null ? this.f2530d.r().w(eVar, cancellationSignal) : this.f2530d.r().j(eVar);
    }
}
