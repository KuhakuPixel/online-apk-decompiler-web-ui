package androidx.room;

import android.annotation.SuppressLint;
import androidx.lifecycle.LiveData;
import androidx.room.n;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicBoolean;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes.dex */
public class g0<T> extends LiveData<T> {

    /* renamed from: k  reason: collision with root package name */
    final e0 f2579k;

    /* renamed from: l  reason: collision with root package name */
    final boolean f2580l;

    /* renamed from: m  reason: collision with root package name */
    final Callable<T> f2581m;

    /* renamed from: n  reason: collision with root package name */
    private final l f2582n;

    /* renamed from: o  reason: collision with root package name */
    final n.c f2583o;

    /* renamed from: p  reason: collision with root package name */
    final AtomicBoolean f2584p = new AtomicBoolean(true);

    /* renamed from: q  reason: collision with root package name */
    final AtomicBoolean f2585q = new AtomicBoolean(false);

    /* renamed from: r  reason: collision with root package name */
    final AtomicBoolean f2586r = new AtomicBoolean(false);

    /* renamed from: s  reason: collision with root package name */
    final Runnable f2587s = new a();

    /* renamed from: t  reason: collision with root package name */
    final Runnable f2588t = new b();

    /* loaded from: classes.dex */
    class a implements Runnable {
        a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            boolean z2;
            if (g0.this.f2586r.compareAndSet(false, true)) {
                g0.this.f2579k.k().b(g0.this.f2583o);
            }
            do {
                if (g0.this.f2585q.compareAndSet(false, true)) {
                    T t2 = null;
                    z2 = false;
                    while (g0.this.f2584p.compareAndSet(true, false)) {
                        try {
                            try {
                                t2 = g0.this.f2581m.call();
                                z2 = true;
                            } catch (Exception e2) {
                                throw new RuntimeException("Exception while computing database live data.", e2);
                            }
                        } finally {
                            g0.this.f2585q.set(false);
                        }
                    }
                    if (z2) {
                        g0.this.k(t2);
                    }
                } else {
                    z2 = false;
                }
                if (!z2) {
                    return;
                }
            } while (g0.this.f2584p.get());
        }
    }

    /* loaded from: classes.dex */
    class b implements Runnable {
        b() {
        }

        @Override // java.lang.Runnable
        public void run() {
            boolean f2 = g0.this.f();
            if (g0.this.f2584p.compareAndSet(false, true) && f2) {
                g0.this.o().execute(g0.this.f2587s);
            }
        }
    }

    /* loaded from: classes.dex */
    class c extends n.c {
        c(String[] strArr) {
            super(strArr);
        }

        @Override // androidx.room.n.c
        public void b(Set<String> set) {
            h.a.f().b(g0.this.f2588t);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    @SuppressLint({"RestrictedApi"})
    public g0(e0 e0Var, l lVar, boolean z2, Callable<T> callable, String[] strArr) {
        this.f2579k = e0Var;
        this.f2580l = z2;
        this.f2581m = callable;
        this.f2582n = lVar;
        this.f2583o = new c(strArr);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.lifecycle.LiveData
    public void i() {
        super.i();
        this.f2582n.b(this);
        o().execute(this.f2587s);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.lifecycle.LiveData
    public void j() {
        super.j();
        this.f2582n.c(this);
    }

    Executor o() {
        return this.f2580l ? this.f2579k.o() : this.f2579k.m();
    }
}
