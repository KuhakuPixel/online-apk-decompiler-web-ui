package androidx.fragment.app;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.res.Configuration;
import android.os.Looper;
import android.os.Parcelable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import androidx.activity.OnBackPressedDispatcher;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.e;
import androidx.fragment.app.t;
import androidx.lifecycle.d;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
/* loaded from: classes.dex */
public abstract class l {
    private static boolean F = false;
    private ArrayList<Boolean> A;
    private ArrayList<Fragment> B;
    private ArrayList<i> C;
    private o D;

    /* renamed from: b  reason: collision with root package name */
    private boolean f1641b;

    /* renamed from: d  reason: collision with root package name */
    ArrayList<androidx.fragment.app.a> f1643d;

    /* renamed from: e  reason: collision with root package name */
    private ArrayList<Fragment> f1644e;

    /* renamed from: g  reason: collision with root package name */
    private OnBackPressedDispatcher f1646g;

    /* renamed from: j  reason: collision with root package name */
    private ArrayList<f> f1649j;

    /* renamed from: o  reason: collision with root package name */
    androidx.fragment.app.i<?> f1654o;

    /* renamed from: p  reason: collision with root package name */
    androidx.fragment.app.f f1655p;

    /* renamed from: q  reason: collision with root package name */
    private Fragment f1656q;

    /* renamed from: r  reason: collision with root package name */
    Fragment f1657r;

    /* renamed from: u  reason: collision with root package name */
    private boolean f1660u;

    /* renamed from: v  reason: collision with root package name */
    private boolean f1661v;

    /* renamed from: w  reason: collision with root package name */
    private boolean f1662w;

    /* renamed from: x  reason: collision with root package name */
    private boolean f1663x;

    /* renamed from: y  reason: collision with root package name */
    private boolean f1664y;

    /* renamed from: z  reason: collision with root package name */
    private ArrayList<androidx.fragment.app.a> f1665z;

    /* renamed from: a  reason: collision with root package name */
    private final ArrayList<g> f1640a = new ArrayList<>();

    /* renamed from: c  reason: collision with root package name */
    private final r f1642c = new r();

    /* renamed from: f  reason: collision with root package name */
    private final j f1645f = new j(this);

    /* renamed from: h  reason: collision with root package name */
    private final androidx.activity.b f1647h = new a(false);

    /* renamed from: i  reason: collision with root package name */
    private final AtomicInteger f1648i = new AtomicInteger();

    /* renamed from: k  reason: collision with root package name */
    private ConcurrentHashMap<Fragment, HashSet<a0.a>> f1650k = new ConcurrentHashMap<>();

    /* renamed from: l  reason: collision with root package name */
    private final t.g f1651l = new b();

    /* renamed from: m  reason: collision with root package name */
    private final k f1652m = new k(this);

    /* renamed from: n  reason: collision with root package name */
    int f1653n = -1;

    /* renamed from: s  reason: collision with root package name */
    private androidx.fragment.app.h f1658s = null;

    /* renamed from: t  reason: collision with root package name */
    private androidx.fragment.app.h f1659t = new c();
    private Runnable E = new d();

    /* loaded from: classes.dex */
    class a extends androidx.activity.b {
        a(boolean z2) {
            super(z2);
        }

        @Override // androidx.activity.b
        public void b() {
            l.this.m0();
        }
    }

    /* loaded from: classes.dex */
    class b implements t.g {
        b() {
        }

        @Override // androidx.fragment.app.t.g
        public void a(Fragment fragment, a0.a aVar) {
            if (aVar.b()) {
                return;
            }
            l.this.J0(fragment, aVar);
        }

        @Override // androidx.fragment.app.t.g
        public void b(Fragment fragment, a0.a aVar) {
            l.this.c(fragment, aVar);
        }
    }

    /* loaded from: classes.dex */
    class c extends androidx.fragment.app.h {
        c() {
        }

        @Override // androidx.fragment.app.h
        public Fragment a(ClassLoader classLoader, String str) {
            androidx.fragment.app.i<?> iVar = l.this.f1654o;
            return iVar.d(iVar.i(), str, null);
        }
    }

    /* loaded from: classes.dex */
    class d implements Runnable {
        d() {
        }

        @Override // java.lang.Runnable
        public void run() {
            l.this.Q(true);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public class e extends AnimatorListenerAdapter {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ ViewGroup f1670a;

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ View f1671b;

        /* renamed from: c  reason: collision with root package name */
        final /* synthetic */ Fragment f1672c;

        e(ViewGroup viewGroup, View view, Fragment fragment) {
            this.f1670a = viewGroup;
            this.f1671b = view;
            this.f1672c = fragment;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            this.f1670a.endViewTransition(this.f1671b);
            animator.removeListener(this);
            Fragment fragment = this.f1672c;
            View view = fragment.H;
            if (view == null || !fragment.f1545z) {
                return;
            }
            view.setVisibility(8);
        }
    }

    /* loaded from: classes.dex */
    public interface f {
        void a();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public interface g {
        boolean a(ArrayList<androidx.fragment.app.a> arrayList, ArrayList<Boolean> arrayList2);
    }

    /* loaded from: classes.dex */
    private class h implements g {

        /* renamed from: a  reason: collision with root package name */
        final String f1674a;

        /* renamed from: b  reason: collision with root package name */
        final int f1675b;

        /* renamed from: c  reason: collision with root package name */
        final int f1676c;

        h(String str, int i2, int i3) {
            this.f1674a = str;
            this.f1675b = i2;
            this.f1676c = i3;
        }

        @Override // androidx.fragment.app.l.g
        public boolean a(ArrayList<androidx.fragment.app.a> arrayList, ArrayList<Boolean> arrayList2) {
            Fragment fragment = l.this.f1657r;
            if (fragment == null || this.f1675b >= 0 || this.f1674a != null || !fragment.o().F0()) {
                return l.this.H0(arrayList, arrayList2, this.f1674a, this.f1675b, this.f1676c);
            }
            return false;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public static class i implements Fragment.f {

        /* renamed from: a  reason: collision with root package name */
        final boolean f1678a;

        /* renamed from: b  reason: collision with root package name */
        final androidx.fragment.app.a f1679b;

        /* renamed from: c  reason: collision with root package name */
        private int f1680c;

        i(androidx.fragment.app.a aVar, boolean z2) {
            this.f1678a = z2;
            this.f1679b = aVar;
        }

        @Override // androidx.fragment.app.Fragment.f
        public void a() {
            int i2 = this.f1680c - 1;
            this.f1680c = i2;
            if (i2 != 0) {
                return;
            }
            this.f1679b.f1569t.R0();
        }

        @Override // androidx.fragment.app.Fragment.f
        public void b() {
            this.f1680c++;
        }

        void c() {
            androidx.fragment.app.a aVar = this.f1679b;
            aVar.f1569t.n(aVar, this.f1678a, false, false);
        }

        void d() {
            boolean z2 = this.f1680c > 0;
            for (Fragment fragment : this.f1679b.f1569t.f0()) {
                fragment.m1(null);
                if (z2 && fragment.S()) {
                    fragment.o1();
                }
            }
            androidx.fragment.app.a aVar = this.f1679b;
            aVar.f1569t.n(aVar, this.f1678a, !z2, true);
        }

        public boolean e() {
            return this.f1680c == 0;
        }
    }

    private void C(Fragment fragment) {
        if (fragment == null || !fragment.equals(V(fragment.f1525f))) {
            return;
        }
        fragment.W0();
    }

    private boolean G0(String str, int i2, int i3) {
        Q(false);
        P(true);
        Fragment fragment = this.f1657r;
        if (fragment == null || i2 >= 0 || str != null || !fragment.o().F0()) {
            boolean H0 = H0(this.f1665z, this.A, str, i2, i3);
            if (H0) {
                this.f1641b = true;
                try {
                    L0(this.f1665z, this.A);
                } finally {
                    m();
                }
            }
            Y0();
            L();
            this.f1642c.b();
            return H0;
        }
        return true;
    }

    private int I0(ArrayList<androidx.fragment.app.a> arrayList, ArrayList<Boolean> arrayList2, int i2, int i3, l.b<Fragment> bVar) {
        int i4 = i3;
        for (int i5 = i3 - 1; i5 >= i2; i5--) {
            androidx.fragment.app.a aVar = arrayList.get(i5);
            boolean booleanValue = arrayList2.get(i5).booleanValue();
            if (aVar.E() && !aVar.C(arrayList, i5 + 1, i3)) {
                if (this.C == null) {
                    this.C = new ArrayList<>();
                }
                i iVar = new i(aVar, booleanValue);
                this.C.add(iVar);
                aVar.G(iVar);
                if (booleanValue) {
                    aVar.x();
                } else {
                    aVar.y(false);
                }
                i4--;
                if (i5 != i4) {
                    arrayList.remove(i5);
                    arrayList.add(i4, aVar);
                }
                a(bVar);
            }
        }
        return i4;
    }

    private void J(int i2) {
        try {
            this.f1641b = true;
            this.f1642c.d(i2);
            y0(i2, false);
            this.f1641b = false;
            Q(true);
        } catch (Throwable th) {
            this.f1641b = false;
            throw th;
        }
    }

    private void L() {
        if (this.f1664y) {
            this.f1664y = false;
            X0();
        }
    }

    private void L0(ArrayList<androidx.fragment.app.a> arrayList, ArrayList<Boolean> arrayList2) {
        if (arrayList.isEmpty()) {
            return;
        }
        if (arrayList.size() != arrayList2.size()) {
            throw new IllegalStateException("Internal error with the back stack records");
        }
        U(arrayList, arrayList2);
        int size = arrayList.size();
        int i2 = 0;
        int i3 = 0;
        while (i2 < size) {
            if (!arrayList.get(i2).f1729r) {
                if (i3 != i2) {
                    T(arrayList, arrayList2, i3, i2);
                }
                i3 = i2 + 1;
                if (arrayList2.get(i2).booleanValue()) {
                    while (i3 < size && arrayList2.get(i3).booleanValue() && !arrayList.get(i3).f1729r) {
                        i3++;
                    }
                }
                T(arrayList, arrayList2, i2, i3);
                i2 = i3 - 1;
            }
            i2++;
        }
        if (i3 != size) {
            T(arrayList, arrayList2, i3, size);
        }
    }

    private void N() {
        if (this.f1650k.isEmpty()) {
            return;
        }
        for (Fragment fragment : this.f1650k.keySet()) {
            j(fragment);
            A0(fragment, fragment.H());
        }
    }

    private void N0() {
        if (this.f1649j != null) {
            for (int i2 = 0; i2 < this.f1649j.size(); i2++) {
                this.f1649j.get(i2).a();
            }
        }
    }

    private void P(boolean z2) {
        if (this.f1641b) {
            throw new IllegalStateException("FragmentManager is already executing transactions");
        }
        if (this.f1654o == null) {
            if (!this.f1663x) {
                throw new IllegalStateException("FragmentManager has not been attached to a host.");
            }
            throw new IllegalStateException("FragmentManager has been destroyed");
        } else if (Looper.myLooper() != this.f1654o.j().getLooper()) {
            throw new IllegalStateException("Must be called from main thread of fragment host");
        } else {
            if (!z2) {
                l();
            }
            if (this.f1665z == null) {
                this.f1665z = new ArrayList<>();
                this.A = new ArrayList<>();
            }
            this.f1641b = true;
            try {
                U(null, null);
            } finally {
                this.f1641b = false;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static int P0(int i2) {
        if (i2 != 4097) {
            if (i2 != 4099) {
                return i2 != 8194 ? 0 : 4097;
            }
            return 4099;
        }
        return 8194;
    }

    private static void S(ArrayList<androidx.fragment.app.a> arrayList, ArrayList<Boolean> arrayList2, int i2, int i3) {
        while (i2 < i3) {
            androidx.fragment.app.a aVar = arrayList.get(i2);
            if (arrayList2.get(i2).booleanValue()) {
                aVar.t(-1);
                aVar.y(i2 == i3 + (-1));
            } else {
                aVar.t(1);
                aVar.x();
            }
            i2++;
        }
    }

    private void T(ArrayList<androidx.fragment.app.a> arrayList, ArrayList<Boolean> arrayList2, int i2, int i3) {
        int i4;
        int i5 = i2;
        boolean z2 = arrayList.get(i5).f1729r;
        ArrayList<Fragment> arrayList3 = this.B;
        if (arrayList3 == null) {
            this.B = new ArrayList<>();
        } else {
            arrayList3.clear();
        }
        this.B.addAll(this.f1642c.m());
        Fragment j02 = j0();
        boolean z3 = false;
        for (int i6 = i5; i6 < i3; i6++) {
            androidx.fragment.app.a aVar = arrayList.get(i6);
            j02 = !arrayList2.get(i6).booleanValue() ? aVar.z(this.B, j02) : aVar.H(this.B, j02);
            z3 = z3 || aVar.f1720i;
        }
        this.B.clear();
        if (!z2) {
            t.B(this, arrayList, arrayList2, i2, i3, false, this.f1651l);
        }
        S(arrayList, arrayList2, i2, i3);
        if (z2) {
            l.b<Fragment> bVar = new l.b<>();
            a(bVar);
            int I0 = I0(arrayList, arrayList2, i2, i3, bVar);
            w0(bVar);
            i4 = I0;
        } else {
            i4 = i3;
        }
        if (i4 != i5 && z2) {
            t.B(this, arrayList, arrayList2, i2, i4, true, this.f1651l);
            y0(this.f1653n, true);
        }
        while (i5 < i3) {
            androidx.fragment.app.a aVar2 = arrayList.get(i5);
            if (arrayList2.get(i5).booleanValue() && aVar2.f1571v >= 0) {
                aVar2.f1571v = -1;
            }
            aVar2.F();
            i5++;
        }
        if (z3) {
            N0();
        }
    }

    private void U(ArrayList<androidx.fragment.app.a> arrayList, ArrayList<Boolean> arrayList2) {
        int indexOf;
        int indexOf2;
        ArrayList<i> arrayList3 = this.C;
        int size = arrayList3 == null ? 0 : arrayList3.size();
        int i2 = 0;
        while (i2 < size) {
            i iVar = this.C.get(i2);
            if (arrayList == null || iVar.f1678a || (indexOf2 = arrayList.indexOf(iVar.f1679b)) == -1 || arrayList2 == null || !arrayList2.get(indexOf2).booleanValue()) {
                if (iVar.e() || (arrayList != null && iVar.f1679b.C(arrayList, 0, arrayList.size()))) {
                    this.C.remove(i2);
                    i2--;
                    size--;
                    if (arrayList == null || iVar.f1678a || (indexOf = arrayList.indexOf(iVar.f1679b)) == -1 || arrayList2 == null || !arrayList2.get(indexOf).booleanValue()) {
                        iVar.d();
                    }
                }
                i2++;
            } else {
                this.C.remove(i2);
                i2--;
                size--;
            }
            iVar.c();
            i2++;
        }
    }

    private void V0(Fragment fragment) {
        ViewGroup d02 = d0(fragment);
        if (d02 != null) {
            int i2 = l0.b.visible_removing_fragment_view_tag;
            if (d02.getTag(i2) == null) {
                d02.setTag(i2, fragment);
            }
            ((Fragment) d02.getTag(i2)).k1(fragment.x());
        }
    }

    private void X0() {
        for (Fragment fragment : this.f1642c.k()) {
            if (fragment != null) {
                C0(fragment);
            }
        }
    }

    private void Y0() {
        synchronized (this.f1640a) {
            if (this.f1640a.isEmpty()) {
                this.f1647h.f(b0() > 0 && r0(this.f1656q));
            } else {
                this.f1647h.f(true);
            }
        }
    }

    private void Z() {
        if (this.C != null) {
            while (!this.C.isEmpty()) {
                this.C.remove(0).d();
            }
        }
    }

    private void a(l.b<Fragment> bVar) {
        int i2 = this.f1653n;
        if (i2 < 1) {
            return;
        }
        int min = Math.min(i2, 3);
        for (Fragment fragment : this.f1642c.m()) {
            if (fragment.f1521b < min) {
                A0(fragment, min);
                if (fragment.H != null && !fragment.f1545z && fragment.M) {
                    bVar.add(fragment);
                }
            }
        }
    }

    private boolean a0(ArrayList<androidx.fragment.app.a> arrayList, ArrayList<Boolean> arrayList2) {
        synchronized (this.f1640a) {
            if (this.f1640a.isEmpty()) {
                return false;
            }
            int size = this.f1640a.size();
            boolean z2 = false;
            for (int i2 = 0; i2 < size; i2++) {
                z2 |= this.f1640a.get(i2).a(arrayList, arrayList2);
            }
            this.f1640a.clear();
            this.f1654o.j().removeCallbacks(this.E);
            return z2;
        }
    }

    private o c0(Fragment fragment) {
        return this.D.h(fragment);
    }

    private ViewGroup d0(Fragment fragment) {
        if (fragment.f1543x > 0 && this.f1655p.f()) {
            View e2 = this.f1655p.e(fragment.f1543x);
            if (e2 instanceof ViewGroup) {
                return (ViewGroup) e2;
            }
        }
        return null;
    }

    private void j(Fragment fragment) {
        HashSet<a0.a> hashSet = this.f1650k.get(fragment);
        if (hashSet != null) {
            Iterator<a0.a> it = hashSet.iterator();
            while (it.hasNext()) {
                it.next().a();
            }
            hashSet.clear();
            p(fragment);
            this.f1650k.remove(fragment);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static Fragment k0(View view) {
        Object tag = view.getTag(l0.b.fragment_container_view_tag);
        if (tag instanceof Fragment) {
            return (Fragment) tag;
        }
        return null;
    }

    private void l() {
        if (t0()) {
            throw new IllegalStateException("Can not perform this action after onSaveInstanceState");
        }
    }

    private void m() {
        this.f1641b = false;
        this.A.clear();
        this.f1665z.clear();
    }

    private void o(Fragment fragment) {
        Animator animator;
        if (fragment.H != null) {
            e.d b2 = androidx.fragment.app.e.b(this.f1654o.i(), this.f1655p, fragment, !fragment.f1545z);
            if (b2 == null || (animator = b2.f1623b) == null) {
                if (b2 != null) {
                    fragment.H.startAnimation(b2.f1622a);
                    b2.f1622a.start();
                }
                fragment.H.setVisibility((!fragment.f1545z || fragment.Q()) ? 0 : 8);
                if (fragment.Q()) {
                    fragment.j1(false);
                }
            } else {
                animator.setTarget(fragment.H);
                if (!fragment.f1545z) {
                    fragment.H.setVisibility(0);
                } else if (fragment.Q()) {
                    fragment.j1(false);
                } else {
                    ViewGroup viewGroup = fragment.G;
                    View view = fragment.H;
                    viewGroup.startViewTransition(view);
                    b2.f1623b.addListener(new e(viewGroup, view, fragment));
                }
                b2.f1623b.start();
            }
        }
        if (fragment.f1531l && q0(fragment)) {
            this.f1660u = true;
        }
        fragment.N = false;
        fragment.n0(fragment.f1545z);
    }

    private void p(Fragment fragment) {
        fragment.M0();
        this.f1652m.n(fragment, false);
        fragment.G = null;
        fragment.H = null;
        fragment.T = null;
        fragment.U.m(null);
        fragment.f1534o = false;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static boolean p0(int i2) {
        return F || Log.isLoggable("FragmentManager", i2);
    }

    private boolean q0(Fragment fragment) {
        return (fragment.D && fragment.E) || fragment.f1540u.k();
    }

    private void v0(q qVar) {
        Fragment i2 = qVar.i();
        if (this.f1642c.c(i2.f1525f)) {
            if (p0(2)) {
                Log.v("FragmentManager", "Removed fragment from active set " + i2);
            }
            this.f1642c.o(qVar);
            M0(i2);
        }
    }

    private void w0(l.b<Fragment> bVar) {
        int size = bVar.size();
        for (int i2 = 0; i2 < size; i2++) {
            Fragment j2 = bVar.j(i2);
            if (!j2.f1531l) {
                View d12 = j2.d1();
                j2.O = d12.getAlpha();
                d12.setAlpha(0.0f);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public boolean A(MenuItem menuItem) {
        if (this.f1653n < 1) {
            return false;
        }
        for (Fragment fragment : this.f1642c.m()) {
            if (fragment != null && fragment.R0(menuItem)) {
                return true;
            }
        }
        return false;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x003e, code lost:
        if (r2 != 3) goto L127;
     */
    /* JADX WARN: Removed duplicated region for block: B:125:0x01ef  */
    /* JADX WARN: Removed duplicated region for block: B:45:0x00e6  */
    /* JADX WARN: Removed duplicated region for block: B:47:0x00eb  */
    /* JADX WARN: Removed duplicated region for block: B:49:0x00f8  */
    /* JADX WARN: Removed duplicated region for block: B:51:0x00fd  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void A0(androidx.fragment.app.Fragment r13, int r14) {
        /*
            Method dump skipped, instructions count: 552
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.fragment.app.l.A0(androidx.fragment.app.Fragment, int):void");
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void B(Menu menu) {
        if (this.f1653n < 1) {
            return;
        }
        for (Fragment fragment : this.f1642c.m()) {
            if (fragment != null) {
                fragment.S0(menu);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void B0() {
        if (this.f1654o == null) {
            return;
        }
        this.f1661v = false;
        this.f1662w = false;
        for (Fragment fragment : this.f1642c.m()) {
            if (fragment != null) {
                fragment.W();
            }
        }
    }

    void C0(Fragment fragment) {
        if (fragment.I) {
            if (this.f1641b) {
                this.f1664y = true;
                return;
            }
            fragment.I = false;
            A0(fragment, this.f1653n);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void D() {
        J(3);
    }

    public void D0(int i2, int i3) {
        if (i2 >= 0) {
            O(new h(null, i2, i3), false);
            return;
        }
        throw new IllegalArgumentException("Bad id: " + i2);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void E(boolean z2) {
        for (Fragment fragment : this.f1642c.m()) {
            if (fragment != null) {
                fragment.U0(z2);
            }
        }
    }

    public void E0(String str, int i2) {
        O(new h(str, -1, i2), false);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public boolean F(Menu menu) {
        boolean z2 = false;
        if (this.f1653n < 1) {
            return false;
        }
        for (Fragment fragment : this.f1642c.m()) {
            if (fragment != null && fragment.V0(menu)) {
                z2 = true;
            }
        }
        return z2;
    }

    public boolean F0() {
        return G0(null, -1, 0);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void G() {
        Y0();
        C(this.f1657r);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void H() {
        this.f1661v = false;
        this.f1662w = false;
        J(4);
    }

    boolean H0(ArrayList<androidx.fragment.app.a> arrayList, ArrayList<Boolean> arrayList2, String str, int i2, int i3) {
        int i4;
        ArrayList<androidx.fragment.app.a> arrayList3 = this.f1643d;
        if (arrayList3 == null) {
            return false;
        }
        if (str == null && i2 < 0 && (i3 & 1) == 0) {
            int size = arrayList3.size() - 1;
            if (size < 0) {
                return false;
            }
            arrayList.add(this.f1643d.remove(size));
            arrayList2.add(Boolean.TRUE);
        } else {
            if (str != null || i2 >= 0) {
                int size2 = arrayList3.size() - 1;
                while (size2 >= 0) {
                    androidx.fragment.app.a aVar = this.f1643d.get(size2);
                    if ((str != null && str.equals(aVar.A())) || (i2 >= 0 && i2 == aVar.f1571v)) {
                        break;
                    }
                    size2--;
                }
                if (size2 < 0) {
                    return false;
                }
                if ((i3 & 1) != 0) {
                    while (true) {
                        size2--;
                        if (size2 < 0) {
                            break;
                        }
                        androidx.fragment.app.a aVar2 = this.f1643d.get(size2);
                        if (str == null || !str.equals(aVar2.A())) {
                            if (i2 < 0 || i2 != aVar2.f1571v) {
                                break;
                            }
                        }
                    }
                }
                i4 = size2;
            } else {
                i4 = -1;
            }
            if (i4 == this.f1643d.size() - 1) {
                return false;
            }
            for (int size3 = this.f1643d.size() - 1; size3 > i4; size3--) {
                arrayList.add(this.f1643d.remove(size3));
                arrayList2.add(Boolean.TRUE);
            }
        }
        return true;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void I() {
        this.f1661v = false;
        this.f1662w = false;
        J(3);
    }

    void J0(Fragment fragment, a0.a aVar) {
        HashSet<a0.a> hashSet = this.f1650k.get(fragment);
        if (hashSet != null && hashSet.remove(aVar) && hashSet.isEmpty()) {
            this.f1650k.remove(fragment);
            if (fragment.f1521b < 3) {
                p(fragment);
                A0(fragment, fragment.H());
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void K() {
        this.f1662w = true;
        J(2);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void K0(Fragment fragment) {
        if (p0(2)) {
            Log.v("FragmentManager", "remove: " + fragment + " nesting=" + fragment.f1537r);
        }
        boolean z2 = !fragment.R();
        if (!fragment.A || z2) {
            this.f1642c.p(fragment);
            if (q0(fragment)) {
                this.f1660u = true;
            }
            fragment.f1532m = true;
            V0(fragment);
        }
    }

    public void M(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        int size;
        int size2;
        String str2 = str + "    ";
        this.f1642c.e(str, fileDescriptor, printWriter, strArr);
        ArrayList<Fragment> arrayList = this.f1644e;
        if (arrayList != null && (size2 = arrayList.size()) > 0) {
            printWriter.print(str);
            printWriter.println("Fragments Created Menus:");
            for (int i2 = 0; i2 < size2; i2++) {
                Fragment fragment = this.f1644e.get(i2);
                printWriter.print(str);
                printWriter.print("  #");
                printWriter.print(i2);
                printWriter.print(": ");
                printWriter.println(fragment.toString());
            }
        }
        ArrayList<androidx.fragment.app.a> arrayList2 = this.f1643d;
        if (arrayList2 != null && (size = arrayList2.size()) > 0) {
            printWriter.print(str);
            printWriter.println("Back Stack:");
            for (int i3 = 0; i3 < size; i3++) {
                androidx.fragment.app.a aVar = this.f1643d.get(i3);
                printWriter.print(str);
                printWriter.print("  #");
                printWriter.print(i3);
                printWriter.print(": ");
                printWriter.println(aVar.toString());
                aVar.v(str2, printWriter);
            }
        }
        printWriter.print(str);
        printWriter.println("Back Stack Index: " + this.f1648i.get());
        synchronized (this.f1640a) {
            int size3 = this.f1640a.size();
            if (size3 > 0) {
                printWriter.print(str);
                printWriter.println("Pending Actions:");
                for (int i4 = 0; i4 < size3; i4++) {
                    g gVar = this.f1640a.get(i4);
                    printWriter.print(str);
                    printWriter.print("  #");
                    printWriter.print(i4);
                    printWriter.print(": ");
                    printWriter.println(gVar);
                }
            }
        }
        printWriter.print(str);
        printWriter.println("FragmentManager misc state:");
        printWriter.print(str);
        printWriter.print("  mHost=");
        printWriter.println(this.f1654o);
        printWriter.print(str);
        printWriter.print("  mContainer=");
        printWriter.println(this.f1655p);
        if (this.f1656q != null) {
            printWriter.print(str);
            printWriter.print("  mParent=");
            printWriter.println(this.f1656q);
        }
        printWriter.print(str);
        printWriter.print("  mCurState=");
        printWriter.print(this.f1653n);
        printWriter.print(" mStateSaved=");
        printWriter.print(this.f1661v);
        printWriter.print(" mStopped=");
        printWriter.print(this.f1662w);
        printWriter.print(" mDestroyed=");
        printWriter.println(this.f1663x);
        if (this.f1660u) {
            printWriter.print(str);
            printWriter.print("  mNeedMenuInvalidate=");
            printWriter.println(this.f1660u);
        }
    }

    void M0(Fragment fragment) {
        if (t0()) {
            if (p0(2)) {
                Log.v("FragmentManager", "Ignoring removeRetainedFragment as the state is already saved");
            }
        } else if (this.D.m(fragment) && p0(2)) {
            Log.v("FragmentManager", "Updating retained Fragments: Removed " + fragment);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void O(g gVar, boolean z2) {
        if (!z2) {
            if (this.f1654o == null) {
                if (!this.f1663x) {
                    throw new IllegalStateException("FragmentManager has not been attached to a host.");
                }
                throw new IllegalStateException("FragmentManager has been destroyed");
            }
            l();
        }
        synchronized (this.f1640a) {
            if (this.f1654o == null) {
                if (!z2) {
                    throw new IllegalStateException("Activity has been destroyed");
                }
                return;
            }
            this.f1640a.add(gVar);
            R0();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void O0(Parcelable parcelable) {
        q qVar;
        if (parcelable == null) {
            return;
        }
        n nVar = (n) parcelable;
        if (nVar.f1681b == null) {
            return;
        }
        this.f1642c.q();
        Iterator<p> it = nVar.f1681b.iterator();
        while (it.hasNext()) {
            p next = it.next();
            if (next != null) {
                Fragment g2 = this.D.g(next.f1694c);
                if (g2 != null) {
                    if (p0(2)) {
                        Log.v("FragmentManager", "restoreSaveState: re-attaching retained " + g2);
                    }
                    qVar = new q(this.f1652m, g2, next);
                } else {
                    qVar = new q(this.f1652m, this.f1654o.i().getClassLoader(), e0(), next);
                }
                Fragment i2 = qVar.i();
                i2.f1538s = this;
                if (p0(2)) {
                    Log.v("FragmentManager", "restoreSaveState: active (" + i2.f1525f + "): " + i2);
                }
                qVar.k(this.f1654o.i().getClassLoader());
                this.f1642c.n(qVar);
                qVar.q(this.f1653n);
            }
        }
        for (Fragment fragment : this.D.j()) {
            if (!this.f1642c.c(fragment.f1525f)) {
                if (p0(2)) {
                    Log.v("FragmentManager", "Discarding retained Fragment " + fragment + " that was not found in the set of active Fragments " + nVar.f1681b);
                }
                A0(fragment, 1);
                fragment.f1532m = true;
                A0(fragment, -1);
            }
        }
        this.f1642c.r(nVar.f1682c);
        if (nVar.f1683d != null) {
            this.f1643d = new ArrayList<>(nVar.f1683d.length);
            int i3 = 0;
            while (true) {
                androidx.fragment.app.b[] bVarArr = nVar.f1683d;
                if (i3 >= bVarArr.length) {
                    break;
                }
                androidx.fragment.app.a j2 = bVarArr[i3].j(this);
                if (p0(2)) {
                    Log.v("FragmentManager", "restoreAllState: back stack #" + i3 + " (index " + j2.f1571v + "): " + j2);
                    PrintWriter printWriter = new PrintWriter(new d0.b("FragmentManager"));
                    j2.w("  ", printWriter, false);
                    printWriter.close();
                }
                this.f1643d.add(j2);
                i3++;
            }
        } else {
            this.f1643d = null;
        }
        this.f1648i.set(nVar.f1684e);
        String str = nVar.f1685f;
        if (str != null) {
            Fragment V = V(str);
            this.f1657r = V;
            C(V);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public boolean Q(boolean z2) {
        P(z2);
        boolean z3 = false;
        while (a0(this.f1665z, this.A)) {
            this.f1641b = true;
            try {
                L0(this.f1665z, this.A);
                m();
                z3 = true;
            } catch (Throwable th) {
                m();
                throw th;
            }
        }
        Y0();
        L();
        this.f1642c.b();
        return z3;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public Parcelable Q0() {
        int size;
        Z();
        N();
        Q(true);
        this.f1661v = true;
        ArrayList<p> s2 = this.f1642c.s();
        androidx.fragment.app.b[] bVarArr = null;
        if (s2.isEmpty()) {
            if (p0(2)) {
                Log.v("FragmentManager", "saveAllState: no fragments!");
            }
            return null;
        }
        ArrayList<String> t2 = this.f1642c.t();
        ArrayList<androidx.fragment.app.a> arrayList = this.f1643d;
        if (arrayList != null && (size = arrayList.size()) > 0) {
            bVarArr = new androidx.fragment.app.b[size];
            for (int i2 = 0; i2 < size; i2++) {
                bVarArr[i2] = new androidx.fragment.app.b(this.f1643d.get(i2));
                if (p0(2)) {
                    Log.v("FragmentManager", "saveAllState: adding back stack #" + i2 + ": " + this.f1643d.get(i2));
                }
            }
        }
        n nVar = new n();
        nVar.f1681b = s2;
        nVar.f1682c = t2;
        nVar.f1683d = bVarArr;
        nVar.f1684e = this.f1648i.get();
        Fragment fragment = this.f1657r;
        if (fragment != null) {
            nVar.f1685f = fragment.f1525f;
        }
        return nVar;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void R(g gVar, boolean z2) {
        if (z2 && (this.f1654o == null || this.f1663x)) {
            return;
        }
        P(z2);
        if (gVar.a(this.f1665z, this.A)) {
            this.f1641b = true;
            try {
                L0(this.f1665z, this.A);
            } finally {
                m();
            }
        }
        Y0();
        L();
        this.f1642c.b();
    }

    void R0() {
        synchronized (this.f1640a) {
            ArrayList<i> arrayList = this.C;
            boolean z2 = (arrayList == null || arrayList.isEmpty()) ? false : true;
            boolean z3 = this.f1640a.size() == 1;
            if (z2 || z3) {
                this.f1654o.j().removeCallbacks(this.E);
                this.f1654o.j().post(this.E);
                Y0();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void S0(Fragment fragment, boolean z2) {
        ViewGroup d02 = d0(fragment);
        if (d02 == null || !(d02 instanceof FragmentContainerView)) {
            return;
        }
        ((FragmentContainerView) d02).setDrawDisappearingViewsLast(!z2);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void T0(Fragment fragment, d.b bVar) {
        if (fragment.equals(V(fragment.f1525f)) && (fragment.f1539t == null || fragment.f1538s == this)) {
            fragment.R = bVar;
            return;
        }
        throw new IllegalArgumentException("Fragment " + fragment + " is not an active fragment of FragmentManager " + this);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void U0(Fragment fragment) {
        if (fragment == null || (fragment.equals(V(fragment.f1525f)) && (fragment.f1539t == null || fragment.f1538s == this))) {
            Fragment fragment2 = this.f1657r;
            this.f1657r = fragment;
            C(fragment2);
            C(this.f1657r);
            return;
        }
        throw new IllegalArgumentException("Fragment " + fragment + " is not an active fragment of FragmentManager " + this);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public Fragment V(String str) {
        return this.f1642c.f(str);
    }

    public Fragment W(int i2) {
        return this.f1642c.g(i2);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void W0(Fragment fragment) {
        if (p0(2)) {
            Log.v("FragmentManager", "show: " + fragment);
        }
        if (fragment.f1545z) {
            fragment.f1545z = false;
            fragment.N = !fragment.N;
        }
    }

    public Fragment X(String str) {
        return this.f1642c.h(str);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public Fragment Y(String str) {
        return this.f1642c.i(str);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void b(androidx.fragment.app.a aVar) {
        if (this.f1643d == null) {
            this.f1643d = new ArrayList<>();
        }
        this.f1643d.add(aVar);
    }

    public int b0() {
        ArrayList<androidx.fragment.app.a> arrayList = this.f1643d;
        if (arrayList != null) {
            return arrayList.size();
        }
        return 0;
    }

    void c(Fragment fragment, a0.a aVar) {
        if (this.f1650k.get(fragment) == null) {
            this.f1650k.put(fragment, new HashSet<>());
        }
        this.f1650k.get(fragment).add(aVar);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void d(Fragment fragment) {
        if (p0(2)) {
            Log.v("FragmentManager", "add: " + fragment);
        }
        u0(fragment);
        if (fragment.A) {
            return;
        }
        this.f1642c.a(fragment);
        fragment.f1532m = false;
        if (fragment.H == null) {
            fragment.N = false;
        }
        if (q0(fragment)) {
            this.f1660u = true;
        }
    }

    void e(Fragment fragment) {
        if (t0()) {
            if (p0(2)) {
                Log.v("FragmentManager", "Ignoring addRetainedFragment as the state is already saved");
            }
        } else if (this.D.e(fragment) && p0(2)) {
            Log.v("FragmentManager", "Updating retained Fragments: Added " + fragment);
        }
    }

    public androidx.fragment.app.h e0() {
        androidx.fragment.app.h hVar = this.f1658s;
        if (hVar != null) {
            return hVar;
        }
        Fragment fragment = this.f1656q;
        return fragment != null ? fragment.f1538s.e0() : this.f1659t;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public int f() {
        return this.f1648i.getAndIncrement();
    }

    public List<Fragment> f0() {
        return this.f1642c.m();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void g(androidx.fragment.app.i<?> iVar, androidx.fragment.app.f fVar, Fragment fragment) {
        if (this.f1654o != null) {
            throw new IllegalStateException("Already attached");
        }
        this.f1654o = iVar;
        this.f1655p = fVar;
        this.f1656q = fragment;
        if (fragment != null) {
            Y0();
        }
        if (iVar instanceof androidx.activity.c) {
            androidx.activity.c cVar = (androidx.activity.c) iVar;
            OnBackPressedDispatcher b2 = cVar.b();
            this.f1646g = b2;
            androidx.lifecycle.g gVar = cVar;
            if (fragment != null) {
                gVar = fragment;
            }
            b2.a(gVar, this.f1647h);
        }
        this.D = fragment != null ? fragment.f1538s.c0(fragment) : iVar instanceof androidx.lifecycle.u ? o.i(((androidx.lifecycle.u) iVar).g()) : new o(false);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public LayoutInflater.Factory2 g0() {
        return this.f1645f;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void h(Fragment fragment) {
        if (p0(2)) {
            Log.v("FragmentManager", "attach: " + fragment);
        }
        if (fragment.A) {
            fragment.A = false;
            if (fragment.f1531l) {
                return;
            }
            this.f1642c.a(fragment);
            if (p0(2)) {
                Log.v("FragmentManager", "add from attach: " + fragment);
            }
            if (q0(fragment)) {
                this.f1660u = true;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public k h0() {
        return this.f1652m;
    }

    public s i() {
        return new androidx.fragment.app.a(this);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public Fragment i0() {
        return this.f1656q;
    }

    public Fragment j0() {
        return this.f1657r;
    }

    boolean k() {
        boolean z2 = false;
        for (Fragment fragment : this.f1642c.k()) {
            if (fragment != null) {
                z2 = q0(fragment);
            }
            if (z2) {
                return true;
            }
        }
        return false;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public androidx.lifecycle.t l0(Fragment fragment) {
        return this.D.k(fragment);
    }

    void m0() {
        Q(true);
        if (this.f1647h.c()) {
            F0();
        } else {
            this.f1646g.c();
        }
    }

    void n(androidx.fragment.app.a aVar, boolean z2, boolean z3, boolean z4) {
        if (z2) {
            aVar.y(z4);
        } else {
            aVar.x();
        }
        ArrayList arrayList = new ArrayList(1);
        ArrayList arrayList2 = new ArrayList(1);
        arrayList.add(aVar);
        arrayList2.add(Boolean.valueOf(z2));
        if (z3) {
            t.B(this, arrayList, arrayList2, 0, 1, true, this.f1651l);
        }
        if (z4) {
            y0(this.f1653n, true);
        }
        for (Fragment fragment : this.f1642c.k()) {
            if (fragment != null && fragment.H != null && fragment.M && aVar.B(fragment.f1543x)) {
                float f2 = fragment.O;
                if (f2 > 0.0f) {
                    fragment.H.setAlpha(f2);
                }
                if (z4) {
                    fragment.O = 0.0f;
                } else {
                    fragment.O = -1.0f;
                    fragment.M = false;
                }
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void n0(Fragment fragment) {
        if (p0(2)) {
            Log.v("FragmentManager", "hide: " + fragment);
        }
        if (fragment.f1545z) {
            return;
        }
        fragment.f1545z = true;
        fragment.N = true ^ fragment.N;
        V0(fragment);
    }

    public boolean o0() {
        return this.f1663x;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void q(Fragment fragment) {
        if (p0(2)) {
            Log.v("FragmentManager", "detach: " + fragment);
        }
        if (fragment.A) {
            return;
        }
        fragment.A = true;
        if (fragment.f1531l) {
            if (p0(2)) {
                Log.v("FragmentManager", "remove from detach: " + fragment);
            }
            this.f1642c.p(fragment);
            if (q0(fragment)) {
                this.f1660u = true;
            }
            V0(fragment);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void r() {
        this.f1661v = false;
        this.f1662w = false;
        J(2);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public boolean r0(Fragment fragment) {
        if (fragment == null) {
            return true;
        }
        l lVar = fragment.f1538s;
        return fragment.equals(lVar.j0()) && r0(lVar.f1656q);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void s(Configuration configuration) {
        for (Fragment fragment : this.f1642c.m()) {
            if (fragment != null) {
                fragment.G0(configuration);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public boolean s0(int i2) {
        return this.f1653n >= i2;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public boolean t(MenuItem menuItem) {
        if (this.f1653n < 1) {
            return false;
        }
        for (Fragment fragment : this.f1642c.m()) {
            if (fragment != null && fragment.H0(menuItem)) {
                return true;
            }
        }
        return false;
    }

    public boolean t0() {
        return this.f1661v || this.f1662w;
    }

    public String toString() {
        Object obj;
        StringBuilder sb = new StringBuilder(128);
        sb.append("FragmentManager{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        sb.append(" in ");
        Fragment fragment = this.f1656q;
        if (fragment != null) {
            sb.append(fragment.getClass().getSimpleName());
            sb.append("{");
            obj = this.f1656q;
        } else {
            androidx.fragment.app.i<?> iVar = this.f1654o;
            if (iVar == null) {
                sb.append("null");
                sb.append("}}");
                return sb.toString();
            }
            sb.append(iVar.getClass().getSimpleName());
            sb.append("{");
            obj = this.f1654o;
        }
        sb.append(Integer.toHexString(System.identityHashCode(obj)));
        sb.append("}");
        sb.append("}}");
        return sb.toString();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void u() {
        this.f1661v = false;
        this.f1662w = false;
        J(1);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void u0(Fragment fragment) {
        if (this.f1642c.c(fragment.f1525f)) {
            return;
        }
        q qVar = new q(this.f1652m, fragment);
        qVar.k(this.f1654o.i().getClassLoader());
        this.f1642c.n(qVar);
        if (fragment.C) {
            if (fragment.B) {
                e(fragment);
            } else {
                M0(fragment);
            }
            fragment.C = false;
        }
        qVar.q(this.f1653n);
        if (p0(2)) {
            Log.v("FragmentManager", "Added fragment to active set " + fragment);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public boolean v(Menu menu, MenuInflater menuInflater) {
        if (this.f1653n < 1) {
            return false;
        }
        ArrayList<Fragment> arrayList = null;
        boolean z2 = false;
        for (Fragment fragment : this.f1642c.m()) {
            if (fragment != null && fragment.J0(menu, menuInflater)) {
                if (arrayList == null) {
                    arrayList = new ArrayList<>();
                }
                arrayList.add(fragment);
                z2 = true;
            }
        }
        if (this.f1644e != null) {
            for (int i2 = 0; i2 < this.f1644e.size(); i2++) {
                Fragment fragment2 = this.f1644e.get(i2);
                if (arrayList == null || !arrayList.contains(fragment2)) {
                    fragment2.j0();
                }
            }
        }
        this.f1644e = arrayList;
        return z2;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void w() {
        this.f1663x = true;
        Q(true);
        N();
        J(-1);
        this.f1654o = null;
        this.f1655p = null;
        this.f1656q = null;
        if (this.f1646g != null) {
            this.f1647h.d();
            this.f1646g = null;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void x() {
        J(1);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void x0(Fragment fragment) {
        if (!this.f1642c.c(fragment.f1525f)) {
            if (p0(3)) {
                Log.d("FragmentManager", "Ignoring moving " + fragment + " to state " + this.f1653n + "since it is not added to " + this);
                return;
            }
            return;
        }
        z0(fragment);
        if (fragment.H != null) {
            Fragment j2 = this.f1642c.j(fragment);
            if (j2 != null) {
                View view = j2.H;
                ViewGroup viewGroup = fragment.G;
                int indexOfChild = viewGroup.indexOfChild(view);
                int indexOfChild2 = viewGroup.indexOfChild(fragment.H);
                if (indexOfChild2 < indexOfChild) {
                    viewGroup.removeViewAt(indexOfChild2);
                    viewGroup.addView(fragment.H, indexOfChild);
                }
            }
            if (fragment.M && fragment.G != null) {
                float f2 = fragment.O;
                if (f2 > 0.0f) {
                    fragment.H.setAlpha(f2);
                }
                fragment.O = 0.0f;
                fragment.M = false;
                e.d b2 = androidx.fragment.app.e.b(this.f1654o.i(), this.f1655p, fragment, true);
                if (b2 != null) {
                    Animation animation = b2.f1622a;
                    if (animation != null) {
                        fragment.H.startAnimation(animation);
                    } else {
                        b2.f1623b.setTarget(fragment.H);
                        b2.f1623b.start();
                    }
                }
            }
        }
        if (fragment.N) {
            o(fragment);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void y() {
        for (Fragment fragment : this.f1642c.m()) {
            if (fragment != null) {
                fragment.P0();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void y0(int i2, boolean z2) {
        androidx.fragment.app.i<?> iVar;
        if (this.f1654o == null && i2 != -1) {
            throw new IllegalStateException("No activity");
        }
        if (z2 || i2 != this.f1653n) {
            this.f1653n = i2;
            Iterator<Fragment> it = this.f1642c.m().iterator();
            while (it.hasNext()) {
                x0(it.next());
            }
            for (Fragment fragment : this.f1642c.k()) {
                if (fragment != null && !fragment.M) {
                    x0(fragment);
                }
            }
            X0();
            if (this.f1660u && (iVar = this.f1654o) != null && this.f1653n == 4) {
                iVar.o();
                this.f1660u = false;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void z(boolean z2) {
        for (Fragment fragment : this.f1642c.m()) {
            if (fragment != null) {
                fragment.Q0(z2);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void z0(Fragment fragment) {
        A0(fragment, this.f1653n);
    }
}
