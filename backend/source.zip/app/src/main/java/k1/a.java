package k1;
/* loaded from: classes.dex */
public interface a {
    boolean a();
}
