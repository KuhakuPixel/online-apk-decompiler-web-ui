package androidx.fragment.app;

import android.app.Activity;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import androidx.lifecycle.d;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes.dex */
public class q {

    /* renamed from: a  reason: collision with root package name */
    private final k f1706a;

    /* renamed from: b  reason: collision with root package name */
    private final Fragment f1707b;

    /* renamed from: c  reason: collision with root package name */
    private int f1708c = -1;

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public static /* synthetic */ class a {

        /* renamed from: a  reason: collision with root package name */
        static final /* synthetic */ int[] f1709a;

        static {
            int[] iArr = new int[d.b.values().length];
            f1709a = iArr;
            try {
                iArr[d.b.RESUMED.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                f1709a[d.b.STARTED.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                f1709a[d.b.CREATED.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public q(k kVar, Fragment fragment) {
        this.f1706a = kVar;
        this.f1707b = fragment;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public q(k kVar, Fragment fragment, p pVar) {
        this.f1706a = kVar;
        this.f1707b = fragment;
        fragment.f1523d = null;
        fragment.f1537r = 0;
        fragment.f1534o = false;
        fragment.f1531l = false;
        Fragment fragment2 = fragment.f1527h;
        fragment.f1528i = fragment2 != null ? fragment2.f1525f : null;
        fragment.f1527h = null;
        Bundle bundle = pVar.f1705n;
        fragment.f1522c = bundle == null ? new Bundle() : bundle;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public q(k kVar, ClassLoader classLoader, h hVar, p pVar) {
        this.f1706a = kVar;
        Fragment a2 = hVar.a(classLoader, pVar.f1693b);
        this.f1707b = a2;
        Bundle bundle = pVar.f1702k;
        if (bundle != null) {
            bundle.setClassLoader(classLoader);
        }
        a2.i1(pVar.f1702k);
        a2.f1525f = pVar.f1694c;
        a2.f1533n = pVar.f1695d;
        a2.f1535p = true;
        a2.f1542w = pVar.f1696e;
        a2.f1543x = pVar.f1697f;
        a2.f1544y = pVar.f1698g;
        a2.B = pVar.f1699h;
        a2.f1532m = pVar.f1700i;
        a2.A = pVar.f1701j;
        a2.f1545z = pVar.f1703l;
        a2.R = d.b.values()[pVar.f1704m];
        Bundle bundle2 = pVar.f1705n;
        a2.f1522c = bundle2 == null ? new Bundle() : bundle2;
        if (l.p0(2)) {
            Log.v("FragmentManager", "Instantiated fragment " + a2);
        }
    }

    private Bundle n() {
        Bundle bundle = new Bundle();
        this.f1707b.Y0(bundle);
        this.f1706a.j(this.f1707b, bundle, false);
        if (bundle.isEmpty()) {
            bundle = null;
        }
        if (this.f1707b.H != null) {
            p();
        }
        if (this.f1707b.f1523d != null) {
            if (bundle == null) {
                bundle = new Bundle();
            }
            bundle.putSparseParcelableArray("android:view_state", this.f1707b.f1523d);
        }
        if (!this.f1707b.J) {
            if (bundle == null) {
                bundle = new Bundle();
            }
            bundle.putBoolean("android:user_visible_hint", this.f1707b.J);
        }
        return bundle;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void a() {
        if (l.p0(3)) {
            Log.d("FragmentManager", "moveto ACTIVITY_CREATED: " + this.f1707b);
        }
        Fragment fragment = this.f1707b;
        fragment.E0(fragment.f1522c);
        k kVar = this.f1706a;
        Fragment fragment2 = this.f1707b;
        kVar.a(fragment2, fragment2.f1522c, false);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void b(i<?> iVar, l lVar, Fragment fragment) {
        Fragment fragment2 = this.f1707b;
        fragment2.f1539t = iVar;
        fragment2.f1541v = fragment;
        fragment2.f1538s = lVar;
        this.f1706a.g(fragment2, iVar.i(), false);
        this.f1707b.F0();
        Fragment fragment3 = this.f1707b;
        Fragment fragment4 = fragment3.f1541v;
        if (fragment4 == null) {
            iVar.k(fragment3);
        } else {
            fragment4.b0(fragment3);
        }
        this.f1706a.b(this.f1707b, iVar.i(), false);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public int c() {
        int i2 = this.f1708c;
        Fragment fragment = this.f1707b;
        if (fragment.f1533n) {
            i2 = fragment.f1534o ? Math.max(i2, 1) : i2 < 2 ? Math.min(i2, fragment.f1521b) : Math.min(i2, 1);
        }
        if (!this.f1707b.f1531l) {
            i2 = Math.min(i2, 1);
        }
        Fragment fragment2 = this.f1707b;
        if (fragment2.f1532m) {
            i2 = fragment2.R() ? Math.min(i2, 1) : Math.min(i2, -1);
        }
        Fragment fragment3 = this.f1707b;
        if (fragment3.I && fragment3.f1521b < 3) {
            i2 = Math.min(i2, 2);
        }
        int i3 = a.f1709a[this.f1707b.R.ordinal()];
        return i3 != 1 ? i3 != 2 ? i3 != 3 ? Math.min(i2, -1) : Math.min(i2, 1) : Math.min(i2, 3) : i2;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void d() {
        if (l.p0(3)) {
            Log.d("FragmentManager", "moveto CREATED: " + this.f1707b);
        }
        Fragment fragment = this.f1707b;
        if (fragment.Q) {
            fragment.e1(fragment.f1522c);
            this.f1707b.f1521b = 1;
            return;
        }
        this.f1706a.h(fragment, fragment.f1522c, false);
        Fragment fragment2 = this.f1707b;
        fragment2.I0(fragment2.f1522c);
        k kVar = this.f1706a;
        Fragment fragment3 = this.f1707b;
        kVar.c(fragment3, fragment3.f1522c, false);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void e(f fVar) {
        String str;
        if (this.f1707b.f1533n) {
            return;
        }
        if (l.p0(3)) {
            Log.d("FragmentManager", "moveto CREATE_VIEW: " + this.f1707b);
        }
        ViewGroup viewGroup = null;
        Fragment fragment = this.f1707b;
        ViewGroup viewGroup2 = fragment.G;
        if (viewGroup2 != null) {
            viewGroup = viewGroup2;
        } else {
            int i2 = fragment.f1543x;
            if (i2 != 0) {
                if (i2 == -1) {
                    throw new IllegalArgumentException("Cannot create fragment " + this.f1707b + " for a container view with no id");
                }
                viewGroup = (ViewGroup) fVar.e(i2);
                if (viewGroup == null) {
                    Fragment fragment2 = this.f1707b;
                    if (!fragment2.f1535p) {
                        try {
                            str = fragment2.C().getResourceName(this.f1707b.f1543x);
                        } catch (Resources.NotFoundException unused) {
                            str = "unknown";
                        }
                        throw new IllegalArgumentException("No view found for id 0x" + Integer.toHexString(this.f1707b.f1543x) + " (" + str + ") for fragment " + this.f1707b);
                    }
                }
            }
        }
        Fragment fragment3 = this.f1707b;
        fragment3.G = viewGroup;
        fragment3.K0(fragment3.O0(fragment3.f1522c), viewGroup, this.f1707b.f1522c);
        View view = this.f1707b.H;
        if (view != null) {
            boolean z2 = false;
            view.setSaveFromParentEnabled(false);
            Fragment fragment4 = this.f1707b;
            fragment4.H.setTag(l0.b.fragment_container_view_tag, fragment4);
            if (viewGroup != null) {
                viewGroup.addView(this.f1707b.H);
            }
            Fragment fragment5 = this.f1707b;
            if (fragment5.f1545z) {
                fragment5.H.setVisibility(8);
            }
            e0.q.h0(this.f1707b.H);
            Fragment fragment6 = this.f1707b;
            fragment6.C0(fragment6.H, fragment6.f1522c);
            k kVar = this.f1706a;
            Fragment fragment7 = this.f1707b;
            kVar.m(fragment7, fragment7.H, fragment7.f1522c, false);
            Fragment fragment8 = this.f1707b;
            if (fragment8.H.getVisibility() == 0 && this.f1707b.G != null) {
                z2 = true;
            }
            fragment8.M = z2;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void f(i<?> iVar, o oVar) {
        if (l.p0(3)) {
            Log.d("FragmentManager", "movefrom CREATED: " + this.f1707b);
        }
        Fragment fragment = this.f1707b;
        boolean z2 = true;
        boolean z3 = fragment.f1532m && !fragment.R();
        if (!(z3 || oVar.n(this.f1707b))) {
            this.f1707b.f1521b = 0;
            return;
        }
        if (iVar instanceof androidx.lifecycle.u) {
            z2 = oVar.l();
        } else if (iVar.i() instanceof Activity) {
            z2 = true ^ ((Activity) iVar.i()).isChangingConfigurations();
        }
        if (z3 || z2) {
            oVar.f(this.f1707b);
        }
        this.f1707b.L0();
        this.f1706a.d(this.f1707b, false);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void g(o oVar) {
        if (l.p0(3)) {
            Log.d("FragmentManager", "movefrom ATTACHED: " + this.f1707b);
        }
        this.f1707b.N0();
        boolean z2 = false;
        this.f1706a.e(this.f1707b, false);
        Fragment fragment = this.f1707b;
        fragment.f1521b = -1;
        fragment.f1539t = null;
        fragment.f1541v = null;
        fragment.f1538s = null;
        if (fragment.f1532m && !fragment.R()) {
            z2 = true;
        }
        if (z2 || oVar.n(this.f1707b)) {
            if (l.p0(3)) {
                Log.d("FragmentManager", "initState called for fragment: " + this.f1707b);
            }
            this.f1707b.O();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void h() {
        Fragment fragment = this.f1707b;
        if (fragment.f1533n && fragment.f1534o && !fragment.f1536q) {
            if (l.p0(3)) {
                Log.d("FragmentManager", "moveto CREATE_VIEW: " + this.f1707b);
            }
            Fragment fragment2 = this.f1707b;
            fragment2.K0(fragment2.O0(fragment2.f1522c), null, this.f1707b.f1522c);
            View view = this.f1707b.H;
            if (view != null) {
                view.setSaveFromParentEnabled(false);
                Fragment fragment3 = this.f1707b;
                fragment3.H.setTag(l0.b.fragment_container_view_tag, fragment3);
                Fragment fragment4 = this.f1707b;
                if (fragment4.f1545z) {
                    fragment4.H.setVisibility(8);
                }
                Fragment fragment5 = this.f1707b;
                fragment5.C0(fragment5.H, fragment5.f1522c);
                k kVar = this.f1706a;
                Fragment fragment6 = this.f1707b;
                kVar.m(fragment6, fragment6.H, fragment6.f1522c, false);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public Fragment i() {
        return this.f1707b;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void j() {
        if (l.p0(3)) {
            Log.d("FragmentManager", "movefrom RESUMED: " + this.f1707b);
        }
        this.f1707b.T0();
        this.f1706a.f(this.f1707b, false);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void k(ClassLoader classLoader) {
        Bundle bundle = this.f1707b.f1522c;
        if (bundle == null) {
            return;
        }
        bundle.setClassLoader(classLoader);
        Fragment fragment = this.f1707b;
        fragment.f1523d = fragment.f1522c.getSparseParcelableArray("android:view_state");
        Fragment fragment2 = this.f1707b;
        fragment2.f1528i = fragment2.f1522c.getString("android:target_state");
        Fragment fragment3 = this.f1707b;
        if (fragment3.f1528i != null) {
            fragment3.f1529j = fragment3.f1522c.getInt("android:target_req_state", 0);
        }
        Fragment fragment4 = this.f1707b;
        Boolean bool = fragment4.f1524e;
        if (bool != null) {
            fragment4.J = bool.booleanValue();
            this.f1707b.f1524e = null;
        } else {
            fragment4.J = fragment4.f1522c.getBoolean("android:user_visible_hint", true);
        }
        Fragment fragment5 = this.f1707b;
        if (fragment5.J) {
            return;
        }
        fragment5.I = true;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void l() {
        if (l.p0(3)) {
            Log.d("FragmentManager", "moveto RESTORE_VIEW_STATE: " + this.f1707b);
        }
        Fragment fragment = this.f1707b;
        if (fragment.H != null) {
            fragment.f1(fragment.f1522c);
        }
        this.f1707b.f1522c = null;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void m() {
        if (l.p0(3)) {
            Log.d("FragmentManager", "moveto RESUMED: " + this.f1707b);
        }
        this.f1707b.X0();
        this.f1706a.i(this.f1707b, false);
        Fragment fragment = this.f1707b;
        fragment.f1522c = null;
        fragment.f1523d = null;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public p o() {
        p pVar = new p(this.f1707b);
        Fragment fragment = this.f1707b;
        if (fragment.f1521b <= -1 || pVar.f1705n != null) {
            pVar.f1705n = fragment.f1522c;
        } else {
            Bundle n2 = n();
            pVar.f1705n = n2;
            if (this.f1707b.f1528i != null) {
                if (n2 == null) {
                    pVar.f1705n = new Bundle();
                }
                pVar.f1705n.putString("android:target_state", this.f1707b.f1528i);
                int i2 = this.f1707b.f1529j;
                if (i2 != 0) {
                    pVar.f1705n.putInt("android:target_req_state", i2);
                }
            }
        }
        return pVar;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void p() {
        if (this.f1707b.H == null) {
            return;
        }
        SparseArray<Parcelable> sparseArray = new SparseArray<>();
        this.f1707b.H.saveHierarchyState(sparseArray);
        if (sparseArray.size() > 0) {
            this.f1707b.f1523d = sparseArray;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void q(int i2) {
        this.f1708c = i2;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void r() {
        if (l.p0(3)) {
            Log.d("FragmentManager", "moveto STARTED: " + this.f1707b);
        }
        this.f1707b.Z0();
        this.f1706a.k(this.f1707b, false);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void s() {
        if (l.p0(3)) {
            Log.d("FragmentManager", "movefrom STARTED: " + this.f1707b);
        }
        this.f1707b.a1();
        this.f1706a.l(this.f1707b, false);
    }
}
