package a0;

import android.os.Build;
import android.os.Trace;
import android.util.Log;
import java.lang.reflect.Method;
/* loaded from: classes.dex */
public final class b {

    /* renamed from: a  reason: collision with root package name */
    private static long f97a;

    /* renamed from: b  reason: collision with root package name */
    private static Method f98b;

    /* renamed from: c  reason: collision with root package name */
    private static Method f99c;

    /* renamed from: d  reason: collision with root package name */
    private static Method f100d;

    /* renamed from: e  reason: collision with root package name */
    private static Method f101e;

    static {
        if (Build.VERSION.SDK_INT < 29) {
            try {
                f97a = Trace.class.getField("TRACE_TAG_APP").getLong(null);
                Class cls = Long.TYPE;
                f98b = Trace.class.getMethod("isTagEnabled", cls);
                Class cls2 = Integer.TYPE;
                f99c = Trace.class.getMethod("asyncTraceBegin", cls, String.class, cls2);
                f100d = Trace.class.getMethod("asyncTraceEnd", cls, String.class, cls2);
                f101e = Trace.class.getMethod("traceCounter", cls, String.class, cls2);
            } catch (Exception e2) {
                Log.i("TraceCompat", "Unable to initialize via reflection.", e2);
            }
        }
    }

    public static void a(String str) {
        Trace.beginSection(str);
    }

    public static void b() {
        Trace.endSection();
    }
}
