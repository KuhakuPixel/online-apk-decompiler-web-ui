package androidx.fragment.app;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
/* JADX INFO: Access modifiers changed from: package-private */
@SuppressLint({"BanParcelableUsage"})
/* loaded from: classes.dex */
public final class p implements Parcelable {
    public static final Parcelable.Creator<p> CREATOR = new a();

    /* renamed from: b  reason: collision with root package name */
    final String f1693b;

    /* renamed from: c  reason: collision with root package name */
    final String f1694c;

    /* renamed from: d  reason: collision with root package name */
    final boolean f1695d;

    /* renamed from: e  reason: collision with root package name */
    final int f1696e;

    /* renamed from: f  reason: collision with root package name */
    final int f1697f;

    /* renamed from: g  reason: collision with root package name */
    final String f1698g;

    /* renamed from: h  reason: collision with root package name */
    final boolean f1699h;

    /* renamed from: i  reason: collision with root package name */
    final boolean f1700i;

    /* renamed from: j  reason: collision with root package name */
    final boolean f1701j;

    /* renamed from: k  reason: collision with root package name */
    final Bundle f1702k;

    /* renamed from: l  reason: collision with root package name */
    final boolean f1703l;

    /* renamed from: m  reason: collision with root package name */
    final int f1704m;

    /* renamed from: n  reason: collision with root package name */
    Bundle f1705n;

    /* loaded from: classes.dex */
    static class a implements Parcelable.Creator<p> {
        a() {
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: a  reason: merged with bridge method [inline-methods] */
        public p createFromParcel(Parcel parcel) {
            return new p(parcel);
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: b  reason: merged with bridge method [inline-methods] */
        public p[] newArray(int i2) {
            return new p[i2];
        }
    }

    p(Parcel parcel) {
        this.f1693b = parcel.readString();
        this.f1694c = parcel.readString();
        this.f1695d = parcel.readInt() != 0;
        this.f1696e = parcel.readInt();
        this.f1697f = parcel.readInt();
        this.f1698g = parcel.readString();
        this.f1699h = parcel.readInt() != 0;
        this.f1700i = parcel.readInt() != 0;
        this.f1701j = parcel.readInt() != 0;
        this.f1702k = parcel.readBundle();
        this.f1703l = parcel.readInt() != 0;
        this.f1705n = parcel.readBundle();
        this.f1704m = parcel.readInt();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public p(Fragment fragment) {
        this.f1693b = fragment.getClass().getName();
        this.f1694c = fragment.f1525f;
        this.f1695d = fragment.f1533n;
        this.f1696e = fragment.f1542w;
        this.f1697f = fragment.f1543x;
        this.f1698g = fragment.f1544y;
        this.f1699h = fragment.B;
        this.f1700i = fragment.f1532m;
        this.f1701j = fragment.A;
        this.f1702k = fragment.f1526g;
        this.f1703l = fragment.f1545z;
        this.f1704m = fragment.R.ordinal();
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append("FragmentState{");
        sb.append(this.f1693b);
        sb.append(" (");
        sb.append(this.f1694c);
        sb.append(")}:");
        if (this.f1695d) {
            sb.append(" fromLayout");
        }
        if (this.f1697f != 0) {
            sb.append(" id=0x");
            sb.append(Integer.toHexString(this.f1697f));
        }
        String str = this.f1698g;
        if (str != null && !str.isEmpty()) {
            sb.append(" tag=");
            sb.append(this.f1698g);
        }
        if (this.f1699h) {
            sb.append(" retainInstance");
        }
        if (this.f1700i) {
            sb.append(" removing");
        }
        if (this.f1701j) {
            sb.append(" detached");
        }
        if (this.f1703l) {
            sb.append(" hidden");
        }
        return sb.toString();
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i2) {
        parcel.writeString(this.f1693b);
        parcel.writeString(this.f1694c);
        parcel.writeInt(this.f1695d ? 1 : 0);
        parcel.writeInt(this.f1696e);
        parcel.writeInt(this.f1697f);
        parcel.writeString(this.f1698g);
        parcel.writeInt(this.f1699h ? 1 : 0);
        parcel.writeInt(this.f1700i ? 1 : 0);
        parcel.writeInt(this.f1701j ? 1 : 0);
        parcel.writeBundle(this.f1702k);
        parcel.writeInt(this.f1703l ? 1 : 0);
        parcel.writeBundle(this.f1705n);
        parcel.writeInt(this.f1704m);
    }
}
