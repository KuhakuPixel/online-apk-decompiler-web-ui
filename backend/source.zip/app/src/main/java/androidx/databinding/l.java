package androidx.databinding;

import androidx.databinding.b;
import androidx.databinding.g;
/* loaded from: classes.dex */
public class l extends b<g.a, g, Void> {

    /* renamed from: g  reason: collision with root package name */
    private static final b.a<g.a, g, Void> f1516g = new a();

    /* loaded from: classes.dex */
    class a extends b.a<g.a, g, Void> {
        a() {
        }

        @Override // androidx.databinding.b.a
        /* renamed from: b  reason: merged with bridge method [inline-methods] */
        public void a(g.a aVar, g gVar, int i2, Void r4) {
            aVar.c(gVar, i2);
        }
    }

    public l() {
        super(f1516g);
    }
}
