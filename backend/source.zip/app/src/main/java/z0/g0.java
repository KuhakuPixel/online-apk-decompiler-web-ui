package z0;

import java.util.Iterator;
/* loaded from: classes.dex */
public final class g0 {
    public static Object a(Iterable iterable, Object obj) {
        Iterator it = iterable.iterator();
        if (it.hasNext()) {
            return it.next();
        }
        return null;
    }
}
