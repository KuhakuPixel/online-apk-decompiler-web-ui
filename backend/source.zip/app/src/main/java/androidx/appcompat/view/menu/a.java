package androidx.appcompat.view.menu;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.view.menu.j;
import androidx.appcompat.view.menu.k;
import java.util.ArrayList;
/* loaded from: classes.dex */
public abstract class a implements j {

    /* renamed from: b  reason: collision with root package name */
    protected Context f326b;

    /* renamed from: c  reason: collision with root package name */
    protected Context f327c;

    /* renamed from: d  reason: collision with root package name */
    protected e f328d;

    /* renamed from: e  reason: collision with root package name */
    protected LayoutInflater f329e;

    /* renamed from: f  reason: collision with root package name */
    protected LayoutInflater f330f;

    /* renamed from: g  reason: collision with root package name */
    private j.a f331g;

    /* renamed from: h  reason: collision with root package name */
    private int f332h;

    /* renamed from: i  reason: collision with root package name */
    private int f333i;

    /* renamed from: j  reason: collision with root package name */
    protected k f334j;

    /* renamed from: k  reason: collision with root package name */
    private int f335k;

    public a(Context context, int i2, int i3) {
        this.f326b = context;
        this.f329e = LayoutInflater.from(context);
        this.f332h = i2;
        this.f333i = i3;
    }

    protected void a(View view, int i2) {
        ViewGroup viewGroup = (ViewGroup) view.getParent();
        if (viewGroup != null) {
            viewGroup.removeView(view);
        }
        ((ViewGroup) this.f334j).addView(view, i2);
    }

    @Override // androidx.appcompat.view.menu.j
    public void b(e eVar, boolean z2) {
        j.a aVar = this.f331g;
        if (aVar != null) {
            aVar.b(eVar, z2);
        }
    }

    public abstract void c(g gVar, k.a aVar);

    @Override // androidx.appcompat.view.menu.j
    public void e(Context context, e eVar) {
        this.f327c = context;
        this.f330f = LayoutInflater.from(context);
        this.f328d = eVar;
    }

    @Override // androidx.appcompat.view.menu.j
    public boolean f(e eVar, g gVar) {
        return false;
    }

    @Override // androidx.appcompat.view.menu.j
    public boolean g(e eVar, g gVar) {
        return false;
    }

    @Override // androidx.appcompat.view.menu.j
    public void h(j.a aVar) {
        this.f331g = aVar;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r2v4, types: [androidx.appcompat.view.menu.e] */
    @Override // androidx.appcompat.view.menu.j
    public boolean i(m mVar) {
        j.a aVar = this.f331g;
        m mVar2 = mVar;
        if (aVar != null) {
            if (mVar == null) {
                mVar2 = this.f328d;
            }
            return aVar.c(mVar2);
        }
        return false;
    }

    @Override // androidx.appcompat.view.menu.j
    public void j(boolean z2) {
        ViewGroup viewGroup = (ViewGroup) this.f334j;
        if (viewGroup == null) {
            return;
        }
        e eVar = this.f328d;
        int i2 = 0;
        if (eVar != null) {
            eVar.r();
            ArrayList<g> E = this.f328d.E();
            int size = E.size();
            int i3 = 0;
            for (int i4 = 0; i4 < size; i4++) {
                g gVar = E.get(i4);
                if (q(i3, gVar)) {
                    View childAt = viewGroup.getChildAt(i3);
                    g itemData = childAt instanceof k.a ? ((k.a) childAt).getItemData() : null;
                    View n2 = n(gVar, childAt, viewGroup);
                    if (gVar != itemData) {
                        n2.setPressed(false);
                        n2.jumpDrawablesToCurrentState();
                    }
                    if (n2 != childAt) {
                        a(n2, i3);
                    }
                    i3++;
                }
            }
            i2 = i3;
        }
        while (i2 < viewGroup.getChildCount()) {
            if (!l(viewGroup, i2)) {
                i2++;
            }
        }
    }

    public k.a k(ViewGroup viewGroup) {
        return (k.a) this.f329e.inflate(this.f333i, viewGroup, false);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public boolean l(ViewGroup viewGroup, int i2) {
        viewGroup.removeViewAt(i2);
        return true;
    }

    public j.a m() {
        return this.f331g;
    }

    public View n(g gVar, View view, ViewGroup viewGroup) {
        k.a k2 = view instanceof k.a ? (k.a) view : k(viewGroup);
        c(gVar, k2);
        return (View) k2;
    }

    public k o(ViewGroup viewGroup) {
        if (this.f334j == null) {
            k kVar = (k) this.f329e.inflate(this.f332h, viewGroup, false);
            this.f334j = kVar;
            kVar.b(this.f328d);
            j(true);
        }
        return this.f334j;
    }

    public void p(int i2) {
        this.f335k = i2;
    }

    public abstract boolean q(int i2, g gVar);
}
