package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import android.util.Xml;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.e;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import org.xmlpull.v1.XmlPullParserException;
/* loaded from: classes.dex */
public class d {

    /* renamed from: d  reason: collision with root package name */
    private static final int[] f1163d = {0, 4, 8};

    /* renamed from: e  reason: collision with root package name */
    private static SparseIntArray f1164e;

    /* renamed from: a  reason: collision with root package name */
    private HashMap<String, androidx.constraintlayout.widget.a> f1165a = new HashMap<>();

    /* renamed from: b  reason: collision with root package name */
    private boolean f1166b = true;

    /* renamed from: c  reason: collision with root package name */
    private HashMap<Integer, a> f1167c = new HashMap<>();

    /* loaded from: classes.dex */
    public static class a {

        /* renamed from: a  reason: collision with root package name */
        int f1168a;

        /* renamed from: b  reason: collision with root package name */
        public final C0006d f1169b = new C0006d();

        /* renamed from: c  reason: collision with root package name */
        public final c f1170c = new c();

        /* renamed from: d  reason: collision with root package name */
        public final b f1171d = new b();

        /* renamed from: e  reason: collision with root package name */
        public final e f1172e = new e();

        /* renamed from: f  reason: collision with root package name */
        public HashMap<String, androidx.constraintlayout.widget.a> f1173f = new HashMap<>();

        /* JADX INFO: Access modifiers changed from: private */
        public void f(int i2, ConstraintLayout.b bVar) {
            this.f1168a = i2;
            b bVar2 = this.f1171d;
            bVar2.f1189h = bVar.f1079d;
            bVar2.f1191i = bVar.f1081e;
            bVar2.f1193j = bVar.f1083f;
            bVar2.f1195k = bVar.f1085g;
            bVar2.f1196l = bVar.f1087h;
            bVar2.f1197m = bVar.f1089i;
            bVar2.f1198n = bVar.f1091j;
            bVar2.f1199o = bVar.f1093k;
            bVar2.f1200p = bVar.f1095l;
            bVar2.f1201q = bVar.f1103p;
            bVar2.f1202r = bVar.f1104q;
            bVar2.f1203s = bVar.f1105r;
            bVar2.f1204t = bVar.f1106s;
            bVar2.f1205u = bVar.f1113z;
            bVar2.f1206v = bVar.A;
            bVar2.f1207w = bVar.B;
            bVar2.f1208x = bVar.f1097m;
            bVar2.f1209y = bVar.f1099n;
            bVar2.f1210z = bVar.f1101o;
            bVar2.A = bVar.Q;
            bVar2.B = bVar.R;
            bVar2.C = bVar.S;
            bVar2.f1187g = bVar.f1077c;
            bVar2.f1183e = bVar.f1073a;
            bVar2.f1185f = bVar.f1075b;
            bVar2.f1179c = ((ViewGroup.MarginLayoutParams) bVar).width;
            bVar2.f1181d = ((ViewGroup.MarginLayoutParams) bVar).height;
            bVar2.D = ((ViewGroup.MarginLayoutParams) bVar).leftMargin;
            bVar2.E = ((ViewGroup.MarginLayoutParams) bVar).rightMargin;
            bVar2.F = ((ViewGroup.MarginLayoutParams) bVar).topMargin;
            bVar2.G = ((ViewGroup.MarginLayoutParams) bVar).bottomMargin;
            bVar2.P = bVar.F;
            bVar2.Q = bVar.E;
            bVar2.S = bVar.H;
            bVar2.R = bVar.G;
            bVar2.f1190h0 = bVar.T;
            bVar2.f1192i0 = bVar.U;
            bVar2.T = bVar.I;
            bVar2.U = bVar.J;
            bVar2.V = bVar.M;
            bVar2.W = bVar.N;
            bVar2.X = bVar.K;
            bVar2.Y = bVar.L;
            bVar2.Z = bVar.O;
            bVar2.f1176a0 = bVar.P;
            bVar2.f1188g0 = bVar.V;
            bVar2.K = bVar.f1108u;
            bVar2.M = bVar.f1110w;
            bVar2.J = bVar.f1107t;
            bVar2.L = bVar.f1109v;
            bVar2.O = bVar.f1111x;
            bVar2.N = bVar.f1112y;
            bVar2.H = bVar.getMarginEnd();
            this.f1171d.I = bVar.getMarginStart();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void g(int i2, e.a aVar) {
            f(i2, aVar);
            this.f1169b.f1222d = aVar.f1239p0;
            e eVar = this.f1172e;
            eVar.f1226b = aVar.f1242s0;
            eVar.f1227c = aVar.f1243t0;
            eVar.f1228d = aVar.f1244u0;
            eVar.f1229e = aVar.f1245v0;
            eVar.f1230f = aVar.f1246w0;
            eVar.f1231g = aVar.f1247x0;
            eVar.f1232h = aVar.f1248y0;
            eVar.f1233i = aVar.f1249z0;
            eVar.f1234j = aVar.A0;
            eVar.f1235k = aVar.B0;
            eVar.f1237m = aVar.f1241r0;
            eVar.f1236l = aVar.f1240q0;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void h(androidx.constraintlayout.widget.b bVar, int i2, e.a aVar) {
            g(i2, aVar);
            if (bVar instanceof Barrier) {
                b bVar2 = this.f1171d;
                bVar2.f1182d0 = 1;
                Barrier barrier = (Barrier) bVar;
                bVar2.f1178b0 = barrier.getType();
                this.f1171d.f1184e0 = barrier.getReferencedIds();
                this.f1171d.f1180c0 = barrier.getMargin();
            }
        }

        public void d(ConstraintLayout.b bVar) {
            b bVar2 = this.f1171d;
            bVar.f1079d = bVar2.f1189h;
            bVar.f1081e = bVar2.f1191i;
            bVar.f1083f = bVar2.f1193j;
            bVar.f1085g = bVar2.f1195k;
            bVar.f1087h = bVar2.f1196l;
            bVar.f1089i = bVar2.f1197m;
            bVar.f1091j = bVar2.f1198n;
            bVar.f1093k = bVar2.f1199o;
            bVar.f1095l = bVar2.f1200p;
            bVar.f1103p = bVar2.f1201q;
            bVar.f1104q = bVar2.f1202r;
            bVar.f1105r = bVar2.f1203s;
            bVar.f1106s = bVar2.f1204t;
            ((ViewGroup.MarginLayoutParams) bVar).leftMargin = bVar2.D;
            ((ViewGroup.MarginLayoutParams) bVar).rightMargin = bVar2.E;
            ((ViewGroup.MarginLayoutParams) bVar).topMargin = bVar2.F;
            ((ViewGroup.MarginLayoutParams) bVar).bottomMargin = bVar2.G;
            bVar.f1111x = bVar2.O;
            bVar.f1112y = bVar2.N;
            bVar.f1108u = bVar2.K;
            bVar.f1110w = bVar2.M;
            bVar.f1113z = bVar2.f1205u;
            bVar.A = bVar2.f1206v;
            bVar.f1097m = bVar2.f1208x;
            bVar.f1099n = bVar2.f1209y;
            bVar.f1101o = bVar2.f1210z;
            bVar.B = bVar2.f1207w;
            bVar.Q = bVar2.A;
            bVar.R = bVar2.B;
            bVar.F = bVar2.P;
            bVar.E = bVar2.Q;
            bVar.H = bVar2.S;
            bVar.G = bVar2.R;
            bVar.T = bVar2.f1190h0;
            bVar.U = bVar2.f1192i0;
            bVar.I = bVar2.T;
            bVar.J = bVar2.U;
            bVar.M = bVar2.V;
            bVar.N = bVar2.W;
            bVar.K = bVar2.X;
            bVar.L = bVar2.Y;
            bVar.O = bVar2.Z;
            bVar.P = bVar2.f1176a0;
            bVar.S = bVar2.C;
            bVar.f1077c = bVar2.f1187g;
            bVar.f1073a = bVar2.f1183e;
            bVar.f1075b = bVar2.f1185f;
            ((ViewGroup.MarginLayoutParams) bVar).width = bVar2.f1179c;
            ((ViewGroup.MarginLayoutParams) bVar).height = bVar2.f1181d;
            String str = bVar2.f1188g0;
            if (str != null) {
                bVar.V = str;
            }
            bVar.setMarginStart(bVar2.I);
            bVar.setMarginEnd(this.f1171d.H);
            bVar.a();
        }

        /* renamed from: e  reason: merged with bridge method [inline-methods] */
        public a clone() {
            a aVar = new a();
            aVar.f1171d.a(this.f1171d);
            aVar.f1170c.a(this.f1170c);
            aVar.f1169b.a(this.f1169b);
            aVar.f1172e.a(this.f1172e);
            aVar.f1168a = this.f1168a;
            return aVar;
        }
    }

    /* loaded from: classes.dex */
    public static class b {

        /* renamed from: k0  reason: collision with root package name */
        private static SparseIntArray f1174k0;

        /* renamed from: c  reason: collision with root package name */
        public int f1179c;

        /* renamed from: d  reason: collision with root package name */
        public int f1181d;

        /* renamed from: e0  reason: collision with root package name */
        public int[] f1184e0;

        /* renamed from: f0  reason: collision with root package name */
        public String f1186f0;

        /* renamed from: g0  reason: collision with root package name */
        public String f1188g0;

        /* renamed from: a  reason: collision with root package name */
        public boolean f1175a = false;

        /* renamed from: b  reason: collision with root package name */
        public boolean f1177b = false;

        /* renamed from: e  reason: collision with root package name */
        public int f1183e = -1;

        /* renamed from: f  reason: collision with root package name */
        public int f1185f = -1;

        /* renamed from: g  reason: collision with root package name */
        public float f1187g = -1.0f;

        /* renamed from: h  reason: collision with root package name */
        public int f1189h = -1;

        /* renamed from: i  reason: collision with root package name */
        public int f1191i = -1;

        /* renamed from: j  reason: collision with root package name */
        public int f1193j = -1;

        /* renamed from: k  reason: collision with root package name */
        public int f1195k = -1;

        /* renamed from: l  reason: collision with root package name */
        public int f1196l = -1;

        /* renamed from: m  reason: collision with root package name */
        public int f1197m = -1;

        /* renamed from: n  reason: collision with root package name */
        public int f1198n = -1;

        /* renamed from: o  reason: collision with root package name */
        public int f1199o = -1;

        /* renamed from: p  reason: collision with root package name */
        public int f1200p = -1;

        /* renamed from: q  reason: collision with root package name */
        public int f1201q = -1;

        /* renamed from: r  reason: collision with root package name */
        public int f1202r = -1;

        /* renamed from: s  reason: collision with root package name */
        public int f1203s = -1;

        /* renamed from: t  reason: collision with root package name */
        public int f1204t = -1;

        /* renamed from: u  reason: collision with root package name */
        public float f1205u = 0.5f;

        /* renamed from: v  reason: collision with root package name */
        public float f1206v = 0.5f;

        /* renamed from: w  reason: collision with root package name */
        public String f1207w = null;

        /* renamed from: x  reason: collision with root package name */
        public int f1208x = -1;

        /* renamed from: y  reason: collision with root package name */
        public int f1209y = 0;

        /* renamed from: z  reason: collision with root package name */
        public float f1210z = 0.0f;
        public int A = -1;
        public int B = -1;
        public int C = -1;
        public int D = -1;
        public int E = -1;
        public int F = -1;
        public int G = -1;
        public int H = -1;
        public int I = -1;
        public int J = -1;
        public int K = -1;
        public int L = -1;
        public int M = -1;
        public int N = -1;
        public int O = -1;
        public float P = -1.0f;
        public float Q = -1.0f;
        public int R = 0;
        public int S = 0;
        public int T = 0;
        public int U = 0;
        public int V = -1;
        public int W = -1;
        public int X = -1;
        public int Y = -1;
        public float Z = 1.0f;

        /* renamed from: a0  reason: collision with root package name */
        public float f1176a0 = 1.0f;

        /* renamed from: b0  reason: collision with root package name */
        public int f1178b0 = -1;

        /* renamed from: c0  reason: collision with root package name */
        public int f1180c0 = 0;

        /* renamed from: d0  reason: collision with root package name */
        public int f1182d0 = -1;

        /* renamed from: h0  reason: collision with root package name */
        public boolean f1190h0 = false;

        /* renamed from: i0  reason: collision with root package name */
        public boolean f1192i0 = false;

        /* renamed from: j0  reason: collision with root package name */
        public boolean f1194j0 = true;

        static {
            SparseIntArray sparseIntArray = new SparseIntArray();
            f1174k0 = sparseIntArray;
            sparseIntArray.append(i.F3, 24);
            f1174k0.append(i.G3, 25);
            f1174k0.append(i.I3, 28);
            f1174k0.append(i.J3, 29);
            f1174k0.append(i.O3, 35);
            f1174k0.append(i.N3, 34);
            f1174k0.append(i.q3, 4);
            f1174k0.append(i.p3, 3);
            f1174k0.append(i.n3, 1);
            f1174k0.append(i.T3, 6);
            f1174k0.append(i.U3, 7);
            f1174k0.append(i.x3, 17);
            f1174k0.append(i.y3, 18);
            f1174k0.append(i.z3, 19);
            f1174k0.append(i.Y2, 26);
            f1174k0.append(i.K3, 31);
            f1174k0.append(i.L3, 32);
            f1174k0.append(i.w3, 10);
            f1174k0.append(i.v3, 9);
            f1174k0.append(i.X3, 13);
            f1174k0.append(i.a4, 16);
            f1174k0.append(i.Y3, 14);
            f1174k0.append(i.V3, 11);
            f1174k0.append(i.Z3, 15);
            f1174k0.append(i.W3, 12);
            f1174k0.append(i.R3, 38);
            f1174k0.append(i.D3, 37);
            f1174k0.append(i.C3, 39);
            f1174k0.append(i.Q3, 40);
            f1174k0.append(i.B3, 20);
            f1174k0.append(i.P3, 36);
            f1174k0.append(i.u3, 5);
            f1174k0.append(i.E3, 76);
            f1174k0.append(i.M3, 76);
            f1174k0.append(i.H3, 76);
            f1174k0.append(i.o3, 76);
            f1174k0.append(i.m3, 76);
            f1174k0.append(i.b3, 23);
            f1174k0.append(i.d3, 27);
            f1174k0.append(i.f3, 30);
            f1174k0.append(i.g3, 8);
            f1174k0.append(i.c3, 33);
            f1174k0.append(i.e3, 2);
            f1174k0.append(i.Z2, 22);
            f1174k0.append(i.a3, 21);
            f1174k0.append(i.r3, 61);
            f1174k0.append(i.t3, 62);
            f1174k0.append(i.s3, 63);
            f1174k0.append(i.S3, 69);
            f1174k0.append(i.A3, 70);
            f1174k0.append(i.k3, 71);
            f1174k0.append(i.i3, 72);
            f1174k0.append(i.j3, 73);
            f1174k0.append(i.l3, 74);
            f1174k0.append(i.h3, 75);
        }

        public void a(b bVar) {
            this.f1175a = bVar.f1175a;
            this.f1179c = bVar.f1179c;
            this.f1177b = bVar.f1177b;
            this.f1181d = bVar.f1181d;
            this.f1183e = bVar.f1183e;
            this.f1185f = bVar.f1185f;
            this.f1187g = bVar.f1187g;
            this.f1189h = bVar.f1189h;
            this.f1191i = bVar.f1191i;
            this.f1193j = bVar.f1193j;
            this.f1195k = bVar.f1195k;
            this.f1196l = bVar.f1196l;
            this.f1197m = bVar.f1197m;
            this.f1198n = bVar.f1198n;
            this.f1199o = bVar.f1199o;
            this.f1200p = bVar.f1200p;
            this.f1201q = bVar.f1201q;
            this.f1202r = bVar.f1202r;
            this.f1203s = bVar.f1203s;
            this.f1204t = bVar.f1204t;
            this.f1205u = bVar.f1205u;
            this.f1206v = bVar.f1206v;
            this.f1207w = bVar.f1207w;
            this.f1208x = bVar.f1208x;
            this.f1209y = bVar.f1209y;
            this.f1210z = bVar.f1210z;
            this.A = bVar.A;
            this.B = bVar.B;
            this.C = bVar.C;
            this.D = bVar.D;
            this.E = bVar.E;
            this.F = bVar.F;
            this.G = bVar.G;
            this.H = bVar.H;
            this.I = bVar.I;
            this.J = bVar.J;
            this.K = bVar.K;
            this.L = bVar.L;
            this.M = bVar.M;
            this.N = bVar.N;
            this.O = bVar.O;
            this.P = bVar.P;
            this.Q = bVar.Q;
            this.R = bVar.R;
            this.S = bVar.S;
            this.T = bVar.T;
            this.U = bVar.U;
            this.V = bVar.V;
            this.W = bVar.W;
            this.X = bVar.X;
            this.Y = bVar.Y;
            this.Z = bVar.Z;
            this.f1176a0 = bVar.f1176a0;
            this.f1178b0 = bVar.f1178b0;
            this.f1180c0 = bVar.f1180c0;
            this.f1182d0 = bVar.f1182d0;
            this.f1188g0 = bVar.f1188g0;
            int[] iArr = bVar.f1184e0;
            if (iArr != null) {
                this.f1184e0 = Arrays.copyOf(iArr, iArr.length);
            } else {
                this.f1184e0 = null;
            }
            this.f1186f0 = bVar.f1186f0;
            this.f1190h0 = bVar.f1190h0;
            this.f1192i0 = bVar.f1192i0;
            this.f1194j0 = bVar.f1194j0;
        }

        void b(Context context, AttributeSet attributeSet) {
            StringBuilder sb;
            String str;
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, i.X2);
            this.f1177b = true;
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i2 = 0; i2 < indexCount; i2++) {
                int index = obtainStyledAttributes.getIndex(i2);
                int i3 = f1174k0.get(index);
                if (i3 == 80) {
                    this.f1190h0 = obtainStyledAttributes.getBoolean(index, this.f1190h0);
                } else if (i3 != 81) {
                    switch (i3) {
                        case 1:
                            this.f1200p = d.o(obtainStyledAttributes, index, this.f1200p);
                            continue;
                        case 2:
                            this.G = obtainStyledAttributes.getDimensionPixelSize(index, this.G);
                            continue;
                        case 3:
                            this.f1199o = d.o(obtainStyledAttributes, index, this.f1199o);
                            continue;
                        case 4:
                            this.f1198n = d.o(obtainStyledAttributes, index, this.f1198n);
                            continue;
                        case 5:
                            this.f1207w = obtainStyledAttributes.getString(index);
                            continue;
                        case 6:
                            this.A = obtainStyledAttributes.getDimensionPixelOffset(index, this.A);
                            continue;
                        case 7:
                            this.B = obtainStyledAttributes.getDimensionPixelOffset(index, this.B);
                            continue;
                        case 8:
                            this.H = obtainStyledAttributes.getDimensionPixelSize(index, this.H);
                            continue;
                        case 9:
                            this.f1204t = d.o(obtainStyledAttributes, index, this.f1204t);
                            continue;
                        case 10:
                            this.f1203s = d.o(obtainStyledAttributes, index, this.f1203s);
                            continue;
                        case 11:
                            this.M = obtainStyledAttributes.getDimensionPixelSize(index, this.M);
                            continue;
                        case 12:
                            this.N = obtainStyledAttributes.getDimensionPixelSize(index, this.N);
                            continue;
                        case 13:
                            this.J = obtainStyledAttributes.getDimensionPixelSize(index, this.J);
                            continue;
                        case 14:
                            this.L = obtainStyledAttributes.getDimensionPixelSize(index, this.L);
                            continue;
                        case 15:
                            this.O = obtainStyledAttributes.getDimensionPixelSize(index, this.O);
                            continue;
                        case 16:
                            this.K = obtainStyledAttributes.getDimensionPixelSize(index, this.K);
                            continue;
                        case 17:
                            this.f1183e = obtainStyledAttributes.getDimensionPixelOffset(index, this.f1183e);
                            continue;
                        case 18:
                            this.f1185f = obtainStyledAttributes.getDimensionPixelOffset(index, this.f1185f);
                            continue;
                        case 19:
                            this.f1187g = obtainStyledAttributes.getFloat(index, this.f1187g);
                            continue;
                        case 20:
                            this.f1205u = obtainStyledAttributes.getFloat(index, this.f1205u);
                            continue;
                        case 21:
                            this.f1181d = obtainStyledAttributes.getLayoutDimension(index, this.f1181d);
                            continue;
                        case 22:
                            this.f1179c = obtainStyledAttributes.getLayoutDimension(index, this.f1179c);
                            continue;
                        case 23:
                            this.D = obtainStyledAttributes.getDimensionPixelSize(index, this.D);
                            continue;
                        case 24:
                            this.f1189h = d.o(obtainStyledAttributes, index, this.f1189h);
                            continue;
                        case 25:
                            this.f1191i = d.o(obtainStyledAttributes, index, this.f1191i);
                            continue;
                        case 26:
                            this.C = obtainStyledAttributes.getInt(index, this.C);
                            continue;
                        case 27:
                            this.E = obtainStyledAttributes.getDimensionPixelSize(index, this.E);
                            continue;
                        case 28:
                            this.f1193j = d.o(obtainStyledAttributes, index, this.f1193j);
                            continue;
                        case 29:
                            this.f1195k = d.o(obtainStyledAttributes, index, this.f1195k);
                            continue;
                        case 30:
                            this.I = obtainStyledAttributes.getDimensionPixelSize(index, this.I);
                            continue;
                        case 31:
                            this.f1201q = d.o(obtainStyledAttributes, index, this.f1201q);
                            continue;
                        case 32:
                            this.f1202r = d.o(obtainStyledAttributes, index, this.f1202r);
                            continue;
                        case 33:
                            this.F = obtainStyledAttributes.getDimensionPixelSize(index, this.F);
                            continue;
                        case 34:
                            this.f1197m = d.o(obtainStyledAttributes, index, this.f1197m);
                            continue;
                        case 35:
                            this.f1196l = d.o(obtainStyledAttributes, index, this.f1196l);
                            continue;
                        case 36:
                            this.f1206v = obtainStyledAttributes.getFloat(index, this.f1206v);
                            continue;
                        case 37:
                            this.Q = obtainStyledAttributes.getFloat(index, this.Q);
                            continue;
                        case 38:
                            this.P = obtainStyledAttributes.getFloat(index, this.P);
                            continue;
                        case 39:
                            this.R = obtainStyledAttributes.getInt(index, this.R);
                            continue;
                        case 40:
                            this.S = obtainStyledAttributes.getInt(index, this.S);
                            continue;
                        default:
                            switch (i3) {
                                case 54:
                                    this.T = obtainStyledAttributes.getInt(index, this.T);
                                    continue;
                                case 55:
                                    this.U = obtainStyledAttributes.getInt(index, this.U);
                                    continue;
                                case 56:
                                    this.V = obtainStyledAttributes.getDimensionPixelSize(index, this.V);
                                    continue;
                                case 57:
                                    this.W = obtainStyledAttributes.getDimensionPixelSize(index, this.W);
                                    continue;
                                case 58:
                                    this.X = obtainStyledAttributes.getDimensionPixelSize(index, this.X);
                                    continue;
                                case 59:
                                    this.Y = obtainStyledAttributes.getDimensionPixelSize(index, this.Y);
                                    continue;
                                default:
                                    switch (i3) {
                                        case 61:
                                            this.f1208x = d.o(obtainStyledAttributes, index, this.f1208x);
                                            continue;
                                        case 62:
                                            this.f1209y = obtainStyledAttributes.getDimensionPixelSize(index, this.f1209y);
                                            continue;
                                        case 63:
                                            this.f1210z = obtainStyledAttributes.getFloat(index, this.f1210z);
                                            continue;
                                        default:
                                            switch (i3) {
                                                case 69:
                                                    this.Z = obtainStyledAttributes.getFloat(index, 1.0f);
                                                    break;
                                                case 70:
                                                    this.f1176a0 = obtainStyledAttributes.getFloat(index, 1.0f);
                                                    break;
                                                case 71:
                                                    Log.e("ConstraintSet", "CURRENTLY UNSUPPORTED");
                                                    break;
                                                case 72:
                                                    this.f1178b0 = obtainStyledAttributes.getInt(index, this.f1178b0);
                                                    break;
                                                case 73:
                                                    this.f1180c0 = obtainStyledAttributes.getDimensionPixelSize(index, this.f1180c0);
                                                    break;
                                                case 74:
                                                    this.f1186f0 = obtainStyledAttributes.getString(index);
                                                    break;
                                                case 75:
                                                    this.f1194j0 = obtainStyledAttributes.getBoolean(index, this.f1194j0);
                                                    break;
                                                case 76:
                                                    sb = new StringBuilder();
                                                    str = "unused attribute 0x";
                                                    sb.append(str);
                                                    sb.append(Integer.toHexString(index));
                                                    sb.append("   ");
                                                    sb.append(f1174k0.get(index));
                                                    Log.w("ConstraintSet", sb.toString());
                                                    continue;
                                                    continue;
                                                    continue;
                                                case 77:
                                                    this.f1188g0 = obtainStyledAttributes.getString(index);
                                                    break;
                                                default:
                                                    sb = new StringBuilder();
                                                    str = "Unknown attribute 0x";
                                                    sb.append(str);
                                                    sb.append(Integer.toHexString(index));
                                                    sb.append("   ");
                                                    sb.append(f1174k0.get(index));
                                                    Log.w("ConstraintSet", sb.toString());
                                                    continue;
                                                    continue;
                                                    continue;
                                            }
                                    }
                            }
                    }
                } else {
                    this.f1192i0 = obtainStyledAttributes.getBoolean(index, this.f1192i0);
                }
            }
            obtainStyledAttributes.recycle();
        }
    }

    /* loaded from: classes.dex */
    public static class c {

        /* renamed from: h  reason: collision with root package name */
        private static SparseIntArray f1211h;

        /* renamed from: a  reason: collision with root package name */
        public boolean f1212a = false;

        /* renamed from: b  reason: collision with root package name */
        public int f1213b = -1;

        /* renamed from: c  reason: collision with root package name */
        public String f1214c = null;

        /* renamed from: d  reason: collision with root package name */
        public int f1215d = -1;

        /* renamed from: e  reason: collision with root package name */
        public int f1216e = 0;

        /* renamed from: f  reason: collision with root package name */
        public float f1217f = Float.NaN;

        /* renamed from: g  reason: collision with root package name */
        public float f1218g = Float.NaN;

        static {
            SparseIntArray sparseIntArray = new SparseIntArray();
            f1211h = sparseIntArray;
            sparseIntArray.append(i.l4, 1);
            f1211h.append(i.n4, 2);
            f1211h.append(i.o4, 3);
            f1211h.append(i.k4, 4);
            f1211h.append(i.j4, 5);
            f1211h.append(i.m4, 6);
        }

        public void a(c cVar) {
            this.f1212a = cVar.f1212a;
            this.f1213b = cVar.f1213b;
            this.f1214c = cVar.f1214c;
            this.f1215d = cVar.f1215d;
            this.f1216e = cVar.f1216e;
            this.f1218g = cVar.f1218g;
            this.f1217f = cVar.f1217f;
        }

        void b(Context context, AttributeSet attributeSet) {
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, i.i4);
            this.f1212a = true;
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i2 = 0; i2 < indexCount; i2++) {
                int index = obtainStyledAttributes.getIndex(i2);
                switch (f1211h.get(index)) {
                    case 1:
                        this.f1218g = obtainStyledAttributes.getFloat(index, this.f1218g);
                        break;
                    case 2:
                        this.f1215d = obtainStyledAttributes.getInt(index, this.f1215d);
                        break;
                    case 3:
                        this.f1214c = obtainStyledAttributes.peekValue(index).type == 3 ? obtainStyledAttributes.getString(index) : m.a.f4669c[obtainStyledAttributes.getInteger(index, 0)];
                        break;
                    case 4:
                        this.f1216e = obtainStyledAttributes.getInt(index, 0);
                        break;
                    case 5:
                        this.f1213b = d.o(obtainStyledAttributes, index, this.f1213b);
                        break;
                    case 6:
                        this.f1217f = obtainStyledAttributes.getFloat(index, this.f1217f);
                        break;
                }
            }
            obtainStyledAttributes.recycle();
        }
    }

    /* renamed from: androidx.constraintlayout.widget.d$d  reason: collision with other inner class name */
    /* loaded from: classes.dex */
    public static class C0006d {

        /* renamed from: a  reason: collision with root package name */
        public boolean f1219a = false;

        /* renamed from: b  reason: collision with root package name */
        public int f1220b = 0;

        /* renamed from: c  reason: collision with root package name */
        public int f1221c = 0;

        /* renamed from: d  reason: collision with root package name */
        public float f1222d = 1.0f;

        /* renamed from: e  reason: collision with root package name */
        public float f1223e = Float.NaN;

        public void a(C0006d c0006d) {
            this.f1219a = c0006d.f1219a;
            this.f1220b = c0006d.f1220b;
            this.f1222d = c0006d.f1222d;
            this.f1223e = c0006d.f1223e;
            this.f1221c = c0006d.f1221c;
        }

        void b(Context context, AttributeSet attributeSet) {
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, i.x4);
            this.f1219a = true;
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i2 = 0; i2 < indexCount; i2++) {
                int index = obtainStyledAttributes.getIndex(i2);
                if (index == i.z4) {
                    this.f1222d = obtainStyledAttributes.getFloat(index, this.f1222d);
                } else if (index == i.y4) {
                    this.f1220b = obtainStyledAttributes.getInt(index, this.f1220b);
                    this.f1220b = d.f1163d[this.f1220b];
                } else if (index == i.B4) {
                    this.f1221c = obtainStyledAttributes.getInt(index, this.f1221c);
                } else if (index == i.A4) {
                    this.f1223e = obtainStyledAttributes.getFloat(index, this.f1223e);
                }
            }
            obtainStyledAttributes.recycle();
        }
    }

    /* loaded from: classes.dex */
    public static class e {

        /* renamed from: n  reason: collision with root package name */
        private static SparseIntArray f1224n;

        /* renamed from: a  reason: collision with root package name */
        public boolean f1225a = false;

        /* renamed from: b  reason: collision with root package name */
        public float f1226b = 0.0f;

        /* renamed from: c  reason: collision with root package name */
        public float f1227c = 0.0f;

        /* renamed from: d  reason: collision with root package name */
        public float f1228d = 0.0f;

        /* renamed from: e  reason: collision with root package name */
        public float f1229e = 1.0f;

        /* renamed from: f  reason: collision with root package name */
        public float f1230f = 1.0f;

        /* renamed from: g  reason: collision with root package name */
        public float f1231g = Float.NaN;

        /* renamed from: h  reason: collision with root package name */
        public float f1232h = Float.NaN;

        /* renamed from: i  reason: collision with root package name */
        public float f1233i = 0.0f;

        /* renamed from: j  reason: collision with root package name */
        public float f1234j = 0.0f;

        /* renamed from: k  reason: collision with root package name */
        public float f1235k = 0.0f;

        /* renamed from: l  reason: collision with root package name */
        public boolean f1236l = false;

        /* renamed from: m  reason: collision with root package name */
        public float f1237m = 0.0f;

        static {
            SparseIntArray sparseIntArray = new SparseIntArray();
            f1224n = sparseIntArray;
            sparseIntArray.append(i.V4, 1);
            f1224n.append(i.W4, 2);
            f1224n.append(i.X4, 3);
            f1224n.append(i.T4, 4);
            f1224n.append(i.U4, 5);
            f1224n.append(i.P4, 6);
            f1224n.append(i.Q4, 7);
            f1224n.append(i.R4, 8);
            f1224n.append(i.S4, 9);
            f1224n.append(i.Y4, 10);
            f1224n.append(i.Z4, 11);
        }

        public void a(e eVar) {
            this.f1225a = eVar.f1225a;
            this.f1226b = eVar.f1226b;
            this.f1227c = eVar.f1227c;
            this.f1228d = eVar.f1228d;
            this.f1229e = eVar.f1229e;
            this.f1230f = eVar.f1230f;
            this.f1231g = eVar.f1231g;
            this.f1232h = eVar.f1232h;
            this.f1233i = eVar.f1233i;
            this.f1234j = eVar.f1234j;
            this.f1235k = eVar.f1235k;
            this.f1236l = eVar.f1236l;
            this.f1237m = eVar.f1237m;
        }

        void b(Context context, AttributeSet attributeSet) {
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, i.O4);
            this.f1225a = true;
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i2 = 0; i2 < indexCount; i2++) {
                int index = obtainStyledAttributes.getIndex(i2);
                switch (f1224n.get(index)) {
                    case 1:
                        this.f1226b = obtainStyledAttributes.getFloat(index, this.f1226b);
                        break;
                    case 2:
                        this.f1227c = obtainStyledAttributes.getFloat(index, this.f1227c);
                        break;
                    case 3:
                        this.f1228d = obtainStyledAttributes.getFloat(index, this.f1228d);
                        break;
                    case 4:
                        this.f1229e = obtainStyledAttributes.getFloat(index, this.f1229e);
                        break;
                    case 5:
                        this.f1230f = obtainStyledAttributes.getFloat(index, this.f1230f);
                        break;
                    case 6:
                        this.f1231g = obtainStyledAttributes.getDimension(index, this.f1231g);
                        break;
                    case 7:
                        this.f1232h = obtainStyledAttributes.getDimension(index, this.f1232h);
                        break;
                    case 8:
                        this.f1233i = obtainStyledAttributes.getDimension(index, this.f1233i);
                        break;
                    case 9:
                        this.f1234j = obtainStyledAttributes.getDimension(index, this.f1234j);
                        break;
                    case 10:
                        this.f1235k = obtainStyledAttributes.getDimension(index, this.f1235k);
                        break;
                    case 11:
                        this.f1236l = true;
                        this.f1237m = obtainStyledAttributes.getDimension(index, this.f1237m);
                        break;
                }
            }
            obtainStyledAttributes.recycle();
        }
    }

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        f1164e = sparseIntArray;
        sparseIntArray.append(i.f1314u0, 25);
        f1164e.append(i.f1317v0, 26);
        f1164e.append(i.f1323x0, 29);
        f1164e.append(i.f1326y0, 30);
        f1164e.append(i.E0, 36);
        f1164e.append(i.D0, 35);
        f1164e.append(i.f1260c0, 4);
        f1164e.append(i.f1257b0, 3);
        f1164e.append(i.Z, 1);
        f1164e.append(i.M0, 6);
        f1164e.append(i.N0, 7);
        f1164e.append(i.f1281j0, 17);
        f1164e.append(i.f1284k0, 18);
        f1164e.append(i.f1287l0, 19);
        f1164e.append(i.f1307s, 27);
        f1164e.append(i.f1329z0, 32);
        f1164e.append(i.A0, 33);
        f1164e.append(i.f1278i0, 10);
        f1164e.append(i.f1275h0, 9);
        f1164e.append(i.Q0, 13);
        f1164e.append(i.T0, 16);
        f1164e.append(i.R0, 14);
        f1164e.append(i.O0, 11);
        f1164e.append(i.S0, 15);
        f1164e.append(i.P0, 12);
        f1164e.append(i.H0, 40);
        f1164e.append(i.f1308s0, 39);
        f1164e.append(i.f1305r0, 41);
        f1164e.append(i.G0, 42);
        f1164e.append(i.f1302q0, 20);
        f1164e.append(i.F0, 37);
        f1164e.append(i.f1272g0, 5);
        f1164e.append(i.f1311t0, 82);
        f1164e.append(i.C0, 82);
        f1164e.append(i.f1320w0, 82);
        f1164e.append(i.f1254a0, 82);
        f1164e.append(i.Y, 82);
        f1164e.append(i.f1322x, 24);
        f1164e.append(i.f1328z, 28);
        f1164e.append(i.L, 31);
        f1164e.append(i.M, 8);
        f1164e.append(i.f1325y, 34);
        f1164e.append(i.A, 2);
        f1164e.append(i.f1316v, 23);
        f1164e.append(i.f1319w, 21);
        f1164e.append(i.f1313u, 22);
        f1164e.append(i.B, 43);
        f1164e.append(i.O, 44);
        f1164e.append(i.J, 45);
        f1164e.append(i.K, 46);
        f1164e.append(i.I, 60);
        f1164e.append(i.G, 47);
        f1164e.append(i.H, 48);
        f1164e.append(i.C, 49);
        f1164e.append(i.D, 50);
        f1164e.append(i.E, 51);
        f1164e.append(i.F, 52);
        f1164e.append(i.N, 53);
        f1164e.append(i.I0, 54);
        f1164e.append(i.f1290m0, 55);
        f1164e.append(i.J0, 56);
        f1164e.append(i.f1293n0, 57);
        f1164e.append(i.K0, 58);
        f1164e.append(i.f1296o0, 59);
        f1164e.append(i.f1263d0, 61);
        f1164e.append(i.f1269f0, 62);
        f1164e.append(i.f1266e0, 63);
        f1164e.append(i.P, 64);
        f1164e.append(i.X0, 65);
        f1164e.append(i.V, 66);
        f1164e.append(i.Y0, 67);
        f1164e.append(i.V0, 79);
        f1164e.append(i.f1310t, 38);
        f1164e.append(i.U0, 68);
        f1164e.append(i.L0, 69);
        f1164e.append(i.f1299p0, 70);
        f1164e.append(i.T, 71);
        f1164e.append(i.R, 72);
        f1164e.append(i.S, 73);
        f1164e.append(i.U, 74);
        f1164e.append(i.Q, 75);
        f1164e.append(i.W0, 76);
        f1164e.append(i.B0, 77);
        f1164e.append(i.Z0, 78);
        f1164e.append(i.X, 80);
        f1164e.append(i.W, 81);
    }

    private int[] j(View view, String str) {
        int i2;
        Object g2;
        String[] split = str.split(",");
        Context context = view.getContext();
        int[] iArr = new int[split.length];
        int i3 = 0;
        int i4 = 0;
        while (i3 < split.length) {
            String trim = split[i3].trim();
            try {
                i2 = h.class.getField(trim).getInt(null);
            } catch (Exception unused) {
                i2 = 0;
            }
            if (i2 == 0) {
                i2 = context.getResources().getIdentifier(trim, "id", context.getPackageName());
            }
            if (i2 == 0 && view.isInEditMode() && (view.getParent() instanceof ConstraintLayout) && (g2 = ((ConstraintLayout) view.getParent()).g(0, trim)) != null && (g2 instanceof Integer)) {
                i2 = ((Integer) g2).intValue();
            }
            iArr[i4] = i2;
            i3++;
            i4++;
        }
        return i4 != split.length ? Arrays.copyOf(iArr, i4) : iArr;
    }

    private a k(Context context, AttributeSet attributeSet) {
        a aVar = new a();
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, i.f1304r);
        p(context, aVar, obtainStyledAttributes);
        obtainStyledAttributes.recycle();
        return aVar;
    }

    private a l(int i2) {
        if (!this.f1167c.containsKey(Integer.valueOf(i2))) {
            this.f1167c.put(Integer.valueOf(i2), new a());
        }
        return this.f1167c.get(Integer.valueOf(i2));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static int o(TypedArray typedArray, int i2, int i3) {
        int resourceId = typedArray.getResourceId(i2, i3);
        return resourceId == -1 ? typedArray.getInt(i2, -1) : resourceId;
    }

    private void p(Context context, a aVar, TypedArray typedArray) {
        c cVar;
        String str;
        StringBuilder sb;
        String str2;
        int indexCount = typedArray.getIndexCount();
        for (int i2 = 0; i2 < indexCount; i2++) {
            int index = typedArray.getIndex(i2);
            if (index != i.f1310t && i.L != index && i.M != index) {
                aVar.f1170c.f1212a = true;
                aVar.f1171d.f1177b = true;
                aVar.f1169b.f1219a = true;
                aVar.f1172e.f1225a = true;
            }
            switch (f1164e.get(index)) {
                case 1:
                    b bVar = aVar.f1171d;
                    bVar.f1200p = o(typedArray, index, bVar.f1200p);
                    continue;
                case 2:
                    b bVar2 = aVar.f1171d;
                    bVar2.G = typedArray.getDimensionPixelSize(index, bVar2.G);
                    continue;
                case 3:
                    b bVar3 = aVar.f1171d;
                    bVar3.f1199o = o(typedArray, index, bVar3.f1199o);
                    continue;
                case 4:
                    b bVar4 = aVar.f1171d;
                    bVar4.f1198n = o(typedArray, index, bVar4.f1198n);
                    continue;
                case 5:
                    aVar.f1171d.f1207w = typedArray.getString(index);
                    continue;
                case 6:
                    b bVar5 = aVar.f1171d;
                    bVar5.A = typedArray.getDimensionPixelOffset(index, bVar5.A);
                    continue;
                case 7:
                    b bVar6 = aVar.f1171d;
                    bVar6.B = typedArray.getDimensionPixelOffset(index, bVar6.B);
                    continue;
                case 8:
                    b bVar7 = aVar.f1171d;
                    bVar7.H = typedArray.getDimensionPixelSize(index, bVar7.H);
                    continue;
                case 9:
                    b bVar8 = aVar.f1171d;
                    bVar8.f1204t = o(typedArray, index, bVar8.f1204t);
                    continue;
                case 10:
                    b bVar9 = aVar.f1171d;
                    bVar9.f1203s = o(typedArray, index, bVar9.f1203s);
                    continue;
                case 11:
                    b bVar10 = aVar.f1171d;
                    bVar10.M = typedArray.getDimensionPixelSize(index, bVar10.M);
                    continue;
                case 12:
                    b bVar11 = aVar.f1171d;
                    bVar11.N = typedArray.getDimensionPixelSize(index, bVar11.N);
                    continue;
                case 13:
                    b bVar12 = aVar.f1171d;
                    bVar12.J = typedArray.getDimensionPixelSize(index, bVar12.J);
                    continue;
                case 14:
                    b bVar13 = aVar.f1171d;
                    bVar13.L = typedArray.getDimensionPixelSize(index, bVar13.L);
                    continue;
                case 15:
                    b bVar14 = aVar.f1171d;
                    bVar14.O = typedArray.getDimensionPixelSize(index, bVar14.O);
                    continue;
                case 16:
                    b bVar15 = aVar.f1171d;
                    bVar15.K = typedArray.getDimensionPixelSize(index, bVar15.K);
                    continue;
                case 17:
                    b bVar16 = aVar.f1171d;
                    bVar16.f1183e = typedArray.getDimensionPixelOffset(index, bVar16.f1183e);
                    continue;
                case 18:
                    b bVar17 = aVar.f1171d;
                    bVar17.f1185f = typedArray.getDimensionPixelOffset(index, bVar17.f1185f);
                    continue;
                case 19:
                    b bVar18 = aVar.f1171d;
                    bVar18.f1187g = typedArray.getFloat(index, bVar18.f1187g);
                    continue;
                case 20:
                    b bVar19 = aVar.f1171d;
                    bVar19.f1205u = typedArray.getFloat(index, bVar19.f1205u);
                    continue;
                case 21:
                    b bVar20 = aVar.f1171d;
                    bVar20.f1181d = typedArray.getLayoutDimension(index, bVar20.f1181d);
                    continue;
                case 22:
                    C0006d c0006d = aVar.f1169b;
                    c0006d.f1220b = typedArray.getInt(index, c0006d.f1220b);
                    C0006d c0006d2 = aVar.f1169b;
                    c0006d2.f1220b = f1163d[c0006d2.f1220b];
                    continue;
                case 23:
                    b bVar21 = aVar.f1171d;
                    bVar21.f1179c = typedArray.getLayoutDimension(index, bVar21.f1179c);
                    continue;
                case 24:
                    b bVar22 = aVar.f1171d;
                    bVar22.D = typedArray.getDimensionPixelSize(index, bVar22.D);
                    continue;
                case 25:
                    b bVar23 = aVar.f1171d;
                    bVar23.f1189h = o(typedArray, index, bVar23.f1189h);
                    continue;
                case 26:
                    b bVar24 = aVar.f1171d;
                    bVar24.f1191i = o(typedArray, index, bVar24.f1191i);
                    continue;
                case 27:
                    b bVar25 = aVar.f1171d;
                    bVar25.C = typedArray.getInt(index, bVar25.C);
                    continue;
                case 28:
                    b bVar26 = aVar.f1171d;
                    bVar26.E = typedArray.getDimensionPixelSize(index, bVar26.E);
                    continue;
                case 29:
                    b bVar27 = aVar.f1171d;
                    bVar27.f1193j = o(typedArray, index, bVar27.f1193j);
                    continue;
                case 30:
                    b bVar28 = aVar.f1171d;
                    bVar28.f1195k = o(typedArray, index, bVar28.f1195k);
                    continue;
                case 31:
                    b bVar29 = aVar.f1171d;
                    bVar29.I = typedArray.getDimensionPixelSize(index, bVar29.I);
                    continue;
                case 32:
                    b bVar30 = aVar.f1171d;
                    bVar30.f1201q = o(typedArray, index, bVar30.f1201q);
                    continue;
                case 33:
                    b bVar31 = aVar.f1171d;
                    bVar31.f1202r = o(typedArray, index, bVar31.f1202r);
                    continue;
                case 34:
                    b bVar32 = aVar.f1171d;
                    bVar32.F = typedArray.getDimensionPixelSize(index, bVar32.F);
                    continue;
                case 35:
                    b bVar33 = aVar.f1171d;
                    bVar33.f1197m = o(typedArray, index, bVar33.f1197m);
                    continue;
                case 36:
                    b bVar34 = aVar.f1171d;
                    bVar34.f1196l = o(typedArray, index, bVar34.f1196l);
                    continue;
                case 37:
                    b bVar35 = aVar.f1171d;
                    bVar35.f1206v = typedArray.getFloat(index, bVar35.f1206v);
                    continue;
                case 38:
                    aVar.f1168a = typedArray.getResourceId(index, aVar.f1168a);
                    continue;
                case 39:
                    b bVar36 = aVar.f1171d;
                    bVar36.Q = typedArray.getFloat(index, bVar36.Q);
                    continue;
                case 40:
                    b bVar37 = aVar.f1171d;
                    bVar37.P = typedArray.getFloat(index, bVar37.P);
                    continue;
                case 41:
                    b bVar38 = aVar.f1171d;
                    bVar38.R = typedArray.getInt(index, bVar38.R);
                    continue;
                case 42:
                    b bVar39 = aVar.f1171d;
                    bVar39.S = typedArray.getInt(index, bVar39.S);
                    continue;
                case 43:
                    C0006d c0006d3 = aVar.f1169b;
                    c0006d3.f1222d = typedArray.getFloat(index, c0006d3.f1222d);
                    continue;
                case 44:
                    e eVar = aVar.f1172e;
                    eVar.f1236l = true;
                    eVar.f1237m = typedArray.getDimension(index, eVar.f1237m);
                    continue;
                case 45:
                    e eVar2 = aVar.f1172e;
                    eVar2.f1227c = typedArray.getFloat(index, eVar2.f1227c);
                    continue;
                case 46:
                    e eVar3 = aVar.f1172e;
                    eVar3.f1228d = typedArray.getFloat(index, eVar3.f1228d);
                    continue;
                case 47:
                    e eVar4 = aVar.f1172e;
                    eVar4.f1229e = typedArray.getFloat(index, eVar4.f1229e);
                    continue;
                case 48:
                    e eVar5 = aVar.f1172e;
                    eVar5.f1230f = typedArray.getFloat(index, eVar5.f1230f);
                    continue;
                case 49:
                    e eVar6 = aVar.f1172e;
                    eVar6.f1231g = typedArray.getDimension(index, eVar6.f1231g);
                    continue;
                case 50:
                    e eVar7 = aVar.f1172e;
                    eVar7.f1232h = typedArray.getDimension(index, eVar7.f1232h);
                    continue;
                case 51:
                    e eVar8 = aVar.f1172e;
                    eVar8.f1233i = typedArray.getDimension(index, eVar8.f1233i);
                    continue;
                case 52:
                    e eVar9 = aVar.f1172e;
                    eVar9.f1234j = typedArray.getDimension(index, eVar9.f1234j);
                    continue;
                case 53:
                    e eVar10 = aVar.f1172e;
                    eVar10.f1235k = typedArray.getDimension(index, eVar10.f1235k);
                    continue;
                case 54:
                    b bVar40 = aVar.f1171d;
                    bVar40.T = typedArray.getInt(index, bVar40.T);
                    continue;
                case 55:
                    b bVar41 = aVar.f1171d;
                    bVar41.U = typedArray.getInt(index, bVar41.U);
                    continue;
                case 56:
                    b bVar42 = aVar.f1171d;
                    bVar42.V = typedArray.getDimensionPixelSize(index, bVar42.V);
                    continue;
                case 57:
                    b bVar43 = aVar.f1171d;
                    bVar43.W = typedArray.getDimensionPixelSize(index, bVar43.W);
                    continue;
                case 58:
                    b bVar44 = aVar.f1171d;
                    bVar44.X = typedArray.getDimensionPixelSize(index, bVar44.X);
                    continue;
                case 59:
                    b bVar45 = aVar.f1171d;
                    bVar45.Y = typedArray.getDimensionPixelSize(index, bVar45.Y);
                    continue;
                case 60:
                    e eVar11 = aVar.f1172e;
                    eVar11.f1226b = typedArray.getFloat(index, eVar11.f1226b);
                    continue;
                case 61:
                    b bVar46 = aVar.f1171d;
                    bVar46.f1208x = o(typedArray, index, bVar46.f1208x);
                    continue;
                case 62:
                    b bVar47 = aVar.f1171d;
                    bVar47.f1209y = typedArray.getDimensionPixelSize(index, bVar47.f1209y);
                    continue;
                case 63:
                    b bVar48 = aVar.f1171d;
                    bVar48.f1210z = typedArray.getFloat(index, bVar48.f1210z);
                    continue;
                case 64:
                    c cVar2 = aVar.f1170c;
                    cVar2.f1213b = o(typedArray, index, cVar2.f1213b);
                    continue;
                case 65:
                    if (typedArray.peekValue(index).type == 3) {
                        cVar = aVar.f1170c;
                        str = typedArray.getString(index);
                    } else {
                        cVar = aVar.f1170c;
                        str = m.a.f4669c[typedArray.getInteger(index, 0)];
                    }
                    cVar.f1214c = str;
                    continue;
                case 66:
                    aVar.f1170c.f1216e = typedArray.getInt(index, 0);
                    continue;
                case 67:
                    c cVar3 = aVar.f1170c;
                    cVar3.f1218g = typedArray.getFloat(index, cVar3.f1218g);
                    continue;
                case 68:
                    C0006d c0006d4 = aVar.f1169b;
                    c0006d4.f1223e = typedArray.getFloat(index, c0006d4.f1223e);
                    continue;
                case 69:
                    aVar.f1171d.Z = typedArray.getFloat(index, 1.0f);
                    continue;
                case 70:
                    aVar.f1171d.f1176a0 = typedArray.getFloat(index, 1.0f);
                    continue;
                case 71:
                    Log.e("ConstraintSet", "CURRENTLY UNSUPPORTED");
                    continue;
                case 72:
                    b bVar49 = aVar.f1171d;
                    bVar49.f1178b0 = typedArray.getInt(index, bVar49.f1178b0);
                    continue;
                case 73:
                    b bVar50 = aVar.f1171d;
                    bVar50.f1180c0 = typedArray.getDimensionPixelSize(index, bVar50.f1180c0);
                    continue;
                case 74:
                    aVar.f1171d.f1186f0 = typedArray.getString(index);
                    continue;
                case 75:
                    b bVar51 = aVar.f1171d;
                    bVar51.f1194j0 = typedArray.getBoolean(index, bVar51.f1194j0);
                    continue;
                case 76:
                    c cVar4 = aVar.f1170c;
                    cVar4.f1215d = typedArray.getInt(index, cVar4.f1215d);
                    continue;
                case 77:
                    aVar.f1171d.f1188g0 = typedArray.getString(index);
                    continue;
                case 78:
                    C0006d c0006d5 = aVar.f1169b;
                    c0006d5.f1221c = typedArray.getInt(index, c0006d5.f1221c);
                    continue;
                case 79:
                    c cVar5 = aVar.f1170c;
                    cVar5.f1217f = typedArray.getFloat(index, cVar5.f1217f);
                    continue;
                case 80:
                    b bVar52 = aVar.f1171d;
                    bVar52.f1190h0 = typedArray.getBoolean(index, bVar52.f1190h0);
                    continue;
                case 81:
                    b bVar53 = aVar.f1171d;
                    bVar53.f1192i0 = typedArray.getBoolean(index, bVar53.f1192i0);
                    continue;
                case 82:
                    sb = new StringBuilder();
                    str2 = "unused attribute 0x";
                    break;
                default:
                    sb = new StringBuilder();
                    str2 = "Unknown attribute 0x";
                    break;
            }
            sb.append(str2);
            sb.append(Integer.toHexString(index));
            sb.append("   ");
            sb.append(f1164e.get(index));
            Log.w("ConstraintSet", sb.toString());
        }
    }

    public void c(ConstraintLayout constraintLayout) {
        d(constraintLayout, true);
        constraintLayout.setConstraintSet(null);
        constraintLayout.requestLayout();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void d(ConstraintLayout constraintLayout, boolean z2) {
        int childCount = constraintLayout.getChildCount();
        HashSet hashSet = new HashSet(this.f1167c.keySet());
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = constraintLayout.getChildAt(i2);
            int id = childAt.getId();
            if (!this.f1167c.containsKey(Integer.valueOf(id))) {
                Log.w("ConstraintSet", "id unknown " + n.a.a(childAt));
            } else if (this.f1166b && id == -1) {
                throw new RuntimeException("All children of ConstraintLayout must have ids to use ConstraintSet");
            } else {
                if (id != -1) {
                    if (this.f1167c.containsKey(Integer.valueOf(id))) {
                        hashSet.remove(Integer.valueOf(id));
                        a aVar = this.f1167c.get(Integer.valueOf(id));
                        if (childAt instanceof Barrier) {
                            aVar.f1171d.f1182d0 = 1;
                        }
                        int i3 = aVar.f1171d.f1182d0;
                        if (i3 != -1 && i3 == 1) {
                            Barrier barrier = (Barrier) childAt;
                            barrier.setId(id);
                            barrier.setType(aVar.f1171d.f1178b0);
                            barrier.setMargin(aVar.f1171d.f1180c0);
                            barrier.setAllowsGoneWidget(aVar.f1171d.f1194j0);
                            b bVar = aVar.f1171d;
                            int[] iArr = bVar.f1184e0;
                            if (iArr != null) {
                                barrier.setReferencedIds(iArr);
                            } else {
                                String str = bVar.f1186f0;
                                if (str != null) {
                                    bVar.f1184e0 = j(barrier, str);
                                    barrier.setReferencedIds(aVar.f1171d.f1184e0);
                                }
                            }
                        }
                        ConstraintLayout.b bVar2 = (ConstraintLayout.b) childAt.getLayoutParams();
                        bVar2.a();
                        aVar.d(bVar2);
                        if (z2) {
                            androidx.constraintlayout.widget.a.c(childAt, aVar.f1173f);
                        }
                        childAt.setLayoutParams(bVar2);
                        C0006d c0006d = aVar.f1169b;
                        if (c0006d.f1221c == 0) {
                            childAt.setVisibility(c0006d.f1220b);
                        }
                        childAt.setAlpha(aVar.f1169b.f1222d);
                        childAt.setRotation(aVar.f1172e.f1226b);
                        childAt.setRotationX(aVar.f1172e.f1227c);
                        childAt.setRotationY(aVar.f1172e.f1228d);
                        childAt.setScaleX(aVar.f1172e.f1229e);
                        childAt.setScaleY(aVar.f1172e.f1230f);
                        if (!Float.isNaN(aVar.f1172e.f1231g)) {
                            childAt.setPivotX(aVar.f1172e.f1231g);
                        }
                        if (!Float.isNaN(aVar.f1172e.f1232h)) {
                            childAt.setPivotY(aVar.f1172e.f1232h);
                        }
                        childAt.setTranslationX(aVar.f1172e.f1233i);
                        childAt.setTranslationY(aVar.f1172e.f1234j);
                        childAt.setTranslationZ(aVar.f1172e.f1235k);
                        e eVar = aVar.f1172e;
                        if (eVar.f1236l) {
                            childAt.setElevation(eVar.f1237m);
                        }
                    } else {
                        Log.v("ConstraintSet", "WARNING NO CONSTRAINTS for view " + id);
                    }
                }
            }
        }
        Iterator it = hashSet.iterator();
        while (it.hasNext()) {
            Integer num = (Integer) it.next();
            a aVar2 = this.f1167c.get(num);
            int i4 = aVar2.f1171d.f1182d0;
            if (i4 != -1 && i4 == 1) {
                Barrier barrier2 = new Barrier(constraintLayout.getContext());
                barrier2.setId(num.intValue());
                b bVar3 = aVar2.f1171d;
                int[] iArr2 = bVar3.f1184e0;
                if (iArr2 != null) {
                    barrier2.setReferencedIds(iArr2);
                } else {
                    String str2 = bVar3.f1186f0;
                    if (str2 != null) {
                        bVar3.f1184e0 = j(barrier2, str2);
                        barrier2.setReferencedIds(aVar2.f1171d.f1184e0);
                    }
                }
                barrier2.setType(aVar2.f1171d.f1178b0);
                barrier2.setMargin(aVar2.f1171d.f1180c0);
                ConstraintLayout.b generateDefaultLayoutParams = constraintLayout.generateDefaultLayoutParams();
                barrier2.n();
                aVar2.d(generateDefaultLayoutParams);
                constraintLayout.addView(barrier2, generateDefaultLayoutParams);
            }
            if (aVar2.f1171d.f1175a) {
                View guideline = new Guideline(constraintLayout.getContext());
                guideline.setId(num.intValue());
                ConstraintLayout.b generateDefaultLayoutParams2 = constraintLayout.generateDefaultLayoutParams();
                aVar2.d(generateDefaultLayoutParams2);
                constraintLayout.addView(guideline, generateDefaultLayoutParams2);
            }
        }
    }

    public void e(int i2, int i3) {
        if (this.f1167c.containsKey(Integer.valueOf(i2))) {
            a aVar = this.f1167c.get(Integer.valueOf(i2));
            switch (i3) {
                case 1:
                    b bVar = aVar.f1171d;
                    bVar.f1191i = -1;
                    bVar.f1189h = -1;
                    bVar.D = -1;
                    bVar.J = -1;
                    return;
                case 2:
                    b bVar2 = aVar.f1171d;
                    bVar2.f1195k = -1;
                    bVar2.f1193j = -1;
                    bVar2.E = -1;
                    bVar2.L = -1;
                    return;
                case 3:
                    b bVar3 = aVar.f1171d;
                    bVar3.f1197m = -1;
                    bVar3.f1196l = -1;
                    bVar3.F = -1;
                    bVar3.K = -1;
                    return;
                case 4:
                    b bVar4 = aVar.f1171d;
                    bVar4.f1198n = -1;
                    bVar4.f1199o = -1;
                    bVar4.G = -1;
                    bVar4.M = -1;
                    return;
                case 5:
                    aVar.f1171d.f1200p = -1;
                    return;
                case 6:
                    b bVar5 = aVar.f1171d;
                    bVar5.f1201q = -1;
                    bVar5.f1202r = -1;
                    bVar5.I = -1;
                    bVar5.O = -1;
                    return;
                case 7:
                    b bVar6 = aVar.f1171d;
                    bVar6.f1203s = -1;
                    bVar6.f1204t = -1;
                    bVar6.H = -1;
                    bVar6.N = -1;
                    return;
                default:
                    throw new IllegalArgumentException("unknown constraint");
            }
        }
    }

    public void f(Context context, int i2) {
        g((ConstraintLayout) LayoutInflater.from(context).inflate(i2, (ViewGroup) null));
    }

    public void g(ConstraintLayout constraintLayout) {
        int childCount = constraintLayout.getChildCount();
        this.f1167c.clear();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = constraintLayout.getChildAt(i2);
            ConstraintLayout.b bVar = (ConstraintLayout.b) childAt.getLayoutParams();
            int id = childAt.getId();
            if (this.f1166b && id == -1) {
                throw new RuntimeException("All children of ConstraintLayout must have ids to use ConstraintSet");
            }
            if (!this.f1167c.containsKey(Integer.valueOf(id))) {
                this.f1167c.put(Integer.valueOf(id), new a());
            }
            a aVar = this.f1167c.get(Integer.valueOf(id));
            aVar.f1173f = androidx.constraintlayout.widget.a.a(this.f1165a, childAt);
            aVar.f(id, bVar);
            aVar.f1169b.f1220b = childAt.getVisibility();
            aVar.f1169b.f1222d = childAt.getAlpha();
            aVar.f1172e.f1226b = childAt.getRotation();
            aVar.f1172e.f1227c = childAt.getRotationX();
            aVar.f1172e.f1228d = childAt.getRotationY();
            aVar.f1172e.f1229e = childAt.getScaleX();
            aVar.f1172e.f1230f = childAt.getScaleY();
            float pivotX = childAt.getPivotX();
            float pivotY = childAt.getPivotY();
            if (pivotX != 0.0d || pivotY != 0.0d) {
                e eVar = aVar.f1172e;
                eVar.f1231g = pivotX;
                eVar.f1232h = pivotY;
            }
            aVar.f1172e.f1233i = childAt.getTranslationX();
            aVar.f1172e.f1234j = childAt.getTranslationY();
            aVar.f1172e.f1235k = childAt.getTranslationZ();
            e eVar2 = aVar.f1172e;
            if (eVar2.f1236l) {
                eVar2.f1237m = childAt.getElevation();
            }
            if (childAt instanceof Barrier) {
                Barrier barrier = (Barrier) childAt;
                aVar.f1171d.f1194j0 = barrier.o();
                aVar.f1171d.f1184e0 = barrier.getReferencedIds();
                aVar.f1171d.f1178b0 = barrier.getType();
                aVar.f1171d.f1180c0 = barrier.getMargin();
            }
        }
    }

    public void h(androidx.constraintlayout.widget.e eVar) {
        int childCount = eVar.getChildCount();
        this.f1167c.clear();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = eVar.getChildAt(i2);
            e.a aVar = (e.a) childAt.getLayoutParams();
            int id = childAt.getId();
            if (this.f1166b && id == -1) {
                throw new RuntimeException("All children of ConstraintLayout must have ids to use ConstraintSet");
            }
            if (!this.f1167c.containsKey(Integer.valueOf(id))) {
                this.f1167c.put(Integer.valueOf(id), new a());
            }
            a aVar2 = this.f1167c.get(Integer.valueOf(id));
            if (childAt instanceof androidx.constraintlayout.widget.b) {
                aVar2.h((androidx.constraintlayout.widget.b) childAt, id, aVar);
            }
            aVar2.g(id, aVar);
        }
    }

    public void i(int i2, int i3, int i4, float f2) {
        b bVar = l(i2).f1171d;
        bVar.f1208x = i3;
        bVar.f1209y = i4;
        bVar.f1210z = f2;
    }

    public void m(Context context, int i2) {
        XmlResourceParser xml = context.getResources().getXml(i2);
        try {
            for (int eventType = xml.getEventType(); eventType != 1; eventType = xml.next()) {
                if (eventType == 0) {
                    xml.getName();
                } else if (eventType == 2) {
                    String name = xml.getName();
                    a k2 = k(context, Xml.asAttributeSet(xml));
                    if (name.equalsIgnoreCase("Guideline")) {
                        k2.f1171d.f1175a = true;
                    }
                    this.f1167c.put(Integer.valueOf(k2.f1168a), k2);
                }
            }
        } catch (IOException e2) {
            e2.printStackTrace();
        } catch (XmlPullParserException e3) {
            e3.printStackTrace();
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:98:0x0179, code lost:
        continue;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void n(android.content.Context r10, org.xmlpull.v1.XmlPullParser r11) {
        /*
            Method dump skipped, instructions count: 448
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.widget.d.n(android.content.Context, org.xmlpull.v1.XmlPullParser):void");
    }
}
