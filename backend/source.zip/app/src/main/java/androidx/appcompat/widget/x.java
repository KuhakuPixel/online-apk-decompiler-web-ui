package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.widget.TextView;
import java.lang.ref.WeakReference;
import v.f;
/* loaded from: classes.dex */
class x {

    /* renamed from: a  reason: collision with root package name */
    private final TextView f981a;

    /* renamed from: b  reason: collision with root package name */
    private r0 f982b;

    /* renamed from: c  reason: collision with root package name */
    private r0 f983c;

    /* renamed from: d  reason: collision with root package name */
    private r0 f984d;

    /* renamed from: e  reason: collision with root package name */
    private r0 f985e;

    /* renamed from: f  reason: collision with root package name */
    private r0 f986f;

    /* renamed from: g  reason: collision with root package name */
    private r0 f987g;

    /* renamed from: h  reason: collision with root package name */
    private r0 f988h;

    /* renamed from: i  reason: collision with root package name */
    private final y f989i;

    /* renamed from: j  reason: collision with root package name */
    private int f990j = 0;

    /* renamed from: k  reason: collision with root package name */
    private int f991k = -1;

    /* renamed from: l  reason: collision with root package name */
    private Typeface f992l;

    /* renamed from: m  reason: collision with root package name */
    private boolean f993m;

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public class a extends f.a {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ int f994a;

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ int f995b;

        /* renamed from: c  reason: collision with root package name */
        final /* synthetic */ WeakReference f996c;

        a(int i2, int i3, WeakReference weakReference) {
            this.f994a = i2;
            this.f995b = i3;
            this.f996c = weakReference;
        }

        @Override // v.f.a
        public void c(int i2) {
        }

        @Override // v.f.a
        public void d(Typeface typeface) {
            int i2;
            if (Build.VERSION.SDK_INT >= 28 && (i2 = this.f994a) != -1) {
                typeface = Typeface.create(typeface, i2, (this.f995b & 2) != 0);
            }
            x.this.n(this.f996c, typeface);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public x(TextView textView) {
        this.f981a = textView;
        this.f989i = new y(textView);
    }

    private void A(int i2, float f2) {
        this.f989i.v(i2, f2);
    }

    private void B(Context context, t0 t0Var) {
        String o2;
        Typeface create;
        Typeface typeface;
        this.f990j = t0Var.k(a.j.U2, this.f990j);
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 28) {
            int k2 = t0Var.k(a.j.Z2, -1);
            this.f991k = k2;
            if (k2 != -1) {
                this.f990j = (this.f990j & 2) | 0;
            }
        }
        int i3 = a.j.Y2;
        if (!t0Var.s(i3) && !t0Var.s(a.j.a3)) {
            int i4 = a.j.T2;
            if (t0Var.s(i4)) {
                this.f993m = false;
                int k3 = t0Var.k(i4, 1);
                if (k3 == 1) {
                    typeface = Typeface.SANS_SERIF;
                } else if (k3 == 2) {
                    typeface = Typeface.SERIF;
                } else if (k3 != 3) {
                    return;
                } else {
                    typeface = Typeface.MONOSPACE;
                }
                this.f992l = typeface;
                return;
            }
            return;
        }
        this.f992l = null;
        int i5 = a.j.a3;
        if (t0Var.s(i5)) {
            i3 = i5;
        }
        int i6 = this.f991k;
        int i7 = this.f990j;
        if (!context.isRestricted()) {
            try {
                Typeface j2 = t0Var.j(i3, this.f990j, new a(i6, i7, new WeakReference(this.f981a)));
                if (j2 != null) {
                    if (i2 >= 28 && this.f991k != -1) {
                        j2 = Typeface.create(Typeface.create(j2, 0), this.f991k, (this.f990j & 2) != 0);
                    }
                    this.f992l = j2;
                }
                this.f993m = this.f992l == null;
            } catch (Resources.NotFoundException | UnsupportedOperationException unused) {
            }
        }
        if (this.f992l != null || (o2 = t0Var.o(i3)) == null) {
            return;
        }
        if (Build.VERSION.SDK_INT < 28 || this.f991k == -1) {
            create = Typeface.create(o2, this.f990j);
        } else {
            create = Typeface.create(Typeface.create(o2, 0), this.f991k, (this.f990j & 2) != 0);
        }
        this.f992l = create;
    }

    private void a(Drawable drawable, r0 r0Var) {
        if (drawable == null || r0Var == null) {
            return;
        }
        j.i(drawable, r0Var, this.f981a.getDrawableState());
    }

    private static r0 d(Context context, j jVar, int i2) {
        ColorStateList f2 = jVar.f(context, i2);
        if (f2 != null) {
            r0 r0Var = new r0();
            r0Var.f907d = true;
            r0Var.f904a = f2;
            return r0Var;
        }
        return null;
    }

    private void x(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4, Drawable drawable5, Drawable drawable6) {
        if (drawable5 != null || drawable6 != null) {
            Drawable[] compoundDrawablesRelative = this.f981a.getCompoundDrawablesRelative();
            TextView textView = this.f981a;
            if (drawable5 == null) {
                drawable5 = compoundDrawablesRelative[0];
            }
            if (drawable2 == null) {
                drawable2 = compoundDrawablesRelative[1];
            }
            if (drawable6 == null) {
                drawable6 = compoundDrawablesRelative[2];
            }
            if (drawable4 == null) {
                drawable4 = compoundDrawablesRelative[3];
            }
            textView.setCompoundDrawablesRelativeWithIntrinsicBounds(drawable5, drawable2, drawable6, drawable4);
        } else if (drawable == null && drawable2 == null && drawable3 == null && drawable4 == null) {
        } else {
            Drawable[] compoundDrawablesRelative2 = this.f981a.getCompoundDrawablesRelative();
            if (compoundDrawablesRelative2[0] != null || compoundDrawablesRelative2[2] != null) {
                TextView textView2 = this.f981a;
                Drawable drawable7 = compoundDrawablesRelative2[0];
                if (drawable2 == null) {
                    drawable2 = compoundDrawablesRelative2[1];
                }
                Drawable drawable8 = compoundDrawablesRelative2[2];
                if (drawable4 == null) {
                    drawable4 = compoundDrawablesRelative2[3];
                }
                textView2.setCompoundDrawablesRelativeWithIntrinsicBounds(drawable7, drawable2, drawable8, drawable4);
                return;
            }
            Drawable[] compoundDrawables = this.f981a.getCompoundDrawables();
            TextView textView3 = this.f981a;
            if (drawable == null) {
                drawable = compoundDrawables[0];
            }
            if (drawable2 == null) {
                drawable2 = compoundDrawables[1];
            }
            if (drawable3 == null) {
                drawable3 = compoundDrawables[2];
            }
            if (drawable4 == null) {
                drawable4 = compoundDrawables[3];
            }
            textView3.setCompoundDrawablesWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
        }
    }

    private void y() {
        r0 r0Var = this.f988h;
        this.f982b = r0Var;
        this.f983c = r0Var;
        this.f984d = r0Var;
        this.f985e = r0Var;
        this.f986f = r0Var;
        this.f987g = r0Var;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void b() {
        if (this.f982b != null || this.f983c != null || this.f984d != null || this.f985e != null) {
            Drawable[] compoundDrawables = this.f981a.getCompoundDrawables();
            a(compoundDrawables[0], this.f982b);
            a(compoundDrawables[1], this.f983c);
            a(compoundDrawables[2], this.f984d);
            a(compoundDrawables[3], this.f985e);
        }
        if (this.f986f == null && this.f987g == null) {
            return;
        }
        Drawable[] compoundDrawablesRelative = this.f981a.getCompoundDrawablesRelative();
        a(compoundDrawablesRelative[0], this.f986f);
        a(compoundDrawablesRelative[2], this.f987g);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void c() {
        this.f989i.a();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public int e() {
        return this.f989i.h();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public int f() {
        return this.f989i.i();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public int g() {
        return this.f989i.j();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public int[] h() {
        return this.f989i.k();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public int i() {
        return this.f989i.l();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public ColorStateList j() {
        r0 r0Var = this.f988h;
        if (r0Var != null) {
            return r0Var.f904a;
        }
        return null;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public PorterDuff.Mode k() {
        r0 r0Var = this.f988h;
        if (r0Var != null) {
            return r0Var.f905b;
        }
        return null;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public boolean l() {
        return this.f989i.p();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* JADX WARN: Removed duplicated region for block: B:104:0x01de  */
    /* JADX WARN: Removed duplicated region for block: B:106:0x01e5  */
    /* JADX WARN: Removed duplicated region for block: B:112:0x0212  */
    /* JADX WARN: Removed duplicated region for block: B:116:0x0223  */
    /* JADX WARN: Removed duplicated region for block: B:122:0x0260  */
    /* JADX WARN: Removed duplicated region for block: B:123:0x0266  */
    /* JADX WARN: Removed duplicated region for block: B:126:0x026f  */
    /* JADX WARN: Removed duplicated region for block: B:127:0x0275  */
    /* JADX WARN: Removed duplicated region for block: B:130:0x027e  */
    /* JADX WARN: Removed duplicated region for block: B:131:0x0284  */
    /* JADX WARN: Removed duplicated region for block: B:134:0x028d  */
    /* JADX WARN: Removed duplicated region for block: B:135:0x0293  */
    /* JADX WARN: Removed duplicated region for block: B:138:0x029c  */
    /* JADX WARN: Removed duplicated region for block: B:139:0x02a2  */
    /* JADX WARN: Removed duplicated region for block: B:142:0x02ab  */
    /* JADX WARN: Removed duplicated region for block: B:143:0x02b1  */
    /* JADX WARN: Removed duplicated region for block: B:146:0x02c5  */
    /* JADX WARN: Removed duplicated region for block: B:149:0x02d6  */
    /* JADX WARN: Removed duplicated region for block: B:150:0x02e6  */
    /* JADX WARN: Removed duplicated region for block: B:153:0x02fe  */
    /* JADX WARN: Removed duplicated region for block: B:155:0x0305  */
    /* JADX WARN: Removed duplicated region for block: B:157:0x030c  */
    /* JADX WARN: Removed duplicated region for block: B:159:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:30:0x00cc  */
    /* JADX WARN: Removed duplicated region for block: B:41:0x00f5  */
    /* JADX WARN: Removed duplicated region for block: B:45:0x0100  */
    /* JADX WARN: Removed duplicated region for block: B:46:0x0105  */
    /* JADX WARN: Removed duplicated region for block: B:48:0x0108  */
    /* JADX WARN: Removed duplicated region for block: B:61:0x0142  */
    /* JADX WARN: Removed duplicated region for block: B:72:0x016e  */
    /* JADX WARN: Removed duplicated region for block: B:75:0x0176  */
    /* JADX WARN: Removed duplicated region for block: B:81:0x0189  */
    /* JADX WARN: Removed duplicated region for block: B:89:0x01ac  */
    /* JADX WARN: Removed duplicated region for block: B:91:0x01b3  */
    /* JADX WARN: Removed duplicated region for block: B:93:0x01ba  */
    /* JADX WARN: Removed duplicated region for block: B:95:0x01c1 A[ADDED_TO_REGION] */
    /* JADX WARN: Removed duplicated region for block: B:99:0x01ca  */
    @android.annotation.SuppressLint({"NewApi"})
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void m(android.util.AttributeSet r24, int r25) {
        /*
            Method dump skipped, instructions count: 786
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.x.m(android.util.AttributeSet, int):void");
    }

    void n(WeakReference<TextView> weakReference, Typeface typeface) {
        if (this.f993m) {
            this.f992l = typeface;
            TextView textView = weakReference.get();
            if (textView != null) {
                textView.setTypeface(typeface, this.f990j);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void o(boolean z2, int i2, int i3, int i4, int i5) {
        if (androidx.core.widget.b.f1458a) {
            return;
        }
        c();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void p() {
        b();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void q(Context context, int i2) {
        String o2;
        ColorStateList c2;
        t0 t2 = t0.t(context, i2, a.j.R2);
        int i3 = a.j.c3;
        if (t2.s(i3)) {
            r(t2.a(i3, false));
        }
        int i4 = Build.VERSION.SDK_INT;
        if (i4 < 23) {
            int i5 = a.j.V2;
            if (t2.s(i5) && (c2 = t2.c(i5)) != null) {
                this.f981a.setTextColor(c2);
            }
        }
        int i6 = a.j.S2;
        if (t2.s(i6) && t2.f(i6, -1) == 0) {
            this.f981a.setTextSize(0, 0.0f);
        }
        B(context, t2);
        if (i4 >= 26) {
            int i7 = a.j.b3;
            if (t2.s(i7) && (o2 = t2.o(i7)) != null) {
                this.f981a.setFontVariationSettings(o2);
            }
        }
        t2.w();
        Typeface typeface = this.f992l;
        if (typeface != null) {
            this.f981a.setTypeface(typeface, this.f990j);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void r(boolean z2) {
        this.f981a.setAllCaps(z2);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void s(int i2, int i3, int i4, int i5) {
        this.f989i.r(i2, i3, i4, i5);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void t(int[] iArr, int i2) {
        this.f989i.s(iArr, i2);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void u(int i2) {
        this.f989i.t(i2);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void v(ColorStateList colorStateList) {
        if (this.f988h == null) {
            this.f988h = new r0();
        }
        r0 r0Var = this.f988h;
        r0Var.f904a = colorStateList;
        r0Var.f907d = colorStateList != null;
        y();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void w(PorterDuff.Mode mode) {
        if (this.f988h == null) {
            this.f988h = new r0();
        }
        r0 r0Var = this.f988h;
        r0Var.f905b = mode;
        r0Var.f906c = mode != null;
        y();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void z(int i2, float f2) {
        if (androidx.core.widget.b.f1458a || l()) {
            return;
        }
        A(i2, f2);
    }
}
