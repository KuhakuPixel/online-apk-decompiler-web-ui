package androidx.appcompat.widget;

import android.text.TextUtils;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.accessibility.AccessibilityManager;
/* loaded from: classes.dex */
class w0 implements View.OnLongClickListener, View.OnHoverListener, View.OnAttachStateChangeListener {

    /* renamed from: k  reason: collision with root package name */
    private static w0 f968k;

    /* renamed from: l  reason: collision with root package name */
    private static w0 f969l;

    /* renamed from: b  reason: collision with root package name */
    private final View f970b;

    /* renamed from: c  reason: collision with root package name */
    private final CharSequence f971c;

    /* renamed from: d  reason: collision with root package name */
    private final int f972d;

    /* renamed from: e  reason: collision with root package name */
    private final Runnable f973e = new a();

    /* renamed from: f  reason: collision with root package name */
    private final Runnable f974f = new b();

    /* renamed from: g  reason: collision with root package name */
    private int f975g;

    /* renamed from: h  reason: collision with root package name */
    private int f976h;

    /* renamed from: i  reason: collision with root package name */
    private x0 f977i;

    /* renamed from: j  reason: collision with root package name */
    private boolean f978j;

    /* loaded from: classes.dex */
    class a implements Runnable {
        a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            w0.this.g(false);
        }
    }

    /* loaded from: classes.dex */
    class b implements Runnable {
        b() {
        }

        @Override // java.lang.Runnable
        public void run() {
            w0.this.c();
        }
    }

    private w0(View view, CharSequence charSequence) {
        this.f970b = view;
        this.f971c = charSequence;
        this.f972d = e0.r.c(ViewConfiguration.get(view.getContext()));
        b();
        view.setOnLongClickListener(this);
        view.setOnHoverListener(this);
    }

    private void a() {
        this.f970b.removeCallbacks(this.f973e);
    }

    private void b() {
        this.f975g = Integer.MAX_VALUE;
        this.f976h = Integer.MAX_VALUE;
    }

    private void d() {
        this.f970b.postDelayed(this.f973e, ViewConfiguration.getLongPressTimeout());
    }

    private static void e(w0 w0Var) {
        w0 w0Var2 = f968k;
        if (w0Var2 != null) {
            w0Var2.a();
        }
        f968k = w0Var;
        if (w0Var != null) {
            w0Var.d();
        }
    }

    public static void f(View view, CharSequence charSequence) {
        w0 w0Var = f968k;
        if (w0Var != null && w0Var.f970b == view) {
            e(null);
        }
        if (!TextUtils.isEmpty(charSequence)) {
            new w0(view, charSequence);
            return;
        }
        w0 w0Var2 = f969l;
        if (w0Var2 != null && w0Var2.f970b == view) {
            w0Var2.c();
        }
        view.setOnLongClickListener(null);
        view.setLongClickable(false);
        view.setOnHoverListener(null);
    }

    private boolean h(MotionEvent motionEvent) {
        int x2 = (int) motionEvent.getX();
        int y2 = (int) motionEvent.getY();
        if (Math.abs(x2 - this.f975g) > this.f972d || Math.abs(y2 - this.f976h) > this.f972d) {
            this.f975g = x2;
            this.f976h = y2;
            return true;
        }
        return false;
    }

    void c() {
        if (f969l == this) {
            f969l = null;
            x0 x0Var = this.f977i;
            if (x0Var != null) {
                x0Var.c();
                this.f977i = null;
                b();
                this.f970b.removeOnAttachStateChangeListener(this);
            } else {
                Log.e("TooltipCompatHandler", "sActiveHandler.mPopup == null");
            }
        }
        if (f968k == this) {
            e(null);
        }
        this.f970b.removeCallbacks(this.f974f);
    }

    void g(boolean z2) {
        long longPressTimeout;
        if (e0.q.P(this.f970b)) {
            e(null);
            w0 w0Var = f969l;
            if (w0Var != null) {
                w0Var.c();
            }
            f969l = this;
            this.f978j = z2;
            x0 x0Var = new x0(this.f970b.getContext());
            this.f977i = x0Var;
            x0Var.e(this.f970b, this.f975g, this.f976h, this.f978j, this.f971c);
            this.f970b.addOnAttachStateChangeListener(this);
            if (this.f978j) {
                longPressTimeout = 2500;
            } else {
                longPressTimeout = ((e0.q.J(this.f970b) & 1) == 1 ? 3000L : 15000L) - ViewConfiguration.getLongPressTimeout();
            }
            this.f970b.removeCallbacks(this.f974f);
            this.f970b.postDelayed(this.f974f, longPressTimeout);
        }
    }

    @Override // android.view.View.OnHoverListener
    public boolean onHover(View view, MotionEvent motionEvent) {
        if (this.f977i == null || !this.f978j) {
            AccessibilityManager accessibilityManager = (AccessibilityManager) this.f970b.getContext().getSystemService("accessibility");
            if (accessibilityManager.isEnabled() && accessibilityManager.isTouchExplorationEnabled()) {
                return false;
            }
            int action = motionEvent.getAction();
            if (action != 7) {
                if (action == 10) {
                    b();
                    c();
                }
            } else if (this.f970b.isEnabled() && this.f977i == null && h(motionEvent)) {
                e(this);
            }
            return false;
        }
        return false;
    }

    @Override // android.view.View.OnLongClickListener
    public boolean onLongClick(View view) {
        this.f975g = view.getWidth() / 2;
        this.f976h = view.getHeight() / 2;
        g(true);
        return true;
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public void onViewAttachedToWindow(View view) {
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public void onViewDetachedFromWindow(View view) {
        c();
    }
}
