package q;

import java.util.List;
import p.d;
import p.e;
import q.f;
import q.p;
/* loaded from: classes.dex */
public class l extends p {

    /* renamed from: k  reason: collision with root package name */
    private static int[] f5030k = new int[2];

    /* loaded from: classes.dex */
    static /* synthetic */ class a {

        /* renamed from: a  reason: collision with root package name */
        static final /* synthetic */ int[] f5031a;

        static {
            int[] iArr = new int[p.b.values().length];
            f5031a = iArr;
            try {
                iArr[p.b.START.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                f5031a[p.b.END.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                f5031a[p.b.CENTER.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
        }
    }

    public l(p.e eVar) {
        super(eVar);
        this.f5065h.f5011e = f.a.LEFT;
        this.f5066i.f5011e = f.a.RIGHT;
        this.f5063f = 0;
    }

    private void q(int[] iArr, int i2, int i3, int i4, int i5, float f2, int i6) {
        int i7 = i3 - i2;
        int i8 = i5 - i4;
        if (i6 != -1) {
            if (i6 == 0) {
                iArr[0] = (int) ((i8 * f2) + 0.5f);
                iArr[1] = i8;
                return;
            } else if (i6 != 1) {
                return;
            } else {
                iArr[0] = i7;
                iArr[1] = (int) ((i7 * f2) + 0.5f);
                return;
            }
        }
        int i9 = (int) ((i8 * f2) + 0.5f);
        int i10 = (int) ((i7 / f2) + 0.5f);
        if (i9 <= i7) {
            iArr[0] = i9;
            iArr[1] = i8;
        } else if (i10 <= i8) {
            iArr[0] = i7;
            iArr[1] = i10;
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:116:0x0295, code lost:
        if (r14 != 1) goto L134;
     */
    @Override // q.p, q.d
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void a(q.d r17) {
        /*
            Method dump skipped, instructions count: 1040
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: q.l.a(q.d):void");
    }

    @Override // q.p
    void d() {
        p.e I;
        f fVar;
        f fVar2;
        int S;
        f fVar3;
        p.d dVar;
        List<d> list;
        d dVar2;
        f fVar4;
        f fVar5;
        f fVar6;
        int S2;
        f fVar7;
        f fVar8;
        int i2;
        p.e I2;
        p.e eVar = this.f5059b;
        if (eVar.f4887a) {
            this.f5062e.d(eVar.R());
        }
        if (this.f5062e.f5016j) {
            e.b bVar = this.f5061d;
            e.b bVar2 = e.b.MATCH_PARENT;
            if (bVar == bVar2 && (((I = this.f5059b.I()) != null && I.y() == e.b.FIXED) || I.y() == bVar2)) {
                b(this.f5065h, I.f4895e.f5065h, this.f5059b.H.e());
                b(this.f5066i, I.f4895e.f5066i, -this.f5059b.J.e());
                return;
            }
        } else {
            e.b y2 = this.f5059b.y();
            this.f5061d = y2;
            if (y2 != e.b.MATCH_CONSTRAINT) {
                e.b bVar3 = e.b.MATCH_PARENT;
                if (y2 == bVar3 && (((I2 = this.f5059b.I()) != null && I2.y() == e.b.FIXED) || I2.y() == bVar3)) {
                    int R = (I2.R() - this.f5059b.H.e()) - this.f5059b.J.e();
                    b(this.f5065h, I2.f4895e.f5065h, this.f5059b.H.e());
                    b(this.f5066i, I2.f4895e.f5066i, -this.f5059b.J.e());
                    this.f5062e.d(R);
                    return;
                } else if (this.f5061d == e.b.FIXED) {
                    this.f5062e.d(this.f5059b.R());
                }
            }
        }
        g gVar = this.f5062e;
        if (gVar.f5016j) {
            p.e eVar2 = this.f5059b;
            if (eVar2.f4887a) {
                p.d[] dVarArr = eVar2.P;
                if (dVarArr[0].f4872f != null && dVarArr[1].f4872f != null) {
                    if (eVar2.Z()) {
                        this.f5065h.f5012f = this.f5059b.P[0].e();
                        fVar3 = this.f5066i;
                        dVar = this.f5059b.P[1];
                        fVar3.f5012f = -dVar.e();
                        return;
                    }
                    f h2 = h(this.f5059b.P[0]);
                    if (h2 != null) {
                        b(this.f5065h, h2, this.f5059b.P[0].e());
                    }
                    f h3 = h(this.f5059b.P[1]);
                    if (h3 != null) {
                        b(this.f5066i, h3, -this.f5059b.P[1].e());
                    }
                    this.f5065h.f5008b = true;
                    this.f5066i.f5008b = true;
                    return;
                }
                if (dVarArr[0].f4872f != null) {
                    fVar5 = h(dVarArr[0]);
                    if (fVar5 == null) {
                        return;
                    }
                    fVar6 = this.f5065h;
                    S2 = this.f5059b.P[0].e();
                } else if (dVarArr[1].f4872f != null) {
                    f h4 = h(dVarArr[1]);
                    if (h4 != null) {
                        b(this.f5066i, h4, -this.f5059b.P[1].e());
                        fVar7 = this.f5065h;
                        fVar8 = this.f5066i;
                        i2 = -this.f5062e.f5013g;
                        b(fVar7, fVar8, i2);
                        return;
                    }
                    return;
                } else if ((eVar2 instanceof p.h) || eVar2.I() == null || this.f5059b.m(d.b.CENTER).f4872f != null) {
                    return;
                } else {
                    fVar5 = this.f5059b.I().f4895e.f5065h;
                    fVar6 = this.f5065h;
                    S2 = this.f5059b.S();
                }
                b(fVar6, fVar5, S2);
                fVar7 = this.f5066i;
                fVar8 = this.f5065h;
                i2 = this.f5062e.f5013g;
                b(fVar7, fVar8, i2);
                return;
            }
        }
        if (this.f5061d == e.b.MATCH_CONSTRAINT) {
            p.e eVar3 = this.f5059b;
            int i3 = eVar3.f4917p;
            if (i3 == 2) {
                p.e I3 = eVar3.I();
                if (I3 != null) {
                    g gVar2 = I3.f4897f.f5062e;
                    this.f5062e.f5018l.add(gVar2);
                    gVar2.f5017k.add(this.f5062e);
                    g gVar3 = this.f5062e;
                    gVar3.f5008b = true;
                    gVar3.f5017k.add(this.f5065h);
                    list = this.f5062e.f5017k;
                    dVar2 = this.f5066i;
                    list.add(dVar2);
                }
            } else if (i3 == 3) {
                if (eVar3.f4919q == 3) {
                    this.f5065h.f5007a = this;
                    this.f5066i.f5007a = this;
                    n nVar = eVar3.f4897f;
                    nVar.f5065h.f5007a = this;
                    nVar.f5066i.f5007a = this;
                    gVar.f5007a = this;
                    if (eVar3.b0()) {
                        this.f5062e.f5018l.add(this.f5059b.f4897f.f5062e);
                        this.f5059b.f4897f.f5062e.f5017k.add(this.f5062e);
                        n nVar2 = this.f5059b.f4897f;
                        nVar2.f5062e.f5007a = this;
                        this.f5062e.f5018l.add(nVar2.f5065h);
                        this.f5062e.f5018l.add(this.f5059b.f4897f.f5066i);
                        this.f5059b.f4897f.f5065h.f5017k.add(this.f5062e);
                        list = this.f5059b.f4897f.f5066i.f5017k;
                        dVar2 = this.f5062e;
                        list.add(dVar2);
                    } else if (this.f5059b.Z()) {
                        this.f5059b.f4897f.f5062e.f5018l.add(this.f5062e);
                        list = this.f5062e.f5017k;
                        dVar2 = this.f5059b.f4897f.f5062e;
                        list.add(dVar2);
                    } else {
                        fVar4 = this.f5059b.f4897f.f5062e;
                    }
                } else {
                    g gVar4 = eVar3.f4897f.f5062e;
                    gVar.f5018l.add(gVar4);
                    gVar4.f5017k.add(this.f5062e);
                    this.f5059b.f4897f.f5065h.f5017k.add(this.f5062e);
                    this.f5059b.f4897f.f5066i.f5017k.add(this.f5062e);
                    g gVar5 = this.f5062e;
                    gVar5.f5008b = true;
                    gVar5.f5017k.add(this.f5065h);
                    this.f5062e.f5017k.add(this.f5066i);
                    this.f5065h.f5018l.add(this.f5062e);
                    fVar4 = this.f5066i;
                }
                list = fVar4.f5018l;
                dVar2 = this.f5062e;
                list.add(dVar2);
            }
            fVar3.f5012f = -dVar.e();
            return;
        }
        p.e eVar4 = this.f5059b;
        p.d[] dVarArr2 = eVar4.P;
        if (dVarArr2[0].f4872f != null && dVarArr2[1].f4872f != null) {
            if (eVar4.Z()) {
                this.f5065h.f5012f = this.f5059b.P[0].e();
                fVar3 = this.f5066i;
                dVar = this.f5059b.P[1];
                fVar3.f5012f = -dVar.e();
                return;
            }
            f h5 = h(this.f5059b.P[0]);
            f h6 = h(this.f5059b.P[1]);
            h5.b(this);
            h6.b(this);
            this.f5067j = p.b.CENTER;
            return;
        }
        if (dVarArr2[0].f4872f != null) {
            fVar = h(dVarArr2[0]);
            if (fVar == null) {
                return;
            }
            fVar2 = this.f5065h;
            S = this.f5059b.P[0].e();
        } else if (dVarArr2[1].f4872f != null) {
            f h7 = h(dVarArr2[1]);
            if (h7 != null) {
                b(this.f5066i, h7, -this.f5059b.P[1].e());
                c(this.f5065h, this.f5066i, -1, this.f5062e);
                return;
            }
            return;
        } else if ((eVar4 instanceof p.h) || eVar4.I() == null) {
            return;
        } else {
            fVar = this.f5059b.I().f4895e.f5065h;
            fVar2 = this.f5065h;
            S = this.f5059b.S();
        }
        b(fVar2, fVar, S);
        c(this.f5066i, this.f5065h, 1, this.f5062e);
    }

    @Override // q.p
    public void e() {
        f fVar = this.f5065h;
        if (fVar.f5016j) {
            this.f5059b.V0(fVar.f5013g);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    @Override // q.p
    public void f() {
        this.f5060c = null;
        this.f5065h.c();
        this.f5066i.c();
        this.f5062e.c();
        this.f5064g = false;
    }

    @Override // q.p
    boolean m() {
        return this.f5061d != e.b.MATCH_CONSTRAINT || this.f5059b.f4917p == 0;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void r() {
        this.f5064g = false;
        this.f5065h.c();
        this.f5065h.f5016j = false;
        this.f5066i.c();
        this.f5066i.f5016j = false;
        this.f5062e.f5016j = false;
    }

    public String toString() {
        return "HorizontalRun " + this.f5059b.r();
    }
}
