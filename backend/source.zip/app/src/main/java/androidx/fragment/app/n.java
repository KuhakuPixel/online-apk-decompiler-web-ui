package androidx.fragment.app;

import android.annotation.SuppressLint;
import android.os.Parcel;
import android.os.Parcelable;
import java.util.ArrayList;
/* JADX INFO: Access modifiers changed from: package-private */
@SuppressLint({"BanParcelableUsage"})
/* loaded from: classes.dex */
public final class n implements Parcelable {
    public static final Parcelable.Creator<n> CREATOR = new a();

    /* renamed from: b  reason: collision with root package name */
    ArrayList<p> f1681b;

    /* renamed from: c  reason: collision with root package name */
    ArrayList<String> f1682c;

    /* renamed from: d  reason: collision with root package name */
    b[] f1683d;

    /* renamed from: e  reason: collision with root package name */
    int f1684e;

    /* renamed from: f  reason: collision with root package name */
    String f1685f;

    /* loaded from: classes.dex */
    static class a implements Parcelable.Creator<n> {
        a() {
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: a  reason: merged with bridge method [inline-methods] */
        public n createFromParcel(Parcel parcel) {
            return new n(parcel);
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: b  reason: merged with bridge method [inline-methods] */
        public n[] newArray(int i2) {
            return new n[i2];
        }
    }

    public n() {
        this.f1685f = null;
    }

    public n(Parcel parcel) {
        this.f1685f = null;
        this.f1681b = parcel.createTypedArrayList(p.CREATOR);
        this.f1682c = parcel.createStringArrayList();
        this.f1683d = (b[]) parcel.createTypedArray(b.CREATOR);
        this.f1684e = parcel.readInt();
        this.f1685f = parcel.readString();
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i2) {
        parcel.writeTypedList(this.f1681b);
        parcel.writeStringList(this.f1682c);
        parcel.writeTypedArray(this.f1683d, i2);
        parcel.writeInt(this.f1684e);
        parcel.writeString(this.f1685f);
    }
}
