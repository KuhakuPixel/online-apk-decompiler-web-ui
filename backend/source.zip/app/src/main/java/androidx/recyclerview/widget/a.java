package androidx.recyclerview.widget;

import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.h;
import java.util.ArrayList;
import java.util.List;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes.dex */
public class a implements h.a {

    /* renamed from: a  reason: collision with root package name */
    private d0.e<b> f2327a;

    /* renamed from: b  reason: collision with root package name */
    final ArrayList<b> f2328b;

    /* renamed from: c  reason: collision with root package name */
    final ArrayList<b> f2329c;

    /* renamed from: d  reason: collision with root package name */
    final InterfaceC0015a f2330d;

    /* renamed from: e  reason: collision with root package name */
    Runnable f2331e;

    /* renamed from: f  reason: collision with root package name */
    final boolean f2332f;

    /* renamed from: g  reason: collision with root package name */
    final h f2333g;

    /* renamed from: h  reason: collision with root package name */
    private int f2334h;

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: androidx.recyclerview.widget.a$a  reason: collision with other inner class name */
    /* loaded from: classes.dex */
    public interface InterfaceC0015a {
        void a(int i2, int i3);

        void b(b bVar);

        RecyclerView.d0 c(int i2);

        void d(int i2, int i3);

        void e(int i2, int i3);

        void f(b bVar);

        void g(int i2, int i3);

        void h(int i2, int i3, Object obj);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public static class b {

        /* renamed from: a  reason: collision with root package name */
        int f2335a;

        /* renamed from: b  reason: collision with root package name */
        int f2336b;

        /* renamed from: c  reason: collision with root package name */
        Object f2337c;

        /* renamed from: d  reason: collision with root package name */
        int f2338d;

        b(int i2, int i3, int i4, Object obj) {
            this.f2335a = i2;
            this.f2336b = i3;
            this.f2338d = i4;
            this.f2337c = obj;
        }

        String a() {
            int i2 = this.f2335a;
            return i2 != 1 ? i2 != 2 ? i2 != 4 ? i2 != 8 ? "??" : "mv" : "up" : "rm" : "add";
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null || getClass() != obj.getClass()) {
                return false;
            }
            b bVar = (b) obj;
            int i2 = this.f2335a;
            if (i2 != bVar.f2335a) {
                return false;
            }
            if (i2 == 8 && Math.abs(this.f2338d - this.f2336b) == 1 && this.f2338d == bVar.f2336b && this.f2336b == bVar.f2338d) {
                return true;
            }
            if (this.f2338d == bVar.f2338d && this.f2336b == bVar.f2336b) {
                Object obj2 = this.f2337c;
                Object obj3 = bVar.f2337c;
                if (obj2 != null) {
                    if (!obj2.equals(obj3)) {
                        return false;
                    }
                } else if (obj3 != null) {
                    return false;
                }
                return true;
            }
            return false;
        }

        public int hashCode() {
            return (((this.f2335a * 31) + this.f2336b) * 31) + this.f2338d;
        }

        public String toString() {
            return Integer.toHexString(System.identityHashCode(this)) + "[" + a() + ",s:" + this.f2336b + "c:" + this.f2338d + ",p:" + this.f2337c + "]";
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public a(InterfaceC0015a interfaceC0015a) {
        this(interfaceC0015a, false);
    }

    a(InterfaceC0015a interfaceC0015a, boolean z2) {
        this.f2327a = new d0.f(30);
        this.f2328b = new ArrayList<>();
        this.f2329c = new ArrayList<>();
        this.f2334h = 0;
        this.f2330d = interfaceC0015a;
        this.f2332f = z2;
        this.f2333g = new h(this);
    }

    private void c(b bVar) {
        r(bVar);
    }

    private void d(b bVar) {
        r(bVar);
    }

    private void f(b bVar) {
        boolean z2;
        char c2;
        int i2 = bVar.f2336b;
        int i3 = bVar.f2338d + i2;
        char c3 = 65535;
        int i4 = i2;
        int i5 = 0;
        while (i4 < i3) {
            if (this.f2330d.c(i4) != null || h(i4)) {
                if (c3 == 0) {
                    k(b(2, i2, i5, null));
                    z2 = true;
                } else {
                    z2 = false;
                }
                c2 = 1;
            } else {
                if (c3 == 1) {
                    r(b(2, i2, i5, null));
                    z2 = true;
                } else {
                    z2 = false;
                }
                c2 = 0;
            }
            if (z2) {
                i4 -= i5;
                i3 -= i5;
                i5 = 1;
            } else {
                i5++;
            }
            i4++;
            c3 = c2;
        }
        if (i5 != bVar.f2338d) {
            a(bVar);
            bVar = b(2, i2, i5, null);
        }
        if (c3 == 0) {
            k(bVar);
        } else {
            r(bVar);
        }
    }

    private void g(b bVar) {
        int i2 = bVar.f2336b;
        int i3 = bVar.f2338d + i2;
        int i4 = i2;
        char c2 = 65535;
        int i5 = 0;
        while (i2 < i3) {
            if (this.f2330d.c(i2) != null || h(i2)) {
                if (c2 == 0) {
                    k(b(4, i4, i5, bVar.f2337c));
                    i4 = i2;
                    i5 = 0;
                }
                c2 = 1;
            } else {
                if (c2 == 1) {
                    r(b(4, i4, i5, bVar.f2337c));
                    i4 = i2;
                    i5 = 0;
                }
                c2 = 0;
            }
            i5++;
            i2++;
        }
        if (i5 != bVar.f2338d) {
            Object obj = bVar.f2337c;
            a(bVar);
            bVar = b(4, i4, i5, obj);
        }
        if (c2 == 0) {
            k(bVar);
        } else {
            r(bVar);
        }
    }

    private boolean h(int i2) {
        int size = this.f2329c.size();
        for (int i3 = 0; i3 < size; i3++) {
            b bVar = this.f2329c.get(i3);
            int i4 = bVar.f2335a;
            if (i4 == 8) {
                if (n(bVar.f2338d, i3 + 1) == i2) {
                    return true;
                }
            } else if (i4 == 1) {
                int i5 = bVar.f2336b;
                int i6 = bVar.f2338d + i5;
                while (i5 < i6) {
                    if (n(i5, i3 + 1) == i2) {
                        return true;
                    }
                    i5++;
                }
            } else {
                continue;
            }
        }
        return false;
    }

    private void k(b bVar) {
        int i2;
        int i3 = bVar.f2335a;
        if (i3 == 1 || i3 == 8) {
            throw new IllegalArgumentException("should not dispatch add or move for pre layout");
        }
        int v2 = v(bVar.f2336b, i3);
        int i4 = bVar.f2336b;
        int i5 = bVar.f2335a;
        if (i5 == 2) {
            i2 = 0;
        } else if (i5 != 4) {
            throw new IllegalArgumentException("op should be remove or update." + bVar);
        } else {
            i2 = 1;
        }
        int i6 = 1;
        for (int i7 = 1; i7 < bVar.f2338d; i7++) {
            int v3 = v(bVar.f2336b + (i2 * i7), bVar.f2335a);
            int i8 = bVar.f2335a;
            if (i8 == 2 ? v3 == v2 : i8 == 4 && v3 == v2 + 1) {
                i6++;
            } else {
                b b2 = b(i8, v2, i6, bVar.f2337c);
                l(b2, i4);
                a(b2);
                if (bVar.f2335a == 4) {
                    i4 += i6;
                }
                v2 = v3;
                i6 = 1;
            }
        }
        Object obj = bVar.f2337c;
        a(bVar);
        if (i6 > 0) {
            b b3 = b(bVar.f2335a, v2, i6, obj);
            l(b3, i4);
            a(b3);
        }
    }

    private void r(b bVar) {
        this.f2329c.add(bVar);
        int i2 = bVar.f2335a;
        if (i2 == 1) {
            this.f2330d.g(bVar.f2336b, bVar.f2338d);
        } else if (i2 == 2) {
            this.f2330d.e(bVar.f2336b, bVar.f2338d);
        } else if (i2 == 4) {
            this.f2330d.h(bVar.f2336b, bVar.f2338d, bVar.f2337c);
        } else if (i2 == 8) {
            this.f2330d.a(bVar.f2336b, bVar.f2338d);
        } else {
            throw new IllegalArgumentException("Unknown update op type for " + bVar);
        }
    }

    private int v(int i2, int i3) {
        int i4;
        int i5;
        int i6;
        int i7;
        int i8;
        int i9;
        for (int size = this.f2329c.size() - 1; size >= 0; size--) {
            b bVar = this.f2329c.get(size);
            int i10 = bVar.f2335a;
            if (i10 == 8) {
                int i11 = bVar.f2336b;
                int i12 = bVar.f2338d;
                if (i11 < i12) {
                    i6 = i11;
                    i5 = i12;
                } else {
                    i5 = i11;
                    i6 = i12;
                }
                if (i2 < i6 || i2 > i5) {
                    if (i2 < i11) {
                        if (i3 == 1) {
                            bVar.f2336b = i11 + 1;
                            i7 = i12 + 1;
                        } else if (i3 == 2) {
                            bVar.f2336b = i11 - 1;
                            i7 = i12 - 1;
                        }
                        bVar.f2338d = i7;
                    }
                } else if (i6 == i11) {
                    if (i3 == 1) {
                        i9 = i12 + 1;
                    } else {
                        if (i3 == 2) {
                            i9 = i12 - 1;
                        }
                        i2++;
                    }
                    bVar.f2338d = i9;
                    i2++;
                } else {
                    if (i3 == 1) {
                        i8 = i11 + 1;
                    } else {
                        if (i3 == 2) {
                            i8 = i11 - 1;
                        }
                        i2--;
                    }
                    bVar.f2336b = i8;
                    i2--;
                }
            } else {
                int i13 = bVar.f2336b;
                if (i13 > i2) {
                    if (i3 == 1) {
                        i4 = i13 + 1;
                    } else if (i3 == 2) {
                        i4 = i13 - 1;
                    }
                    bVar.f2336b = i4;
                } else if (i10 == 1) {
                    i2 -= bVar.f2338d;
                } else if (i10 == 2) {
                    i2 += bVar.f2338d;
                }
            }
        }
        for (int size2 = this.f2329c.size() - 1; size2 >= 0; size2--) {
            b bVar2 = this.f2329c.get(size2);
            if (bVar2.f2335a == 8) {
                int i14 = bVar2.f2338d;
                if (i14 != bVar2.f2336b && i14 >= 0) {
                }
                this.f2329c.remove(size2);
                a(bVar2);
            } else {
                if (bVar2.f2338d > 0) {
                }
                this.f2329c.remove(size2);
                a(bVar2);
            }
        }
        return i2;
    }

    @Override // androidx.recyclerview.widget.h.a
    public void a(b bVar) {
        if (this.f2332f) {
            return;
        }
        bVar.f2337c = null;
        this.f2327a.a(bVar);
    }

    @Override // androidx.recyclerview.widget.h.a
    public b b(int i2, int i3, int i4, Object obj) {
        b b2 = this.f2327a.b();
        if (b2 == null) {
            return new b(i2, i3, i4, obj);
        }
        b2.f2335a = i2;
        b2.f2336b = i3;
        b2.f2338d = i4;
        b2.f2337c = obj;
        return b2;
    }

    public int e(int i2) {
        int size = this.f2328b.size();
        for (int i3 = 0; i3 < size; i3++) {
            b bVar = this.f2328b.get(i3);
            int i4 = bVar.f2335a;
            if (i4 != 1) {
                if (i4 == 2) {
                    int i5 = bVar.f2336b;
                    if (i5 <= i2) {
                        int i6 = bVar.f2338d;
                        if (i5 + i6 > i2) {
                            return -1;
                        }
                        i2 -= i6;
                    } else {
                        continue;
                    }
                } else if (i4 == 8) {
                    int i7 = bVar.f2336b;
                    if (i7 == i2) {
                        i2 = bVar.f2338d;
                    } else {
                        if (i7 < i2) {
                            i2--;
                        }
                        if (bVar.f2338d <= i2) {
                            i2++;
                        }
                    }
                }
            } else if (bVar.f2336b <= i2) {
                i2 += bVar.f2338d;
            }
        }
        return i2;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void i() {
        int size = this.f2329c.size();
        for (int i2 = 0; i2 < size; i2++) {
            this.f2330d.b(this.f2329c.get(i2));
        }
        t(this.f2329c);
        this.f2334h = 0;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void j() {
        i();
        int size = this.f2328b.size();
        for (int i2 = 0; i2 < size; i2++) {
            b bVar = this.f2328b.get(i2);
            int i3 = bVar.f2335a;
            if (i3 == 1) {
                this.f2330d.b(bVar);
                this.f2330d.g(bVar.f2336b, bVar.f2338d);
            } else if (i3 == 2) {
                this.f2330d.b(bVar);
                this.f2330d.d(bVar.f2336b, bVar.f2338d);
            } else if (i3 == 4) {
                this.f2330d.b(bVar);
                this.f2330d.h(bVar.f2336b, bVar.f2338d, bVar.f2337c);
            } else if (i3 == 8) {
                this.f2330d.b(bVar);
                this.f2330d.a(bVar.f2336b, bVar.f2338d);
            }
            Runnable runnable = this.f2331e;
            if (runnable != null) {
                runnable.run();
            }
        }
        t(this.f2328b);
        this.f2334h = 0;
    }

    void l(b bVar, int i2) {
        this.f2330d.f(bVar);
        int i3 = bVar.f2335a;
        if (i3 == 2) {
            this.f2330d.d(i2, bVar.f2338d);
        } else if (i3 != 4) {
            throw new IllegalArgumentException("only remove and update ops can be dispatched in first pass");
        } else {
            this.f2330d.h(i2, bVar.f2338d, bVar.f2337c);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public int m(int i2) {
        return n(i2, 0);
    }

    int n(int i2, int i3) {
        int size = this.f2329c.size();
        while (i3 < size) {
            b bVar = this.f2329c.get(i3);
            int i4 = bVar.f2335a;
            if (i4 == 8) {
                int i5 = bVar.f2336b;
                if (i5 == i2) {
                    i2 = bVar.f2338d;
                } else {
                    if (i5 < i2) {
                        i2--;
                    }
                    if (bVar.f2338d <= i2) {
                        i2++;
                    }
                }
            } else {
                int i6 = bVar.f2336b;
                if (i6 > i2) {
                    continue;
                } else if (i4 == 2) {
                    int i7 = bVar.f2338d;
                    if (i2 < i6 + i7) {
                        return -1;
                    }
                    i2 -= i7;
                } else if (i4 == 1) {
                    i2 += bVar.f2338d;
                }
            }
            i3++;
        }
        return i2;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public boolean o(int i2) {
        return (i2 & this.f2334h) != 0;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public boolean p() {
        return this.f2328b.size() > 0;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public boolean q() {
        return (this.f2329c.isEmpty() || this.f2328b.isEmpty()) ? false : true;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void s() {
        this.f2333g.b(this.f2328b);
        int size = this.f2328b.size();
        for (int i2 = 0; i2 < size; i2++) {
            b bVar = this.f2328b.get(i2);
            int i3 = bVar.f2335a;
            if (i3 == 1) {
                c(bVar);
            } else if (i3 == 2) {
                f(bVar);
            } else if (i3 == 4) {
                g(bVar);
            } else if (i3 == 8) {
                d(bVar);
            }
            Runnable runnable = this.f2331e;
            if (runnable != null) {
                runnable.run();
            }
        }
        this.f2328b.clear();
    }

    void t(List<b> list) {
        int size = list.size();
        for (int i2 = 0; i2 < size; i2++) {
            a(list.get(i2));
        }
        list.clear();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void u() {
        t(this.f2328b);
        t(this.f2329c);
        this.f2334h = 0;
    }
}
