package s0;

import u0.b;
/* loaded from: classes.dex */
public abstract class a {
    public abstract void a(b bVar);
}
