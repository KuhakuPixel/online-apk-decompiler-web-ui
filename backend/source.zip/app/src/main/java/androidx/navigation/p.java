package androidx.navigation;
/* loaded from: classes.dex */
public final class p {

    /* renamed from: a  reason: collision with root package name */
    private boolean f2024a;

    /* renamed from: b  reason: collision with root package name */
    private int f2025b;

    /* renamed from: c  reason: collision with root package name */
    private boolean f2026c;

    /* renamed from: d  reason: collision with root package name */
    private int f2027d;

    /* renamed from: e  reason: collision with root package name */
    private int f2028e;

    /* renamed from: f  reason: collision with root package name */
    private int f2029f;

    /* renamed from: g  reason: collision with root package name */
    private int f2030g;

    /* loaded from: classes.dex */
    public static final class a {

        /* renamed from: a  reason: collision with root package name */
        boolean f2031a;

        /* renamed from: c  reason: collision with root package name */
        boolean f2033c;

        /* renamed from: b  reason: collision with root package name */
        int f2032b = -1;

        /* renamed from: d  reason: collision with root package name */
        int f2034d = -1;

        /* renamed from: e  reason: collision with root package name */
        int f2035e = -1;

        /* renamed from: f  reason: collision with root package name */
        int f2036f = -1;

        /* renamed from: g  reason: collision with root package name */
        int f2037g = -1;

        public p a() {
            return new p(this.f2031a, this.f2032b, this.f2033c, this.f2034d, this.f2035e, this.f2036f, this.f2037g);
        }

        public a b(int i2) {
            this.f2034d = i2;
            return this;
        }

        public a c(int i2) {
            this.f2035e = i2;
            return this;
        }

        public a d(boolean z2) {
            this.f2031a = z2;
            return this;
        }

        public a e(int i2) {
            this.f2036f = i2;
            return this;
        }

        public a f(int i2) {
            this.f2037g = i2;
            return this;
        }

        public a g(int i2, boolean z2) {
            this.f2032b = i2;
            this.f2033c = z2;
            return this;
        }
    }

    p(boolean z2, int i2, boolean z3, int i3, int i4, int i5, int i6) {
        this.f2024a = z2;
        this.f2025b = i2;
        this.f2026c = z3;
        this.f2027d = i3;
        this.f2028e = i4;
        this.f2029f = i5;
        this.f2030g = i6;
    }

    public int a() {
        return this.f2027d;
    }

    public int b() {
        return this.f2028e;
    }

    public int c() {
        return this.f2029f;
    }

    public int d() {
        return this.f2030g;
    }

    public int e() {
        return this.f2025b;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || p.class != obj.getClass()) {
            return false;
        }
        p pVar = (p) obj;
        return this.f2024a == pVar.f2024a && this.f2025b == pVar.f2025b && this.f2026c == pVar.f2026c && this.f2027d == pVar.f2027d && this.f2028e == pVar.f2028e && this.f2029f == pVar.f2029f && this.f2030g == pVar.f2030g;
    }

    public boolean f() {
        return this.f2026c;
    }

    public boolean g() {
        return this.f2024a;
    }

    public int hashCode() {
        return ((((((((((((g() ? 1 : 0) * 31) + e()) * 31) + (f() ? 1 : 0)) * 31) + a()) * 31) + b()) * 31) + c()) * 31) + d();
    }
}
