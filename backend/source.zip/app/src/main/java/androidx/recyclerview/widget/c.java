package androidx.recyclerview.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.view.View;
import android.view.ViewPropertyAnimator;
import androidx.recyclerview.widget.RecyclerView;
import e0.q;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
/* loaded from: classes.dex */
public class c extends m {

    /* renamed from: s  reason: collision with root package name */
    private static TimeInterpolator f2344s;

    /* renamed from: h  reason: collision with root package name */
    private ArrayList<RecyclerView.d0> f2345h = new ArrayList<>();

    /* renamed from: i  reason: collision with root package name */
    private ArrayList<RecyclerView.d0> f2346i = new ArrayList<>();

    /* renamed from: j  reason: collision with root package name */
    private ArrayList<j> f2347j = new ArrayList<>();

    /* renamed from: k  reason: collision with root package name */
    private ArrayList<i> f2348k = new ArrayList<>();

    /* renamed from: l  reason: collision with root package name */
    ArrayList<ArrayList<RecyclerView.d0>> f2349l = new ArrayList<>();

    /* renamed from: m  reason: collision with root package name */
    ArrayList<ArrayList<j>> f2350m = new ArrayList<>();

    /* renamed from: n  reason: collision with root package name */
    ArrayList<ArrayList<i>> f2351n = new ArrayList<>();

    /* renamed from: o  reason: collision with root package name */
    ArrayList<RecyclerView.d0> f2352o = new ArrayList<>();

    /* renamed from: p  reason: collision with root package name */
    ArrayList<RecyclerView.d0> f2353p = new ArrayList<>();

    /* renamed from: q  reason: collision with root package name */
    ArrayList<RecyclerView.d0> f2354q = new ArrayList<>();

    /* renamed from: r  reason: collision with root package name */
    ArrayList<RecyclerView.d0> f2355r = new ArrayList<>();

    /* loaded from: classes.dex */
    class a implements Runnable {

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ ArrayList f2356b;

        a(ArrayList arrayList) {
            this.f2356b = arrayList;
        }

        @Override // java.lang.Runnable
        public void run() {
            Iterator it = this.f2356b.iterator();
            while (it.hasNext()) {
                j jVar = (j) it.next();
                c.this.S(jVar.f2390a, jVar.f2391b, jVar.f2392c, jVar.f2393d, jVar.f2394e);
            }
            this.f2356b.clear();
            c.this.f2350m.remove(this.f2356b);
        }
    }

    /* loaded from: classes.dex */
    class b implements Runnable {

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ ArrayList f2358b;

        b(ArrayList arrayList) {
            this.f2358b = arrayList;
        }

        @Override // java.lang.Runnable
        public void run() {
            Iterator it = this.f2358b.iterator();
            while (it.hasNext()) {
                c.this.R((i) it.next());
            }
            this.f2358b.clear();
            c.this.f2351n.remove(this.f2358b);
        }
    }

    /* renamed from: androidx.recyclerview.widget.c$c  reason: collision with other inner class name */
    /* loaded from: classes.dex */
    class RunnableC0017c implements Runnable {

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ ArrayList f2360b;

        RunnableC0017c(ArrayList arrayList) {
            this.f2360b = arrayList;
        }

        @Override // java.lang.Runnable
        public void run() {
            Iterator it = this.f2360b.iterator();
            while (it.hasNext()) {
                c.this.Q((RecyclerView.d0) it.next());
            }
            this.f2360b.clear();
            c.this.f2349l.remove(this.f2360b);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public class d extends AnimatorListenerAdapter {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ RecyclerView.d0 f2362a;

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ ViewPropertyAnimator f2363b;

        /* renamed from: c  reason: collision with root package name */
        final /* synthetic */ View f2364c;

        d(RecyclerView.d0 d0Var, ViewPropertyAnimator viewPropertyAnimator, View view) {
            this.f2362a = d0Var;
            this.f2363b = viewPropertyAnimator;
            this.f2364c = view;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            this.f2363b.setListener(null);
            this.f2364c.setAlpha(1.0f);
            c.this.G(this.f2362a);
            c.this.f2354q.remove(this.f2362a);
            c.this.V();
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationStart(Animator animator) {
            c.this.H(this.f2362a);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public class e extends AnimatorListenerAdapter {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ RecyclerView.d0 f2366a;

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ View f2367b;

        /* renamed from: c  reason: collision with root package name */
        final /* synthetic */ ViewPropertyAnimator f2368c;

        e(RecyclerView.d0 d0Var, View view, ViewPropertyAnimator viewPropertyAnimator) {
            this.f2366a = d0Var;
            this.f2367b = view;
            this.f2368c = viewPropertyAnimator;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationCancel(Animator animator) {
            this.f2367b.setAlpha(1.0f);
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            this.f2368c.setListener(null);
            c.this.A(this.f2366a);
            c.this.f2352o.remove(this.f2366a);
            c.this.V();
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationStart(Animator animator) {
            c.this.B(this.f2366a);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public class f extends AnimatorListenerAdapter {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ RecyclerView.d0 f2370a;

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ int f2371b;

        /* renamed from: c  reason: collision with root package name */
        final /* synthetic */ View f2372c;

        /* renamed from: d  reason: collision with root package name */
        final /* synthetic */ int f2373d;

        /* renamed from: e  reason: collision with root package name */
        final /* synthetic */ ViewPropertyAnimator f2374e;

        f(RecyclerView.d0 d0Var, int i2, View view, int i3, ViewPropertyAnimator viewPropertyAnimator) {
            this.f2370a = d0Var;
            this.f2371b = i2;
            this.f2372c = view;
            this.f2373d = i3;
            this.f2374e = viewPropertyAnimator;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationCancel(Animator animator) {
            if (this.f2371b != 0) {
                this.f2372c.setTranslationX(0.0f);
            }
            if (this.f2373d != 0) {
                this.f2372c.setTranslationY(0.0f);
            }
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            this.f2374e.setListener(null);
            c.this.E(this.f2370a);
            c.this.f2353p.remove(this.f2370a);
            c.this.V();
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationStart(Animator animator) {
            c.this.F(this.f2370a);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public class g extends AnimatorListenerAdapter {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ i f2376a;

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ ViewPropertyAnimator f2377b;

        /* renamed from: c  reason: collision with root package name */
        final /* synthetic */ View f2378c;

        g(i iVar, ViewPropertyAnimator viewPropertyAnimator, View view) {
            this.f2376a = iVar;
            this.f2377b = viewPropertyAnimator;
            this.f2378c = view;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            this.f2377b.setListener(null);
            this.f2378c.setAlpha(1.0f);
            this.f2378c.setTranslationX(0.0f);
            this.f2378c.setTranslationY(0.0f);
            c.this.C(this.f2376a.f2384a, true);
            c.this.f2355r.remove(this.f2376a.f2384a);
            c.this.V();
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationStart(Animator animator) {
            c.this.D(this.f2376a.f2384a, true);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public class h extends AnimatorListenerAdapter {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ i f2380a;

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ ViewPropertyAnimator f2381b;

        /* renamed from: c  reason: collision with root package name */
        final /* synthetic */ View f2382c;

        h(i iVar, ViewPropertyAnimator viewPropertyAnimator, View view) {
            this.f2380a = iVar;
            this.f2381b = viewPropertyAnimator;
            this.f2382c = view;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            this.f2381b.setListener(null);
            this.f2382c.setAlpha(1.0f);
            this.f2382c.setTranslationX(0.0f);
            this.f2382c.setTranslationY(0.0f);
            c.this.C(this.f2380a.f2385b, false);
            c.this.f2355r.remove(this.f2380a.f2385b);
            c.this.V();
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationStart(Animator animator) {
            c.this.D(this.f2380a.f2385b, false);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public static class i {

        /* renamed from: a  reason: collision with root package name */
        public RecyclerView.d0 f2384a;

        /* renamed from: b  reason: collision with root package name */
        public RecyclerView.d0 f2385b;

        /* renamed from: c  reason: collision with root package name */
        public int f2386c;

        /* renamed from: d  reason: collision with root package name */
        public int f2387d;

        /* renamed from: e  reason: collision with root package name */
        public int f2388e;

        /* renamed from: f  reason: collision with root package name */
        public int f2389f;

        private i(RecyclerView.d0 d0Var, RecyclerView.d0 d0Var2) {
            this.f2384a = d0Var;
            this.f2385b = d0Var2;
        }

        i(RecyclerView.d0 d0Var, RecyclerView.d0 d0Var2, int i2, int i3, int i4, int i5) {
            this(d0Var, d0Var2);
            this.f2386c = i2;
            this.f2387d = i3;
            this.f2388e = i4;
            this.f2389f = i5;
        }

        public String toString() {
            return "ChangeInfo{oldHolder=" + this.f2384a + ", newHolder=" + this.f2385b + ", fromX=" + this.f2386c + ", fromY=" + this.f2387d + ", toX=" + this.f2388e + ", toY=" + this.f2389f + '}';
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public static class j {

        /* renamed from: a  reason: collision with root package name */
        public RecyclerView.d0 f2390a;

        /* renamed from: b  reason: collision with root package name */
        public int f2391b;

        /* renamed from: c  reason: collision with root package name */
        public int f2392c;

        /* renamed from: d  reason: collision with root package name */
        public int f2393d;

        /* renamed from: e  reason: collision with root package name */
        public int f2394e;

        j(RecyclerView.d0 d0Var, int i2, int i3, int i4, int i5) {
            this.f2390a = d0Var;
            this.f2391b = i2;
            this.f2392c = i3;
            this.f2393d = i4;
            this.f2394e = i5;
        }
    }

    private void T(RecyclerView.d0 d0Var) {
        View view = d0Var.f2195a;
        ViewPropertyAnimator animate = view.animate();
        this.f2354q.add(d0Var);
        animate.setDuration(o()).alpha(0.0f).setListener(new d(d0Var, animate, view)).start();
    }

    private void W(List<i> list, RecyclerView.d0 d0Var) {
        for (int size = list.size() - 1; size >= 0; size--) {
            i iVar = list.get(size);
            if (Y(iVar, d0Var) && iVar.f2384a == null && iVar.f2385b == null) {
                list.remove(iVar);
            }
        }
    }

    private void X(i iVar) {
        RecyclerView.d0 d0Var = iVar.f2384a;
        if (d0Var != null) {
            Y(iVar, d0Var);
        }
        RecyclerView.d0 d0Var2 = iVar.f2385b;
        if (d0Var2 != null) {
            Y(iVar, d0Var2);
        }
    }

    private boolean Y(i iVar, RecyclerView.d0 d0Var) {
        boolean z2 = false;
        if (iVar.f2385b == d0Var) {
            iVar.f2385b = null;
        } else if (iVar.f2384a != d0Var) {
            return false;
        } else {
            iVar.f2384a = null;
            z2 = true;
        }
        d0Var.f2195a.setAlpha(1.0f);
        d0Var.f2195a.setTranslationX(0.0f);
        d0Var.f2195a.setTranslationY(0.0f);
        C(d0Var, z2);
        return true;
    }

    private void Z(RecyclerView.d0 d0Var) {
        if (f2344s == null) {
            f2344s = new ValueAnimator().getInterpolator();
        }
        d0Var.f2195a.animate().setInterpolator(f2344s);
        j(d0Var);
    }

    void Q(RecyclerView.d0 d0Var) {
        View view = d0Var.f2195a;
        ViewPropertyAnimator animate = view.animate();
        this.f2352o.add(d0Var);
        animate.alpha(1.0f).setDuration(l()).setListener(new e(d0Var, view, animate)).start();
    }

    void R(i iVar) {
        RecyclerView.d0 d0Var = iVar.f2384a;
        View view = d0Var == null ? null : d0Var.f2195a;
        RecyclerView.d0 d0Var2 = iVar.f2385b;
        View view2 = d0Var2 != null ? d0Var2.f2195a : null;
        if (view != null) {
            ViewPropertyAnimator duration = view.animate().setDuration(m());
            this.f2355r.add(iVar.f2384a);
            duration.translationX(iVar.f2388e - iVar.f2386c);
            duration.translationY(iVar.f2389f - iVar.f2387d);
            duration.alpha(0.0f).setListener(new g(iVar, duration, view)).start();
        }
        if (view2 != null) {
            ViewPropertyAnimator animate = view2.animate();
            this.f2355r.add(iVar.f2385b);
            animate.translationX(0.0f).translationY(0.0f).setDuration(m()).alpha(1.0f).setListener(new h(iVar, animate, view2)).start();
        }
    }

    void S(RecyclerView.d0 d0Var, int i2, int i3, int i4, int i5) {
        View view = d0Var.f2195a;
        int i6 = i4 - i2;
        int i7 = i5 - i3;
        if (i6 != 0) {
            view.animate().translationX(0.0f);
        }
        if (i7 != 0) {
            view.animate().translationY(0.0f);
        }
        ViewPropertyAnimator animate = view.animate();
        this.f2353p.add(d0Var);
        animate.setDuration(n()).setListener(new f(d0Var, i6, view, i7, animate)).start();
    }

    void U(List<RecyclerView.d0> list) {
        for (int size = list.size() - 1; size >= 0; size--) {
            list.get(size).f2195a.animate().cancel();
        }
    }

    void V() {
        if (p()) {
            return;
        }
        i();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.l
    public boolean g(RecyclerView.d0 d0Var, List<Object> list) {
        return !list.isEmpty() || super.g(d0Var, list);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.l
    public void j(RecyclerView.d0 d0Var) {
        View view = d0Var.f2195a;
        view.animate().cancel();
        int size = this.f2347j.size();
        while (true) {
            size--;
            if (size < 0) {
                break;
            } else if (this.f2347j.get(size).f2390a == d0Var) {
                view.setTranslationY(0.0f);
                view.setTranslationX(0.0f);
                E(d0Var);
                this.f2347j.remove(size);
            }
        }
        W(this.f2348k, d0Var);
        if (this.f2345h.remove(d0Var)) {
            view.setAlpha(1.0f);
            G(d0Var);
        }
        if (this.f2346i.remove(d0Var)) {
            view.setAlpha(1.0f);
            A(d0Var);
        }
        for (int size2 = this.f2351n.size() - 1; size2 >= 0; size2--) {
            ArrayList<i> arrayList = this.f2351n.get(size2);
            W(arrayList, d0Var);
            if (arrayList.isEmpty()) {
                this.f2351n.remove(size2);
            }
        }
        for (int size3 = this.f2350m.size() - 1; size3 >= 0; size3--) {
            ArrayList<j> arrayList2 = this.f2350m.get(size3);
            int size4 = arrayList2.size() - 1;
            while (true) {
                if (size4 < 0) {
                    break;
                } else if (arrayList2.get(size4).f2390a == d0Var) {
                    view.setTranslationY(0.0f);
                    view.setTranslationX(0.0f);
                    E(d0Var);
                    arrayList2.remove(size4);
                    if (arrayList2.isEmpty()) {
                        this.f2350m.remove(size3);
                    }
                } else {
                    size4--;
                }
            }
        }
        for (int size5 = this.f2349l.size() - 1; size5 >= 0; size5--) {
            ArrayList<RecyclerView.d0> arrayList3 = this.f2349l.get(size5);
            if (arrayList3.remove(d0Var)) {
                view.setAlpha(1.0f);
                A(d0Var);
                if (arrayList3.isEmpty()) {
                    this.f2349l.remove(size5);
                }
            }
        }
        this.f2354q.remove(d0Var);
        this.f2352o.remove(d0Var);
        this.f2355r.remove(d0Var);
        this.f2353p.remove(d0Var);
        V();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.l
    public void k() {
        int size = this.f2347j.size();
        while (true) {
            size--;
            if (size < 0) {
                break;
            }
            j jVar = this.f2347j.get(size);
            View view = jVar.f2390a.f2195a;
            view.setTranslationY(0.0f);
            view.setTranslationX(0.0f);
            E(jVar.f2390a);
            this.f2347j.remove(size);
        }
        for (int size2 = this.f2345h.size() - 1; size2 >= 0; size2--) {
            G(this.f2345h.get(size2));
            this.f2345h.remove(size2);
        }
        int size3 = this.f2346i.size();
        while (true) {
            size3--;
            if (size3 < 0) {
                break;
            }
            RecyclerView.d0 d0Var = this.f2346i.get(size3);
            d0Var.f2195a.setAlpha(1.0f);
            A(d0Var);
            this.f2346i.remove(size3);
        }
        for (int size4 = this.f2348k.size() - 1; size4 >= 0; size4--) {
            X(this.f2348k.get(size4));
        }
        this.f2348k.clear();
        if (p()) {
            for (int size5 = this.f2350m.size() - 1; size5 >= 0; size5--) {
                ArrayList<j> arrayList = this.f2350m.get(size5);
                for (int size6 = arrayList.size() - 1; size6 >= 0; size6--) {
                    j jVar2 = arrayList.get(size6);
                    View view2 = jVar2.f2390a.f2195a;
                    view2.setTranslationY(0.0f);
                    view2.setTranslationX(0.0f);
                    E(jVar2.f2390a);
                    arrayList.remove(size6);
                    if (arrayList.isEmpty()) {
                        this.f2350m.remove(arrayList);
                    }
                }
            }
            for (int size7 = this.f2349l.size() - 1; size7 >= 0; size7--) {
                ArrayList<RecyclerView.d0> arrayList2 = this.f2349l.get(size7);
                for (int size8 = arrayList2.size() - 1; size8 >= 0; size8--) {
                    RecyclerView.d0 d0Var2 = arrayList2.get(size8);
                    d0Var2.f2195a.setAlpha(1.0f);
                    A(d0Var2);
                    arrayList2.remove(size8);
                    if (arrayList2.isEmpty()) {
                        this.f2349l.remove(arrayList2);
                    }
                }
            }
            for (int size9 = this.f2351n.size() - 1; size9 >= 0; size9--) {
                ArrayList<i> arrayList3 = this.f2351n.get(size9);
                for (int size10 = arrayList3.size() - 1; size10 >= 0; size10--) {
                    X(arrayList3.get(size10));
                    if (arrayList3.isEmpty()) {
                        this.f2351n.remove(arrayList3);
                    }
                }
            }
            U(this.f2354q);
            U(this.f2353p);
            U(this.f2352o);
            U(this.f2355r);
            i();
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.l
    public boolean p() {
        return (this.f2346i.isEmpty() && this.f2348k.isEmpty() && this.f2347j.isEmpty() && this.f2345h.isEmpty() && this.f2353p.isEmpty() && this.f2354q.isEmpty() && this.f2352o.isEmpty() && this.f2355r.isEmpty() && this.f2350m.isEmpty() && this.f2349l.isEmpty() && this.f2351n.isEmpty()) ? false : true;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.l
    public void u() {
        boolean z2 = !this.f2345h.isEmpty();
        boolean z3 = !this.f2347j.isEmpty();
        boolean z4 = !this.f2348k.isEmpty();
        boolean z5 = !this.f2346i.isEmpty();
        if (z2 || z3 || z5 || z4) {
            Iterator<RecyclerView.d0> it = this.f2345h.iterator();
            while (it.hasNext()) {
                T(it.next());
            }
            this.f2345h.clear();
            if (z3) {
                ArrayList<j> arrayList = new ArrayList<>();
                arrayList.addAll(this.f2347j);
                this.f2350m.add(arrayList);
                this.f2347j.clear();
                a aVar = new a(arrayList);
                if (z2) {
                    q.d0(arrayList.get(0).f2390a.f2195a, aVar, o());
                } else {
                    aVar.run();
                }
            }
            if (z4) {
                ArrayList<i> arrayList2 = new ArrayList<>();
                arrayList2.addAll(this.f2348k);
                this.f2351n.add(arrayList2);
                this.f2348k.clear();
                b bVar = new b(arrayList2);
                if (z2) {
                    q.d0(arrayList2.get(0).f2384a.f2195a, bVar, o());
                } else {
                    bVar.run();
                }
            }
            if (z5) {
                ArrayList<RecyclerView.d0> arrayList3 = new ArrayList<>();
                arrayList3.addAll(this.f2346i);
                this.f2349l.add(arrayList3);
                this.f2346i.clear();
                RunnableC0017c runnableC0017c = new RunnableC0017c(arrayList3);
                if (z2 || z3 || z4) {
                    q.d0(arrayList3.get(0).f2195a, runnableC0017c, (z2 ? o() : 0L) + Math.max(z3 ? n() : 0L, z4 ? m() : 0L));
                } else {
                    runnableC0017c.run();
                }
            }
        }
    }

    @Override // androidx.recyclerview.widget.m
    public boolean w(RecyclerView.d0 d0Var) {
        Z(d0Var);
        d0Var.f2195a.setAlpha(0.0f);
        this.f2346i.add(d0Var);
        return true;
    }

    @Override // androidx.recyclerview.widget.m
    public boolean x(RecyclerView.d0 d0Var, RecyclerView.d0 d0Var2, int i2, int i3, int i4, int i5) {
        if (d0Var == d0Var2) {
            return y(d0Var, i2, i3, i4, i5);
        }
        float translationX = d0Var.f2195a.getTranslationX();
        float translationY = d0Var.f2195a.getTranslationY();
        float alpha = d0Var.f2195a.getAlpha();
        Z(d0Var);
        int i6 = (int) ((i4 - i2) - translationX);
        int i7 = (int) ((i5 - i3) - translationY);
        d0Var.f2195a.setTranslationX(translationX);
        d0Var.f2195a.setTranslationY(translationY);
        d0Var.f2195a.setAlpha(alpha);
        if (d0Var2 != null) {
            Z(d0Var2);
            d0Var2.f2195a.setTranslationX(-i6);
            d0Var2.f2195a.setTranslationY(-i7);
            d0Var2.f2195a.setAlpha(0.0f);
        }
        this.f2348k.add(new i(d0Var, d0Var2, i2, i3, i4, i5));
        return true;
    }

    @Override // androidx.recyclerview.widget.m
    public boolean y(RecyclerView.d0 d0Var, int i2, int i3, int i4, int i5) {
        View view = d0Var.f2195a;
        int translationX = i2 + ((int) view.getTranslationX());
        int translationY = i3 + ((int) d0Var.f2195a.getTranslationY());
        Z(d0Var);
        int i6 = i4 - translationX;
        int i7 = i5 - translationY;
        if (i6 == 0 && i7 == 0) {
            E(d0Var);
            return false;
        }
        if (i6 != 0) {
            view.setTranslationX(-i6);
        }
        if (i7 != 0) {
            view.setTranslationY(-i7);
        }
        this.f2347j.add(new j(d0Var, translationX, translationY, i4, i5));
        return true;
    }

    @Override // androidx.recyclerview.widget.m
    public boolean z(RecyclerView.d0 d0Var) {
        Z(d0Var);
        this.f2345h.add(d0Var);
        return true;
    }
}
