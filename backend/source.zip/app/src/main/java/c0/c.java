package c0;
/* loaded from: classes.dex */
public interface c {
    boolean a(CharSequence charSequence, int i2, int i3);
}
