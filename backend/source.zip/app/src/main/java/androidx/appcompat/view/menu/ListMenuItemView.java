package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import androidx.appcompat.view.menu.k;
import androidx.appcompat.widget.t0;
import e0.q;
/* loaded from: classes.dex */
public class ListMenuItemView extends LinearLayout implements k.a, AbsListView.SelectionBoundsAdjuster {

    /* renamed from: b  reason: collision with root package name */
    private g f309b;

    /* renamed from: c  reason: collision with root package name */
    private ImageView f310c;

    /* renamed from: d  reason: collision with root package name */
    private RadioButton f311d;

    /* renamed from: e  reason: collision with root package name */
    private TextView f312e;

    /* renamed from: f  reason: collision with root package name */
    private CheckBox f313f;

    /* renamed from: g  reason: collision with root package name */
    private TextView f314g;

    /* renamed from: h  reason: collision with root package name */
    private ImageView f315h;

    /* renamed from: i  reason: collision with root package name */
    private ImageView f316i;

    /* renamed from: j  reason: collision with root package name */
    private LinearLayout f317j;

    /* renamed from: k  reason: collision with root package name */
    private Drawable f318k;

    /* renamed from: l  reason: collision with root package name */
    private int f319l;

    /* renamed from: m  reason: collision with root package name */
    private Context f320m;

    /* renamed from: n  reason: collision with root package name */
    private boolean f321n;

    /* renamed from: o  reason: collision with root package name */
    private Drawable f322o;

    /* renamed from: p  reason: collision with root package name */
    private boolean f323p;

    /* renamed from: q  reason: collision with root package name */
    private LayoutInflater f324q;

    /* renamed from: r  reason: collision with root package name */
    private boolean f325r;

    public ListMenuItemView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, a.a.listMenuViewStyle);
    }

    public ListMenuItemView(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet);
        t0 v2 = t0.v(getContext(), attributeSet, a.j.e2, i2, 0);
        this.f318k = v2.g(a.j.g2);
        this.f319l = v2.n(a.j.f2, -1);
        this.f321n = v2.a(a.j.h2, false);
        this.f320m = context;
        this.f322o = v2.g(a.j.i2);
        TypedArray obtainStyledAttributes = context.getTheme().obtainStyledAttributes(null, new int[]{16843049}, a.a.dropDownListViewStyle, 0);
        this.f323p = obtainStyledAttributes.hasValue(0);
        v2.w();
        obtainStyledAttributes.recycle();
    }

    private void a(View view) {
        b(view, -1);
    }

    private void b(View view, int i2) {
        LinearLayout linearLayout = this.f317j;
        if (linearLayout != null) {
            linearLayout.addView(view, i2);
        } else {
            addView(view, i2);
        }
    }

    private void c() {
        CheckBox checkBox = (CheckBox) getInflater().inflate(a.g.abc_list_menu_item_checkbox, (ViewGroup) this, false);
        this.f313f = checkBox;
        a(checkBox);
    }

    private void f() {
        ImageView imageView = (ImageView) getInflater().inflate(a.g.abc_list_menu_item_icon, (ViewGroup) this, false);
        this.f310c = imageView;
        b(imageView, 0);
    }

    private void g() {
        RadioButton radioButton = (RadioButton) getInflater().inflate(a.g.abc_list_menu_item_radio, (ViewGroup) this, false);
        this.f311d = radioButton;
        a(radioButton);
    }

    private LayoutInflater getInflater() {
        if (this.f324q == null) {
            this.f324q = LayoutInflater.from(getContext());
        }
        return this.f324q;
    }

    private void setSubMenuArrowVisible(boolean z2) {
        ImageView imageView = this.f315h;
        if (imageView != null) {
            imageView.setVisibility(z2 ? 0 : 8);
        }
    }

    @Override // android.widget.AbsListView.SelectionBoundsAdjuster
    public void adjustListItemSelectionBounds(Rect rect) {
        ImageView imageView = this.f316i;
        if (imageView == null || imageView.getVisibility() != 0) {
            return;
        }
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) this.f316i.getLayoutParams();
        rect.top += this.f316i.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
    }

    @Override // androidx.appcompat.view.menu.k.a
    public boolean d() {
        return false;
    }

    @Override // androidx.appcompat.view.menu.k.a
    public void e(g gVar, int i2) {
        this.f309b = gVar;
        setVisibility(gVar.isVisible() ? 0 : 8);
        setTitle(gVar.i(this));
        setCheckable(gVar.isCheckable());
        h(gVar.A(), gVar.g());
        setIcon(gVar.getIcon());
        setEnabled(gVar.isEnabled());
        setSubMenuArrowVisible(gVar.hasSubMenu());
        setContentDescription(gVar.getContentDescription());
    }

    @Override // androidx.appcompat.view.menu.k.a
    public g getItemData() {
        return this.f309b;
    }

    public void h(boolean z2, char c2) {
        int i2 = (z2 && this.f309b.A()) ? 0 : 8;
        if (i2 == 0) {
            this.f314g.setText(this.f309b.h());
        }
        if (this.f314g.getVisibility() != i2) {
            this.f314g.setVisibility(i2);
        }
    }

    @Override // android.view.View
    protected void onFinishInflate() {
        super.onFinishInflate();
        q.n0(this, this.f318k);
        TextView textView = (TextView) findViewById(a.f.title);
        this.f312e = textView;
        int i2 = this.f319l;
        if (i2 != -1) {
            textView.setTextAppearance(this.f320m, i2);
        }
        this.f314g = (TextView) findViewById(a.f.shortcut);
        ImageView imageView = (ImageView) findViewById(a.f.submenuarrow);
        this.f315h = imageView;
        if (imageView != null) {
            imageView.setImageDrawable(this.f322o);
        }
        this.f316i = (ImageView) findViewById(a.f.group_divider);
        this.f317j = (LinearLayout) findViewById(a.f.content);
    }

    @Override // android.widget.LinearLayout, android.view.View
    protected void onMeasure(int i2, int i3) {
        if (this.f310c != null && this.f321n) {
            ViewGroup.LayoutParams layoutParams = getLayoutParams();
            LinearLayout.LayoutParams layoutParams2 = (LinearLayout.LayoutParams) this.f310c.getLayoutParams();
            int i4 = layoutParams.height;
            if (i4 > 0 && layoutParams2.width <= 0) {
                layoutParams2.width = i4;
            }
        }
        super.onMeasure(i2, i3);
    }

    public void setCheckable(boolean z2) {
        CompoundButton compoundButton;
        CompoundButton compoundButton2;
        if (!z2 && this.f311d == null && this.f313f == null) {
            return;
        }
        if (this.f309b.m()) {
            if (this.f311d == null) {
                g();
            }
            compoundButton = this.f311d;
            compoundButton2 = this.f313f;
        } else {
            if (this.f313f == null) {
                c();
            }
            compoundButton = this.f313f;
            compoundButton2 = this.f311d;
        }
        if (z2) {
            compoundButton.setChecked(this.f309b.isChecked());
            if (compoundButton.getVisibility() != 0) {
                compoundButton.setVisibility(0);
            }
            if (compoundButton2 == null || compoundButton2.getVisibility() == 8) {
                return;
            }
            compoundButton2.setVisibility(8);
            return;
        }
        CheckBox checkBox = this.f313f;
        if (checkBox != null) {
            checkBox.setVisibility(8);
        }
        RadioButton radioButton = this.f311d;
        if (radioButton != null) {
            radioButton.setVisibility(8);
        }
    }

    public void setChecked(boolean z2) {
        CompoundButton compoundButton;
        if (this.f309b.m()) {
            if (this.f311d == null) {
                g();
            }
            compoundButton = this.f311d;
        } else {
            if (this.f313f == null) {
                c();
            }
            compoundButton = this.f313f;
        }
        compoundButton.setChecked(z2);
    }

    public void setForceShowIcon(boolean z2) {
        this.f325r = z2;
        this.f321n = z2;
    }

    public void setGroupDividerEnabled(boolean z2) {
        ImageView imageView = this.f316i;
        if (imageView != null) {
            imageView.setVisibility((this.f323p || !z2) ? 8 : 0);
        }
    }

    public void setIcon(Drawable drawable) {
        boolean z2 = this.f309b.z() || this.f325r;
        if (z2 || this.f321n) {
            ImageView imageView = this.f310c;
            if (imageView == null && drawable == null && !this.f321n) {
                return;
            }
            if (imageView == null) {
                f();
            }
            if (drawable == null && !this.f321n) {
                this.f310c.setVisibility(8);
                return;
            }
            ImageView imageView2 = this.f310c;
            if (!z2) {
                drawable = null;
            }
            imageView2.setImageDrawable(drawable);
            if (this.f310c.getVisibility() != 0) {
                this.f310c.setVisibility(0);
            }
        }
    }

    public void setTitle(CharSequence charSequence) {
        int i2;
        TextView textView;
        if (charSequence != null) {
            this.f312e.setText(charSequence);
            if (this.f312e.getVisibility() == 0) {
                return;
            }
            textView = this.f312e;
            i2 = 0;
        } else {
            i2 = 8;
            if (this.f312e.getVisibility() == 8) {
                return;
            }
            textView = this.f312e;
        }
        textView.setVisibility(i2);
    }
}
