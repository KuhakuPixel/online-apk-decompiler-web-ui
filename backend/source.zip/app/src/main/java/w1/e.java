package w1;

import android.view.View;
import androidx.databinding.ViewDataBinding;
import androidx.recyclerview.widget.RecyclerView;
/* loaded from: classes.dex */
public abstract class e extends ViewDataBinding {
    public final RecyclerView B;
    protected u1.d C;

    /* JADX INFO: Access modifiers changed from: protected */
    public e(Object obj, View view, int i2, RecyclerView recyclerView) {
        super(obj, view, i2);
        this.B = recyclerView;
    }

    public abstract void H(u1.d dVar);
}
