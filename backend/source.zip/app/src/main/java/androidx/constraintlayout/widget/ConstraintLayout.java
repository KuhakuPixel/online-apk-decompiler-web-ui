package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.HashMap;
import p.e;
import q.b;
/* loaded from: classes.dex */
public class ConstraintLayout extends ViewGroup {

    /* renamed from: b  reason: collision with root package name */
    SparseArray<View> f1049b;

    /* renamed from: c  reason: collision with root package name */
    private ArrayList<androidx.constraintlayout.widget.b> f1050c;

    /* renamed from: d  reason: collision with root package name */
    protected p.f f1051d;

    /* renamed from: e  reason: collision with root package name */
    private int f1052e;

    /* renamed from: f  reason: collision with root package name */
    private int f1053f;

    /* renamed from: g  reason: collision with root package name */
    private int f1054g;

    /* renamed from: h  reason: collision with root package name */
    private int f1055h;

    /* renamed from: i  reason: collision with root package name */
    protected boolean f1056i;

    /* renamed from: j  reason: collision with root package name */
    private int f1057j;

    /* renamed from: k  reason: collision with root package name */
    private d f1058k;

    /* renamed from: l  reason: collision with root package name */
    protected androidx.constraintlayout.widget.c f1059l;

    /* renamed from: m  reason: collision with root package name */
    private int f1060m;

    /* renamed from: n  reason: collision with root package name */
    private HashMap<String, Integer> f1061n;

    /* renamed from: o  reason: collision with root package name */
    private int f1062o;

    /* renamed from: p  reason: collision with root package name */
    private int f1063p;

    /* renamed from: q  reason: collision with root package name */
    int f1064q;

    /* renamed from: r  reason: collision with root package name */
    int f1065r;

    /* renamed from: s  reason: collision with root package name */
    int f1066s;

    /* renamed from: t  reason: collision with root package name */
    int f1067t;

    /* renamed from: u  reason: collision with root package name */
    private SparseArray<p.e> f1068u;

    /* renamed from: v  reason: collision with root package name */
    c f1069v;

    /* renamed from: w  reason: collision with root package name */
    private int f1070w;

    /* renamed from: x  reason: collision with root package name */
    private int f1071x;

    /* loaded from: classes.dex */
    static /* synthetic */ class a {

        /* renamed from: a  reason: collision with root package name */
        static final /* synthetic */ int[] f1072a;

        static {
            int[] iArr = new int[e.b.values().length];
            f1072a = iArr;
            try {
                iArr[e.b.FIXED.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                f1072a[e.b.WRAP_CONTENT.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                f1072a[e.b.MATCH_PARENT.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                f1072a[e.b.MATCH_CONSTRAINT.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
        }
    }

    /* loaded from: classes.dex */
    public static class b extends ViewGroup.MarginLayoutParams {
        public float A;
        public String B;
        float C;
        int D;
        public float E;
        public float F;
        public int G;
        public int H;
        public int I;
        public int J;
        public int K;
        public int L;
        public int M;
        public int N;
        public float O;
        public float P;
        public int Q;
        public int R;
        public int S;
        public boolean T;
        public boolean U;
        public String V;
        boolean W;
        boolean X;
        boolean Y;
        boolean Z;

        /* renamed from: a  reason: collision with root package name */
        public int f1073a;

        /* renamed from: a0  reason: collision with root package name */
        boolean f1074a0;

        /* renamed from: b  reason: collision with root package name */
        public int f1075b;

        /* renamed from: b0  reason: collision with root package name */
        boolean f1076b0;

        /* renamed from: c  reason: collision with root package name */
        public float f1077c;

        /* renamed from: c0  reason: collision with root package name */
        boolean f1078c0;

        /* renamed from: d  reason: collision with root package name */
        public int f1079d;

        /* renamed from: d0  reason: collision with root package name */
        int f1080d0;

        /* renamed from: e  reason: collision with root package name */
        public int f1081e;

        /* renamed from: e0  reason: collision with root package name */
        int f1082e0;

        /* renamed from: f  reason: collision with root package name */
        public int f1083f;

        /* renamed from: f0  reason: collision with root package name */
        int f1084f0;

        /* renamed from: g  reason: collision with root package name */
        public int f1085g;

        /* renamed from: g0  reason: collision with root package name */
        int f1086g0;

        /* renamed from: h  reason: collision with root package name */
        public int f1087h;

        /* renamed from: h0  reason: collision with root package name */
        int f1088h0;

        /* renamed from: i  reason: collision with root package name */
        public int f1089i;

        /* renamed from: i0  reason: collision with root package name */
        int f1090i0;

        /* renamed from: j  reason: collision with root package name */
        public int f1091j;

        /* renamed from: j0  reason: collision with root package name */
        float f1092j0;

        /* renamed from: k  reason: collision with root package name */
        public int f1093k;

        /* renamed from: k0  reason: collision with root package name */
        int f1094k0;

        /* renamed from: l  reason: collision with root package name */
        public int f1095l;

        /* renamed from: l0  reason: collision with root package name */
        int f1096l0;

        /* renamed from: m  reason: collision with root package name */
        public int f1097m;

        /* renamed from: m0  reason: collision with root package name */
        float f1098m0;

        /* renamed from: n  reason: collision with root package name */
        public int f1099n;

        /* renamed from: n0  reason: collision with root package name */
        p.e f1100n0;

        /* renamed from: o  reason: collision with root package name */
        public float f1101o;

        /* renamed from: o0  reason: collision with root package name */
        public boolean f1102o0;

        /* renamed from: p  reason: collision with root package name */
        public int f1103p;

        /* renamed from: q  reason: collision with root package name */
        public int f1104q;

        /* renamed from: r  reason: collision with root package name */
        public int f1105r;

        /* renamed from: s  reason: collision with root package name */
        public int f1106s;

        /* renamed from: t  reason: collision with root package name */
        public int f1107t;

        /* renamed from: u  reason: collision with root package name */
        public int f1108u;

        /* renamed from: v  reason: collision with root package name */
        public int f1109v;

        /* renamed from: w  reason: collision with root package name */
        public int f1110w;

        /* renamed from: x  reason: collision with root package name */
        public int f1111x;

        /* renamed from: y  reason: collision with root package name */
        public int f1112y;

        /* renamed from: z  reason: collision with root package name */
        public float f1113z;

        /* loaded from: classes.dex */
        private static class a {

            /* renamed from: a  reason: collision with root package name */
            public static final SparseIntArray f1114a;

            static {
                SparseIntArray sparseIntArray = new SparseIntArray();
                f1114a = sparseIntArray;
                sparseIntArray.append(i.N1, 8);
                sparseIntArray.append(i.O1, 9);
                sparseIntArray.append(i.Q1, 10);
                sparseIntArray.append(i.R1, 11);
                sparseIntArray.append(i.X1, 12);
                sparseIntArray.append(i.W1, 13);
                sparseIntArray.append(i.f1318v1, 14);
                sparseIntArray.append(i.f1315u1, 15);
                sparseIntArray.append(i.f1309s1, 16);
                sparseIntArray.append(i.f1321w1, 2);
                sparseIntArray.append(i.f1327y1, 3);
                sparseIntArray.append(i.f1324x1, 4);
                sparseIntArray.append(i.f2, 49);
                sparseIntArray.append(i.g2, 50);
                sparseIntArray.append(i.C1, 5);
                sparseIntArray.append(i.D1, 6);
                sparseIntArray.append(i.E1, 7);
                sparseIntArray.append(i.f1258b1, 1);
                sparseIntArray.append(i.S1, 17);
                sparseIntArray.append(i.T1, 18);
                sparseIntArray.append(i.B1, 19);
                sparseIntArray.append(i.A1, 20);
                sparseIntArray.append(i.j2, 21);
                sparseIntArray.append(i.m2, 22);
                sparseIntArray.append(i.k2, 23);
                sparseIntArray.append(i.h2, 24);
                sparseIntArray.append(i.l2, 25);
                sparseIntArray.append(i.i2, 26);
                sparseIntArray.append(i.J1, 29);
                sparseIntArray.append(i.Y1, 30);
                sparseIntArray.append(i.f1330z1, 44);
                sparseIntArray.append(i.L1, 45);
                sparseIntArray.append(i.a2, 46);
                sparseIntArray.append(i.K1, 47);
                sparseIntArray.append(i.Z1, 48);
                sparseIntArray.append(i.f1303q1, 27);
                sparseIntArray.append(i.f1300p1, 28);
                sparseIntArray.append(i.b2, 31);
                sparseIntArray.append(i.F1, 32);
                sparseIntArray.append(i.d2, 33);
                sparseIntArray.append(i.c2, 34);
                sparseIntArray.append(i.e2, 35);
                sparseIntArray.append(i.H1, 36);
                sparseIntArray.append(i.G1, 37);
                sparseIntArray.append(i.I1, 38);
                sparseIntArray.append(i.M1, 39);
                sparseIntArray.append(i.V1, 40);
                sparseIntArray.append(i.P1, 41);
                sparseIntArray.append(i.f1312t1, 42);
                sparseIntArray.append(i.f1306r1, 43);
                sparseIntArray.append(i.U1, 51);
            }
        }

        public b(int i2, int i3) {
            super(i2, i3);
            this.f1073a = -1;
            this.f1075b = -1;
            this.f1077c = -1.0f;
            this.f1079d = -1;
            this.f1081e = -1;
            this.f1083f = -1;
            this.f1085g = -1;
            this.f1087h = -1;
            this.f1089i = -1;
            this.f1091j = -1;
            this.f1093k = -1;
            this.f1095l = -1;
            this.f1097m = -1;
            this.f1099n = 0;
            this.f1101o = 0.0f;
            this.f1103p = -1;
            this.f1104q = -1;
            this.f1105r = -1;
            this.f1106s = -1;
            this.f1107t = -1;
            this.f1108u = -1;
            this.f1109v = -1;
            this.f1110w = -1;
            this.f1111x = -1;
            this.f1112y = -1;
            this.f1113z = 0.5f;
            this.A = 0.5f;
            this.B = null;
            this.C = 0.0f;
            this.D = 1;
            this.E = -1.0f;
            this.F = -1.0f;
            this.G = 0;
            this.H = 0;
            this.I = 0;
            this.J = 0;
            this.K = 0;
            this.L = 0;
            this.M = 0;
            this.N = 0;
            this.O = 1.0f;
            this.P = 1.0f;
            this.Q = -1;
            this.R = -1;
            this.S = -1;
            this.T = false;
            this.U = false;
            this.V = null;
            this.W = true;
            this.X = true;
            this.Y = false;
            this.Z = false;
            this.f1074a0 = false;
            this.f1076b0 = false;
            this.f1078c0 = false;
            this.f1080d0 = -1;
            this.f1082e0 = -1;
            this.f1084f0 = -1;
            this.f1086g0 = -1;
            this.f1088h0 = -1;
            this.f1090i0 = -1;
            this.f1092j0 = 0.5f;
            this.f1100n0 = new p.e();
            this.f1102o0 = false;
        }

        public b(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            String str;
            int i2;
            float parseFloat;
            this.f1073a = -1;
            this.f1075b = -1;
            this.f1077c = -1.0f;
            this.f1079d = -1;
            this.f1081e = -1;
            this.f1083f = -1;
            this.f1085g = -1;
            this.f1087h = -1;
            this.f1089i = -1;
            this.f1091j = -1;
            this.f1093k = -1;
            this.f1095l = -1;
            this.f1097m = -1;
            this.f1099n = 0;
            this.f1101o = 0.0f;
            this.f1103p = -1;
            this.f1104q = -1;
            this.f1105r = -1;
            this.f1106s = -1;
            this.f1107t = -1;
            this.f1108u = -1;
            this.f1109v = -1;
            this.f1110w = -1;
            this.f1111x = -1;
            this.f1112y = -1;
            this.f1113z = 0.5f;
            this.A = 0.5f;
            this.B = null;
            this.C = 0.0f;
            this.D = 1;
            this.E = -1.0f;
            this.F = -1.0f;
            this.G = 0;
            this.H = 0;
            this.I = 0;
            this.J = 0;
            this.K = 0;
            this.L = 0;
            this.M = 0;
            this.N = 0;
            this.O = 1.0f;
            this.P = 1.0f;
            this.Q = -1;
            this.R = -1;
            this.S = -1;
            this.T = false;
            this.U = false;
            this.V = null;
            this.W = true;
            this.X = true;
            this.Y = false;
            this.Z = false;
            this.f1074a0 = false;
            this.f1076b0 = false;
            this.f1078c0 = false;
            this.f1080d0 = -1;
            this.f1082e0 = -1;
            this.f1084f0 = -1;
            this.f1086g0 = -1;
            this.f1088h0 = -1;
            this.f1090i0 = -1;
            this.f1092j0 = 0.5f;
            this.f1100n0 = new p.e();
            this.f1102o0 = false;
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, i.f1255a1);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i3 = 0; i3 < indexCount; i3++) {
                int index = obtainStyledAttributes.getIndex(i3);
                int i4 = a.f1114a.get(index);
                switch (i4) {
                    case 1:
                        this.S = obtainStyledAttributes.getInt(index, this.S);
                        continue;
                    case 2:
                        int resourceId = obtainStyledAttributes.getResourceId(index, this.f1097m);
                        this.f1097m = resourceId;
                        if (resourceId == -1) {
                            this.f1097m = obtainStyledAttributes.getInt(index, -1);
                        } else {
                            continue;
                        }
                    case 3:
                        this.f1099n = obtainStyledAttributes.getDimensionPixelSize(index, this.f1099n);
                        continue;
                    case 4:
                        float f2 = obtainStyledAttributes.getFloat(index, this.f1101o) % 360.0f;
                        this.f1101o = f2;
                        if (f2 < 0.0f) {
                            this.f1101o = (360.0f - f2) % 360.0f;
                        } else {
                            continue;
                        }
                    case 5:
                        this.f1073a = obtainStyledAttributes.getDimensionPixelOffset(index, this.f1073a);
                        continue;
                    case 6:
                        this.f1075b = obtainStyledAttributes.getDimensionPixelOffset(index, this.f1075b);
                        continue;
                    case 7:
                        this.f1077c = obtainStyledAttributes.getFloat(index, this.f1077c);
                        continue;
                    case 8:
                        int resourceId2 = obtainStyledAttributes.getResourceId(index, this.f1079d);
                        this.f1079d = resourceId2;
                        if (resourceId2 == -1) {
                            this.f1079d = obtainStyledAttributes.getInt(index, -1);
                        } else {
                            continue;
                        }
                    case 9:
                        int resourceId3 = obtainStyledAttributes.getResourceId(index, this.f1081e);
                        this.f1081e = resourceId3;
                        if (resourceId3 == -1) {
                            this.f1081e = obtainStyledAttributes.getInt(index, -1);
                        } else {
                            continue;
                        }
                    case 10:
                        int resourceId4 = obtainStyledAttributes.getResourceId(index, this.f1083f);
                        this.f1083f = resourceId4;
                        if (resourceId4 == -1) {
                            this.f1083f = obtainStyledAttributes.getInt(index, -1);
                        } else {
                            continue;
                        }
                    case 11:
                        int resourceId5 = obtainStyledAttributes.getResourceId(index, this.f1085g);
                        this.f1085g = resourceId5;
                        if (resourceId5 == -1) {
                            this.f1085g = obtainStyledAttributes.getInt(index, -1);
                        } else {
                            continue;
                        }
                    case 12:
                        int resourceId6 = obtainStyledAttributes.getResourceId(index, this.f1087h);
                        this.f1087h = resourceId6;
                        if (resourceId6 == -1) {
                            this.f1087h = obtainStyledAttributes.getInt(index, -1);
                        } else {
                            continue;
                        }
                    case 13:
                        int resourceId7 = obtainStyledAttributes.getResourceId(index, this.f1089i);
                        this.f1089i = resourceId7;
                        if (resourceId7 == -1) {
                            this.f1089i = obtainStyledAttributes.getInt(index, -1);
                        } else {
                            continue;
                        }
                    case 14:
                        int resourceId8 = obtainStyledAttributes.getResourceId(index, this.f1091j);
                        this.f1091j = resourceId8;
                        if (resourceId8 == -1) {
                            this.f1091j = obtainStyledAttributes.getInt(index, -1);
                        } else {
                            continue;
                        }
                    case 15:
                        int resourceId9 = obtainStyledAttributes.getResourceId(index, this.f1093k);
                        this.f1093k = resourceId9;
                        if (resourceId9 == -1) {
                            this.f1093k = obtainStyledAttributes.getInt(index, -1);
                        } else {
                            continue;
                        }
                    case 16:
                        int resourceId10 = obtainStyledAttributes.getResourceId(index, this.f1095l);
                        this.f1095l = resourceId10;
                        if (resourceId10 == -1) {
                            this.f1095l = obtainStyledAttributes.getInt(index, -1);
                        } else {
                            continue;
                        }
                    case 17:
                        int resourceId11 = obtainStyledAttributes.getResourceId(index, this.f1103p);
                        this.f1103p = resourceId11;
                        if (resourceId11 == -1) {
                            this.f1103p = obtainStyledAttributes.getInt(index, -1);
                        } else {
                            continue;
                        }
                    case 18:
                        int resourceId12 = obtainStyledAttributes.getResourceId(index, this.f1104q);
                        this.f1104q = resourceId12;
                        if (resourceId12 == -1) {
                            this.f1104q = obtainStyledAttributes.getInt(index, -1);
                        } else {
                            continue;
                        }
                    case 19:
                        int resourceId13 = obtainStyledAttributes.getResourceId(index, this.f1105r);
                        this.f1105r = resourceId13;
                        if (resourceId13 == -1) {
                            this.f1105r = obtainStyledAttributes.getInt(index, -1);
                        } else {
                            continue;
                        }
                    case 20:
                        int resourceId14 = obtainStyledAttributes.getResourceId(index, this.f1106s);
                        this.f1106s = resourceId14;
                        if (resourceId14 == -1) {
                            this.f1106s = obtainStyledAttributes.getInt(index, -1);
                        } else {
                            continue;
                        }
                    case 21:
                        this.f1107t = obtainStyledAttributes.getDimensionPixelSize(index, this.f1107t);
                        continue;
                    case 22:
                        this.f1108u = obtainStyledAttributes.getDimensionPixelSize(index, this.f1108u);
                        continue;
                    case 23:
                        this.f1109v = obtainStyledAttributes.getDimensionPixelSize(index, this.f1109v);
                        continue;
                    case 24:
                        this.f1110w = obtainStyledAttributes.getDimensionPixelSize(index, this.f1110w);
                        continue;
                    case 25:
                        this.f1111x = obtainStyledAttributes.getDimensionPixelSize(index, this.f1111x);
                        continue;
                    case 26:
                        this.f1112y = obtainStyledAttributes.getDimensionPixelSize(index, this.f1112y);
                        continue;
                    case 27:
                        this.T = obtainStyledAttributes.getBoolean(index, this.T);
                        continue;
                    case 28:
                        this.U = obtainStyledAttributes.getBoolean(index, this.U);
                        continue;
                    case 29:
                        this.f1113z = obtainStyledAttributes.getFloat(index, this.f1113z);
                        continue;
                    case 30:
                        this.A = obtainStyledAttributes.getFloat(index, this.A);
                        continue;
                    case 31:
                        int i5 = obtainStyledAttributes.getInt(index, 0);
                        this.I = i5;
                        if (i5 == 1) {
                            str = "layout_constraintWidth_default=\"wrap\" is deprecated.\nUse layout_width=\"WRAP_CONTENT\" and layout_constrainedWidth=\"true\" instead.";
                            break;
                        } else {
                            continue;
                        }
                    case 32:
                        int i6 = obtainStyledAttributes.getInt(index, 0);
                        this.J = i6;
                        if (i6 == 1) {
                            str = "layout_constraintHeight_default=\"wrap\" is deprecated.\nUse layout_height=\"WRAP_CONTENT\" and layout_constrainedHeight=\"true\" instead.";
                            break;
                        } else {
                            continue;
                        }
                    case 33:
                        try {
                            this.K = obtainStyledAttributes.getDimensionPixelSize(index, this.K);
                            continue;
                        } catch (Exception unused) {
                            if (obtainStyledAttributes.getInt(index, this.K) == -2) {
                                this.K = -2;
                            }
                        }
                    case 34:
                        try {
                            this.M = obtainStyledAttributes.getDimensionPixelSize(index, this.M);
                            continue;
                        } catch (Exception unused2) {
                            if (obtainStyledAttributes.getInt(index, this.M) == -2) {
                                this.M = -2;
                            }
                        }
                    case 35:
                        this.O = Math.max(0.0f, obtainStyledAttributes.getFloat(index, this.O));
                        this.I = 2;
                        continue;
                    case 36:
                        try {
                            this.L = obtainStyledAttributes.getDimensionPixelSize(index, this.L);
                            continue;
                        } catch (Exception unused3) {
                            if (obtainStyledAttributes.getInt(index, this.L) == -2) {
                                this.L = -2;
                            }
                        }
                    case 37:
                        try {
                            this.N = obtainStyledAttributes.getDimensionPixelSize(index, this.N);
                            continue;
                        } catch (Exception unused4) {
                            if (obtainStyledAttributes.getInt(index, this.N) == -2) {
                                this.N = -2;
                            }
                        }
                    case 38:
                        this.P = Math.max(0.0f, obtainStyledAttributes.getFloat(index, this.P));
                        this.J = 2;
                        continue;
                    default:
                        switch (i4) {
                            case 44:
                                String string = obtainStyledAttributes.getString(index);
                                this.B = string;
                                this.C = Float.NaN;
                                this.D = -1;
                                if (string != null) {
                                    int length = string.length();
                                    int indexOf = this.B.indexOf(44);
                                    if (indexOf <= 0 || indexOf >= length - 1) {
                                        i2 = 0;
                                    } else {
                                        String substring = this.B.substring(0, indexOf);
                                        if (substring.equalsIgnoreCase("W")) {
                                            this.D = 0;
                                        } else if (substring.equalsIgnoreCase("H")) {
                                            this.D = 1;
                                        }
                                        i2 = indexOf + 1;
                                    }
                                    int indexOf2 = this.B.indexOf(58);
                                    if (indexOf2 >= 0 && indexOf2 < length - 1) {
                                        String substring2 = this.B.substring(i2, indexOf2);
                                        String substring3 = this.B.substring(indexOf2 + 1);
                                        if (substring2.length() > 0 && substring3.length() > 0) {
                                            try {
                                                float parseFloat2 = Float.parseFloat(substring2);
                                                float parseFloat3 = Float.parseFloat(substring3);
                                                parseFloat = (parseFloat2 > 0.0f && parseFloat3 > 0.0f) ? this.D == 1 ? Math.abs(parseFloat3 / parseFloat2) : Math.abs(parseFloat2 / parseFloat3) : parseFloat;
                                            } catch (NumberFormatException unused5) {
                                                break;
                                            }
                                        }
                                    } else {
                                        String substring4 = this.B.substring(i2);
                                        if (substring4.length() <= 0) {
                                            break;
                                        } else {
                                            parseFloat = Float.parseFloat(substring4);
                                        }
                                    }
                                    this.C = parseFloat;
                                    break;
                                } else {
                                    continue;
                                }
                            case 45:
                                this.E = obtainStyledAttributes.getFloat(index, this.E);
                                continue;
                            case 46:
                                this.F = obtainStyledAttributes.getFloat(index, this.F);
                                continue;
                            case 47:
                                this.G = obtainStyledAttributes.getInt(index, 0);
                                continue;
                            case 48:
                                this.H = obtainStyledAttributes.getInt(index, 0);
                                continue;
                            case 49:
                                this.Q = obtainStyledAttributes.getDimensionPixelOffset(index, this.Q);
                                continue;
                            case 50:
                                this.R = obtainStyledAttributes.getDimensionPixelOffset(index, this.R);
                                continue;
                            case 51:
                                this.V = obtainStyledAttributes.getString(index);
                                continue;
                                continue;
                        }
                        break;
                }
                Log.e("ConstraintLayout", str);
            }
            obtainStyledAttributes.recycle();
            a();
        }

        public b(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
            this.f1073a = -1;
            this.f1075b = -1;
            this.f1077c = -1.0f;
            this.f1079d = -1;
            this.f1081e = -1;
            this.f1083f = -1;
            this.f1085g = -1;
            this.f1087h = -1;
            this.f1089i = -1;
            this.f1091j = -1;
            this.f1093k = -1;
            this.f1095l = -1;
            this.f1097m = -1;
            this.f1099n = 0;
            this.f1101o = 0.0f;
            this.f1103p = -1;
            this.f1104q = -1;
            this.f1105r = -1;
            this.f1106s = -1;
            this.f1107t = -1;
            this.f1108u = -1;
            this.f1109v = -1;
            this.f1110w = -1;
            this.f1111x = -1;
            this.f1112y = -1;
            this.f1113z = 0.5f;
            this.A = 0.5f;
            this.B = null;
            this.C = 0.0f;
            this.D = 1;
            this.E = -1.0f;
            this.F = -1.0f;
            this.G = 0;
            this.H = 0;
            this.I = 0;
            this.J = 0;
            this.K = 0;
            this.L = 0;
            this.M = 0;
            this.N = 0;
            this.O = 1.0f;
            this.P = 1.0f;
            this.Q = -1;
            this.R = -1;
            this.S = -1;
            this.T = false;
            this.U = false;
            this.V = null;
            this.W = true;
            this.X = true;
            this.Y = false;
            this.Z = false;
            this.f1074a0 = false;
            this.f1076b0 = false;
            this.f1078c0 = false;
            this.f1080d0 = -1;
            this.f1082e0 = -1;
            this.f1084f0 = -1;
            this.f1086g0 = -1;
            this.f1088h0 = -1;
            this.f1090i0 = -1;
            this.f1092j0 = 0.5f;
            this.f1100n0 = new p.e();
            this.f1102o0 = false;
        }

        public void a() {
            this.Z = false;
            this.W = true;
            this.X = true;
            int i2 = ((ViewGroup.MarginLayoutParams) this).width;
            if (i2 == -2 && this.T) {
                this.W = false;
                if (this.I == 0) {
                    this.I = 1;
                }
            }
            int i3 = ((ViewGroup.MarginLayoutParams) this).height;
            if (i3 == -2 && this.U) {
                this.X = false;
                if (this.J == 0) {
                    this.J = 1;
                }
            }
            if (i2 == 0 || i2 == -1) {
                this.W = false;
                if (i2 == 0 && this.I == 1) {
                    ((ViewGroup.MarginLayoutParams) this).width = -2;
                    this.T = true;
                }
            }
            if (i3 == 0 || i3 == -1) {
                this.X = false;
                if (i3 == 0 && this.J == 1) {
                    ((ViewGroup.MarginLayoutParams) this).height = -2;
                    this.U = true;
                }
            }
            if (this.f1077c == -1.0f && this.f1073a == -1 && this.f1075b == -1) {
                return;
            }
            this.Z = true;
            this.W = true;
            this.X = true;
            if (!(this.f1100n0 instanceof p.g)) {
                this.f1100n0 = new p.g();
            }
            ((p.g) this.f1100n0).j1(this.S);
        }

        /* JADX WARN: Code restructure failed: missing block: B:72:0x00ca, code lost:
            if (r1 > 0) goto L73;
         */
        /* JADX WARN: Code restructure failed: missing block: B:73:0x00cc, code lost:
            ((android.view.ViewGroup.MarginLayoutParams) r9).rightMargin = r1;
         */
        /* JADX WARN: Code restructure failed: missing block: B:78:0x00d9, code lost:
            if (r1 > 0) goto L73;
         */
        /* JADX WARN: Removed duplicated region for block: B:17:0x0048  */
        /* JADX WARN: Removed duplicated region for block: B:20:0x004f  */
        /* JADX WARN: Removed duplicated region for block: B:23:0x0056  */
        /* JADX WARN: Removed duplicated region for block: B:26:0x005c  */
        /* JADX WARN: Removed duplicated region for block: B:29:0x0062  */
        /* JADX WARN: Removed duplicated region for block: B:36:0x0074  */
        /* JADX WARN: Removed duplicated region for block: B:37:0x007c  */
        /* JADX WARN: Removed duplicated region for block: B:82:0x00e0  */
        /* JADX WARN: Removed duplicated region for block: B:86:0x00eb  */
        @Override // android.view.ViewGroup.MarginLayoutParams, android.view.ViewGroup.LayoutParams
        @android.annotation.TargetApi(17)
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public void resolveLayoutDirection(int r10) {
            /*
                Method dump skipped, instructions count: 249
                To view this dump add '--comments-level debug' option
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.widget.ConstraintLayout.b.resolveLayoutDirection(int):void");
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public class c implements b.InterfaceC0068b {

        /* renamed from: a  reason: collision with root package name */
        ConstraintLayout f1115a;

        /* renamed from: b  reason: collision with root package name */
        int f1116b;

        /* renamed from: c  reason: collision with root package name */
        int f1117c;

        /* renamed from: d  reason: collision with root package name */
        int f1118d;

        /* renamed from: e  reason: collision with root package name */
        int f1119e;

        /* renamed from: f  reason: collision with root package name */
        int f1120f;

        /* renamed from: g  reason: collision with root package name */
        int f1121g;

        public c(ConstraintLayout constraintLayout) {
            this.f1115a = constraintLayout;
        }

        private boolean d(int i2, int i3, int i4) {
            if (i2 == i3) {
                return true;
            }
            int mode = View.MeasureSpec.getMode(i2);
            View.MeasureSpec.getSize(i2);
            int mode2 = View.MeasureSpec.getMode(i3);
            int size = View.MeasureSpec.getSize(i3);
            if (mode2 == 1073741824) {
                return (mode == Integer.MIN_VALUE || mode == 0) && i4 == size;
            }
            return false;
        }

        @Override // q.b.InterfaceC0068b
        public final void a() {
            int childCount = this.f1115a.getChildCount();
            for (int i2 = 0; i2 < childCount; i2++) {
                View childAt = this.f1115a.getChildAt(i2);
                if (childAt instanceof g) {
                    ((g) childAt).a(this.f1115a);
                }
            }
            int size = this.f1115a.f1050c.size();
            if (size > 0) {
                for (int i3 = 0; i3 < size; i3++) {
                    ((androidx.constraintlayout.widget.b) this.f1115a.f1050c.get(i3)).k(this.f1115a);
                }
            }
        }

        /* JADX WARN: Removed duplicated region for block: B:111:0x018c  */
        /* JADX WARN: Removed duplicated region for block: B:115:0x01a3  */
        /* JADX WARN: Removed duplicated region for block: B:116:0x01a5  */
        /* JADX WARN: Removed duplicated region for block: B:118:0x01a8  */
        /* JADX WARN: Removed duplicated region for block: B:119:0x01aa  */
        /* JADX WARN: Removed duplicated region for block: B:122:0x01af  */
        /* JADX WARN: Removed duplicated region for block: B:128:0x01b9  */
        /* JADX WARN: Removed duplicated region for block: B:135:0x01c4  */
        /* JADX WARN: Removed duplicated region for block: B:140:0x01cf  */
        /* JADX WARN: Removed duplicated region for block: B:145:0x01da A[RETURN] */
        /* JADX WARN: Removed duplicated region for block: B:146:0x01db  */
        /* JADX WARN: Removed duplicated region for block: B:52:0x00b6  */
        /* JADX WARN: Removed duplicated region for block: B:90:0x0125  */
        @Override // q.b.InterfaceC0068b
        @android.annotation.SuppressLint({"WrongCall"})
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public final void b(p.e r18, q.b.a r19) {
            /*
                Method dump skipped, instructions count: 713
                To view this dump add '--comments-level debug' option
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.widget.ConstraintLayout.c.b(p.e, q.b$a):void");
        }

        public void c(int i2, int i3, int i4, int i5, int i6, int i7) {
            this.f1116b = i4;
            this.f1117c = i5;
            this.f1118d = i6;
            this.f1119e = i7;
            this.f1120f = i2;
            this.f1121g = i3;
        }
    }

    public ConstraintLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f1049b = new SparseArray<>();
        this.f1050c = new ArrayList<>(4);
        this.f1051d = new p.f();
        this.f1052e = 0;
        this.f1053f = 0;
        this.f1054g = Integer.MAX_VALUE;
        this.f1055h = Integer.MAX_VALUE;
        this.f1056i = true;
        this.f1057j = 257;
        this.f1058k = null;
        this.f1059l = null;
        this.f1060m = -1;
        this.f1061n = new HashMap<>();
        this.f1062o = -1;
        this.f1063p = -1;
        this.f1064q = -1;
        this.f1065r = -1;
        this.f1066s = 0;
        this.f1067t = 0;
        this.f1068u = new SparseArray<>();
        this.f1069v = new c(this);
        this.f1070w = 0;
        this.f1071x = 0;
        k(attributeSet, 0, 0);
    }

    public ConstraintLayout(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.f1049b = new SparseArray<>();
        this.f1050c = new ArrayList<>(4);
        this.f1051d = new p.f();
        this.f1052e = 0;
        this.f1053f = 0;
        this.f1054g = Integer.MAX_VALUE;
        this.f1055h = Integer.MAX_VALUE;
        this.f1056i = true;
        this.f1057j = 257;
        this.f1058k = null;
        this.f1059l = null;
        this.f1060m = -1;
        this.f1061n = new HashMap<>();
        this.f1062o = -1;
        this.f1063p = -1;
        this.f1064q = -1;
        this.f1065r = -1;
        this.f1066s = 0;
        this.f1067t = 0;
        this.f1068u = new SparseArray<>();
        this.f1069v = new c(this);
        this.f1070w = 0;
        this.f1071x = 0;
        k(attributeSet, i2, 0);
    }

    private int getPaddingWidth() {
        int max = Math.max(0, getPaddingLeft()) + Math.max(0, getPaddingRight());
        int max2 = Math.max(0, getPaddingStart()) + Math.max(0, getPaddingEnd());
        return max2 > 0 ? max2 : max;
    }

    private final p.e h(int i2) {
        if (i2 == 0) {
            return this.f1051d;
        }
        View view = this.f1049b.get(i2);
        if (view == null && (view = findViewById(i2)) != null && view != this && view.getParent() == this) {
            onViewAdded(view);
        }
        if (view == this) {
            return this.f1051d;
        }
        if (view == null) {
            return null;
        }
        return ((b) view.getLayoutParams()).f1100n0;
    }

    private void k(AttributeSet attributeSet, int i2, int i3) {
        this.f1051d.l0(this);
        this.f1051d.D1(this.f1069v);
        this.f1049b.put(getId(), this);
        this.f1058k = null;
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, i.f1255a1, i2, i3);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i4 = 0; i4 < indexCount; i4++) {
                int index = obtainStyledAttributes.getIndex(i4);
                if (index == i.f1270f1) {
                    this.f1052e = obtainStyledAttributes.getDimensionPixelOffset(index, this.f1052e);
                } else if (index == i.f1273g1) {
                    this.f1053f = obtainStyledAttributes.getDimensionPixelOffset(index, this.f1053f);
                } else if (index == i.f1264d1) {
                    this.f1054g = obtainStyledAttributes.getDimensionPixelOffset(index, this.f1054g);
                } else if (index == i.f1267e1) {
                    this.f1055h = obtainStyledAttributes.getDimensionPixelOffset(index, this.f1055h);
                } else if (index == i.n2) {
                    this.f1057j = obtainStyledAttributes.getInt(index, this.f1057j);
                } else if (index == i.f1297o1) {
                    int resourceId = obtainStyledAttributes.getResourceId(index, 0);
                    if (resourceId != 0) {
                        try {
                            n(resourceId);
                        } catch (Resources.NotFoundException unused) {
                            this.f1059l = null;
                        }
                    }
                } else if (index == i.f1288l1) {
                    int resourceId2 = obtainStyledAttributes.getResourceId(index, 0);
                    try {
                        d dVar = new d();
                        this.f1058k = dVar;
                        dVar.m(getContext(), resourceId2);
                    } catch (Resources.NotFoundException unused2) {
                        this.f1058k = null;
                    }
                    this.f1060m = resourceId2;
                }
            }
            obtainStyledAttributes.recycle();
        }
        this.f1051d.E1(this.f1057j);
    }

    private void m() {
        this.f1056i = true;
        this.f1062o = -1;
        this.f1063p = -1;
        this.f1064q = -1;
        this.f1065r = -1;
        this.f1066s = 0;
        this.f1067t = 0;
    }

    private void q() {
        boolean isInEditMode = isInEditMode();
        int childCount = getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            p.e j2 = j(getChildAt(i2));
            if (j2 != null) {
                j2.h0();
            }
        }
        if (isInEditMode) {
            for (int i3 = 0; i3 < childCount; i3++) {
                View childAt = getChildAt(i3);
                try {
                    String resourceName = getResources().getResourceName(childAt.getId());
                    r(0, resourceName, Integer.valueOf(childAt.getId()));
                    int indexOf = resourceName.indexOf(47);
                    if (indexOf != -1) {
                        resourceName = resourceName.substring(indexOf + 1);
                    }
                    h(childAt.getId()).m0(resourceName);
                } catch (Resources.NotFoundException unused) {
                }
            }
        }
        if (this.f1060m != -1) {
            for (int i4 = 0; i4 < childCount; i4++) {
                View childAt2 = getChildAt(i4);
                if (childAt2.getId() == this.f1060m && (childAt2 instanceof e)) {
                    this.f1058k = ((e) childAt2).getConstraintSet();
                }
            }
        }
        d dVar = this.f1058k;
        if (dVar != null) {
            dVar.d(this, true);
        }
        this.f1051d.d1();
        int size = this.f1050c.size();
        if (size > 0) {
            for (int i5 = 0; i5 < size; i5++) {
                this.f1050c.get(i5).m(this);
            }
        }
        for (int i6 = 0; i6 < childCount; i6++) {
            View childAt3 = getChildAt(i6);
            if (childAt3 instanceof g) {
                ((g) childAt3).b(this);
            }
        }
        this.f1068u.clear();
        this.f1068u.put(0, this.f1051d);
        this.f1068u.put(getId(), this.f1051d);
        for (int i7 = 0; i7 < childCount; i7++) {
            View childAt4 = getChildAt(i7);
            this.f1068u.put(childAt4.getId(), j(childAt4));
        }
        for (int i8 = 0; i8 < childCount; i8++) {
            View childAt5 = getChildAt(i8);
            p.e j3 = j(childAt5);
            if (j3 != null) {
                b bVar = (b) childAt5.getLayoutParams();
                this.f1051d.c(j3);
                d(isInEditMode, childAt5, j3, bVar, this.f1068u);
            }
        }
    }

    private boolean t() {
        int childCount = getChildCount();
        boolean z2 = false;
        int i2 = 0;
        while (true) {
            if (i2 >= childCount) {
                break;
            } else if (getChildAt(i2).isLayoutRequested()) {
                z2 = true;
                break;
            } else {
                i2++;
            }
        }
        if (z2) {
            q();
        }
        return z2;
    }

    @Override // android.view.ViewGroup
    public void addView(View view, int i2, ViewGroup.LayoutParams layoutParams) {
        super.addView(view, i2, layoutParams);
    }

    @Override // android.view.ViewGroup
    protected boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof b;
    }

    /* JADX WARN: Removed duplicated region for block: B:34:0x00b6  */
    /* JADX WARN: Removed duplicated region for block: B:37:0x00c8  */
    /* JADX WARN: Removed duplicated region for block: B:44:0x00e2  */
    /* JADX WARN: Removed duplicated region for block: B:47:0x00f5  */
    /* JADX WARN: Removed duplicated region for block: B:55:0x0113  */
    /* JADX WARN: Removed duplicated region for block: B:58:0x0127  */
    /* JADX WARN: Removed duplicated region for block: B:66:0x0144  */
    /* JADX WARN: Removed duplicated region for block: B:74:0x0198  */
    /* JADX WARN: Removed duplicated region for block: B:77:0x01a1  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    protected void d(boolean r19, android.view.View r20, p.e r21, androidx.constraintlayout.widget.ConstraintLayout.b r22, android.util.SparseArray<p.e> r23) {
        /*
            Method dump skipped, instructions count: 622
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.widget.ConstraintLayout.d(boolean, android.view.View, p.e, androidx.constraintlayout.widget.ConstraintLayout$b, android.util.SparseArray):void");
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void dispatchDraw(Canvas canvas) {
        Object tag;
        int size;
        ArrayList<androidx.constraintlayout.widget.b> arrayList = this.f1050c;
        if (arrayList != null && (size = arrayList.size()) > 0) {
            for (int i2 = 0; i2 < size; i2++) {
                this.f1050c.get(i2).l(this);
            }
        }
        super.dispatchDraw(canvas);
        if (isInEditMode()) {
            int childCount = getChildCount();
            float width = getWidth();
            float height = getHeight();
            for (int i3 = 0; i3 < childCount; i3++) {
                View childAt = getChildAt(i3);
                if (childAt.getVisibility() != 8 && (tag = childAt.getTag()) != null && (tag instanceof String)) {
                    String[] split = ((String) tag).split(",");
                    if (split.length == 4) {
                        int parseInt = Integer.parseInt(split[0]);
                        int parseInt2 = Integer.parseInt(split[1]);
                        int parseInt3 = Integer.parseInt(split[2]);
                        int i4 = (int) ((parseInt / 1080.0f) * width);
                        int i5 = (int) ((parseInt2 / 1920.0f) * height);
                        Paint paint = new Paint();
                        paint.setColor(-65536);
                        float f2 = i4;
                        float f3 = i5;
                        float f4 = i4 + ((int) ((parseInt3 / 1080.0f) * width));
                        canvas.drawLine(f2, f3, f4, f3, paint);
                        float parseInt4 = i5 + ((int) ((Integer.parseInt(split[3]) / 1920.0f) * height));
                        canvas.drawLine(f4, f3, f4, parseInt4, paint);
                        canvas.drawLine(f4, parseInt4, f2, parseInt4, paint);
                        canvas.drawLine(f2, parseInt4, f2, f3, paint);
                        paint.setColor(-16711936);
                        canvas.drawLine(f2, f3, f4, parseInt4, paint);
                        canvas.drawLine(f2, parseInt4, f4, f3, paint);
                    }
                }
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.view.ViewGroup
    /* renamed from: e  reason: merged with bridge method [inline-methods] */
    public b generateDefaultLayoutParams() {
        return new b(-2, -2);
    }

    @Override // android.view.ViewGroup
    /* renamed from: f  reason: merged with bridge method [inline-methods] */
    public b generateLayoutParams(AttributeSet attributeSet) {
        return new b(getContext(), attributeSet);
    }

    @Override // android.view.View
    public void forceLayout() {
        m();
        super.forceLayout();
    }

    public Object g(int i2, Object obj) {
        if (i2 == 0 && (obj instanceof String)) {
            String str = (String) obj;
            HashMap<String, Integer> hashMap = this.f1061n;
            if (hashMap == null || !hashMap.containsKey(str)) {
                return null;
            }
            return this.f1061n.get(str);
        }
        return null;
    }

    @Override // android.view.ViewGroup
    protected ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new b(layoutParams);
    }

    public int getMaxHeight() {
        return this.f1055h;
    }

    public int getMaxWidth() {
        return this.f1054g;
    }

    public int getMinHeight() {
        return this.f1053f;
    }

    public int getMinWidth() {
        return this.f1052e;
    }

    public int getOptimizationLevel() {
        return this.f1051d.s1();
    }

    public View i(int i2) {
        return this.f1049b.get(i2);
    }

    public final p.e j(View view) {
        if (view == this) {
            return this.f1051d;
        }
        if (view == null) {
            return null;
        }
        return ((b) view.getLayoutParams()).f1100n0;
    }

    protected boolean l() {
        return ((getContext().getApplicationInfo().flags & 4194304) != 0) && 1 == getLayoutDirection();
    }

    protected void n(int i2) {
        this.f1059l = new androidx.constraintlayout.widget.c(getContext(), this, i2);
    }

    protected void o(int i2, int i3, int i4, int i5, boolean z2, boolean z3) {
        c cVar = this.f1069v;
        int i6 = cVar.f1119e;
        int resolveSizeAndState = ViewGroup.resolveSizeAndState(i4 + cVar.f1118d, i2, 0);
        int resolveSizeAndState2 = ViewGroup.resolveSizeAndState(i5 + i6, i3, 0) & 16777215;
        int min = Math.min(this.f1054g, resolveSizeAndState & 16777215);
        int min2 = Math.min(this.f1055h, resolveSizeAndState2);
        if (z2) {
            min |= 16777216;
        }
        if (z3) {
            min2 |= 16777216;
        }
        setMeasuredDimension(min, min2);
        this.f1062o = min;
        this.f1063p = min2;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.view.ViewGroup, android.view.View
    public void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        View content;
        int childCount = getChildCount();
        boolean isInEditMode = isInEditMode();
        for (int i6 = 0; i6 < childCount; i6++) {
            View childAt = getChildAt(i6);
            b bVar = (b) childAt.getLayoutParams();
            p.e eVar = bVar.f1100n0;
            if ((childAt.getVisibility() != 8 || bVar.Z || bVar.f1074a0 || bVar.f1078c0 || isInEditMode) && !bVar.f1076b0) {
                int S = eVar.S();
                int T = eVar.T();
                int R = eVar.R() + S;
                int v2 = eVar.v() + T;
                childAt.layout(S, T, R, v2);
                if ((childAt instanceof g) && (content = ((g) childAt).getContent()) != null) {
                    content.setVisibility(0);
                    content.layout(S, T, R, v2);
                }
            }
        }
        int size = this.f1050c.size();
        if (size > 0) {
            for (int i7 = 0; i7 < size; i7++) {
                this.f1050c.get(i7).j(this);
            }
        }
    }

    @Override // android.view.View
    protected void onMeasure(int i2, int i3) {
        if (!this.f1056i) {
            int childCount = getChildCount();
            int i4 = 0;
            while (true) {
                if (i4 >= childCount) {
                    break;
                } else if (getChildAt(i4).isLayoutRequested()) {
                    this.f1056i = true;
                    break;
                } else {
                    i4++;
                }
            }
        }
        if (!this.f1056i) {
            int i5 = this.f1070w;
            if (i5 != i2 || this.f1071x != i3) {
                if (i5 == i2 && View.MeasureSpec.getMode(i2) == 1073741824 && View.MeasureSpec.getMode(i3) == Integer.MIN_VALUE && View.MeasureSpec.getMode(this.f1071x) == Integer.MIN_VALUE && View.MeasureSpec.getSize(i3) >= this.f1051d.v()) {
                    this.f1070w = i2;
                    this.f1071x = i3;
                }
            }
            o(i2, i3, this.f1051d.R(), this.f1051d.v(), this.f1051d.y1(), this.f1051d.w1());
        }
        this.f1070w = i2;
        this.f1071x = i3;
        this.f1051d.F1(l());
        if (this.f1056i) {
            this.f1056i = false;
            if (t()) {
                this.f1051d.H1();
            }
        }
        p(this.f1051d, this.f1057j, i2, i3);
        o(i2, i3, this.f1051d.R(), this.f1051d.v(), this.f1051d.y1(), this.f1051d.w1());
    }

    @Override // android.view.ViewGroup
    public void onViewAdded(View view) {
        super.onViewAdded(view);
        p.e j2 = j(view);
        if ((view instanceof Guideline) && !(j2 instanceof p.g)) {
            b bVar = (b) view.getLayoutParams();
            p.g gVar = new p.g();
            bVar.f1100n0 = gVar;
            bVar.Z = true;
            gVar.j1(bVar.S);
        }
        if (view instanceof androidx.constraintlayout.widget.b) {
            androidx.constraintlayout.widget.b bVar2 = (androidx.constraintlayout.widget.b) view;
            bVar2.n();
            ((b) view.getLayoutParams()).f1074a0 = true;
            if (!this.f1050c.contains(bVar2)) {
                this.f1050c.add(bVar2);
            }
        }
        this.f1049b.put(view.getId(), view);
        this.f1056i = true;
    }

    @Override // android.view.ViewGroup
    public void onViewRemoved(View view) {
        super.onViewRemoved(view);
        this.f1049b.remove(view.getId());
        this.f1051d.c1(j(view));
        this.f1050c.remove(view);
        this.f1056i = true;
    }

    protected void p(p.f fVar, int i2, int i3, int i4) {
        int mode = View.MeasureSpec.getMode(i3);
        int size = View.MeasureSpec.getSize(i3);
        int mode2 = View.MeasureSpec.getMode(i4);
        int size2 = View.MeasureSpec.getSize(i4);
        int max = Math.max(0, getPaddingTop());
        int max2 = Math.max(0, getPaddingBottom());
        int i5 = max + max2;
        int paddingWidth = getPaddingWidth();
        this.f1069v.c(i3, i4, max, max2, paddingWidth, i5);
        int max3 = Math.max(0, getPaddingStart());
        int max4 = Math.max(0, getPaddingEnd());
        int max5 = (max3 > 0 || max4 > 0) ? l() ? max4 : max3 : Math.max(0, getPaddingLeft());
        int i6 = size - paddingWidth;
        int i7 = size2 - i5;
        s(fVar, mode, i6, mode2, i7);
        fVar.z1(i2, mode, i6, mode2, i7, this.f1062o, this.f1063p, max5, max);
    }

    public void r(int i2, Object obj, Object obj2) {
        if (i2 == 0 && (obj instanceof String) && (obj2 instanceof Integer)) {
            if (this.f1061n == null) {
                this.f1061n = new HashMap<>();
            }
            String str = (String) obj;
            int indexOf = str.indexOf("/");
            if (indexOf != -1) {
                str = str.substring(indexOf + 1);
            }
            this.f1061n.put(str, Integer.valueOf(((Integer) obj2).intValue()));
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewManager
    public void removeView(View view) {
        super.removeView(view);
    }

    @Override // android.view.View, android.view.ViewParent
    public void requestLayout() {
        m();
        super.requestLayout();
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0025, code lost:
        if (r3 == 0) goto L14;
     */
    /* JADX WARN: Code restructure failed: missing block: B:13:0x002a, code lost:
        if (r3 == 0) goto L14;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x002c, code lost:
        r10 = java.lang.Math.max(0, r7.f1052e);
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x0044, code lost:
        if (r3 == 0) goto L25;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x0049, code lost:
        if (r3 == 0) goto L25;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x004b, code lost:
        r12 = java.lang.Math.max(0, r7.f1053f);
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    protected void s(p.f r8, int r9, int r10, int r11, int r12) {
        /*
            r7 = this;
            androidx.constraintlayout.widget.ConstraintLayout$c r0 = r7.f1069v
            int r1 = r0.f1119e
            int r0 = r0.f1118d
            p.e$b r2 = p.e.b.FIXED
            int r3 = r7.getChildCount()
            r4 = 1073741824(0x40000000, float:2.0)
            r5 = -2147483648(0xffffffff80000000, float:-0.0)
            r6 = 0
            if (r9 == r5) goto L28
            if (r9 == 0) goto L23
            if (r9 == r4) goto L1a
            r9 = r2
        L18:
            r10 = 0
            goto L32
        L1a:
            int r9 = r7.f1054g
            int r9 = r9 - r0
            int r10 = java.lang.Math.min(r9, r10)
            r9 = r2
            goto L32
        L23:
            p.e$b r9 = p.e.b.WRAP_CONTENT
            if (r3 != 0) goto L18
            goto L2c
        L28:
            p.e$b r9 = p.e.b.WRAP_CONTENT
            if (r3 != 0) goto L32
        L2c:
            int r10 = r7.f1052e
            int r10 = java.lang.Math.max(r6, r10)
        L32:
            if (r11 == r5) goto L47
            if (r11 == 0) goto L42
            if (r11 == r4) goto L3a
        L38:
            r12 = 0
            goto L51
        L3a:
            int r11 = r7.f1055h
            int r11 = r11 - r1
            int r12 = java.lang.Math.min(r11, r12)
            goto L51
        L42:
            p.e$b r2 = p.e.b.WRAP_CONTENT
            if (r3 != 0) goto L38
            goto L4b
        L47:
            p.e$b r2 = p.e.b.WRAP_CONTENT
            if (r3 != 0) goto L51
        L4b:
            int r11 = r7.f1053f
            int r12 = java.lang.Math.max(r6, r11)
        L51:
            int r11 = r8.R()
            if (r10 != r11) goto L5d
            int r11 = r8.v()
            if (r12 == r11) goto L60
        L5d:
            r8.v1()
        L60:
            r8.V0(r6)
            r8.W0(r6)
            int r11 = r7.f1054g
            int r11 = r11 - r0
            r8.H0(r11)
            int r11 = r7.f1055h
            int r11 = r11 - r1
            r8.G0(r11)
            r8.K0(r6)
            r8.J0(r6)
            r8.z0(r9)
            r8.U0(r10)
            r8.Q0(r2)
            r8.v0(r12)
            int r9 = r7.f1052e
            int r9 = r9 - r0
            r8.K0(r9)
            int r9 = r7.f1053f
            int r9 = r9 - r1
            r8.J0(r9)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.widget.ConstraintLayout.s(p.f, int, int, int, int):void");
    }

    public void setConstraintSet(d dVar) {
        this.f1058k = dVar;
    }

    @Override // android.view.View
    public void setId(int i2) {
        this.f1049b.remove(getId());
        super.setId(i2);
        this.f1049b.put(getId(), this);
    }

    public void setMaxHeight(int i2) {
        if (i2 == this.f1055h) {
            return;
        }
        this.f1055h = i2;
        requestLayout();
    }

    public void setMaxWidth(int i2) {
        if (i2 == this.f1054g) {
            return;
        }
        this.f1054g = i2;
        requestLayout();
    }

    public void setMinHeight(int i2) {
        if (i2 == this.f1053f) {
            return;
        }
        this.f1053f = i2;
        requestLayout();
    }

    public void setMinWidth(int i2) {
        if (i2 == this.f1052e) {
            return;
        }
        this.f1052e = i2;
        requestLayout();
    }

    public void setOnConstraintsChanged(f fVar) {
        androidx.constraintlayout.widget.c cVar = this.f1059l;
        if (cVar != null) {
            cVar.c(fVar);
        }
    }

    public void setOptimizationLevel(int i2) {
        this.f1057j = i2;
        this.f1051d.E1(i2);
    }

    @Override // android.view.ViewGroup
    public boolean shouldDelayChildPressedState() {
        return false;
    }
}
