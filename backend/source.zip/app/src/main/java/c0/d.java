package c0;

import java.util.Locale;
/* loaded from: classes.dex */
public final class d {

    /* renamed from: a  reason: collision with root package name */
    public static final c0.c f3084a = new e(null, false);

    /* renamed from: b  reason: collision with root package name */
    public static final c0.c f3085b = new e(null, true);

    /* renamed from: c  reason: collision with root package name */
    public static final c0.c f3086c;

    /* renamed from: d  reason: collision with root package name */
    public static final c0.c f3087d;

    /* renamed from: e  reason: collision with root package name */
    public static final c0.c f3088e;

    /* renamed from: f  reason: collision with root package name */
    public static final c0.c f3089f;

    /* loaded from: classes.dex */
    private static class a implements c {

        /* renamed from: b  reason: collision with root package name */
        static final a f3090b = new a(true);

        /* renamed from: a  reason: collision with root package name */
        private final boolean f3091a;

        private a(boolean z2) {
            this.f3091a = z2;
        }

        @Override // c0.d.c
        public int a(CharSequence charSequence, int i2, int i3) {
            int i4 = i3 + i2;
            boolean z2 = false;
            while (i2 < i4) {
                int a2 = d.a(Character.getDirectionality(charSequence.charAt(i2)));
                if (a2 != 0) {
                    if (a2 != 1) {
                        continue;
                        i2++;
                    } else if (!this.f3091a) {
                        return 1;
                    }
                } else if (this.f3091a) {
                    return 0;
                }
                z2 = true;
                i2++;
            }
            if (z2) {
                return this.f3091a ? 1 : 0;
            }
            return 2;
        }
    }

    /* loaded from: classes.dex */
    private static class b implements c {

        /* renamed from: a  reason: collision with root package name */
        static final b f3092a = new b();

        private b() {
        }

        @Override // c0.d.c
        public int a(CharSequence charSequence, int i2, int i3) {
            int i4 = i3 + i2;
            int i5 = 2;
            while (i2 < i4 && i5 == 2) {
                i5 = d.b(Character.getDirectionality(charSequence.charAt(i2)));
                i2++;
            }
            return i5;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public interface c {
        int a(CharSequence charSequence, int i2, int i3);
    }

    /* renamed from: c0.d$d  reason: collision with other inner class name */
    /* loaded from: classes.dex */
    private static abstract class AbstractC0032d implements c0.c {

        /* renamed from: a  reason: collision with root package name */
        private final c f3093a;

        AbstractC0032d(c cVar) {
            this.f3093a = cVar;
        }

        private boolean c(CharSequence charSequence, int i2, int i3) {
            int a2 = this.f3093a.a(charSequence, i2, i3);
            if (a2 != 0) {
                if (a2 != 1) {
                    return b();
                }
                return false;
            }
            return true;
        }

        @Override // c0.c
        public boolean a(CharSequence charSequence, int i2, int i3) {
            if (charSequence == null || i2 < 0 || i3 < 0 || charSequence.length() - i3 < i2) {
                throw new IllegalArgumentException();
            }
            return this.f3093a == null ? b() : c(charSequence, i2, i3);
        }

        protected abstract boolean b();
    }

    /* loaded from: classes.dex */
    private static class e extends AbstractC0032d {

        /* renamed from: b  reason: collision with root package name */
        private final boolean f3094b;

        e(c cVar, boolean z2) {
            super(cVar);
            this.f3094b = z2;
        }

        @Override // c0.d.AbstractC0032d
        protected boolean b() {
            return this.f3094b;
        }
    }

    /* loaded from: classes.dex */
    private static class f extends AbstractC0032d {

        /* renamed from: b  reason: collision with root package name */
        static final f f3095b = new f();

        f() {
            super(null);
        }

        @Override // c0.d.AbstractC0032d
        protected boolean b() {
            return c0.e.a(Locale.getDefault()) == 1;
        }
    }

    static {
        b bVar = b.f3092a;
        f3086c = new e(bVar, false);
        f3087d = new e(bVar, true);
        f3088e = new e(a.f3090b, false);
        f3089f = f.f3095b;
    }

    static int a(int i2) {
        if (i2 != 0) {
            return (i2 == 1 || i2 == 2) ? 0 : 2;
        }
        return 1;
    }

    static int b(int i2) {
        if (i2 != 0) {
            if (i2 == 1 || i2 == 2) {
                return 0;
            }
            switch (i2) {
                case 14:
                case 15:
                    break;
                case 16:
                case 17:
                    return 0;
                default:
                    return 2;
            }
        }
        return 1;
    }
}
