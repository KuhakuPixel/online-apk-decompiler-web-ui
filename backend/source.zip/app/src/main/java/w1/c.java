package w1;

import android.content.res.TypedArray;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.databinding.ViewDataBinding;
import com.sample.android.kuhakupixelinapppurchase.ui.GameFragment;
/* loaded from: classes.dex */
public abstract class c extends ViewDataBinding {
    public final Button B;
    public final ConstraintLayout C;
    public final Button D;
    public final ImageView E;
    public final ImageView F;
    public final TextView G;
    protected u1.b H;
    protected TypedArray I;
    protected GameFragment J;

    /* JADX INFO: Access modifiers changed from: protected */
    public c(Object obj, View view, int i2, Button button, ConstraintLayout constraintLayout, Button button2, ImageView imageView, ImageView imageView2, TextView textView) {
        super(obj, view, i2);
        this.B = button;
        this.C = constraintLayout;
        this.D = button2;
        this.E = imageView;
        this.F = imageView2;
        this.G = textView;
    }

    public abstract void H(GameFragment gameFragment);

    public abstract void I(TypedArray typedArray);

    public abstract void J(u1.b bVar);
}
