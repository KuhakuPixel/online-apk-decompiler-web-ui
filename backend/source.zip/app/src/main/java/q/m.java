package q;

import java.util.ArrayList;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes.dex */
public class m {

    /* renamed from: h  reason: collision with root package name */
    public static int f5032h;

    /* renamed from: c  reason: collision with root package name */
    p f5035c;

    /* renamed from: d  reason: collision with root package name */
    p f5036d;

    /* renamed from: f  reason: collision with root package name */
    int f5038f;

    /* renamed from: g  reason: collision with root package name */
    int f5039g;

    /* renamed from: a  reason: collision with root package name */
    public int f5033a = 0;

    /* renamed from: b  reason: collision with root package name */
    public boolean f5034b = false;

    /* renamed from: e  reason: collision with root package name */
    ArrayList<p> f5037e = new ArrayList<>();

    public m(p pVar, int i2) {
        this.f5035c = null;
        this.f5036d = null;
        int i3 = f5032h;
        this.f5038f = i3;
        f5032h = i3 + 1;
        this.f5035c = pVar;
        this.f5036d = pVar;
        this.f5039g = i2;
    }

    private long c(f fVar, long j2) {
        p pVar = fVar.f5010d;
        if (pVar instanceof k) {
            return j2;
        }
        int size = fVar.f5017k.size();
        long j3 = j2;
        for (int i2 = 0; i2 < size; i2++) {
            d dVar = fVar.f5017k.get(i2);
            if (dVar instanceof f) {
                f fVar2 = (f) dVar;
                if (fVar2.f5010d != pVar) {
                    j3 = Math.min(j3, c(fVar2, fVar2.f5012f + j2));
                }
            }
        }
        if (fVar == pVar.f5066i) {
            long j4 = j2 - pVar.j();
            return Math.min(Math.min(j3, c(pVar.f5065h, j4)), j4 - pVar.f5065h.f5012f);
        }
        return j3;
    }

    private long d(f fVar, long j2) {
        p pVar = fVar.f5010d;
        if (pVar instanceof k) {
            return j2;
        }
        int size = fVar.f5017k.size();
        long j3 = j2;
        for (int i2 = 0; i2 < size; i2++) {
            d dVar = fVar.f5017k.get(i2);
            if (dVar instanceof f) {
                f fVar2 = (f) dVar;
                if (fVar2.f5010d != pVar) {
                    j3 = Math.max(j3, d(fVar2, fVar2.f5012f + j2));
                }
            }
        }
        if (fVar == pVar.f5065h) {
            long j4 = j2 + pVar.j();
            return Math.max(Math.max(j3, d(pVar.f5066i, j4)), j4 - pVar.f5066i.f5012f);
        }
        return j3;
    }

    public void a(p pVar) {
        this.f5037e.add(pVar);
        this.f5036d = pVar;
    }

    public long b(p.f fVar, int i2) {
        long j2;
        p pVar;
        long j3;
        long j4;
        p pVar2 = this.f5035c;
        if (pVar2 instanceof c) {
            if (((c) pVar2).f5063f != i2) {
                return 0L;
            }
        } else if (i2 == 0) {
            if (!(pVar2 instanceof l)) {
                return 0L;
            }
        } else if (!(pVar2 instanceof n)) {
            return 0L;
        }
        f fVar2 = (i2 == 0 ? fVar.f4895e : fVar.f4897f).f5065h;
        f fVar3 = (i2 == 0 ? fVar.f4895e : fVar.f4897f).f5066i;
        boolean contains = pVar2.f5065h.f5018l.contains(fVar2);
        boolean contains2 = this.f5035c.f5066i.f5018l.contains(fVar3);
        long j5 = this.f5035c.j();
        if (!contains || !contains2) {
            if (contains) {
                j4 = d(this.f5035c.f5065h, r13.f5012f);
                j3 = this.f5035c.f5065h.f5012f + j5;
            } else if (contains2) {
                j3 = (-this.f5035c.f5066i.f5012f) + j5;
                j4 = -c(this.f5035c.f5066i, r13.f5012f);
            } else {
                j2 = r13.f5065h.f5012f + this.f5035c.j();
                pVar = this.f5035c;
            }
            return Math.max(j4, j3);
        }
        long d2 = d(this.f5035c.f5065h, 0L);
        long c2 = c(this.f5035c.f5066i, 0L);
        long j6 = d2 - j5;
        p pVar3 = this.f5035c;
        int i3 = pVar3.f5066i.f5012f;
        if (j6 >= (-i3)) {
            j6 += i3;
        }
        int i4 = pVar3.f5065h.f5012f;
        long j7 = ((-c2) - j5) - i4;
        if (j7 >= i4) {
            j7 -= i4;
        }
        float f2 = (float) (pVar3.f5059b.o(i2) > 0.0f ? (((float) j7) / r13) + (((float) j6) / (1.0f - r13)) : 0L);
        long j8 = (f2 * r13) + 0.5f + j5 + (f2 * (1.0f - r13)) + 0.5f;
        pVar = this.f5035c;
        j2 = pVar.f5065h.f5012f + j8;
        return j2 - pVar.f5066i.f5012f;
    }
}
