package androidx.navigation;

import androidx.lifecycle.s;
import java.util.HashMap;
import java.util.Iterator;
import java.util.UUID;
/* loaded from: classes.dex */
class g extends androidx.lifecycle.r {

    /* renamed from: d  reason: collision with root package name */
    private static final s.a f1973d = new a();

    /* renamed from: c  reason: collision with root package name */
    private final HashMap<UUID, androidx.lifecycle.t> f1974c = new HashMap<>();

    /* loaded from: classes.dex */
    class a implements s.a {
        a() {
        }

        @Override // androidx.lifecycle.s.a
        public <T extends androidx.lifecycle.r> T a(Class<T> cls) {
            return new g();
        }
    }

    g() {
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static g f(androidx.lifecycle.t tVar) {
        return (g) new androidx.lifecycle.s(tVar, f1973d).a(g.class);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.lifecycle.r
    public void d() {
        Iterator<androidx.lifecycle.t> it = this.f1974c.values().iterator();
        while (it.hasNext()) {
            it.next().a();
        }
        this.f1974c.clear();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void e(UUID uuid) {
        androidx.lifecycle.t remove = this.f1974c.remove(uuid);
        if (remove != null) {
            remove.a();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public androidx.lifecycle.t g(UUID uuid) {
        androidx.lifecycle.t tVar = this.f1974c.get(uuid);
        if (tVar == null) {
            androidx.lifecycle.t tVar2 = new androidx.lifecycle.t();
            this.f1974c.put(uuid, tVar2);
            return tVar2;
        }
        return tVar;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder("NavControllerViewModel{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        sb.append("} ViewModelStores (");
        Iterator<UUID> it = this.f1974c.keySet().iterator();
        while (it.hasNext()) {
            sb.append(it.next());
            if (it.hasNext()) {
                sb.append(", ");
            }
        }
        sb.append(')');
        return sb.toString();
    }
}
