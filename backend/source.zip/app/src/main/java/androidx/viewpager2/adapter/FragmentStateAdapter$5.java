package androidx.viewpager2.adapter;

import android.os.Handler;
import androidx.lifecycle.d;
import androidx.lifecycle.e;
import androidx.lifecycle.g;
/* loaded from: classes.dex */
class FragmentStateAdapter$5 implements e {

    /* renamed from: a  reason: collision with root package name */
    final /* synthetic */ Handler f2821a;

    /* renamed from: b  reason: collision with root package name */
    final /* synthetic */ Runnable f2822b;

    @Override // androidx.lifecycle.e
    public void f(g gVar, d.a aVar) {
        if (aVar == d.a.ON_DESTROY) {
            this.f2821a.removeCallbacks(this.f2822b);
            gVar.a().c(this);
        }
    }
}
