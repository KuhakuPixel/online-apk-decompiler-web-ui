package androidx.appcompat.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewPropertyAnimator;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.OverScroller;
import androidx.appcompat.view.menu.j;
import e0.y;
@SuppressLint({"UnknownNullness"})
/* loaded from: classes.dex */
public class ActionBarOverlayLayout extends ViewGroup implements a0, e0.l, e0.m {
    static final int[] G = {a.a.actionBarSize, 16842841};
    private OverScroller A;
    ViewPropertyAnimator B;
    final AnimatorListenerAdapter C;
    private final Runnable D;
    private final Runnable E;
    private final e0.n F;

    /* renamed from: b  reason: collision with root package name */
    private int f504b;

    /* renamed from: c  reason: collision with root package name */
    private int f505c;

    /* renamed from: d  reason: collision with root package name */
    private ContentFrameLayout f506d;

    /* renamed from: e  reason: collision with root package name */
    ActionBarContainer f507e;

    /* renamed from: f  reason: collision with root package name */
    private b0 f508f;

    /* renamed from: g  reason: collision with root package name */
    private Drawable f509g;

    /* renamed from: h  reason: collision with root package name */
    private boolean f510h;

    /* renamed from: i  reason: collision with root package name */
    private boolean f511i;

    /* renamed from: j  reason: collision with root package name */
    private boolean f512j;

    /* renamed from: k  reason: collision with root package name */
    private boolean f513k;

    /* renamed from: l  reason: collision with root package name */
    boolean f514l;

    /* renamed from: m  reason: collision with root package name */
    private int f515m;

    /* renamed from: n  reason: collision with root package name */
    private int f516n;

    /* renamed from: o  reason: collision with root package name */
    private final Rect f517o;

    /* renamed from: p  reason: collision with root package name */
    private final Rect f518p;

    /* renamed from: q  reason: collision with root package name */
    private final Rect f519q;

    /* renamed from: r  reason: collision with root package name */
    private final Rect f520r;

    /* renamed from: s  reason: collision with root package name */
    private final Rect f521s;

    /* renamed from: t  reason: collision with root package name */
    private final Rect f522t;

    /* renamed from: u  reason: collision with root package name */
    private final Rect f523u;

    /* renamed from: v  reason: collision with root package name */
    private e0.y f524v;

    /* renamed from: w  reason: collision with root package name */
    private e0.y f525w;

    /* renamed from: x  reason: collision with root package name */
    private e0.y f526x;

    /* renamed from: y  reason: collision with root package name */
    private e0.y f527y;

    /* renamed from: z  reason: collision with root package name */
    private d f528z;

    /* loaded from: classes.dex */
    class a extends AnimatorListenerAdapter {
        a() {
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationCancel(Animator animator) {
            ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
            actionBarOverlayLayout.B = null;
            actionBarOverlayLayout.f514l = false;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
            actionBarOverlayLayout.B = null;
            actionBarOverlayLayout.f514l = false;
        }
    }

    /* loaded from: classes.dex */
    class b implements Runnable {
        b() {
        }

        @Override // java.lang.Runnable
        public void run() {
            ActionBarOverlayLayout.this.u();
            ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
            actionBarOverlayLayout.B = actionBarOverlayLayout.f507e.animate().translationY(0.0f).setListener(ActionBarOverlayLayout.this.C);
        }
    }

    /* loaded from: classes.dex */
    class c implements Runnable {
        c() {
        }

        @Override // java.lang.Runnable
        public void run() {
            ActionBarOverlayLayout.this.u();
            ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
            actionBarOverlayLayout.B = actionBarOverlayLayout.f507e.animate().translationY(-ActionBarOverlayLayout.this.f507e.getHeight()).setListener(ActionBarOverlayLayout.this.C);
        }
    }

    /* loaded from: classes.dex */
    public interface d {
        void a(boolean z2);

        void b();

        void c();

        void d(int i2);

        void e();

        void f();
    }

    /* loaded from: classes.dex */
    public static class e extends ViewGroup.MarginLayoutParams {
        public e(int i2, int i3) {
            super(i2, i3);
        }

        public e(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public e(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }
    }

    public ActionBarOverlayLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f505c = 0;
        this.f517o = new Rect();
        this.f518p = new Rect();
        this.f519q = new Rect();
        this.f520r = new Rect();
        this.f521s = new Rect();
        this.f522t = new Rect();
        this.f523u = new Rect();
        e0.y yVar = e0.y.f4329b;
        this.f524v = yVar;
        this.f525w = yVar;
        this.f526x = yVar;
        this.f527y = yVar;
        this.C = new a();
        this.D = new b();
        this.E = new c();
        v(context);
        this.F = new e0.n(this);
    }

    private void A() {
        u();
        this.D.run();
    }

    private boolean B(float f2) {
        this.A.fling(0, 0, 0, (int) f2, 0, 0, Integer.MIN_VALUE, Integer.MAX_VALUE);
        return this.A.getFinalY() > this.f507e.getHeight();
    }

    private void p() {
        u();
        this.E.run();
    }

    /* JADX WARN: Removed duplicated region for block: B:13:0x0021  */
    /* JADX WARN: Removed duplicated region for block: B:17:0x002c  */
    /* JADX WARN: Removed duplicated region for block: B:9:0x0016  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private boolean q(android.view.View r3, android.graphics.Rect r4, boolean r5, boolean r6, boolean r7, boolean r8) {
        /*
            r2 = this;
            android.view.ViewGroup$LayoutParams r3 = r3.getLayoutParams()
            androidx.appcompat.widget.ActionBarOverlayLayout$e r3 = (androidx.appcompat.widget.ActionBarOverlayLayout.e) r3
            r0 = 1
            if (r5 == 0) goto L13
            int r5 = r3.leftMargin
            int r1 = r4.left
            if (r5 == r1) goto L13
            r3.leftMargin = r1
            r5 = 1
            goto L14
        L13:
            r5 = 0
        L14:
            if (r6 == 0) goto L1f
            int r6 = r3.topMargin
            int r1 = r4.top
            if (r6 == r1) goto L1f
            r3.topMargin = r1
            r5 = 1
        L1f:
            if (r8 == 0) goto L2a
            int r6 = r3.rightMargin
            int r8 = r4.right
            if (r6 == r8) goto L2a
            r3.rightMargin = r8
            r5 = 1
        L2a:
            if (r7 == 0) goto L35
            int r6 = r3.bottomMargin
            int r4 = r4.bottom
            if (r6 == r4) goto L35
            r3.bottomMargin = r4
            goto L36
        L35:
            r0 = r5
        L36:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.ActionBarOverlayLayout.q(android.view.View, android.graphics.Rect, boolean, boolean, boolean, boolean):boolean");
    }

    private b0 t(View view) {
        if (view instanceof b0) {
            return (b0) view;
        }
        if (view instanceof Toolbar) {
            return ((Toolbar) view).getWrapper();
        }
        throw new IllegalStateException("Can't make a decor toolbar out of " + view.getClass().getSimpleName());
    }

    private void v(Context context) {
        TypedArray obtainStyledAttributes = getContext().getTheme().obtainStyledAttributes(G);
        this.f504b = obtainStyledAttributes.getDimensionPixelSize(0, 0);
        Drawable drawable = obtainStyledAttributes.getDrawable(1);
        this.f509g = drawable;
        setWillNotDraw(drawable == null);
        obtainStyledAttributes.recycle();
        this.f510h = context.getApplicationInfo().targetSdkVersion < 19;
        this.A = new OverScroller(context);
    }

    private void x() {
        u();
        postDelayed(this.E, 600L);
    }

    private void y() {
        u();
        postDelayed(this.D, 600L);
    }

    @Override // androidx.appcompat.widget.a0
    public void a(Menu menu, j.a aVar) {
        z();
        this.f508f.a(menu, aVar);
    }

    @Override // androidx.appcompat.widget.a0
    public boolean b() {
        z();
        return this.f508f.b();
    }

    @Override // androidx.appcompat.widget.a0
    public boolean c() {
        z();
        return this.f508f.c();
    }

    @Override // android.view.ViewGroup
    protected boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof e;
    }

    @Override // androidx.appcompat.widget.a0
    public boolean d() {
        z();
        return this.f508f.d();
    }

    @Override // android.view.View
    public void draw(Canvas canvas) {
        super.draw(canvas);
        if (this.f509g == null || this.f510h) {
            return;
        }
        int bottom = this.f507e.getVisibility() == 0 ? (int) (this.f507e.getBottom() + this.f507e.getTranslationY() + 0.5f) : 0;
        this.f509g.setBounds(0, bottom, getWidth(), this.f509g.getIntrinsicHeight() + bottom);
        this.f509g.draw(canvas);
    }

    @Override // androidx.appcompat.widget.a0
    public boolean e() {
        z();
        return this.f508f.e();
    }

    @Override // androidx.appcompat.widget.a0
    public void f() {
        z();
        this.f508f.f();
    }

    @Override // android.view.View
    protected boolean fitSystemWindows(Rect rect) {
        return super.fitSystemWindows(rect);
    }

    @Override // androidx.appcompat.widget.a0
    public boolean g() {
        z();
        return this.f508f.g();
    }

    @Override // android.view.ViewGroup
    protected ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new e(layoutParams);
    }

    public int getActionBarHideOffset() {
        ActionBarContainer actionBarContainer = this.f507e;
        if (actionBarContainer != null) {
            return -((int) actionBarContainer.getTranslationY());
        }
        return 0;
    }

    @Override // android.view.ViewGroup
    public int getNestedScrollAxes() {
        return this.F.a();
    }

    public CharSequence getTitle() {
        z();
        return this.f508f.getTitle();
    }

    @Override // e0.l
    public void h(View view, View view2, int i2, int i3) {
        if (i3 == 0) {
            onNestedScrollAccepted(view, view2, i2);
        }
    }

    @Override // e0.l
    public void i(View view, int i2) {
        if (i2 == 0) {
            onStopNestedScroll(view);
        }
    }

    @Override // e0.l
    public void j(View view, int i2, int i3, int[] iArr, int i4) {
        if (i4 == 0) {
            onNestedPreScroll(view, i2, i3, iArr);
        }
    }

    @Override // androidx.appcompat.widget.a0
    public void k(int i2) {
        z();
        if (i2 == 2) {
            this.f508f.t();
        } else if (i2 == 5) {
            this.f508f.v();
        } else if (i2 != 109) {
        } else {
            setOverlayMode(true);
        }
    }

    @Override // androidx.appcompat.widget.a0
    public void l() {
        z();
        this.f508f.h();
    }

    @Override // e0.m
    public void m(View view, int i2, int i3, int i4, int i5, int i6, int[] iArr) {
        n(view, i2, i3, i4, i5, i6);
    }

    @Override // e0.l
    public void n(View view, int i2, int i3, int i4, int i5, int i6) {
        if (i6 == 0) {
            onNestedScroll(view, i2, i3, i4, i5);
        }
    }

    @Override // e0.l
    public boolean o(View view, View view2, int i2, int i3) {
        return i3 == 0 && onStartNestedScroll(view, view2, i2);
    }

    @Override // android.view.View
    public WindowInsets onApplyWindowInsets(WindowInsets windowInsets) {
        z();
        e0.y o2 = e0.y.o(windowInsets);
        boolean q2 = q(this.f507e, new Rect(o2.f(), o2.h(), o2.g(), o2.e()), true, true, false, true);
        e0.q.g(this, o2, this.f517o);
        Rect rect = this.f517o;
        e0.y j2 = o2.j(rect.left, rect.top, rect.right, rect.bottom);
        this.f524v = j2;
        boolean z2 = true;
        if (!this.f525w.equals(j2)) {
            this.f525w = this.f524v;
            q2 = true;
        }
        if (this.f518p.equals(this.f517o)) {
            z2 = q2;
        } else {
            this.f518p.set(this.f517o);
        }
        if (z2) {
            requestLayout();
        }
        return o2.a().c().b().n();
    }

    @Override // android.view.View
    protected void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        v(getContext());
        e0.q.h0(this);
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        u();
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        int childCount = getChildCount();
        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        for (int i6 = 0; i6 < childCount; i6++) {
            View childAt = getChildAt(i6);
            if (childAt.getVisibility() != 8) {
                e eVar = (e) childAt.getLayoutParams();
                int measuredWidth = childAt.getMeasuredWidth();
                int measuredHeight = childAt.getMeasuredHeight();
                int i7 = ((ViewGroup.MarginLayoutParams) eVar).leftMargin + paddingLeft;
                int i8 = ((ViewGroup.MarginLayoutParams) eVar).topMargin + paddingTop;
                childAt.layout(i7, i8, measuredWidth + i7, measuredHeight + i8);
            }
        }
    }

    @Override // android.view.View
    protected void onMeasure(int i2, int i3) {
        int measuredHeight;
        e0.y a2;
        z();
        measureChildWithMargins(this.f507e, i2, 0, i3, 0);
        e eVar = (e) this.f507e.getLayoutParams();
        int max = Math.max(0, this.f507e.getMeasuredWidth() + ((ViewGroup.MarginLayoutParams) eVar).leftMargin + ((ViewGroup.MarginLayoutParams) eVar).rightMargin);
        int max2 = Math.max(0, this.f507e.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) eVar).topMargin + ((ViewGroup.MarginLayoutParams) eVar).bottomMargin);
        int combineMeasuredStates = View.combineMeasuredStates(0, this.f507e.getMeasuredState());
        boolean z2 = (e0.q.J(this) & 256) != 0;
        if (z2) {
            measuredHeight = this.f504b;
            if (this.f512j && this.f507e.getTabContainer() != null) {
                measuredHeight += this.f504b;
            }
        } else {
            measuredHeight = this.f507e.getVisibility() != 8 ? this.f507e.getMeasuredHeight() : 0;
        }
        this.f519q.set(this.f517o);
        e0.y yVar = this.f524v;
        this.f526x = yVar;
        if (this.f511i || z2) {
            a2 = new y.a(this.f526x).c(w.b.a(yVar.f(), this.f526x.h() + measuredHeight, this.f526x.g(), this.f526x.e() + 0)).a();
        } else {
            Rect rect = this.f519q;
            rect.top += measuredHeight;
            rect.bottom += 0;
            a2 = yVar.j(0, measuredHeight, 0, 0);
        }
        this.f526x = a2;
        q(this.f506d, this.f519q, true, true, true, true);
        if (!this.f527y.equals(this.f526x)) {
            e0.y yVar2 = this.f526x;
            this.f527y = yVar2;
            e0.q.h(this.f506d, yVar2);
        }
        measureChildWithMargins(this.f506d, i2, 0, i3, 0);
        e eVar2 = (e) this.f506d.getLayoutParams();
        int max3 = Math.max(max, this.f506d.getMeasuredWidth() + ((ViewGroup.MarginLayoutParams) eVar2).leftMargin + ((ViewGroup.MarginLayoutParams) eVar2).rightMargin);
        int max4 = Math.max(max2, this.f506d.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) eVar2).topMargin + ((ViewGroup.MarginLayoutParams) eVar2).bottomMargin);
        int combineMeasuredStates2 = View.combineMeasuredStates(combineMeasuredStates, this.f506d.getMeasuredState());
        setMeasuredDimension(View.resolveSizeAndState(Math.max(max3 + getPaddingLeft() + getPaddingRight(), getSuggestedMinimumWidth()), i2, combineMeasuredStates2), View.resolveSizeAndState(Math.max(max4 + getPaddingTop() + getPaddingBottom(), getSuggestedMinimumHeight()), i3, combineMeasuredStates2 << 16));
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean onNestedFling(View view, float f2, float f3, boolean z2) {
        if (this.f513k && z2) {
            if (B(f3)) {
                p();
            } else {
                A();
            }
            this.f514l = true;
            return true;
        }
        return false;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean onNestedPreFling(View view, float f2, float f3) {
        return false;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onNestedPreScroll(View view, int i2, int i3, int[] iArr) {
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onNestedScroll(View view, int i2, int i3, int i4, int i5) {
        int i6 = this.f515m + i3;
        this.f515m = i6;
        setActionBarHideOffset(i6);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onNestedScrollAccepted(View view, View view2, int i2) {
        this.F.b(view, view2, i2);
        this.f515m = getActionBarHideOffset();
        u();
        d dVar = this.f528z;
        if (dVar != null) {
            dVar.c();
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean onStartNestedScroll(View view, View view2, int i2) {
        if ((i2 & 2) == 0 || this.f507e.getVisibility() != 0) {
            return false;
        }
        return this.f513k;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onStopNestedScroll(View view) {
        if (this.f513k && !this.f514l) {
            if (this.f515m <= this.f507e.getHeight()) {
                y();
            } else {
                x();
            }
        }
        d dVar = this.f528z;
        if (dVar != null) {
            dVar.f();
        }
    }

    @Override // android.view.View
    public void onWindowSystemUiVisibilityChanged(int i2) {
        super.onWindowSystemUiVisibilityChanged(i2);
        z();
        int i3 = this.f516n ^ i2;
        this.f516n = i2;
        boolean z2 = (i2 & 4) == 0;
        boolean z3 = (i2 & 256) != 0;
        d dVar = this.f528z;
        if (dVar != null) {
            dVar.a(!z3);
            if (z2 || !z3) {
                this.f528z.b();
            } else {
                this.f528z.e();
            }
        }
        if ((i3 & 256) == 0 || this.f528z == null) {
            return;
        }
        e0.q.h0(this);
    }

    @Override // android.view.View
    protected void onWindowVisibilityChanged(int i2) {
        super.onWindowVisibilityChanged(i2);
        this.f505c = i2;
        d dVar = this.f528z;
        if (dVar != null) {
            dVar.d(i2);
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.view.ViewGroup
    /* renamed from: r  reason: merged with bridge method [inline-methods] */
    public e generateDefaultLayoutParams() {
        return new e(-1, -1);
    }

    @Override // android.view.ViewGroup
    /* renamed from: s  reason: merged with bridge method [inline-methods] */
    public e generateLayoutParams(AttributeSet attributeSet) {
        return new e(getContext(), attributeSet);
    }

    public void setActionBarHideOffset(int i2) {
        u();
        this.f507e.setTranslationY(-Math.max(0, Math.min(i2, this.f507e.getHeight())));
    }

    public void setActionBarVisibilityCallback(d dVar) {
        this.f528z = dVar;
        if (getWindowToken() != null) {
            this.f528z.d(this.f505c);
            int i2 = this.f516n;
            if (i2 != 0) {
                onWindowSystemUiVisibilityChanged(i2);
                e0.q.h0(this);
            }
        }
    }

    public void setHasNonEmbeddedTabs(boolean z2) {
        this.f512j = z2;
    }

    public void setHideOnContentScrollEnabled(boolean z2) {
        if (z2 != this.f513k) {
            this.f513k = z2;
            if (z2) {
                return;
            }
            u();
            setActionBarHideOffset(0);
        }
    }

    public void setIcon(int i2) {
        z();
        this.f508f.setIcon(i2);
    }

    public void setIcon(Drawable drawable) {
        z();
        this.f508f.setIcon(drawable);
    }

    public void setLogo(int i2) {
        z();
        this.f508f.m(i2);
    }

    public void setOverlayMode(boolean z2) {
        this.f511i = z2;
        this.f510h = z2 && getContext().getApplicationInfo().targetSdkVersion < 19;
    }

    public void setShowingForActionMode(boolean z2) {
    }

    public void setUiOptions(int i2) {
    }

    @Override // androidx.appcompat.widget.a0
    public void setWindowCallback(Window.Callback callback) {
        z();
        this.f508f.setWindowCallback(callback);
    }

    @Override // androidx.appcompat.widget.a0
    public void setWindowTitle(CharSequence charSequence) {
        z();
        this.f508f.setWindowTitle(charSequence);
    }

    @Override // android.view.ViewGroup
    public boolean shouldDelayChildPressedState() {
        return false;
    }

    void u() {
        removeCallbacks(this.D);
        removeCallbacks(this.E);
        ViewPropertyAnimator viewPropertyAnimator = this.B;
        if (viewPropertyAnimator != null) {
            viewPropertyAnimator.cancel();
        }
    }

    public boolean w() {
        return this.f511i;
    }

    void z() {
        if (this.f506d == null) {
            this.f506d = (ContentFrameLayout) findViewById(a.f.action_bar_activity_content);
            this.f507e = (ActionBarContainer) findViewById(a.f.action_bar_container);
            this.f508f = t(findViewById(a.f.action_bar));
        }
    }
}
