package androidx.navigation;

import android.os.Bundle;
import androidx.navigation.s;
@s.b("navigation")
/* loaded from: classes.dex */
public class m extends s<l> {

    /* renamed from: a  reason: collision with root package name */
    private final t f2020a;

    public m(t tVar) {
        this.f2020a = tVar;
    }

    @Override // androidx.navigation.s
    public boolean e() {
        return true;
    }

    @Override // androidx.navigation.s
    /* renamed from: f  reason: merged with bridge method [inline-methods] */
    public l a() {
        return new l(this);
    }

    @Override // androidx.navigation.s
    /* renamed from: g  reason: merged with bridge method [inline-methods] */
    public k b(l lVar, Bundle bundle, p pVar, s.a aVar) {
        int z2 = lVar.z();
        if (z2 == 0) {
            throw new IllegalStateException("no start destination defined via app:startDestination for " + lVar.i());
        }
        k x2 = lVar.x(z2, false);
        if (x2 != null) {
            return this.f2020a.e(x2.m()).b(x2, x2.e(bundle), pVar, aVar);
        }
        throw new IllegalArgumentException("navigation destination " + lVar.y() + " is not a direct child of this NavGraph");
    }
}
