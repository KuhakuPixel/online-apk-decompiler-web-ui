package androidx.navigation;

import android.content.Intent;
import android.net.Uri;
/* loaded from: classes.dex */
public class j {

    /* renamed from: a  reason: collision with root package name */
    private final Uri f1997a;

    /* renamed from: b  reason: collision with root package name */
    private final String f1998b;

    /* renamed from: c  reason: collision with root package name */
    private final String f1999c;

    /* JADX INFO: Access modifiers changed from: package-private */
    public j(Intent intent) {
        this(intent.getData(), intent.getAction(), intent.getType());
    }

    j(Uri uri, String str, String str2) {
        this.f1997a = uri;
        this.f1998b = str;
        this.f1999c = str2;
    }

    public String a() {
        return this.f1998b;
    }

    public String b() {
        return this.f1999c;
    }

    public Uri c() {
        return this.f1997a;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("NavDeepLinkRequest");
        sb.append("{");
        if (this.f1997a != null) {
            sb.append(" uri=");
            sb.append(this.f1997a.toString());
        }
        if (this.f1998b != null) {
            sb.append(" action=");
            sb.append(this.f1998b);
        }
        if (this.f1999c != null) {
            sb.append(" mimetype=");
            sb.append(this.f1999c);
        }
        sb.append(" }");
        return sb.toString();
    }
}
