package androidx.appcompat.view.menu;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ListAdapter;
import androidx.appcompat.view.menu.j;
import androidx.appcompat.view.menu.k;
import java.util.ArrayList;
/* loaded from: classes.dex */
public class c implements j, AdapterView.OnItemClickListener {

    /* renamed from: b  reason: collision with root package name */
    Context f370b;

    /* renamed from: c  reason: collision with root package name */
    LayoutInflater f371c;

    /* renamed from: d  reason: collision with root package name */
    e f372d;

    /* renamed from: e  reason: collision with root package name */
    ExpandedMenuView f373e;

    /* renamed from: f  reason: collision with root package name */
    int f374f;

    /* renamed from: g  reason: collision with root package name */
    int f375g;

    /* renamed from: h  reason: collision with root package name */
    int f376h;

    /* renamed from: i  reason: collision with root package name */
    private j.a f377i;

    /* renamed from: j  reason: collision with root package name */
    a f378j;

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public class a extends BaseAdapter {

        /* renamed from: b  reason: collision with root package name */
        private int f379b = -1;

        public a() {
            a();
        }

        void a() {
            g v2 = c.this.f372d.v();
            if (v2 != null) {
                ArrayList<g> z2 = c.this.f372d.z();
                int size = z2.size();
                for (int i2 = 0; i2 < size; i2++) {
                    if (z2.get(i2) == v2) {
                        this.f379b = i2;
                        return;
                    }
                }
            }
            this.f379b = -1;
        }

        @Override // android.widget.Adapter
        /* renamed from: b  reason: merged with bridge method [inline-methods] */
        public g getItem(int i2) {
            ArrayList<g> z2 = c.this.f372d.z();
            int i3 = i2 + c.this.f374f;
            int i4 = this.f379b;
            if (i4 >= 0 && i3 >= i4) {
                i3++;
            }
            return z2.get(i3);
        }

        @Override // android.widget.Adapter
        public int getCount() {
            int size = c.this.f372d.z().size() - c.this.f374f;
            return this.f379b < 0 ? size : size - 1;
        }

        @Override // android.widget.Adapter
        public long getItemId(int i2) {
            return i2;
        }

        @Override // android.widget.Adapter
        public View getView(int i2, View view, ViewGroup viewGroup) {
            if (view == null) {
                c cVar = c.this;
                view = cVar.f371c.inflate(cVar.f376h, viewGroup, false);
            }
            ((k.a) view).e(getItem(i2), 0);
            return view;
        }

        @Override // android.widget.BaseAdapter
        public void notifyDataSetChanged() {
            a();
            super.notifyDataSetChanged();
        }
    }

    public c(int i2, int i3) {
        this.f376h = i2;
        this.f375g = i3;
    }

    public c(Context context, int i2) {
        this(i2, 0);
        this.f370b = context;
        this.f371c = LayoutInflater.from(context);
    }

    public ListAdapter a() {
        if (this.f378j == null) {
            this.f378j = new a();
        }
        return this.f378j;
    }

    @Override // androidx.appcompat.view.menu.j
    public void b(e eVar, boolean z2) {
        j.a aVar = this.f377i;
        if (aVar != null) {
            aVar.b(eVar, z2);
        }
    }

    public k c(ViewGroup viewGroup) {
        if (this.f373e == null) {
            this.f373e = (ExpandedMenuView) this.f371c.inflate(a.g.abc_expanded_menu_layout, viewGroup, false);
            if (this.f378j == null) {
                this.f378j = new a();
            }
            this.f373e.setAdapter((ListAdapter) this.f378j);
            this.f373e.setOnItemClickListener(this);
        }
        return this.f373e;
    }

    @Override // androidx.appcompat.view.menu.j
    public boolean d() {
        return false;
    }

    /* JADX WARN: Removed duplicated region for block: B:13:0x0029  */
    /* JADX WARN: Removed duplicated region for block: B:15:? A[RETURN, SYNTHETIC] */
    @Override // androidx.appcompat.view.menu.j
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void e(android.content.Context r3, androidx.appcompat.view.menu.e r4) {
        /*
            r2 = this;
            int r0 = r2.f375g
            if (r0 == 0) goto L14
            android.view.ContextThemeWrapper r0 = new android.view.ContextThemeWrapper
            int r1 = r2.f375g
            r0.<init>(r3, r1)
            r2.f370b = r0
            android.view.LayoutInflater r3 = android.view.LayoutInflater.from(r0)
        L11:
            r2.f371c = r3
            goto L23
        L14:
            android.content.Context r0 = r2.f370b
            if (r0 == 0) goto L23
            r2.f370b = r3
            android.view.LayoutInflater r0 = r2.f371c
            if (r0 != 0) goto L23
            android.view.LayoutInflater r3 = android.view.LayoutInflater.from(r3)
            goto L11
        L23:
            r2.f372d = r4
            androidx.appcompat.view.menu.c$a r3 = r2.f378j
            if (r3 == 0) goto L2c
            r3.notifyDataSetChanged()
        L2c:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.view.menu.c.e(android.content.Context, androidx.appcompat.view.menu.e):void");
    }

    @Override // androidx.appcompat.view.menu.j
    public boolean f(e eVar, g gVar) {
        return false;
    }

    @Override // androidx.appcompat.view.menu.j
    public boolean g(e eVar, g gVar) {
        return false;
    }

    @Override // androidx.appcompat.view.menu.j
    public void h(j.a aVar) {
        this.f377i = aVar;
    }

    @Override // androidx.appcompat.view.menu.j
    public boolean i(m mVar) {
        if (mVar.hasVisibleItems()) {
            new f(mVar).d(null);
            j.a aVar = this.f377i;
            if (aVar != null) {
                aVar.c(mVar);
                return true;
            }
            return true;
        }
        return false;
    }

    @Override // androidx.appcompat.view.menu.j
    public void j(boolean z2) {
        a aVar = this.f378j;
        if (aVar != null) {
            aVar.notifyDataSetChanged();
        }
    }

    @Override // android.widget.AdapterView.OnItemClickListener
    public void onItemClick(AdapterView<?> adapterView, View view, int i2, long j2) {
        this.f372d.M(this.f378j.getItem(i2), this, 0);
    }
}
