package e0;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.view.View;
import android.view.animation.Interpolator;
import java.lang.ref.WeakReference;
/* loaded from: classes.dex */
public final class u {

    /* renamed from: a  reason: collision with root package name */
    private WeakReference<View> f4319a;

    /* renamed from: b  reason: collision with root package name */
    Runnable f4320b = null;

    /* renamed from: c  reason: collision with root package name */
    Runnable f4321c = null;

    /* renamed from: d  reason: collision with root package name */
    int f4322d = -1;

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public class a extends AnimatorListenerAdapter {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ v f4323a;

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ View f4324b;

        a(v vVar, View view) {
            this.f4323a = vVar;
            this.f4324b = view;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationCancel(Animator animator) {
            this.f4323a.c(this.f4324b);
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            this.f4323a.a(this.f4324b);
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationStart(Animator animator) {
            this.f4323a.b(this.f4324b);
        }
    }

    /* loaded from: classes.dex */
    class b implements ValueAnimator.AnimatorUpdateListener {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ x f4326a;

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ View f4327b;

        b(x xVar, View view) {
            this.f4326a = xVar;
            this.f4327b = view;
        }

        @Override // android.animation.ValueAnimator.AnimatorUpdateListener
        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            this.f4326a.a(this.f4327b);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public u(View view) {
        this.f4319a = new WeakReference<>(view);
    }

    private void g(View view, v vVar) {
        if (vVar != null) {
            view.animate().setListener(new a(vVar, view));
        } else {
            view.animate().setListener(null);
        }
    }

    public u a(float f2) {
        View view = this.f4319a.get();
        if (view != null) {
            view.animate().alpha(f2);
        }
        return this;
    }

    public void b() {
        View view = this.f4319a.get();
        if (view != null) {
            view.animate().cancel();
        }
    }

    public long c() {
        View view = this.f4319a.get();
        if (view != null) {
            return view.animate().getDuration();
        }
        return 0L;
    }

    public u d(long j2) {
        View view = this.f4319a.get();
        if (view != null) {
            view.animate().setDuration(j2);
        }
        return this;
    }

    public u e(Interpolator interpolator) {
        View view = this.f4319a.get();
        if (view != null) {
            view.animate().setInterpolator(interpolator);
        }
        return this;
    }

    public u f(v vVar) {
        View view = this.f4319a.get();
        if (view != null) {
            g(view, vVar);
        }
        return this;
    }

    public u h(long j2) {
        View view = this.f4319a.get();
        if (view != null) {
            view.animate().setStartDelay(j2);
        }
        return this;
    }

    public u i(x xVar) {
        View view = this.f4319a.get();
        if (view != null) {
            view.animate().setUpdateListener(xVar != null ? new b(xVar, view) : null);
        }
        return this;
    }

    public void j() {
        View view = this.f4319a.get();
        if (view != null) {
            view.animate().start();
        }
    }

    public u k(float f2) {
        View view = this.f4319a.get();
        if (view != null) {
            view.animate().translationY(f2);
        }
        return this;
    }
}
