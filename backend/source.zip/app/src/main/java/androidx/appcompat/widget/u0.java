package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import androidx.appcompat.view.menu.e;
import androidx.appcompat.view.menu.j;
import androidx.appcompat.widget.Toolbar;
/* loaded from: classes.dex */
public class u0 implements b0 {

    /* renamed from: a  reason: collision with root package name */
    Toolbar f920a;

    /* renamed from: b  reason: collision with root package name */
    private int f921b;

    /* renamed from: c  reason: collision with root package name */
    private View f922c;

    /* renamed from: d  reason: collision with root package name */
    private View f923d;

    /* renamed from: e  reason: collision with root package name */
    private Drawable f924e;

    /* renamed from: f  reason: collision with root package name */
    private Drawable f925f;

    /* renamed from: g  reason: collision with root package name */
    private Drawable f926g;

    /* renamed from: h  reason: collision with root package name */
    private boolean f927h;

    /* renamed from: i  reason: collision with root package name */
    CharSequence f928i;

    /* renamed from: j  reason: collision with root package name */
    private CharSequence f929j;

    /* renamed from: k  reason: collision with root package name */
    private CharSequence f930k;

    /* renamed from: l  reason: collision with root package name */
    Window.Callback f931l;

    /* renamed from: m  reason: collision with root package name */
    boolean f932m;

    /* renamed from: n  reason: collision with root package name */
    private c f933n;

    /* renamed from: o  reason: collision with root package name */
    private int f934o;

    /* renamed from: p  reason: collision with root package name */
    private int f935p;

    /* renamed from: q  reason: collision with root package name */
    private Drawable f936q;

    /* loaded from: classes.dex */
    class a implements View.OnClickListener {

        /* renamed from: b  reason: collision with root package name */
        final g.a f937b;

        a() {
            this.f937b = new g.a(u0.this.f920a.getContext(), 0, 16908332, 0, 0, u0.this.f928i);
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            u0 u0Var = u0.this;
            Window.Callback callback = u0Var.f931l;
            if (callback == null || !u0Var.f932m) {
                return;
            }
            callback.onMenuItemSelected(0, this.f937b);
        }
    }

    /* loaded from: classes.dex */
    class b extends e0.w {

        /* renamed from: a  reason: collision with root package name */
        private boolean f939a = false;

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ int f940b;

        b(int i2) {
            this.f940b = i2;
        }

        @Override // e0.v
        public void a(View view) {
            if (this.f939a) {
                return;
            }
            u0.this.f920a.setVisibility(this.f940b);
        }

        @Override // e0.w, e0.v
        public void b(View view) {
            u0.this.f920a.setVisibility(0);
        }

        @Override // e0.w, e0.v
        public void c(View view) {
            this.f939a = true;
        }
    }

    public u0(Toolbar toolbar, boolean z2) {
        this(toolbar, z2, a.h.abc_action_bar_up_description, a.e.abc_ic_ab_back_material);
    }

    public u0(Toolbar toolbar, boolean z2, int i2, int i3) {
        Drawable drawable;
        this.f934o = 0;
        this.f935p = 0;
        this.f920a = toolbar;
        this.f928i = toolbar.getTitle();
        this.f929j = toolbar.getSubtitle();
        this.f927h = this.f928i != null;
        this.f926g = toolbar.getNavigationIcon();
        t0 v2 = t0.v(toolbar.getContext(), null, a.j.f15a, a.a.actionBarStyle, 0);
        this.f936q = v2.g(a.j.f48l);
        if (z2) {
            CharSequence p2 = v2.p(a.j.f66r);
            if (!TextUtils.isEmpty(p2)) {
                G(p2);
            }
            CharSequence p3 = v2.p(a.j.f60p);
            if (!TextUtils.isEmpty(p3)) {
                F(p3);
            }
            Drawable g2 = v2.g(a.j.f54n);
            if (g2 != null) {
                B(g2);
            }
            Drawable g3 = v2.g(a.j.f51m);
            if (g3 != null) {
                setIcon(g3);
            }
            if (this.f926g == null && (drawable = this.f936q) != null) {
                E(drawable);
            }
            x(v2.k(a.j.f36h, 0));
            int n2 = v2.n(a.j.f33g, 0);
            if (n2 != 0) {
                z(LayoutInflater.from(this.f920a.getContext()).inflate(n2, (ViewGroup) this.f920a, false));
                x(this.f921b | 16);
            }
            int m2 = v2.m(a.j.f42j, 0);
            if (m2 > 0) {
                ViewGroup.LayoutParams layoutParams = this.f920a.getLayoutParams();
                layoutParams.height = m2;
                this.f920a.setLayoutParams(layoutParams);
            }
            int e2 = v2.e(a.j.f30f, -1);
            int e3 = v2.e(a.j.f27e, -1);
            if (e2 >= 0 || e3 >= 0) {
                this.f920a.H(Math.max(e2, 0), Math.max(e3, 0));
            }
            int n3 = v2.n(a.j.f69s, 0);
            if (n3 != 0) {
                Toolbar toolbar2 = this.f920a;
                toolbar2.L(toolbar2.getContext(), n3);
            }
            int n4 = v2.n(a.j.f63q, 0);
            if (n4 != 0) {
                Toolbar toolbar3 = this.f920a;
                toolbar3.K(toolbar3.getContext(), n4);
            }
            int n5 = v2.n(a.j.f57o, 0);
            if (n5 != 0) {
                this.f920a.setPopupTheme(n5);
            }
        } else {
            this.f921b = y();
        }
        v2.w();
        A(i2);
        this.f930k = this.f920a.getNavigationContentDescription();
        this.f920a.setNavigationOnClickListener(new a());
    }

    private void H(CharSequence charSequence) {
        this.f928i = charSequence;
        if ((this.f921b & 8) != 0) {
            this.f920a.setTitle(charSequence);
        }
    }

    private void I() {
        if ((this.f921b & 4) != 0) {
            if (TextUtils.isEmpty(this.f930k)) {
                this.f920a.setNavigationContentDescription(this.f935p);
            } else {
                this.f920a.setNavigationContentDescription(this.f930k);
            }
        }
    }

    private void J() {
        Toolbar toolbar;
        Drawable drawable;
        if ((this.f921b & 4) != 0) {
            toolbar = this.f920a;
            drawable = this.f926g;
            if (drawable == null) {
                drawable = this.f936q;
            }
        } else {
            toolbar = this.f920a;
            drawable = null;
        }
        toolbar.setNavigationIcon(drawable);
    }

    private void K() {
        Drawable drawable;
        int i2 = this.f921b;
        if ((i2 & 2) == 0) {
            drawable = null;
        } else if ((i2 & 1) == 0 || (drawable = this.f925f) == null) {
            drawable = this.f924e;
        }
        this.f920a.setLogo(drawable);
    }

    private int y() {
        if (this.f920a.getNavigationIcon() != null) {
            this.f936q = this.f920a.getNavigationIcon();
            return 15;
        }
        return 11;
    }

    public void A(int i2) {
        if (i2 == this.f935p) {
            return;
        }
        this.f935p = i2;
        if (TextUtils.isEmpty(this.f920a.getNavigationContentDescription())) {
            C(this.f935p);
        }
    }

    public void B(Drawable drawable) {
        this.f925f = drawable;
        K();
    }

    public void C(int i2) {
        D(i2 == 0 ? null : q().getString(i2));
    }

    public void D(CharSequence charSequence) {
        this.f930k = charSequence;
        I();
    }

    public void E(Drawable drawable) {
        this.f926g = drawable;
        J();
    }

    public void F(CharSequence charSequence) {
        this.f929j = charSequence;
        if ((this.f921b & 8) != 0) {
            this.f920a.setSubtitle(charSequence);
        }
    }

    public void G(CharSequence charSequence) {
        this.f927h = true;
        H(charSequence);
    }

    @Override // androidx.appcompat.widget.b0
    public void a(Menu menu, j.a aVar) {
        if (this.f933n == null) {
            c cVar = new c(this.f920a.getContext());
            this.f933n = cVar;
            cVar.p(a.f.action_menu_presenter);
        }
        this.f933n.h(aVar);
        this.f920a.I((androidx.appcompat.view.menu.e) menu, this.f933n);
    }

    @Override // androidx.appcompat.widget.b0
    public boolean b() {
        return this.f920a.z();
    }

    @Override // androidx.appcompat.widget.b0
    public boolean c() {
        return this.f920a.A();
    }

    @Override // androidx.appcompat.widget.b0
    public void collapseActionView() {
        this.f920a.e();
    }

    @Override // androidx.appcompat.widget.b0
    public boolean d() {
        return this.f920a.w();
    }

    @Override // androidx.appcompat.widget.b0
    public boolean e() {
        return this.f920a.O();
    }

    @Override // androidx.appcompat.widget.b0
    public void f() {
        this.f932m = true;
    }

    @Override // androidx.appcompat.widget.b0
    public boolean g() {
        return this.f920a.d();
    }

    @Override // androidx.appcompat.widget.b0
    public CharSequence getTitle() {
        return this.f920a.getTitle();
    }

    @Override // androidx.appcompat.widget.b0
    public void h() {
        this.f920a.f();
    }

    @Override // androidx.appcompat.widget.b0
    public void i(j.a aVar, e.a aVar2) {
        this.f920a.J(aVar, aVar2);
    }

    @Override // androidx.appcompat.widget.b0
    public int j() {
        return this.f921b;
    }

    @Override // androidx.appcompat.widget.b0
    public void k(int i2) {
        this.f920a.setVisibility(i2);
    }

    @Override // androidx.appcompat.widget.b0
    public Menu l() {
        return this.f920a.getMenu();
    }

    @Override // androidx.appcompat.widget.b0
    public void m(int i2) {
        B(i2 != 0 ? c.a.d(q(), i2) : null);
    }

    @Override // androidx.appcompat.widget.b0
    public void n(m0 m0Var) {
        View view = this.f922c;
        if (view != null) {
            ViewParent parent = view.getParent();
            Toolbar toolbar = this.f920a;
            if (parent == toolbar) {
                toolbar.removeView(this.f922c);
            }
        }
        this.f922c = m0Var;
        if (m0Var == null || this.f934o != 2) {
            return;
        }
        this.f920a.addView(m0Var, 0);
        Toolbar.e eVar = (Toolbar.e) this.f922c.getLayoutParams();
        ((ViewGroup.MarginLayoutParams) eVar).width = -2;
        ((ViewGroup.MarginLayoutParams) eVar).height = -2;
        eVar.f2823a = 8388691;
        m0Var.setAllowCollapse(true);
    }

    @Override // androidx.appcompat.widget.b0
    public ViewGroup o() {
        return this.f920a;
    }

    @Override // androidx.appcompat.widget.b0
    public void p(boolean z2) {
    }

    @Override // androidx.appcompat.widget.b0
    public Context q() {
        return this.f920a.getContext();
    }

    @Override // androidx.appcompat.widget.b0
    public int r() {
        return this.f934o;
    }

    @Override // androidx.appcompat.widget.b0
    public e0.u s(int i2, long j2) {
        return e0.q.d(this.f920a).a(i2 == 0 ? 1.0f : 0.0f).d(j2).f(new b(i2));
    }

    @Override // androidx.appcompat.widget.b0
    public void setIcon(int i2) {
        setIcon(i2 != 0 ? c.a.d(q(), i2) : null);
    }

    @Override // androidx.appcompat.widget.b0
    public void setIcon(Drawable drawable) {
        this.f924e = drawable;
        K();
    }

    @Override // androidx.appcompat.widget.b0
    public void setWindowCallback(Window.Callback callback) {
        this.f931l = callback;
    }

    @Override // androidx.appcompat.widget.b0
    public void setWindowTitle(CharSequence charSequence) {
        if (this.f927h) {
            return;
        }
        H(charSequence);
    }

    @Override // androidx.appcompat.widget.b0
    public void t() {
        Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
    }

    @Override // androidx.appcompat.widget.b0
    public boolean u() {
        return this.f920a.v();
    }

    @Override // androidx.appcompat.widget.b0
    public void v() {
        Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
    }

    @Override // androidx.appcompat.widget.b0
    public void w(boolean z2) {
        this.f920a.setCollapsible(z2);
    }

    @Override // androidx.appcompat.widget.b0
    public void x(int i2) {
        View view;
        CharSequence charSequence;
        Toolbar toolbar;
        int i3 = this.f921b ^ i2;
        this.f921b = i2;
        if (i3 != 0) {
            if ((i3 & 4) != 0) {
                if ((i2 & 4) != 0) {
                    I();
                }
                J();
            }
            if ((i3 & 3) != 0) {
                K();
            }
            if ((i3 & 8) != 0) {
                if ((i2 & 8) != 0) {
                    this.f920a.setTitle(this.f928i);
                    toolbar = this.f920a;
                    charSequence = this.f929j;
                } else {
                    charSequence = null;
                    this.f920a.setTitle((CharSequence) null);
                    toolbar = this.f920a;
                }
                toolbar.setSubtitle(charSequence);
            }
            if ((i3 & 16) == 0 || (view = this.f923d) == null) {
                return;
            }
            if ((i2 & 16) != 0) {
                this.f920a.addView(view);
            } else {
                this.f920a.removeView(view);
            }
        }
    }

    public void z(View view) {
        View view2 = this.f923d;
        if (view2 != null && (this.f921b & 16) != 0) {
            this.f920a.removeView(view2);
        }
        this.f923d = view;
        if (view == null || (this.f921b & 16) == 0) {
            return;
        }
        this.f920a.addView(view);
    }
}
