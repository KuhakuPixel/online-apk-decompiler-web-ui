package l0;
/* loaded from: classes.dex */
public final class a {

    /* renamed from: a */
    public static final int fragment_close_enter = 2130771996;

    /* renamed from: b */
    public static final int fragment_close_exit = 2130771997;

    /* renamed from: c */
    public static final int fragment_fade_enter = 2130771998;

    /* renamed from: d */
    public static final int fragment_fade_exit = 2130771999;

    /* renamed from: e */
    public static final int fragment_open_enter = 2130772001;

    /* renamed from: f */
    public static final int fragment_open_exit = 2130772002;
}
