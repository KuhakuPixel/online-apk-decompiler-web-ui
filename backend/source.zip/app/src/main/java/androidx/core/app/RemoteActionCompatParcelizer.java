package androidx.core.app;

import android.app.PendingIntent;
import androidx.core.graphics.drawable.IconCompat;
import androidx.versionedparcelable.a;
/* loaded from: classes.dex */
public class RemoteActionCompatParcelizer {
    public static RemoteActionCompat read(a aVar) {
        RemoteActionCompat remoteActionCompat = new RemoteActionCompat();
        remoteActionCompat.f1386a = (IconCompat) aVar.v(remoteActionCompat.f1386a, 1);
        remoteActionCompat.f1387b = aVar.l(remoteActionCompat.f1387b, 2);
        remoteActionCompat.f1388c = aVar.l(remoteActionCompat.f1388c, 3);
        remoteActionCompat.f1389d = (PendingIntent) aVar.r(remoteActionCompat.f1389d, 4);
        remoteActionCompat.f1390e = aVar.h(remoteActionCompat.f1390e, 5);
        remoteActionCompat.f1391f = aVar.h(remoteActionCompat.f1391f, 6);
        return remoteActionCompat;
    }

    public static void write(RemoteActionCompat remoteActionCompat, a aVar) {
        aVar.x(false, false);
        aVar.M(remoteActionCompat.f1386a, 1);
        aVar.D(remoteActionCompat.f1387b, 2);
        aVar.D(remoteActionCompat.f1388c, 3);
        aVar.H(remoteActionCompat.f1389d, 4);
        aVar.z(remoteActionCompat.f1390e, 5);
        aVar.z(remoteActionCompat.f1391f, 6);
    }
}
