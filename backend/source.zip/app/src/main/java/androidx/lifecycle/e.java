package androidx.lifecycle;

import androidx.lifecycle.d;
/* loaded from: classes.dex */
public interface e extends f {
    void f(g gVar, d.a aVar);
}
