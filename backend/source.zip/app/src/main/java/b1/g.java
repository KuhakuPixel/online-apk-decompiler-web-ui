package b1;

import android.animation.TypeEvaluator;
import android.graphics.Matrix;
/* loaded from: classes.dex */
public class g implements TypeEvaluator<Matrix> {

    /* renamed from: a  reason: collision with root package name */
    private final float[] f3036a = new float[9];

    /* renamed from: b  reason: collision with root package name */
    private final float[] f3037b = new float[9];

    /* renamed from: c  reason: collision with root package name */
    private final Matrix f3038c = new Matrix();

    public Matrix a(float f2, Matrix matrix, Matrix matrix2) {
        matrix.getValues(this.f3036a);
        matrix2.getValues(this.f3037b);
        for (int i2 = 0; i2 < 9; i2++) {
            float[] fArr = this.f3037b;
            float f3 = fArr[i2];
            float[] fArr2 = this.f3036a;
            fArr[i2] = fArr2[i2] + ((f3 - fArr2[i2]) * f2);
        }
        this.f3038c.setValues(this.f3037b);
        return this.f3038c;
    }
}
