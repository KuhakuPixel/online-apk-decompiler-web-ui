package q;

import java.util.ArrayList;
import java.util.Iterator;
/* loaded from: classes.dex */
public class c extends p {

    /* renamed from: k  reason: collision with root package name */
    ArrayList<p> f4996k;

    /* renamed from: l  reason: collision with root package name */
    private int f4997l;

    public c(p.e eVar, int i2) {
        super(eVar);
        this.f4996k = new ArrayList<>();
        this.f5063f = i2;
        q();
    }

    private void q() {
        p.e eVar;
        p.e eVar2 = this.f5059b;
        do {
            eVar = eVar2;
            eVar2 = eVar2.J(this.f5063f);
        } while (eVar2 != null);
        this.f5059b = eVar;
        this.f4996k.add(eVar.L(this.f5063f));
        p.e H = eVar.H(this.f5063f);
        while (H != null) {
            this.f4996k.add(H.L(this.f5063f));
            H = H.H(this.f5063f);
        }
        Iterator<p> it = this.f4996k.iterator();
        while (it.hasNext()) {
            p next = it.next();
            int i2 = this.f5063f;
            if (i2 == 0) {
                next.f5059b.f4891c = this;
            } else if (i2 == 1) {
                next.f5059b.f4893d = this;
            }
        }
        if ((this.f5063f == 0 && ((p.f) this.f5059b.I()).x1()) && this.f4996k.size() > 1) {
            ArrayList<p> arrayList = this.f4996k;
            this.f5059b = arrayList.get(arrayList.size() - 1).f5059b;
        }
        this.f4997l = this.f5063f == 0 ? this.f5059b.x() : this.f5059b.N();
    }

    private p.e r() {
        for (int i2 = 0; i2 < this.f4996k.size(); i2++) {
            p pVar = this.f4996k.get(i2);
            if (pVar.f5059b.Q() != 8) {
                return pVar.f5059b;
            }
        }
        return null;
    }

    private p.e s() {
        for (int size = this.f4996k.size() - 1; size >= 0; size--) {
            p pVar = this.f4996k.get(size);
            if (pVar.f5059b.Q() != 8) {
                return pVar.f5059b;
            }
        }
        return null;
    }

    /* JADX WARN: Code restructure failed: missing block: B:110:0x01a0, code lost:
        if (r1 != r7) goto L120;
     */
    /* JADX WARN: Code restructure failed: missing block: B:119:0x01c6, code lost:
        if (r1 != r7) goto L120;
     */
    /* JADX WARN: Code restructure failed: missing block: B:120:0x01c8, code lost:
        r13 = r13 + 1;
        r7 = r1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:121:0x01cb, code lost:
        r9.f5062e.d(r7);
     */
    /* JADX WARN: Code restructure failed: missing block: B:284:0x03eb, code lost:
        r7 = r7 - r10;
     */
    /* JADX WARN: Removed duplicated region for block: B:64:0x00d9  */
    /* JADX WARN: Removed duplicated region for block: B:67:0x00eb  */
    @Override // q.p, q.d
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void a(q.d r26) {
        /*
            Method dump skipped, instructions count: 1034
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: q.c.a(q.d):void");
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x006d, code lost:
        if (r1 != null) goto L30;
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x00a3, code lost:
        if (r1 != null) goto L30;
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x00a5, code lost:
        b(r5.f5066i, r1, -r0);
     */
    @Override // q.p
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void d() {
        /*
            r5 = this;
            java.util.ArrayList<q.p> r0 = r5.f4996k
            java.util.Iterator r0 = r0.iterator()
        L6:
            boolean r1 = r0.hasNext()
            if (r1 == 0) goto L16
            java.lang.Object r1 = r0.next()
            q.p r1 = (q.p) r1
            r1.d()
            goto L6
        L16:
            java.util.ArrayList<q.p> r0 = r5.f4996k
            int r0 = r0.size()
            r1 = 1
            if (r0 >= r1) goto L20
            return
        L20:
            java.util.ArrayList<q.p> r2 = r5.f4996k
            r3 = 0
            java.lang.Object r2 = r2.get(r3)
            q.p r2 = (q.p) r2
            p.e r2 = r2.f5059b
            java.util.ArrayList<q.p> r4 = r5.f4996k
            int r0 = r0 - r1
            java.lang.Object r0 = r4.get(r0)
            q.p r0 = (q.p) r0
            p.e r0 = r0.f5059b
            int r4 = r5.f5063f
            if (r4 != 0) goto L70
            p.d r1 = r2.H
            p.d r0 = r0.J
            q.f r2 = r5.i(r1, r3)
            int r1 = r1.e()
            p.e r4 = r5.r()
            if (r4 == 0) goto L52
            p.d r1 = r4.H
            int r1 = r1.e()
        L52:
            if (r2 == 0) goto L59
            q.f r4 = r5.f5065h
            r5.b(r4, r2, r1)
        L59:
            q.f r1 = r5.i(r0, r3)
            int r0 = r0.e()
            p.e r2 = r5.s()
            if (r2 == 0) goto L6d
            p.d r0 = r2.J
            int r0 = r0.e()
        L6d:
            if (r1 == 0) goto Lab
            goto La5
        L70:
            p.d r2 = r2.I
            p.d r0 = r0.K
            q.f r3 = r5.i(r2, r1)
            int r2 = r2.e()
            p.e r4 = r5.r()
            if (r4 == 0) goto L88
            p.d r2 = r4.I
            int r2 = r2.e()
        L88:
            if (r3 == 0) goto L8f
            q.f r4 = r5.f5065h
            r5.b(r4, r3, r2)
        L8f:
            q.f r1 = r5.i(r0, r1)
            int r0 = r0.e()
            p.e r2 = r5.s()
            if (r2 == 0) goto La3
            p.d r0 = r2.K
            int r0 = r0.e()
        La3:
            if (r1 == 0) goto Lab
        La5:
            q.f r2 = r5.f5066i
            int r0 = -r0
            r5.b(r2, r1, r0)
        Lab:
            q.f r0 = r5.f5065h
            r0.f5007a = r5
            q.f r0 = r5.f5066i
            r0.f5007a = r5
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: q.c.d():void");
    }

    @Override // q.p
    public void e() {
        for (int i2 = 0; i2 < this.f4996k.size(); i2++) {
            this.f4996k.get(i2).e();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    @Override // q.p
    public void f() {
        this.f5060c = null;
        Iterator<p> it = this.f4996k.iterator();
        while (it.hasNext()) {
            it.next().f();
        }
    }

    @Override // q.p
    public long j() {
        int size = this.f4996k.size();
        long j2 = 0;
        for (int i2 = 0; i2 < size; i2++) {
            j2 = j2 + r4.f5065h.f5012f + this.f4996k.get(i2).j() + r4.f5066i.f5012f;
        }
        return j2;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    @Override // q.p
    public boolean m() {
        int size = this.f4996k.size();
        for (int i2 = 0; i2 < size; i2++) {
            if (!this.f4996k.get(i2).m()) {
                return false;
            }
        }
        return true;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("ChainRun ");
        sb.append(this.f5063f == 0 ? "horizontal : " : "vertical : ");
        String sb2 = sb.toString();
        Iterator<p> it = this.f4996k.iterator();
        while (it.hasNext()) {
            String str = sb2 + "<";
            sb2 = (str + it.next()) + "> ";
        }
        return sb2;
    }
}
