package androidx.navigation;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import androidx.activity.OnBackPressedDispatcher;
import androidx.lifecycle.d;
import androidx.navigation.k;
import androidx.navigation.p;
import androidx.navigation.s;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
/* loaded from: classes.dex */
public class NavController {

    /* renamed from: a  reason: collision with root package name */
    private final Context f1889a;

    /* renamed from: b  reason: collision with root package name */
    private Activity f1890b;

    /* renamed from: c  reason: collision with root package name */
    private o f1891c;

    /* renamed from: d  reason: collision with root package name */
    l f1892d;

    /* renamed from: e  reason: collision with root package name */
    private Bundle f1893e;

    /* renamed from: f  reason: collision with root package name */
    private Parcelable[] f1894f;

    /* renamed from: g  reason: collision with root package name */
    private boolean f1895g;

    /* renamed from: i  reason: collision with root package name */
    private androidx.lifecycle.g f1897i;

    /* renamed from: j  reason: collision with root package name */
    private g f1898j;

    /* renamed from: h  reason: collision with root package name */
    final Deque<e> f1896h = new ArrayDeque();

    /* renamed from: k  reason: collision with root package name */
    private t f1899k = new t();

    /* renamed from: l  reason: collision with root package name */
    private final CopyOnWriteArrayList<b> f1900l = new CopyOnWriteArrayList<>();

    /* renamed from: m  reason: collision with root package name */
    private final androidx.lifecycle.f f1901m = new androidx.lifecycle.e() { // from class: androidx.navigation.NavController.1
        @Override // androidx.lifecycle.e
        public void f(androidx.lifecycle.g gVar, d.a aVar) {
            NavController navController = NavController.this;
            if (navController.f1892d != null) {
                Iterator<e> it = navController.f1896h.iterator();
                while (it.hasNext()) {
                    it.next().i(aVar);
                }
            }
        }
    };

    /* renamed from: n  reason: collision with root package name */
    private final androidx.activity.b f1902n = new a(false);

    /* renamed from: o  reason: collision with root package name */
    private boolean f1903o = true;

    /* loaded from: classes.dex */
    class a extends androidx.activity.b {
        a(boolean z2) {
            super(z2);
        }

        @Override // androidx.activity.b
        public void b() {
            NavController.this.u();
        }
    }

    /* loaded from: classes.dex */
    public interface b {
        void a(NavController navController, k kVar, Bundle bundle);
    }

    public NavController(Context context) {
        this.f1889a = context;
        while (true) {
            if (!(context instanceof ContextWrapper)) {
                break;
            } else if (context instanceof Activity) {
                this.f1890b = (Activity) context;
                break;
            } else {
                context = ((ContextWrapper) context).getBaseContext();
            }
        }
        t tVar = this.f1899k;
        tVar.a(new m(tVar));
        this.f1899k.a(new androidx.navigation.a(this.f1889a));
    }

    private void G() {
        this.f1902n.f(this.f1903o && i() > 1);
    }

    private boolean b() {
        while (!this.f1896h.isEmpty() && (this.f1896h.peekLast().e() instanceof l) && w(this.f1896h.peekLast().e().k(), true)) {
        }
        if (this.f1896h.isEmpty()) {
            return false;
        }
        k e2 = this.f1896h.peekLast().e();
        k kVar = null;
        if (e2 instanceof androidx.navigation.b) {
            Iterator<e> descendingIterator = this.f1896h.descendingIterator();
            while (true) {
                if (!descendingIterator.hasNext()) {
                    break;
                }
                k e3 = descendingIterator.next().e();
                if (!(e3 instanceof l) && !(e3 instanceof androidx.navigation.b)) {
                    kVar = e3;
                    break;
                }
            }
        }
        HashMap hashMap = new HashMap();
        Iterator<e> descendingIterator2 = this.f1896h.descendingIterator();
        while (descendingIterator2.hasNext()) {
            e next = descendingIterator2.next();
            d.b f2 = next.f();
            k e4 = next.e();
            if (e2 != null && e4.k() == e2.k()) {
                d.b bVar = d.b.RESUMED;
                if (f2 != bVar) {
                    hashMap.put(next, bVar);
                }
                e2 = e2.n();
            } else if (kVar == null || e4.k() != kVar.k()) {
                next.l(d.b.CREATED);
            } else {
                if (f2 == d.b.RESUMED) {
                    next.l(d.b.STARTED);
                } else {
                    d.b bVar2 = d.b.STARTED;
                    if (f2 != bVar2) {
                        hashMap.put(next, bVar2);
                    }
                }
                kVar = kVar.n();
            }
        }
        for (e eVar : this.f1896h) {
            d.b bVar3 = (d.b) hashMap.get(eVar);
            if (bVar3 != null) {
                eVar.l(bVar3);
            } else {
                eVar.m();
            }
        }
        e peekLast = this.f1896h.peekLast();
        Iterator<b> it = this.f1900l.iterator();
        while (it.hasNext()) {
            it.next().a(this, peekLast.e(), peekLast.d());
        }
        return true;
    }

    private String e(int[] iArr) {
        l lVar;
        l lVar2 = this.f1892d;
        int i2 = 0;
        while (true) {
            k kVar = null;
            if (i2 >= iArr.length) {
                return null;
            }
            int i3 = iArr[i2];
            if (i2 != 0) {
                kVar = lVar2.w(i3);
            } else if (this.f1892d.k() == i3) {
                kVar = this.f1892d;
            }
            if (kVar == null) {
                return k.j(this.f1889a, i3);
            }
            if (i2 != iArr.length - 1) {
                while (true) {
                    lVar = (l) kVar;
                    if (!(lVar.w(lVar.z()) instanceof l)) {
                        break;
                    }
                    kVar = lVar.w(lVar.z());
                }
                lVar2 = lVar;
            }
            i2++;
        }
    }

    private int i() {
        Iterator<e> it = this.f1896h.iterator();
        int i2 = 0;
        while (it.hasNext()) {
            if (!(it.next().e() instanceof l)) {
                i2++;
            }
        }
        return i2;
    }

    /* JADX WARN: Code restructure failed: missing block: B:11:0x002f, code lost:
        if ((r15 instanceof androidx.navigation.b) == false) goto L12;
     */
    /* JADX WARN: Code restructure failed: missing block: B:13:0x0037, code lost:
        if (r11.f1896h.isEmpty() != false) goto L76;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x0047, code lost:
        if ((r11.f1896h.peekLast().e() instanceof androidx.navigation.b) == false) goto L75;
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x005d, code lost:
        if (w(r11.f1896h.peekLast().e().k(), true) == false) goto L77;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x0060, code lost:
        r14 = new java.util.ArrayDeque();
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x0067, code lost:
        if ((r12 instanceof androidx.navigation.l) == false) goto L33;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x0069, code lost:
        r3 = r15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x006a, code lost:
        r9 = r3.n();
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x006e, code lost:
        if (r9 == null) goto L29;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x0070, code lost:
        r14.addFirst(new androidx.navigation.e(r11.f1889a, r9, r13, r11.f1897i, r11.f1898j));
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x0087, code lost:
        if (r11.f1896h.isEmpty() != false) goto L29;
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x0095, code lost:
        if (r11.f1896h.getLast().e() != r9) goto L29;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x0097, code lost:
        w(r9.k(), true);
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x009e, code lost:
        if (r9 == null) goto L80;
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x00a0, code lost:
        if (r9 != r12) goto L32;
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x00a3, code lost:
        r3 = r9;
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x00a9, code lost:
        if (r14.isEmpty() == false) goto L36;
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x00ab, code lost:
        r12 = r15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:36:0x00ad, code lost:
        r12 = ((androidx.navigation.e) r14.getFirst()).e();
     */
    /* JADX WARN: Code restructure failed: missing block: B:37:0x00b7, code lost:
        if (r12 == null) goto L82;
     */
    /* JADX WARN: Code restructure failed: missing block: B:39:0x00c1, code lost:
        if (d(r12.k()) != null) goto L81;
     */
    /* JADX WARN: Code restructure failed: missing block: B:40:0x00c3, code lost:
        r12 = r12.n();
     */
    /* JADX WARN: Code restructure failed: missing block: B:41:0x00c7, code lost:
        if (r12 == null) goto L85;
     */
    /* JADX WARN: Code restructure failed: missing block: B:42:0x00c9, code lost:
        r14.addFirst(new androidx.navigation.e(r11.f1889a, r12, r13, r11.f1897i, r11.f1898j));
     */
    /* JADX WARN: Code restructure failed: missing block: B:44:0x00df, code lost:
        if (r14.isEmpty() == false) goto L46;
     */
    /* JADX WARN: Code restructure failed: missing block: B:45:0x00e1, code lost:
        r12 = r15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:46:0x00e3, code lost:
        r12 = ((androidx.navigation.e) r14.getLast()).e();
     */
    /* JADX WARN: Code restructure failed: missing block: B:48:0x00f3, code lost:
        if (r11.f1896h.isEmpty() != false) goto L90;
     */
    /* JADX WARN: Code restructure failed: missing block: B:50:0x0103, code lost:
        if ((r11.f1896h.getLast().e() instanceof androidx.navigation.l) == false) goto L89;
     */
    /* JADX WARN: Code restructure failed: missing block: B:52:0x011b, code lost:
        if (((androidx.navigation.l) r11.f1896h.getLast().e()).x(r12.k(), false) != null) goto L91;
     */
    /* JADX WARN: Code restructure failed: missing block: B:54:0x0131, code lost:
        if (w(r11.f1896h.getLast().e().k(), true) == false) goto L88;
     */
    /* JADX WARN: Code restructure failed: missing block: B:56:0x0134, code lost:
        r11.f1896h.addAll(r14);
     */
    /* JADX WARN: Code restructure failed: missing block: B:57:0x013f, code lost:
        if (r11.f1896h.isEmpty() != false) goto L60;
     */
    /* JADX WARN: Code restructure failed: missing block: B:59:0x014f, code lost:
        if (r11.f1896h.getFirst().e() == r11.f1892d) goto L61;
     */
    /* JADX WARN: Code restructure failed: missing block: B:60:0x0151, code lost:
        r11.f1896h.addFirst(new androidx.navigation.e(r11.f1889a, r11.f1892d, r13, r11.f1897i, r11.f1898j));
     */
    /* JADX WARN: Code restructure failed: missing block: B:61:0x0165, code lost:
        r11.f1896h.add(new androidx.navigation.e(r11.f1889a, r15, r15.e(r13), r11.f1897i, r11.f1898j));
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private void r(androidx.navigation.k r12, android.os.Bundle r13, androidx.navigation.p r14, androidx.navigation.s.a r15) {
        /*
            Method dump skipped, instructions count: 415
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.navigation.NavController.r(androidx.navigation.k, android.os.Bundle, androidx.navigation.p, androidx.navigation.s$a):void");
    }

    private void t(Bundle bundle) {
        Activity activity;
        ArrayList<String> stringArrayList;
        Bundle bundle2 = this.f1893e;
        if (bundle2 != null && (stringArrayList = bundle2.getStringArrayList("android-support-nav:controller:navigatorState:names")) != null) {
            Iterator<String> it = stringArrayList.iterator();
            while (it.hasNext()) {
                String next = it.next();
                s e2 = this.f1899k.e(next);
                Bundle bundle3 = this.f1893e.getBundle(next);
                if (bundle3 != null) {
                    e2.c(bundle3);
                }
            }
        }
        Parcelable[] parcelableArr = this.f1894f;
        boolean z2 = false;
        if (parcelableArr != null) {
            for (Parcelable parcelable : parcelableArr) {
                f fVar = (f) parcelable;
                k d2 = d(fVar.k());
                if (d2 == null) {
                    throw new IllegalStateException("Restoring the Navigation back stack failed: destination " + k.j(this.f1889a, fVar.k()) + " cannot be found from the current destination " + h());
                }
                Bundle j2 = fVar.j();
                if (j2 != null) {
                    j2.setClassLoader(this.f1889a.getClassLoader());
                }
                this.f1896h.add(new e(this.f1889a, d2, j2, this.f1897i, this.f1898j, fVar.m(), fVar.l()));
            }
            G();
            this.f1894f = null;
        }
        if (this.f1892d == null || !this.f1896h.isEmpty()) {
            b();
            return;
        }
        if (!this.f1895g && (activity = this.f1890b) != null && m(activity.getIntent())) {
            z2 = true;
        }
        if (z2) {
            return;
        }
        r(this.f1892d, bundle, null, null);
    }

    public void A(int i2) {
        B(i2, null);
    }

    public void B(int i2, Bundle bundle) {
        C(k().c(i2), bundle);
    }

    public void C(l lVar, Bundle bundle) {
        l lVar2 = this.f1892d;
        if (lVar2 != null) {
            w(lVar2.k(), true);
        }
        this.f1892d = lVar;
        t(bundle);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void D(androidx.lifecycle.g gVar) {
        if (gVar == this.f1897i) {
            return;
        }
        this.f1897i = gVar;
        gVar.a().a(this.f1901m);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void E(OnBackPressedDispatcher onBackPressedDispatcher) {
        if (this.f1897i == null) {
            throw new IllegalStateException("You must call setLifecycleOwner() before calling setOnBackPressedDispatcher()");
        }
        this.f1902n.d();
        onBackPressedDispatcher.a(this.f1897i, this.f1902n);
        this.f1897i.a().c(this.f1901m);
        this.f1897i.a().a(this.f1901m);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void F(androidx.lifecycle.t tVar) {
        if (this.f1898j == g.f(tVar)) {
            return;
        }
        if (!this.f1896h.isEmpty()) {
            throw new IllegalStateException("ViewModelStore should be set before setGraph call");
        }
        this.f1898j = g.f(tVar);
    }

    public void a(b bVar) {
        if (!this.f1896h.isEmpty()) {
            e peekLast = this.f1896h.peekLast();
            bVar.a(this, peekLast.e(), peekLast.d());
        }
        this.f1900l.add(bVar);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void c(boolean z2) {
        this.f1903o = z2;
        G();
    }

    k d(int i2) {
        l lVar = this.f1892d;
        if (lVar == null) {
            return null;
        }
        if (lVar.k() == i2) {
            return this.f1892d;
        }
        l e2 = this.f1896h.isEmpty() ? this.f1892d : this.f1896h.getLast().e();
        return (e2 instanceof l ? e2 : e2.n()).w(i2);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public Context f() {
        return this.f1889a;
    }

    public e g() {
        if (this.f1896h.isEmpty()) {
            return null;
        }
        return this.f1896h.getLast();
    }

    public k h() {
        e g2 = g();
        if (g2 != null) {
            return g2.e();
        }
        return null;
    }

    public l j() {
        l lVar = this.f1892d;
        if (lVar != null) {
            return lVar;
        }
        throw new IllegalStateException("You must call setGraph() before calling getGraph()");
    }

    public o k() {
        if (this.f1891c == null) {
            this.f1891c = new o(this.f1889a, this.f1899k);
        }
        return this.f1891c;
    }

    public t l() {
        return this.f1899k;
    }

    public boolean m(Intent intent) {
        k.a o2;
        l lVar;
        if (intent == null) {
            return false;
        }
        Bundle extras = intent.getExtras();
        int[] intArray = extras != null ? extras.getIntArray("android-support-nav:controller:deepLinkIds") : null;
        Bundle bundle = new Bundle();
        Bundle bundle2 = extras != null ? extras.getBundle("android-support-nav:controller:deepLinkExtras") : null;
        if (bundle2 != null) {
            bundle.putAll(bundle2);
        }
        if ((intArray == null || intArray.length == 0) && intent.getData() != null && (o2 = this.f1892d.o(new j(intent))) != null) {
            k b2 = o2.b();
            int[] f2 = b2.f();
            bundle.putAll(b2.e(o2.c()));
            intArray = f2;
        }
        if (intArray == null || intArray.length == 0) {
            return false;
        }
        String e2 = e(intArray);
        if (e2 != null) {
            Log.i("NavController", "Could not find destination " + e2 + " in the navigation graph, ignoring the deep link from " + intent);
            return false;
        }
        bundle.putParcelable("android-support-nav:controller:deepLinkIntent", intent);
        int flags = intent.getFlags();
        int i2 = 268435456 & flags;
        if (i2 != 0 && (flags & 32768) == 0) {
            intent.addFlags(32768);
            t.h.g(this.f1889a).d(intent).j();
            Activity activity = this.f1890b;
            if (activity != null) {
                activity.finish();
                this.f1890b.overridePendingTransition(0, 0);
            }
            return true;
        } else if (i2 != 0) {
            if (!this.f1896h.isEmpty()) {
                w(this.f1892d.k(), true);
            }
            int i3 = 0;
            while (i3 < intArray.length) {
                int i4 = i3 + 1;
                int i5 = intArray[i3];
                k d2 = d(i5);
                if (d2 == null) {
                    throw new IllegalStateException("Deep Linking failed: destination " + k.j(this.f1889a, i5) + " cannot be found from the current destination " + h());
                }
                r(d2, bundle, new p.a().b(0).c(0).a(), null);
                i3 = i4;
            }
            return true;
        } else {
            l lVar2 = this.f1892d;
            int i6 = 0;
            while (i6 < intArray.length) {
                int i7 = intArray[i6];
                k w2 = i6 == 0 ? this.f1892d : lVar2.w(i7);
                if (w2 == null) {
                    throw new IllegalStateException("Deep Linking failed: destination " + k.j(this.f1889a, i7) + " cannot be found in graph " + lVar2);
                }
                if (i6 != intArray.length - 1) {
                    while (true) {
                        lVar = (l) w2;
                        if (!(lVar.w(lVar.z()) instanceof l)) {
                            break;
                        }
                        w2 = lVar.w(lVar.z());
                    }
                    lVar2 = lVar;
                } else {
                    r(w2, w2.e(bundle), new p.a().g(this.f1892d.k(), true).b(0).c(0).a(), null);
                }
                i6++;
            }
            this.f1895g = true;
            return true;
        }
    }

    public void n(int i2) {
        o(i2, null);
    }

    public void o(int i2, Bundle bundle) {
        p(i2, bundle, null);
    }

    public void p(int i2, Bundle bundle, p pVar) {
        q(i2, bundle, pVar, null);
    }

    public void q(int i2, Bundle bundle, p pVar, s.a aVar) {
        int i3;
        k e2 = this.f1896h.isEmpty() ? this.f1892d : this.f1896h.getLast().e();
        if (e2 == null) {
            throw new IllegalStateException("no current navigation node");
        }
        c g2 = e2.g(i2);
        Bundle bundle2 = null;
        if (g2 != null) {
            if (pVar == null) {
                pVar = g2.c();
            }
            i3 = g2.b();
            Bundle a2 = g2.a();
            if (a2 != null) {
                bundle2 = new Bundle();
                bundle2.putAll(a2);
            }
        } else {
            i3 = i2;
        }
        if (bundle != null) {
            if (bundle2 == null) {
                bundle2 = new Bundle();
            }
            bundle2.putAll(bundle);
        }
        if (i3 == 0 && pVar != null && pVar.e() != -1) {
            v(pVar.e(), pVar.f());
        } else if (i3 == 0) {
            throw new IllegalArgumentException("Destination id == 0 can only be used in conjunction with a valid navOptions.popUpTo");
        } else {
            k d2 = d(i3);
            if (d2 != null) {
                r(d2, bundle2, pVar, aVar);
                return;
            }
            String j2 = k.j(this.f1889a, i3);
            if (g2 == null) {
                throw new IllegalArgumentException("Navigation action/destination " + j2 + " cannot be found from the current destination " + e2);
            }
            throw new IllegalArgumentException("Navigation destination " + j2 + " referenced from action " + k.j(this.f1889a, i2) + " cannot be found from the current destination " + e2);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v2, types: [androidx.navigation.k] */
    /* JADX WARN: Type inference failed for: r0v3, types: [androidx.navigation.k] */
    /* JADX WARN: Type inference failed for: r0v4, types: [androidx.navigation.k, androidx.navigation.l] */
    public boolean s() {
        int k2;
        if (i() == 1) {
            ?? h2 = h();
            do {
                k2 = h2.k();
                h2 = h2.n();
                if (h2 == 0) {
                    return false;
                }
            } while (h2.z() == k2);
            Bundle bundle = new Bundle();
            Activity activity = this.f1890b;
            if (activity != null && activity.getIntent() != null && this.f1890b.getIntent().getData() != null) {
                bundle.putParcelable("android-support-nav:controller:deepLinkIntent", this.f1890b.getIntent());
                k.a o2 = this.f1892d.o(new j(this.f1890b.getIntent()));
                if (o2 != null) {
                    bundle.putAll(o2.b().e(o2.c()));
                }
            }
            new i(this).d(h2.k()).c(bundle).a().j();
            Activity activity2 = this.f1890b;
            if (activity2 != null) {
                activity2.finish();
            }
            return true;
        }
        return u();
    }

    public boolean u() {
        if (this.f1896h.isEmpty()) {
            return false;
        }
        return v(h().k(), true);
    }

    public boolean v(int i2, boolean z2) {
        return w(i2, z2) && b();
    }

    boolean w(int i2, boolean z2) {
        boolean z3;
        boolean z4 = false;
        if (this.f1896h.isEmpty()) {
            return false;
        }
        ArrayList arrayList = new ArrayList();
        Iterator<e> descendingIterator = this.f1896h.descendingIterator();
        while (true) {
            if (!descendingIterator.hasNext()) {
                z3 = false;
                break;
            }
            k e2 = descendingIterator.next().e();
            s e3 = this.f1899k.e(e2.m());
            if (z2 || e2.k() != i2) {
                arrayList.add(e3);
            }
            if (e2.k() == i2) {
                z3 = true;
                break;
            }
        }
        if (!z3) {
            Log.i("NavController", "Ignoring popBackStack to destination " + k.j(this.f1889a, i2) + " as it was not found on the current back stack");
            return false;
        }
        Iterator it = arrayList.iterator();
        while (it.hasNext() && ((s) it.next()).e()) {
            e removeLast = this.f1896h.removeLast();
            if (removeLast.a().b().a(d.b.CREATED)) {
                removeLast.l(d.b.DESTROYED);
            }
            g gVar = this.f1898j;
            if (gVar != null) {
                gVar.e(removeLast.f1927g);
            }
            z4 = true;
        }
        G();
        return z4;
    }

    public void x(b bVar) {
        this.f1900l.remove(bVar);
    }

    public void y(Bundle bundle) {
        if (bundle == null) {
            return;
        }
        bundle.setClassLoader(this.f1889a.getClassLoader());
        this.f1893e = bundle.getBundle("android-support-nav:controller:navigatorState");
        this.f1894f = bundle.getParcelableArray("android-support-nav:controller:backStack");
        this.f1895g = bundle.getBoolean("android-support-nav:controller:deepLinkHandled");
    }

    public Bundle z() {
        Bundle bundle;
        ArrayList<String> arrayList = new ArrayList<>();
        Bundle bundle2 = new Bundle();
        for (Map.Entry<String, s<? extends k>> entry : this.f1899k.f().entrySet()) {
            String key = entry.getKey();
            Bundle d2 = entry.getValue().d();
            if (d2 != null) {
                arrayList.add(key);
                bundle2.putBundle(key, d2);
            }
        }
        if (arrayList.isEmpty()) {
            bundle = null;
        } else {
            bundle = new Bundle();
            bundle2.putStringArrayList("android-support-nav:controller:navigatorState:names", arrayList);
            bundle.putBundle("android-support-nav:controller:navigatorState", bundle2);
        }
        if (!this.f1896h.isEmpty()) {
            if (bundle == null) {
                bundle = new Bundle();
            }
            Parcelable[] parcelableArr = new Parcelable[this.f1896h.size()];
            int i2 = 0;
            Iterator<e> it = this.f1896h.iterator();
            while (it.hasNext()) {
                parcelableArr[i2] = new f(it.next());
                i2++;
            }
            bundle.putParcelableArray("android-support-nav:controller:backStack", parcelableArr);
        }
        if (this.f1895g) {
            if (bundle == null) {
                bundle = new Bundle();
            }
            bundle.putBoolean("android-support-nav:controller:deepLinkHandled", this.f1895g);
        }
        return bundle;
    }
}
