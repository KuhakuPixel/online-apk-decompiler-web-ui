package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.util.Log;
import android.util.SparseArray;
import android.util.Xml;
import java.io.IOException;
import java.util.ArrayList;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
/* loaded from: classes.dex */
public class c {

    /* renamed from: a  reason: collision with root package name */
    private final ConstraintLayout f1148a;

    /* renamed from: b  reason: collision with root package name */
    int f1149b = -1;

    /* renamed from: c  reason: collision with root package name */
    int f1150c = -1;

    /* renamed from: d  reason: collision with root package name */
    private SparseArray<a> f1151d = new SparseArray<>();

    /* renamed from: e  reason: collision with root package name */
    private SparseArray<d> f1152e = new SparseArray<>();

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public static class a {

        /* renamed from: a  reason: collision with root package name */
        int f1153a;

        /* renamed from: b  reason: collision with root package name */
        ArrayList<b> f1154b = new ArrayList<>();

        /* renamed from: c  reason: collision with root package name */
        int f1155c;

        /* renamed from: d  reason: collision with root package name */
        d f1156d;

        public a(Context context, XmlPullParser xmlPullParser) {
            this.f1155c = -1;
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(Xml.asAttributeSet(xmlPullParser), i.F4);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i2 = 0; i2 < indexCount; i2++) {
                int index = obtainStyledAttributes.getIndex(i2);
                if (index == i.G4) {
                    this.f1153a = obtainStyledAttributes.getResourceId(index, this.f1153a);
                } else if (index == i.H4) {
                    this.f1155c = obtainStyledAttributes.getResourceId(index, this.f1155c);
                    String resourceTypeName = context.getResources().getResourceTypeName(this.f1155c);
                    context.getResources().getResourceName(this.f1155c);
                    if ("layout".equals(resourceTypeName)) {
                        d dVar = new d();
                        this.f1156d = dVar;
                        dVar.f(context, this.f1155c);
                    }
                }
            }
            obtainStyledAttributes.recycle();
        }

        void a(b bVar) {
            this.f1154b.add(bVar);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public static class b {

        /* renamed from: a  reason: collision with root package name */
        float f1157a;

        /* renamed from: b  reason: collision with root package name */
        float f1158b;

        /* renamed from: c  reason: collision with root package name */
        float f1159c;

        /* renamed from: d  reason: collision with root package name */
        float f1160d;

        /* renamed from: e  reason: collision with root package name */
        int f1161e;

        /* renamed from: f  reason: collision with root package name */
        d f1162f;

        public b(Context context, XmlPullParser xmlPullParser) {
            this.f1157a = Float.NaN;
            this.f1158b = Float.NaN;
            this.f1159c = Float.NaN;
            this.f1160d = Float.NaN;
            this.f1161e = -1;
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(Xml.asAttributeSet(xmlPullParser), i.b5);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i2 = 0; i2 < indexCount; i2++) {
                int index = obtainStyledAttributes.getIndex(i2);
                if (index == i.c5) {
                    this.f1161e = obtainStyledAttributes.getResourceId(index, this.f1161e);
                    String resourceTypeName = context.getResources().getResourceTypeName(this.f1161e);
                    context.getResources().getResourceName(this.f1161e);
                    if ("layout".equals(resourceTypeName)) {
                        d dVar = new d();
                        this.f1162f = dVar;
                        dVar.f(context, this.f1161e);
                    }
                } else if (index == i.d5) {
                    this.f1160d = obtainStyledAttributes.getDimension(index, this.f1160d);
                } else if (index == i.e5) {
                    this.f1158b = obtainStyledAttributes.getDimension(index, this.f1158b);
                } else if (index == i.f5) {
                    this.f1159c = obtainStyledAttributes.getDimension(index, this.f1159c);
                } else if (index == i.g5) {
                    this.f1157a = obtainStyledAttributes.getDimension(index, this.f1157a);
                } else {
                    Log.v("ConstraintLayoutStates", "Unknown tag");
                }
            }
            obtainStyledAttributes.recycle();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public c(Context context, ConstraintLayout constraintLayout, int i2) {
        this.f1148a = constraintLayout;
        a(context, i2);
    }

    private void a(Context context, int i2) {
        XmlResourceParser xml = context.getResources().getXml(i2);
        a aVar = null;
        try {
            for (int eventType = xml.getEventType(); eventType != 1; eventType = xml.next()) {
                if (eventType == 0) {
                    xml.getName();
                } else if (eventType == 2) {
                    String name = xml.getName();
                    char c2 = 65535;
                    switch (name.hashCode()) {
                        case -1349929691:
                            if (name.equals("ConstraintSet")) {
                                c2 = 4;
                                break;
                            }
                            break;
                        case 80204913:
                            if (name.equals("State")) {
                                c2 = 2;
                                break;
                            }
                            break;
                        case 1382829617:
                            if (name.equals("StateSet")) {
                                c2 = 1;
                                break;
                            }
                            break;
                        case 1657696882:
                            if (name.equals("layoutDescription")) {
                                c2 = 0;
                                break;
                            }
                            break;
                        case 1901439077:
                            if (name.equals("Variant")) {
                                c2 = 3;
                                break;
                            }
                            break;
                    }
                    if (c2 != 0 && c2 != 1) {
                        if (c2 == 2) {
                            aVar = new a(context, xml);
                            this.f1151d.put(aVar.f1153a, aVar);
                        } else if (c2 == 3) {
                            b bVar = new b(context, xml);
                            if (aVar != null) {
                                aVar.a(bVar);
                            }
                        } else if (c2 != 4) {
                            Log.v("ConstraintLayoutStates", "unknown tag " + name);
                        } else {
                            b(context, xml);
                        }
                    }
                }
            }
        } catch (IOException e2) {
            e2.printStackTrace();
        } catch (XmlPullParserException e3) {
            e3.printStackTrace();
        }
    }

    private void b(Context context, XmlPullParser xmlPullParser) {
        d dVar = new d();
        int attributeCount = xmlPullParser.getAttributeCount();
        for (int i2 = 0; i2 < attributeCount; i2++) {
            if ("id".equals(xmlPullParser.getAttributeName(i2))) {
                String attributeValue = xmlPullParser.getAttributeValue(i2);
                int identifier = attributeValue.contains("/") ? context.getResources().getIdentifier(attributeValue.substring(attributeValue.indexOf(47) + 1), "id", context.getPackageName()) : -1;
                if (identifier == -1) {
                    if (attributeValue.length() > 1) {
                        identifier = Integer.parseInt(attributeValue.substring(1));
                    } else {
                        Log.e("ConstraintLayoutStates", "error in parsing id");
                    }
                }
                dVar.n(context, xmlPullParser);
                this.f1152e.put(identifier, dVar);
                return;
            }
        }
    }

    public void c(f fVar) {
    }
}
