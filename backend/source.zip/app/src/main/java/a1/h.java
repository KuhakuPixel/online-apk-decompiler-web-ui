package a1;
/* loaded from: classes.dex */
public final class h {

    /* renamed from: a */
    public static final int design_layout_snackbar = 2131558432;

    /* renamed from: b */
    public static final int design_layout_snackbar_include = 2131558433;

    /* renamed from: c */
    public static final int design_navigation_menu_item = 2131558442;

    /* renamed from: d */
    public static final int design_text_input_end_icon = 2131558443;

    /* renamed from: e */
    public static final int design_text_input_start_icon = 2131558444;

    /* renamed from: f */
    public static final int material_clockface_textview = 2131558454;

    /* renamed from: g */
    public static final int material_clockface_view = 2131558455;

    /* renamed from: h */
    public static final int material_radial_view_group = 2131558456;

    /* renamed from: i */
    public static final int material_time_chip = 2131558458;

    /* renamed from: j */
    public static final int material_time_input = 2131558459;

    /* renamed from: k */
    public static final int material_timepicker = 2131558460;

    /* renamed from: l */
    public static final int mtrl_calendar_day = 2131558469;

    /* renamed from: m */
    public static final int mtrl_calendar_day_of_week = 2131558470;

    /* renamed from: n */
    public static final int mtrl_calendar_horizontal = 2131558472;

    /* renamed from: o */
    public static final int mtrl_calendar_month_labeled = 2131558474;

    /* renamed from: p */
    public static final int mtrl_calendar_vertical = 2131558477;

    /* renamed from: q */
    public static final int mtrl_calendar_year = 2131558478;

    /* renamed from: r */
    public static final int mtrl_layout_snackbar = 2131558479;

    /* renamed from: s */
    public static final int mtrl_layout_snackbar_include = 2131558480;

    /* renamed from: t */
    public static final int mtrl_picker_dialog = 2131558482;

    /* renamed from: u */
    public static final int mtrl_picker_fullscreen = 2131558483;
}
