package androidx.databinding;

import androidx.databinding.g;
/* loaded from: classes.dex */
public class a implements g {

    /* renamed from: a  reason: collision with root package name */
    private transient l f1508a;

    @Override // androidx.databinding.g
    public void a(g.a aVar) {
        synchronized (this) {
            if (this.f1508a == null) {
                this.f1508a = new l();
            }
        }
        this.f1508a.a(aVar);
    }

    @Override // androidx.databinding.g
    public void c(g.a aVar) {
        synchronized (this) {
            l lVar = this.f1508a;
            if (lVar == null) {
                return;
            }
            lVar.i(aVar);
        }
    }

    public void d(int i2) {
        synchronized (this) {
            l lVar = this.f1508a;
            if (lVar == null) {
                return;
            }
            lVar.d(this, i2, null);
        }
    }
}
