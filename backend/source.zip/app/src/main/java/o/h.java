package o;

import java.util.Arrays;
import java.util.Comparator;
import o.b;
/* loaded from: classes.dex */
public class h extends o.b {

    /* renamed from: g  reason: collision with root package name */
    private int f4756g;

    /* renamed from: h  reason: collision with root package name */
    private i[] f4757h;

    /* renamed from: i  reason: collision with root package name */
    private i[] f4758i;

    /* renamed from: j  reason: collision with root package name */
    private int f4759j;

    /* renamed from: k  reason: collision with root package name */
    b f4760k;

    /* renamed from: l  reason: collision with root package name */
    c f4761l;

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public class a implements Comparator<i> {
        a() {
        }

        @Override // java.util.Comparator
        /* renamed from: a  reason: merged with bridge method [inline-methods] */
        public int compare(i iVar, i iVar2) {
            return iVar.f4769c - iVar2.f4769c;
        }
    }

    /* loaded from: classes.dex */
    class b implements Comparable {

        /* renamed from: b  reason: collision with root package name */
        i f4763b;

        /* renamed from: c  reason: collision with root package name */
        h f4764c;

        public b(h hVar) {
            this.f4764c = hVar;
        }

        public boolean a(i iVar, float f2) {
            boolean z2 = true;
            if (!this.f4763b.f4767a) {
                for (int i2 = 0; i2 < 9; i2++) {
                    float f3 = iVar.f4775i[i2];
                    if (f3 != 0.0f) {
                        float f4 = f3 * f2;
                        if (Math.abs(f4) < 1.0E-4f) {
                            f4 = 0.0f;
                        }
                        this.f4763b.f4775i[i2] = f4;
                    } else {
                        this.f4763b.f4775i[i2] = 0.0f;
                    }
                }
                return true;
            }
            for (int i3 = 0; i3 < 9; i3++) {
                float[] fArr = this.f4763b.f4775i;
                fArr[i3] = fArr[i3] + (iVar.f4775i[i3] * f2);
                if (Math.abs(fArr[i3]) < 1.0E-4f) {
                    this.f4763b.f4775i[i3] = 0.0f;
                } else {
                    z2 = false;
                }
            }
            if (z2) {
                h.this.G(this.f4763b);
            }
            return false;
        }

        public void b(i iVar) {
            this.f4763b = iVar;
        }

        public final boolean c() {
            for (int i2 = 8; i2 >= 0; i2--) {
                float f2 = this.f4763b.f4775i[i2];
                if (f2 > 0.0f) {
                    return false;
                }
                if (f2 < 0.0f) {
                    return true;
                }
            }
            return false;
        }

        @Override // java.lang.Comparable
        public int compareTo(Object obj) {
            return this.f4763b.f4769c - ((i) obj).f4769c;
        }

        public final boolean d(i iVar) {
            int i2 = 8;
            while (true) {
                if (i2 < 0) {
                    break;
                }
                float f2 = iVar.f4775i[i2];
                float f3 = this.f4763b.f4775i[i2];
                if (f3 == f2) {
                    i2--;
                } else if (f3 < f2) {
                    return true;
                }
            }
            return false;
        }

        public void e() {
            Arrays.fill(this.f4763b.f4775i, 0.0f);
        }

        public String toString() {
            String str = "[ ";
            if (this.f4763b != null) {
                for (int i2 = 0; i2 < 9; i2++) {
                    str = str + this.f4763b.f4775i[i2] + " ";
                }
            }
            return str + "] " + this.f4763b;
        }
    }

    public h(c cVar) {
        super(cVar);
        this.f4756g = 128;
        this.f4757h = new i[128];
        this.f4758i = new i[128];
        this.f4759j = 0;
        this.f4760k = new b(this);
        this.f4761l = cVar;
    }

    private final void F(i iVar) {
        int i2;
        int i3 = this.f4759j + 1;
        i[] iVarArr = this.f4757h;
        if (i3 > iVarArr.length) {
            i[] iVarArr2 = (i[]) Arrays.copyOf(iVarArr, iVarArr.length * 2);
            this.f4757h = iVarArr2;
            this.f4758i = (i[]) Arrays.copyOf(iVarArr2, iVarArr2.length * 2);
        }
        i[] iVarArr3 = this.f4757h;
        int i4 = this.f4759j;
        iVarArr3[i4] = iVar;
        int i5 = i4 + 1;
        this.f4759j = i5;
        if (i5 > 1 && iVarArr3[i5 - 1].f4769c > iVar.f4769c) {
            int i6 = 0;
            while (true) {
                i2 = this.f4759j;
                if (i6 >= i2) {
                    break;
                }
                this.f4758i[i6] = this.f4757h[i6];
                i6++;
            }
            Arrays.sort(this.f4758i, 0, i2, new a());
            for (int i7 = 0; i7 < this.f4759j; i7++) {
                this.f4757h[i7] = this.f4758i[i7];
            }
        }
        iVar.f4767a = true;
        iVar.a(this);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void G(i iVar) {
        int i2 = 0;
        while (i2 < this.f4759j) {
            if (this.f4757h[i2] == iVar) {
                while (true) {
                    int i3 = this.f4759j;
                    if (i2 >= i3 - 1) {
                        this.f4759j = i3 - 1;
                        iVar.f4767a = false;
                        return;
                    }
                    i[] iVarArr = this.f4757h;
                    int i4 = i2 + 1;
                    iVarArr[i2] = iVarArr[i4];
                    i2 = i4;
                }
            } else {
                i2++;
            }
        }
    }

    @Override // o.b
    public void B(d dVar, o.b bVar, boolean z2) {
        i iVar = bVar.f4718a;
        if (iVar == null) {
            return;
        }
        b.a aVar = bVar.f4722e;
        int k2 = aVar.k();
        for (int i2 = 0; i2 < k2; i2++) {
            i g2 = aVar.g(i2);
            float a2 = aVar.a(i2);
            this.f4760k.b(g2);
            if (this.f4760k.a(iVar, a2)) {
                F(g2);
            }
            this.f4719b += bVar.f4719b * a2;
        }
        G(iVar);
    }

    @Override // o.b, o.d.a
    public void a(i iVar) {
        this.f4760k.b(iVar);
        this.f4760k.e();
        iVar.f4775i[iVar.f4771e] = 1.0f;
        F(iVar);
    }

    @Override // o.b, o.d.a
    public i b(d dVar, boolean[] zArr) {
        int i2 = -1;
        for (int i3 = 0; i3 < this.f4759j; i3++) {
            i iVar = this.f4757h[i3];
            if (!zArr[iVar.f4769c]) {
                this.f4760k.b(iVar);
                b bVar = this.f4760k;
                if (i2 == -1) {
                    if (!bVar.c()) {
                    }
                    i2 = i3;
                } else {
                    if (!bVar.d(this.f4757h[i2])) {
                    }
                    i2 = i3;
                }
            }
        }
        if (i2 == -1) {
            return null;
        }
        return this.f4757h[i2];
    }

    @Override // o.b, o.d.a
    public void clear() {
        this.f4759j = 0;
        this.f4719b = 0.0f;
    }

    @Override // o.b, o.d.a
    public boolean isEmpty() {
        return this.f4759j == 0;
    }

    @Override // o.b
    public String toString() {
        String str = " goal -> (" + this.f4719b + ") : ";
        for (int i2 = 0; i2 < this.f4759j; i2++) {
            this.f4760k.b(this.f4757h[i2]);
            str = str + this.f4760k + " ";
        }
        return str;
    }
}
