package androidx.navigation;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import java.util.UUID;
/* JADX INFO: Access modifiers changed from: package-private */
@SuppressLint({"BanParcelableUsage"})
/* loaded from: classes.dex */
public final class f implements Parcelable {
    public static final Parcelable.Creator<f> CREATOR = new a();

    /* renamed from: b  reason: collision with root package name */
    private final UUID f1932b;

    /* renamed from: c  reason: collision with root package name */
    private final int f1933c;

    /* renamed from: d  reason: collision with root package name */
    private final Bundle f1934d;

    /* renamed from: e  reason: collision with root package name */
    private final Bundle f1935e;

    /* loaded from: classes.dex */
    class a implements Parcelable.Creator<f> {
        a() {
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: a  reason: merged with bridge method [inline-methods] */
        public f createFromParcel(Parcel parcel) {
            return new f(parcel);
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: b  reason: merged with bridge method [inline-methods] */
        public f[] newArray(int i2) {
            return new f[i2];
        }
    }

    f(Parcel parcel) {
        this.f1932b = UUID.fromString(parcel.readString());
        this.f1933c = parcel.readInt();
        this.f1934d = parcel.readBundle(f.class.getClassLoader());
        this.f1935e = parcel.readBundle(f.class.getClassLoader());
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public f(e eVar) {
        this.f1932b = eVar.f1927g;
        this.f1933c = eVar.e().k();
        this.f1934d = eVar.d();
        Bundle bundle = new Bundle();
        this.f1935e = bundle;
        eVar.k(bundle);
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public Bundle j() {
        return this.f1934d;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public int k() {
        return this.f1933c;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public Bundle l() {
        return this.f1935e;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public UUID m() {
        return this.f1932b;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i2) {
        parcel.writeString(this.f1932b.toString());
        parcel.writeInt(this.f1933c);
        parcel.writeBundle(this.f1934d);
        parcel.writeBundle(this.f1935e);
    }
}
