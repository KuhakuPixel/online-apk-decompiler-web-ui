package androidx.room;

import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.database.CharArrayBuffer;
import android.database.ContentObserver;
import android.database.Cursor;
import android.database.DataSetObserver;
import android.net.Uri;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.util.Pair;
import androidx.room.e;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
/* loaded from: classes.dex */
final class e implements u0.c, i {

    /* renamed from: b  reason: collision with root package name */
    private final u0.c f2518b;

    /* renamed from: c  reason: collision with root package name */
    private final a f2519c;

    /* renamed from: d  reason: collision with root package name */
    private final androidx.room.a f2520d;

    /* loaded from: classes.dex */
    static final class a implements u0.b {

        /* renamed from: b  reason: collision with root package name */
        private final androidx.room.a f2521b;

        a(androidx.room.a aVar) {
            this.f2521b = aVar;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static /* synthetic */ Object A(u0.b bVar) {
            return null;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static /* synthetic */ Object y(String str, u0.b bVar) {
            bVar.g(str);
            return null;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static /* synthetic */ Boolean z(u0.b bVar) {
            return Boolean.valueOf(bVar.f());
        }

        void B() {
            this.f2521b.c(new j.a() { // from class: androidx.room.d
                @Override // j.a
                public final Object a(Object obj) {
                    Object A;
                    A = e.a.A((u0.b) obj);
                    return A;
                }
            });
        }

        @Override // u0.b
        public void a() {
            if (this.f2521b.d() == null) {
                throw new IllegalStateException("End transaction called but delegateDb is null");
            }
            try {
                this.f2521b.d().a();
            } finally {
                this.f2521b.b();
            }
        }

        @Override // u0.b
        public void b() {
            try {
                this.f2521b.e().b();
            } catch (Throwable th) {
                this.f2521b.b();
                throw th;
            }
        }

        @Override // u0.b
        public boolean c() {
            u0.b d2 = this.f2521b.d();
            if (d2 == null) {
                return false;
            }
            return d2.c();
        }

        @Override // java.io.Closeable, java.lang.AutoCloseable
        public void close() {
            this.f2521b.a();
        }

        @Override // u0.b
        public List<Pair<String, String>> d() {
            return (List) this.f2521b.c(new j.a() { // from class: r0.a
                @Override // j.a
                public final Object a(Object obj) {
                    return ((u0.b) obj).d();
                }
            });
        }

        @Override // u0.b
        @SuppressLint({"UnsafeNewApiCall"})
        public boolean f() {
            return ((Boolean) this.f2521b.c(new j.a() { // from class: androidx.room.c
                @Override // j.a
                public final Object a(Object obj) {
                    Boolean z2;
                    z2 = e.a.z((u0.b) obj);
                    return z2;
                }
            })).booleanValue();
        }

        @Override // u0.b
        public void g(final String str) {
            this.f2521b.c(new j.a() { // from class: androidx.room.b
                @Override // j.a
                public final Object a(Object obj) {
                    Object y2;
                    y2 = e.a.y(str, (u0.b) obj);
                    return y2;
                }
            });
        }

        @Override // u0.b
        public Cursor j(u0.e eVar) {
            try {
                return new c(this.f2521b.e().j(eVar), this.f2521b);
            } catch (Throwable th) {
                this.f2521b.b();
                throw th;
            }
        }

        @Override // u0.b
        public void k() {
            u0.b d2 = this.f2521b.d();
            if (d2 == null) {
                throw new IllegalStateException("setTransactionSuccessful called but delegateDb is null");
            }
            d2.k();
        }

        @Override // u0.b
        public u0.f m(String str) {
            return new b(str, this.f2521b);
        }

        @Override // u0.b
        public void n() {
            try {
                this.f2521b.e().n();
            } catch (Throwable th) {
                this.f2521b.b();
                throw th;
            }
        }

        @Override // u0.b
        public Cursor s(String str) {
            try {
                return new c(this.f2521b.e().s(str), this.f2521b);
            } catch (Throwable th) {
                this.f2521b.b();
                throw th;
            }
        }

        @Override // u0.b
        public String t() {
            return (String) this.f2521b.c(new j.a() { // from class: r0.b
                @Override // j.a
                public final Object a(Object obj) {
                    return ((u0.b) obj).t();
                }
            });
        }

        @Override // u0.b
        public boolean u() {
            if (this.f2521b.d() == null) {
                return false;
            }
            return ((Boolean) this.f2521b.c(new j.a() { // from class: r0.c
                @Override // j.a
                public final Object a(Object obj) {
                    return Boolean.valueOf(((u0.b) obj).u());
                }
            })).booleanValue();
        }

        @Override // u0.b
        public Cursor w(u0.e eVar, CancellationSignal cancellationSignal) {
            try {
                return new c(this.f2521b.e().w(eVar, cancellationSignal), this.f2521b);
            } catch (Throwable th) {
                this.f2521b.b();
                throw th;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public static class b implements u0.f {

        /* renamed from: b  reason: collision with root package name */
        private final String f2522b;

        /* renamed from: c  reason: collision with root package name */
        private final ArrayList<Object> f2523c = new ArrayList<>();

        /* renamed from: d  reason: collision with root package name */
        private final androidx.room.a f2524d;

        b(String str, androidx.room.a aVar) {
            this.f2522b = str;
            this.f2524d = aVar;
        }

        private void v(u0.f fVar) {
            int i2 = 0;
            while (i2 < this.f2523c.size()) {
                int i3 = i2 + 1;
                Object obj = this.f2523c.get(i2);
                if (obj == null) {
                    fVar.p(i3);
                } else if (obj instanceof Long) {
                    fVar.i(i3, ((Long) obj).longValue());
                } else if (obj instanceof Double) {
                    fVar.q(i3, ((Double) obj).doubleValue());
                } else if (obj instanceof String) {
                    fVar.h(i3, (String) obj);
                } else if (obj instanceof byte[]) {
                    fVar.o(i3, (byte[]) obj);
                }
                i2 = i3;
            }
        }

        private <T> T x(final j.a<u0.f, T> aVar) {
            return (T) this.f2524d.c(new j.a() { // from class: androidx.room.f
                @Override // j.a
                public final Object a(Object obj) {
                    Object y2;
                    y2 = e.b.this.y(aVar, (u0.b) obj);
                    return y2;
                }
            });
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ Object y(j.a aVar, u0.b bVar) {
            u0.f m2 = bVar.m(this.f2522b);
            v(m2);
            return aVar.a(m2);
        }

        private void z(int i2, Object obj) {
            int i3 = i2 - 1;
            if (i3 >= this.f2523c.size()) {
                for (int size = this.f2523c.size(); size <= i3; size++) {
                    this.f2523c.add(null);
                }
            }
            this.f2523c.set(i3, obj);
        }

        @Override // java.io.Closeable, java.lang.AutoCloseable
        public void close() {
        }

        @Override // u0.d
        public void h(int i2, String str) {
            z(i2, str);
        }

        @Override // u0.d
        public void i(int i2, long j2) {
            z(i2, Long.valueOf(j2));
        }

        @Override // u0.f
        public int l() {
            return ((Integer) x(new j.a() { // from class: r0.d
                @Override // j.a
                public final Object a(Object obj) {
                    return Integer.valueOf(((u0.f) obj).l());
                }
            })).intValue();
        }

        @Override // u0.d
        public void o(int i2, byte[] bArr) {
            z(i2, bArr);
        }

        @Override // u0.d
        public void p(int i2) {
            z(i2, null);
        }

        @Override // u0.d
        public void q(int i2, double d2) {
            z(i2, Double.valueOf(d2));
        }
    }

    /* loaded from: classes.dex */
    private static final class c implements Cursor {

        /* renamed from: b  reason: collision with root package name */
        private final Cursor f2525b;

        /* renamed from: c  reason: collision with root package name */
        private final androidx.room.a f2526c;

        c(Cursor cursor, androidx.room.a aVar) {
            this.f2525b = cursor;
            this.f2526c = aVar;
        }

        @Override // android.database.Cursor, java.io.Closeable, java.lang.AutoCloseable
        public void close() {
            this.f2525b.close();
            this.f2526c.b();
        }

        @Override // android.database.Cursor
        public void copyStringToBuffer(int i2, CharArrayBuffer charArrayBuffer) {
            this.f2525b.copyStringToBuffer(i2, charArrayBuffer);
        }

        @Override // android.database.Cursor
        @Deprecated
        public void deactivate() {
            this.f2525b.deactivate();
        }

        @Override // android.database.Cursor
        public byte[] getBlob(int i2) {
            return this.f2525b.getBlob(i2);
        }

        @Override // android.database.Cursor
        public int getColumnCount() {
            return this.f2525b.getColumnCount();
        }

        @Override // android.database.Cursor
        public int getColumnIndex(String str) {
            return this.f2525b.getColumnIndex(str);
        }

        @Override // android.database.Cursor
        public int getColumnIndexOrThrow(String str) {
            return this.f2525b.getColumnIndexOrThrow(str);
        }

        @Override // android.database.Cursor
        public String getColumnName(int i2) {
            return this.f2525b.getColumnName(i2);
        }

        @Override // android.database.Cursor
        public String[] getColumnNames() {
            return this.f2525b.getColumnNames();
        }

        @Override // android.database.Cursor
        public int getCount() {
            return this.f2525b.getCount();
        }

        @Override // android.database.Cursor
        public double getDouble(int i2) {
            return this.f2525b.getDouble(i2);
        }

        @Override // android.database.Cursor
        public Bundle getExtras() {
            return this.f2525b.getExtras();
        }

        @Override // android.database.Cursor
        public float getFloat(int i2) {
            return this.f2525b.getFloat(i2);
        }

        @Override // android.database.Cursor
        public int getInt(int i2) {
            return this.f2525b.getInt(i2);
        }

        @Override // android.database.Cursor
        public long getLong(int i2) {
            return this.f2525b.getLong(i2);
        }

        @Override // android.database.Cursor
        @SuppressLint({"UnsafeNewApiCall"})
        public Uri getNotificationUri() {
            return this.f2525b.getNotificationUri();
        }

        @Override // android.database.Cursor
        @SuppressLint({"UnsafeNewApiCall"})
        public List<Uri> getNotificationUris() {
            return this.f2525b.getNotificationUris();
        }

        @Override // android.database.Cursor
        public int getPosition() {
            return this.f2525b.getPosition();
        }

        @Override // android.database.Cursor
        public short getShort(int i2) {
            return this.f2525b.getShort(i2);
        }

        @Override // android.database.Cursor
        public String getString(int i2) {
            return this.f2525b.getString(i2);
        }

        @Override // android.database.Cursor
        public int getType(int i2) {
            return this.f2525b.getType(i2);
        }

        @Override // android.database.Cursor
        public boolean getWantsAllOnMoveCalls() {
            return this.f2525b.getWantsAllOnMoveCalls();
        }

        @Override // android.database.Cursor
        public boolean isAfterLast() {
            return this.f2525b.isAfterLast();
        }

        @Override // android.database.Cursor
        public boolean isBeforeFirst() {
            return this.f2525b.isBeforeFirst();
        }

        @Override // android.database.Cursor
        public boolean isClosed() {
            return this.f2525b.isClosed();
        }

        @Override // android.database.Cursor
        public boolean isFirst() {
            return this.f2525b.isFirst();
        }

        @Override // android.database.Cursor
        public boolean isLast() {
            return this.f2525b.isLast();
        }

        @Override // android.database.Cursor
        public boolean isNull(int i2) {
            return this.f2525b.isNull(i2);
        }

        @Override // android.database.Cursor
        public boolean move(int i2) {
            return this.f2525b.move(i2);
        }

        @Override // android.database.Cursor
        public boolean moveToFirst() {
            return this.f2525b.moveToFirst();
        }

        @Override // android.database.Cursor
        public boolean moveToLast() {
            return this.f2525b.moveToLast();
        }

        @Override // android.database.Cursor
        public boolean moveToNext() {
            return this.f2525b.moveToNext();
        }

        @Override // android.database.Cursor
        public boolean moveToPosition(int i2) {
            return this.f2525b.moveToPosition(i2);
        }

        @Override // android.database.Cursor
        public boolean moveToPrevious() {
            return this.f2525b.moveToPrevious();
        }

        @Override // android.database.Cursor
        public void registerContentObserver(ContentObserver contentObserver) {
            this.f2525b.registerContentObserver(contentObserver);
        }

        @Override // android.database.Cursor
        public void registerDataSetObserver(DataSetObserver dataSetObserver) {
            this.f2525b.registerDataSetObserver(dataSetObserver);
        }

        @Override // android.database.Cursor
        @Deprecated
        public boolean requery() {
            return this.f2525b.requery();
        }

        @Override // android.database.Cursor
        public Bundle respond(Bundle bundle) {
            return this.f2525b.respond(bundle);
        }

        @Override // android.database.Cursor
        @SuppressLint({"UnsafeNewApiCall"})
        public void setExtras(Bundle bundle) {
            this.f2525b.setExtras(bundle);
        }

        @Override // android.database.Cursor
        public void setNotificationUri(ContentResolver contentResolver, Uri uri) {
            this.f2525b.setNotificationUri(contentResolver, uri);
        }

        @Override // android.database.Cursor
        @SuppressLint({"UnsafeNewApiCall"})
        public void setNotificationUris(ContentResolver contentResolver, List<Uri> list) {
            this.f2525b.setNotificationUris(contentResolver, list);
        }

        @Override // android.database.Cursor
        public void unregisterContentObserver(ContentObserver contentObserver) {
            this.f2525b.unregisterContentObserver(contentObserver);
        }

        @Override // android.database.Cursor
        public void unregisterDataSetObserver(DataSetObserver dataSetObserver) {
            this.f2525b.unregisterDataSetObserver(dataSetObserver);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public e(u0.c cVar, androidx.room.a aVar) {
        this.f2518b = cVar;
        this.f2520d = aVar;
        aVar.f(cVar);
        this.f2519c = new a(aVar);
    }

    @Override // u0.c, java.io.Closeable, java.lang.AutoCloseable
    public void close() {
        try {
            this.f2519c.close();
        } catch (IOException e2) {
            t0.e.a(e2);
        }
    }

    @Override // androidx.room.i
    public u0.c e() {
        return this.f2518b;
    }

    @Override // u0.c
    public String getDatabaseName() {
        return this.f2518b.getDatabaseName();
    }

    @Override // u0.c
    public u0.b r() {
        this.f2519c.B();
        return this.f2519c;
    }

    @Override // u0.c
    public void setWriteAheadLoggingEnabled(boolean z2) {
        this.f2518b.setWriteAheadLoggingEnabled(z2);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public androidx.room.a v() {
        return this.f2520d;
    }
}
