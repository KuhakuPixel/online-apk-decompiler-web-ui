package androidx.fragment.app;

import android.view.View;
import android.view.ViewGroup;
import androidx.lifecycle.d;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
/* loaded from: classes.dex */
public abstract class s {

    /* renamed from: a  reason: collision with root package name */
    private final h f1712a;

    /* renamed from: b  reason: collision with root package name */
    private final ClassLoader f1713b;

    /* renamed from: d  reason: collision with root package name */
    int f1715d;

    /* renamed from: e  reason: collision with root package name */
    int f1716e;

    /* renamed from: f  reason: collision with root package name */
    int f1717f;

    /* renamed from: g  reason: collision with root package name */
    int f1718g;

    /* renamed from: h  reason: collision with root package name */
    int f1719h;

    /* renamed from: i  reason: collision with root package name */
    boolean f1720i;

    /* renamed from: k  reason: collision with root package name */
    String f1722k;

    /* renamed from: l  reason: collision with root package name */
    int f1723l;

    /* renamed from: m  reason: collision with root package name */
    CharSequence f1724m;

    /* renamed from: n  reason: collision with root package name */
    int f1725n;

    /* renamed from: o  reason: collision with root package name */
    CharSequence f1726o;

    /* renamed from: p  reason: collision with root package name */
    ArrayList<String> f1727p;

    /* renamed from: q  reason: collision with root package name */
    ArrayList<String> f1728q;

    /* renamed from: s  reason: collision with root package name */
    ArrayList<Runnable> f1730s;

    /* renamed from: c  reason: collision with root package name */
    ArrayList<a> f1714c = new ArrayList<>();

    /* renamed from: j  reason: collision with root package name */
    boolean f1721j = true;

    /* renamed from: r  reason: collision with root package name */
    boolean f1729r = false;

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public static final class a {

        /* renamed from: a  reason: collision with root package name */
        int f1731a;

        /* renamed from: b  reason: collision with root package name */
        Fragment f1732b;

        /* renamed from: c  reason: collision with root package name */
        int f1733c;

        /* renamed from: d  reason: collision with root package name */
        int f1734d;

        /* renamed from: e  reason: collision with root package name */
        int f1735e;

        /* renamed from: f  reason: collision with root package name */
        int f1736f;

        /* renamed from: g  reason: collision with root package name */
        d.b f1737g;

        /* renamed from: h  reason: collision with root package name */
        d.b f1738h;

        /* JADX INFO: Access modifiers changed from: package-private */
        public a() {
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public a(int i2, Fragment fragment) {
            this.f1731a = i2;
            this.f1732b = fragment;
            d.b bVar = d.b.RESUMED;
            this.f1737g = bVar;
            this.f1738h = bVar;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public s(h hVar, ClassLoader classLoader) {
        this.f1712a = hVar;
        this.f1713b = classLoader;
    }

    public s b(int i2, Fragment fragment, String str) {
        m(i2, fragment, str, 1);
        return this;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public s c(ViewGroup viewGroup, Fragment fragment, String str) {
        fragment.G = viewGroup;
        return b(viewGroup.getId(), fragment, str);
    }

    public s d(Fragment fragment, String str) {
        m(0, fragment, str, 1);
        return this;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void e(a aVar) {
        this.f1714c.add(aVar);
        aVar.f1733c = this.f1715d;
        aVar.f1734d = this.f1716e;
        aVar.f1735e = this.f1717f;
        aVar.f1736f = this.f1718g;
    }

    public s f(View view, String str) {
        if (t.C()) {
            String I = e0.q.I(view);
            if (I == null) {
                throw new IllegalArgumentException("Unique transitionNames are required for all sharedElements");
            }
            if (this.f1727p == null) {
                this.f1727p = new ArrayList<>();
                this.f1728q = new ArrayList<>();
            } else if (this.f1728q.contains(str)) {
                throw new IllegalArgumentException("A shared element with the target name '" + str + "' has already been added to the transaction.");
            } else if (this.f1727p.contains(I)) {
                throw new IllegalArgumentException("A shared element with the source name '" + I + "' has already been added to the transaction.");
            }
            this.f1727p.add(I);
            this.f1728q.add(str);
        }
        return this;
    }

    public s g(String str) {
        if (this.f1721j) {
            this.f1720i = true;
            this.f1722k = str;
            return this;
        }
        throw new IllegalStateException("This FragmentTransaction is not allowed to be added to the back stack.");
    }

    public abstract int h();

    public abstract int i();

    public abstract void j();

    public abstract void k();

    public s l() {
        if (this.f1720i) {
            throw new IllegalStateException("This transaction is already being added to the back stack");
        }
        this.f1721j = false;
        return this;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void m(int i2, Fragment fragment, String str, int i3) {
        Class<?> cls = fragment.getClass();
        int modifiers = cls.getModifiers();
        if (cls.isAnonymousClass() || !Modifier.isPublic(modifiers) || (cls.isMemberClass() && !Modifier.isStatic(modifiers))) {
            throw new IllegalStateException("Fragment " + cls.getCanonicalName() + " must be a public static class to be  properly recreated from instance state.");
        }
        if (str != null) {
            String str2 = fragment.f1544y;
            if (str2 != null && !str.equals(str2)) {
                throw new IllegalStateException("Can't change tag of fragment " + fragment + ": was " + fragment.f1544y + " now " + str);
            }
            fragment.f1544y = str;
        }
        if (i2 != 0) {
            if (i2 == -1) {
                throw new IllegalArgumentException("Can't add fragment " + fragment + " with tag " + str + " to container view with no id");
            }
            int i4 = fragment.f1542w;
            if (i4 != 0 && i4 != i2) {
                throw new IllegalStateException("Can't change container ID of fragment " + fragment + ": was " + fragment.f1542w + " now " + i2);
            }
            fragment.f1542w = i2;
            fragment.f1543x = i2;
        }
        e(new a(i3, fragment));
    }

    public s n(Fragment fragment) {
        e(new a(3, fragment));
        return this;
    }

    public s o(int i2, Fragment fragment) {
        return p(i2, fragment, null);
    }

    public s p(int i2, Fragment fragment, String str) {
        if (i2 != 0) {
            m(i2, fragment, str, 2);
            return this;
        }
        throw new IllegalArgumentException("Must use non-zero containerViewId");
    }

    public s q(int i2, int i3, int i4, int i5) {
        this.f1715d = i2;
        this.f1716e = i3;
        this.f1717f = i4;
        this.f1718g = i5;
        return this;
    }

    public s r(Fragment fragment) {
        e(new a(8, fragment));
        return this;
    }

    public s s(boolean z2) {
        this.f1729r = z2;
        return this;
    }
}
