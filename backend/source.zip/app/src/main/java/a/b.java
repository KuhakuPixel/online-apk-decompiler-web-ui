package a;
/* loaded from: classes.dex */
public final class b {

    /* renamed from: a */
    public static final int abc_action_bar_embed_tabs = 2131034112;
}
