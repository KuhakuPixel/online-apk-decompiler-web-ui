package androidx.fragment.app;

import android.annotation.SuppressLint;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.Log;
import androidx.fragment.app.s;
import androidx.lifecycle.d;
import java.util.ArrayList;
/* JADX INFO: Access modifiers changed from: package-private */
@SuppressLint({"BanParcelableUsage"})
/* loaded from: classes.dex */
public final class b implements Parcelable {
    public static final Parcelable.Creator<b> CREATOR = new a();

    /* renamed from: b  reason: collision with root package name */
    final int[] f1572b;

    /* renamed from: c  reason: collision with root package name */
    final ArrayList<String> f1573c;

    /* renamed from: d  reason: collision with root package name */
    final int[] f1574d;

    /* renamed from: e  reason: collision with root package name */
    final int[] f1575e;

    /* renamed from: f  reason: collision with root package name */
    final int f1576f;

    /* renamed from: g  reason: collision with root package name */
    final String f1577g;

    /* renamed from: h  reason: collision with root package name */
    final int f1578h;

    /* renamed from: i  reason: collision with root package name */
    final int f1579i;

    /* renamed from: j  reason: collision with root package name */
    final CharSequence f1580j;

    /* renamed from: k  reason: collision with root package name */
    final int f1581k;

    /* renamed from: l  reason: collision with root package name */
    final CharSequence f1582l;

    /* renamed from: m  reason: collision with root package name */
    final ArrayList<String> f1583m;

    /* renamed from: n  reason: collision with root package name */
    final ArrayList<String> f1584n;

    /* renamed from: o  reason: collision with root package name */
    final boolean f1585o;

    /* loaded from: classes.dex */
    static class a implements Parcelable.Creator<b> {
        a() {
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: a  reason: merged with bridge method [inline-methods] */
        public b createFromParcel(Parcel parcel) {
            return new b(parcel);
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: b  reason: merged with bridge method [inline-methods] */
        public b[] newArray(int i2) {
            return new b[i2];
        }
    }

    public b(Parcel parcel) {
        this.f1572b = parcel.createIntArray();
        this.f1573c = parcel.createStringArrayList();
        this.f1574d = parcel.createIntArray();
        this.f1575e = parcel.createIntArray();
        this.f1576f = parcel.readInt();
        this.f1577g = parcel.readString();
        this.f1578h = parcel.readInt();
        this.f1579i = parcel.readInt();
        this.f1580j = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        this.f1581k = parcel.readInt();
        this.f1582l = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        this.f1583m = parcel.createStringArrayList();
        this.f1584n = parcel.createStringArrayList();
        this.f1585o = parcel.readInt() != 0;
    }

    public b(androidx.fragment.app.a aVar) {
        int size = aVar.f1714c.size();
        this.f1572b = new int[size * 5];
        if (!aVar.f1720i) {
            throw new IllegalStateException("Not on back stack");
        }
        this.f1573c = new ArrayList<>(size);
        this.f1574d = new int[size];
        this.f1575e = new int[size];
        int i2 = 0;
        int i3 = 0;
        while (i2 < size) {
            s.a aVar2 = aVar.f1714c.get(i2);
            int i4 = i3 + 1;
            this.f1572b[i3] = aVar2.f1731a;
            ArrayList<String> arrayList = this.f1573c;
            Fragment fragment = aVar2.f1732b;
            arrayList.add(fragment != null ? fragment.f1525f : null);
            int[] iArr = this.f1572b;
            int i5 = i4 + 1;
            iArr[i4] = aVar2.f1733c;
            int i6 = i5 + 1;
            iArr[i5] = aVar2.f1734d;
            int i7 = i6 + 1;
            iArr[i6] = aVar2.f1735e;
            iArr[i7] = aVar2.f1736f;
            this.f1574d[i2] = aVar2.f1737g.ordinal();
            this.f1575e[i2] = aVar2.f1738h.ordinal();
            i2++;
            i3 = i7 + 1;
        }
        this.f1576f = aVar.f1719h;
        this.f1577g = aVar.f1722k;
        this.f1578h = aVar.f1571v;
        this.f1579i = aVar.f1723l;
        this.f1580j = aVar.f1724m;
        this.f1581k = aVar.f1725n;
        this.f1582l = aVar.f1726o;
        this.f1583m = aVar.f1727p;
        this.f1584n = aVar.f1728q;
        this.f1585o = aVar.f1729r;
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public androidx.fragment.app.a j(l lVar) {
        androidx.fragment.app.a aVar = new androidx.fragment.app.a(lVar);
        int i2 = 0;
        int i3 = 0;
        while (i2 < this.f1572b.length) {
            s.a aVar2 = new s.a();
            int i4 = i2 + 1;
            aVar2.f1731a = this.f1572b[i2];
            if (l.p0(2)) {
                Log.v("FragmentManager", "Instantiate " + aVar + " op #" + i3 + " base fragment #" + this.f1572b[i4]);
            }
            String str = this.f1573c.get(i3);
            aVar2.f1732b = str != null ? lVar.V(str) : null;
            aVar2.f1737g = d.b.values()[this.f1574d[i3]];
            aVar2.f1738h = d.b.values()[this.f1575e[i3]];
            int[] iArr = this.f1572b;
            int i5 = i4 + 1;
            int i6 = iArr[i4];
            aVar2.f1733c = i6;
            int i7 = i5 + 1;
            int i8 = iArr[i5];
            aVar2.f1734d = i8;
            int i9 = i7 + 1;
            int i10 = iArr[i7];
            aVar2.f1735e = i10;
            int i11 = iArr[i9];
            aVar2.f1736f = i11;
            aVar.f1715d = i6;
            aVar.f1716e = i8;
            aVar.f1717f = i10;
            aVar.f1718g = i11;
            aVar.e(aVar2);
            i3++;
            i2 = i9 + 1;
        }
        aVar.f1719h = this.f1576f;
        aVar.f1722k = this.f1577g;
        aVar.f1571v = this.f1578h;
        aVar.f1720i = true;
        aVar.f1723l = this.f1579i;
        aVar.f1724m = this.f1580j;
        aVar.f1725n = this.f1581k;
        aVar.f1726o = this.f1582l;
        aVar.f1727p = this.f1583m;
        aVar.f1728q = this.f1584n;
        aVar.f1729r = this.f1585o;
        aVar.t(1);
        return aVar;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i2) {
        parcel.writeIntArray(this.f1572b);
        parcel.writeStringList(this.f1573c);
        parcel.writeIntArray(this.f1574d);
        parcel.writeIntArray(this.f1575e);
        parcel.writeInt(this.f1576f);
        parcel.writeString(this.f1577g);
        parcel.writeInt(this.f1578h);
        parcel.writeInt(this.f1579i);
        TextUtils.writeToParcel(this.f1580j, parcel, 0);
        parcel.writeInt(this.f1581k);
        TextUtils.writeToParcel(this.f1582l, parcel, 0);
        parcel.writeStringList(this.f1583m);
        parcel.writeStringList(this.f1584n);
        parcel.writeInt(this.f1585o ? 1 : 0);
    }
}
