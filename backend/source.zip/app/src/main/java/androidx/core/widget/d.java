package androidx.core.widget;

import android.widget.EdgeEffect;
/* loaded from: classes.dex */
public final class d {
    public static void a(EdgeEffect edgeEffect, float f2, float f3) {
        edgeEffect.onPull(f2, f3);
    }
}
