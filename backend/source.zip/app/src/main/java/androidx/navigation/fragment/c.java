package androidx.navigation.fragment;

import com.sample.android.kuhakupixelinapppurchase.R;
/* loaded from: classes.dex */
public final class c {

    /* renamed from: d  reason: collision with root package name */
    public static final int f1955d = 0;

    /* renamed from: j  reason: collision with root package name */
    public static final int f1961j = 0;

    /* renamed from: s  reason: collision with root package name */
    public static final int f1970s = 0;

    /* renamed from: a  reason: collision with root package name */
    public static final int[] f1952a = {16842755, R.attr.action, R.attr.data, R.attr.dataPattern, R.attr.targetPackage};

    /* renamed from: b  reason: collision with root package name */
    public static final int[] f1953b = {16843173, 16843551, R.attr.alpha};

    /* renamed from: c  reason: collision with root package name */
    public static final int[] f1954c = {16842755};

    /* renamed from: e  reason: collision with root package name */
    public static final int[] f1956e = {R.attr.fontProviderAuthority, R.attr.fontProviderCerts, R.attr.fontProviderFetchStrategy, R.attr.fontProviderFetchTimeout, R.attr.fontProviderPackage, R.attr.fontProviderQuery};

    /* renamed from: f  reason: collision with root package name */
    public static final int[] f1957f = {16844082, 16844083, 16844095, 16844143, 16844144, R.attr.font, R.attr.fontStyle, R.attr.fontVariationSettings, R.attr.fontWeight, R.attr.ttcIndex};

    /* renamed from: g  reason: collision with root package name */
    public static final int[] f1958g = {16842755, 16842960, 16842961};

    /* renamed from: h  reason: collision with root package name */
    public static final int[] f1959h = {16842755, 16842961};

    /* renamed from: i  reason: collision with root package name */
    public static final int[] f1960i = {16842755};

    /* renamed from: k  reason: collision with root package name */
    public static final int[] f1962k = {16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 16844050, 16844051};

    /* renamed from: l  reason: collision with root package name */
    public static final int[] f1963l = {16843173, 16844052};

    /* renamed from: m  reason: collision with root package name */
    public static final int[] f1964m = {16842960, R.attr.destination, R.attr.enterAnim, R.attr.exitAnim, R.attr.launchSingleTop, R.attr.popEnterAnim, R.attr.popExitAnim, R.attr.popUpTo, R.attr.popUpToInclusive};

    /* renamed from: n  reason: collision with root package name */
    public static final int[] f1965n = {16842755, 16843245, R.attr.argType, R.attr.nullable};

    /* renamed from: o  reason: collision with root package name */
    public static final int[] f1966o = {16844014, R.attr.action, R.attr.mimeType, R.attr.uri};

    /* renamed from: p  reason: collision with root package name */
    public static final int[] f1967p = {R.attr.startDestination};

    /* renamed from: q  reason: collision with root package name */
    public static final int[] f1968q = {R.attr.navGraph};

    /* renamed from: r  reason: collision with root package name */
    public static final int[] f1969r = {R.attr.defaultNavHost};

    /* renamed from: t  reason: collision with root package name */
    public static final int[] f1971t = {R.attr.graph};

    /* renamed from: u  reason: collision with root package name */
    public static final int[] f1972u = {16842753, 16842960};
}
