package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Rect;
import android.os.Build;
import android.os.Handler;
import android.os.SystemClock;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.FrameLayout;
import android.widget.HeaderViewListAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;
import androidx.appcompat.view.menu.j;
import androidx.appcompat.widget.h0;
import androidx.appcompat.widget.i0;
import e0.q;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes.dex */
public final class b extends h implements View.OnKeyListener, PopupWindow.OnDismissListener {
    private static final int C = a.g.abc_cascading_menu_item_layout;
    private PopupWindow.OnDismissListener A;
    boolean B;

    /* renamed from: c  reason: collision with root package name */
    private final Context f336c;

    /* renamed from: d  reason: collision with root package name */
    private final int f337d;

    /* renamed from: e  reason: collision with root package name */
    private final int f338e;

    /* renamed from: f  reason: collision with root package name */
    private final int f339f;

    /* renamed from: g  reason: collision with root package name */
    private final boolean f340g;

    /* renamed from: h  reason: collision with root package name */
    final Handler f341h;

    /* renamed from: p  reason: collision with root package name */
    private View f349p;

    /* renamed from: q  reason: collision with root package name */
    View f350q;

    /* renamed from: s  reason: collision with root package name */
    private boolean f352s;

    /* renamed from: t  reason: collision with root package name */
    private boolean f353t;

    /* renamed from: u  reason: collision with root package name */
    private int f354u;

    /* renamed from: v  reason: collision with root package name */
    private int f355v;

    /* renamed from: x  reason: collision with root package name */
    private boolean f357x;

    /* renamed from: y  reason: collision with root package name */
    private j.a f358y;

    /* renamed from: z  reason: collision with root package name */
    ViewTreeObserver f359z;

    /* renamed from: i  reason: collision with root package name */
    private final List<e> f342i = new ArrayList();

    /* renamed from: j  reason: collision with root package name */
    final List<d> f343j = new ArrayList();

    /* renamed from: k  reason: collision with root package name */
    final ViewTreeObserver.OnGlobalLayoutListener f344k = new a();

    /* renamed from: l  reason: collision with root package name */
    private final View.OnAttachStateChangeListener f345l = new ViewOnAttachStateChangeListenerC0002b();

    /* renamed from: m  reason: collision with root package name */
    private final h0 f346m = new c();

    /* renamed from: n  reason: collision with root package name */
    private int f347n = 0;

    /* renamed from: o  reason: collision with root package name */
    private int f348o = 0;

    /* renamed from: w  reason: collision with root package name */
    private boolean f356w = false;

    /* renamed from: r  reason: collision with root package name */
    private int f351r = D();

    /* loaded from: classes.dex */
    class a implements ViewTreeObserver.OnGlobalLayoutListener {
        a() {
        }

        @Override // android.view.ViewTreeObserver.OnGlobalLayoutListener
        public void onGlobalLayout() {
            if (!b.this.c() || b.this.f343j.size() <= 0 || b.this.f343j.get(0).f367a.B()) {
                return;
            }
            View view = b.this.f350q;
            if (view == null || !view.isShown()) {
                b.this.dismiss();
                return;
            }
            Iterator<d> it = b.this.f343j.iterator();
            while (it.hasNext()) {
                it.next().f367a.a();
            }
        }
    }

    /* renamed from: androidx.appcompat.view.menu.b$b  reason: collision with other inner class name */
    /* loaded from: classes.dex */
    class ViewOnAttachStateChangeListenerC0002b implements View.OnAttachStateChangeListener {
        ViewOnAttachStateChangeListenerC0002b() {
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewAttachedToWindow(View view) {
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewDetachedFromWindow(View view) {
            ViewTreeObserver viewTreeObserver = b.this.f359z;
            if (viewTreeObserver != null) {
                if (!viewTreeObserver.isAlive()) {
                    b.this.f359z = view.getViewTreeObserver();
                }
                b bVar = b.this;
                bVar.f359z.removeGlobalOnLayoutListener(bVar.f344k);
            }
            view.removeOnAttachStateChangeListener(this);
        }
    }

    /* loaded from: classes.dex */
    class c implements h0 {

        /* loaded from: classes.dex */
        class a implements Runnable {

            /* renamed from: b  reason: collision with root package name */
            final /* synthetic */ d f363b;

            /* renamed from: c  reason: collision with root package name */
            final /* synthetic */ MenuItem f364c;

            /* renamed from: d  reason: collision with root package name */
            final /* synthetic */ e f365d;

            a(d dVar, MenuItem menuItem, e eVar) {
                this.f363b = dVar;
                this.f364c = menuItem;
                this.f365d = eVar;
            }

            @Override // java.lang.Runnable
            public void run() {
                d dVar = this.f363b;
                if (dVar != null) {
                    b.this.B = true;
                    dVar.f368b.e(false);
                    b.this.B = false;
                }
                if (this.f364c.isEnabled() && this.f364c.hasSubMenu()) {
                    this.f365d.L(this.f364c, 4);
                }
            }
        }

        c() {
        }

        @Override // androidx.appcompat.widget.h0
        public void b(e eVar, MenuItem menuItem) {
            b.this.f341h.removeCallbacksAndMessages(null);
            int size = b.this.f343j.size();
            int i2 = 0;
            while (true) {
                if (i2 >= size) {
                    i2 = -1;
                    break;
                } else if (eVar == b.this.f343j.get(i2).f368b) {
                    break;
                } else {
                    i2++;
                }
            }
            if (i2 == -1) {
                return;
            }
            int i3 = i2 + 1;
            b.this.f341h.postAtTime(new a(i3 < b.this.f343j.size() ? b.this.f343j.get(i3) : null, menuItem, eVar), eVar, SystemClock.uptimeMillis() + 200);
        }

        @Override // androidx.appcompat.widget.h0
        public void i(e eVar, MenuItem menuItem) {
            b.this.f341h.removeCallbacksAndMessages(eVar);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public static class d {

        /* renamed from: a  reason: collision with root package name */
        public final i0 f367a;

        /* renamed from: b  reason: collision with root package name */
        public final e f368b;

        /* renamed from: c  reason: collision with root package name */
        public final int f369c;

        public d(i0 i0Var, e eVar, int i2) {
            this.f367a = i0Var;
            this.f368b = eVar;
            this.f369c = i2;
        }

        public ListView a() {
            return this.f367a.l();
        }
    }

    public b(Context context, View view, int i2, int i3, boolean z2) {
        this.f336c = context;
        this.f349p = view;
        this.f338e = i2;
        this.f339f = i3;
        this.f340g = z2;
        Resources resources = context.getResources();
        this.f337d = Math.max(resources.getDisplayMetrics().widthPixels / 2, resources.getDimensionPixelSize(a.d.abc_config_prefDialogWidth));
        this.f341h = new Handler();
    }

    private int A(e eVar) {
        int size = this.f343j.size();
        for (int i2 = 0; i2 < size; i2++) {
            if (eVar == this.f343j.get(i2).f368b) {
                return i2;
            }
        }
        return -1;
    }

    private MenuItem B(e eVar, e eVar2) {
        int size = eVar.size();
        for (int i2 = 0; i2 < size; i2++) {
            MenuItem item = eVar.getItem(i2);
            if (item.hasSubMenu() && eVar2 == item.getSubMenu()) {
                return item;
            }
        }
        return null;
    }

    private View C(d dVar, e eVar) {
        androidx.appcompat.view.menu.d dVar2;
        int i2;
        int firstVisiblePosition;
        MenuItem B = B(dVar.f368b, eVar);
        if (B == null) {
            return null;
        }
        ListView a2 = dVar.a();
        ListAdapter adapter = a2.getAdapter();
        int i3 = 0;
        if (adapter instanceof HeaderViewListAdapter) {
            HeaderViewListAdapter headerViewListAdapter = (HeaderViewListAdapter) adapter;
            i2 = headerViewListAdapter.getHeadersCount();
            dVar2 = (androidx.appcompat.view.menu.d) headerViewListAdapter.getWrappedAdapter();
        } else {
            dVar2 = (androidx.appcompat.view.menu.d) adapter;
            i2 = 0;
        }
        int count = dVar2.getCount();
        while (true) {
            if (i3 >= count) {
                i3 = -1;
                break;
            } else if (B == dVar2.getItem(i3)) {
                break;
            } else {
                i3++;
            }
        }
        if (i3 != -1 && (firstVisiblePosition = (i3 + i2) - a2.getFirstVisiblePosition()) >= 0 && firstVisiblePosition < a2.getChildCount()) {
            return a2.getChildAt(firstVisiblePosition);
        }
        return null;
    }

    private int D() {
        return q.B(this.f349p) == 1 ? 0 : 1;
    }

    private int E(int i2) {
        List<d> list = this.f343j;
        ListView a2 = list.get(list.size() - 1).a();
        int[] iArr = new int[2];
        a2.getLocationOnScreen(iArr);
        Rect rect = new Rect();
        this.f350q.getWindowVisibleDisplayFrame(rect);
        return this.f351r == 1 ? (iArr[0] + a2.getWidth()) + i2 > rect.right ? 0 : 1 : iArr[0] - i2 < 0 ? 1 : 0;
    }

    private void F(e eVar) {
        d dVar;
        View view;
        int i2;
        int i3;
        int i4;
        LayoutInflater from = LayoutInflater.from(this.f336c);
        androidx.appcompat.view.menu.d dVar2 = new androidx.appcompat.view.menu.d(eVar, from, this.f340g, C);
        if (!c() && this.f356w) {
            dVar2.d(true);
        } else if (c()) {
            dVar2.d(h.x(eVar));
        }
        int o2 = h.o(dVar2, null, this.f336c, this.f337d);
        i0 z2 = z();
        z2.o(dVar2);
        z2.F(o2);
        z2.G(this.f348o);
        if (this.f343j.size() > 0) {
            List<d> list = this.f343j;
            dVar = list.get(list.size() - 1);
            view = C(dVar, eVar);
        } else {
            dVar = null;
            view = null;
        }
        if (view != null) {
            z2.U(false);
            z2.R(null);
            int E = E(o2);
            boolean z3 = E == 1;
            this.f351r = E;
            if (Build.VERSION.SDK_INT >= 26) {
                z2.D(view);
                i3 = 0;
                i2 = 0;
            } else {
                int[] iArr = new int[2];
                this.f349p.getLocationOnScreen(iArr);
                int[] iArr2 = new int[2];
                view.getLocationOnScreen(iArr2);
                if ((this.f348o & 7) == 5) {
                    iArr[0] = iArr[0] + this.f349p.getWidth();
                    iArr2[0] = iArr2[0] + view.getWidth();
                }
                i2 = iArr2[0] - iArr[0];
                i3 = iArr2[1] - iArr[1];
            }
            if ((this.f348o & 5) == 5) {
                if (!z3) {
                    o2 = view.getWidth();
                    i4 = i2 - o2;
                }
                i4 = i2 + o2;
            } else {
                if (z3) {
                    o2 = view.getWidth();
                    i4 = i2 + o2;
                }
                i4 = i2 - o2;
            }
            z2.e(i4);
            z2.M(true);
            z2.n(i3);
        } else {
            if (this.f352s) {
                z2.e(this.f354u);
            }
            if (this.f353t) {
                z2.n(this.f355v);
            }
            z2.H(n());
        }
        this.f343j.add(new d(z2, eVar, this.f351r));
        z2.a();
        ListView l2 = z2.l();
        l2.setOnKeyListener(this);
        if (dVar == null && this.f357x && eVar.x() != null) {
            FrameLayout frameLayout = (FrameLayout) from.inflate(a.g.abc_popup_menu_header_item_layout, (ViewGroup) l2, false);
            TextView textView = (TextView) frameLayout.findViewById(16908310);
            frameLayout.setEnabled(false);
            textView.setText(eVar.x());
            l2.addHeaderView(frameLayout, null, false);
            z2.a();
        }
    }

    private i0 z() {
        i0 i0Var = new i0(this.f336c, null, this.f338e, this.f339f);
        i0Var.T(this.f346m);
        i0Var.L(this);
        i0Var.K(this);
        i0Var.D(this.f349p);
        i0Var.G(this.f348o);
        i0Var.J(true);
        i0Var.I(2);
        return i0Var;
    }

    @Override // g.e
    public void a() {
        if (c()) {
            return;
        }
        Iterator<e> it = this.f342i.iterator();
        while (it.hasNext()) {
            F(it.next());
        }
        this.f342i.clear();
        View view = this.f349p;
        this.f350q = view;
        if (view != null) {
            boolean z2 = this.f359z == null;
            ViewTreeObserver viewTreeObserver = view.getViewTreeObserver();
            this.f359z = viewTreeObserver;
            if (z2) {
                viewTreeObserver.addOnGlobalLayoutListener(this.f344k);
            }
            this.f350q.addOnAttachStateChangeListener(this.f345l);
        }
    }

    @Override // androidx.appcompat.view.menu.j
    public void b(e eVar, boolean z2) {
        int A = A(eVar);
        if (A < 0) {
            return;
        }
        int i2 = A + 1;
        if (i2 < this.f343j.size()) {
            this.f343j.get(i2).f368b.e(false);
        }
        d remove = this.f343j.remove(A);
        remove.f368b.O(this);
        if (this.B) {
            remove.f367a.S(null);
            remove.f367a.E(0);
        }
        remove.f367a.dismiss();
        int size = this.f343j.size();
        this.f351r = size > 0 ? this.f343j.get(size - 1).f369c : D();
        if (size != 0) {
            if (z2) {
                this.f343j.get(0).f368b.e(false);
                return;
            }
            return;
        }
        dismiss();
        j.a aVar = this.f358y;
        if (aVar != null) {
            aVar.b(eVar, true);
        }
        ViewTreeObserver viewTreeObserver = this.f359z;
        if (viewTreeObserver != null) {
            if (viewTreeObserver.isAlive()) {
                this.f359z.removeGlobalOnLayoutListener(this.f344k);
            }
            this.f359z = null;
        }
        this.f350q.removeOnAttachStateChangeListener(this.f345l);
        this.A.onDismiss();
    }

    @Override // g.e
    public boolean c() {
        return this.f343j.size() > 0 && this.f343j.get(0).f367a.c();
    }

    @Override // androidx.appcompat.view.menu.j
    public boolean d() {
        return false;
    }

    @Override // g.e
    public void dismiss() {
        int size = this.f343j.size();
        if (size > 0) {
            d[] dVarArr = (d[]) this.f343j.toArray(new d[size]);
            for (int i2 = size - 1; i2 >= 0; i2--) {
                d dVar = dVarArr[i2];
                if (dVar.f367a.c()) {
                    dVar.f367a.dismiss();
                }
            }
        }
    }

    @Override // androidx.appcompat.view.menu.j
    public void h(j.a aVar) {
        this.f358y = aVar;
    }

    @Override // androidx.appcompat.view.menu.j
    public boolean i(m mVar) {
        for (d dVar : this.f343j) {
            if (mVar == dVar.f368b) {
                dVar.a().requestFocus();
                return true;
            }
        }
        if (mVar.hasVisibleItems()) {
            k(mVar);
            j.a aVar = this.f358y;
            if (aVar != null) {
                aVar.c(mVar);
            }
            return true;
        }
        return false;
    }

    @Override // androidx.appcompat.view.menu.j
    public void j(boolean z2) {
        Iterator<d> it = this.f343j.iterator();
        while (it.hasNext()) {
            h.y(it.next().a().getAdapter()).notifyDataSetChanged();
        }
    }

    @Override // androidx.appcompat.view.menu.h
    public void k(e eVar) {
        eVar.c(this, this.f336c);
        if (c()) {
            F(eVar);
        } else {
            this.f342i.add(eVar);
        }
    }

    @Override // g.e
    public ListView l() {
        if (this.f343j.isEmpty()) {
            return null;
        }
        return this.f343j.get(r0.size() - 1).a();
    }

    @Override // androidx.appcompat.view.menu.h
    protected boolean m() {
        return false;
    }

    @Override // android.widget.PopupWindow.OnDismissListener
    public void onDismiss() {
        d dVar;
        int size = this.f343j.size();
        int i2 = 0;
        while (true) {
            if (i2 >= size) {
                dVar = null;
                break;
            }
            dVar = this.f343j.get(i2);
            if (!dVar.f367a.c()) {
                break;
            }
            i2++;
        }
        if (dVar != null) {
            dVar.f368b.e(false);
        }
    }

    @Override // android.view.View.OnKeyListener
    public boolean onKey(View view, int i2, KeyEvent keyEvent) {
        if (keyEvent.getAction() == 1 && i2 == 82) {
            dismiss();
            return true;
        }
        return false;
    }

    @Override // androidx.appcompat.view.menu.h
    public void p(View view) {
        if (this.f349p != view) {
            this.f349p = view;
            this.f348o = e0.d.b(this.f347n, q.B(view));
        }
    }

    @Override // androidx.appcompat.view.menu.h
    public void r(boolean z2) {
        this.f356w = z2;
    }

    @Override // androidx.appcompat.view.menu.h
    public void s(int i2) {
        if (this.f347n != i2) {
            this.f347n = i2;
            this.f348o = e0.d.b(i2, q.B(this.f349p));
        }
    }

    @Override // androidx.appcompat.view.menu.h
    public void t(int i2) {
        this.f352s = true;
        this.f354u = i2;
    }

    @Override // androidx.appcompat.view.menu.h
    public void u(PopupWindow.OnDismissListener onDismissListener) {
        this.A = onDismissListener;
    }

    @Override // androidx.appcompat.view.menu.h
    public void v(boolean z2) {
        this.f357x = z2;
    }

    @Override // androidx.appcompat.view.menu.h
    public void w(int i2) {
        this.f353t = true;
        this.f355v = i2;
    }
}
