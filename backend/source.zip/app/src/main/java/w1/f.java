package w1;

import android.util.SparseIntArray;
import android.view.View;
import android.widget.FrameLayout;
import androidx.databinding.ViewDataBinding;
import androidx.lifecycle.LiveData;
import androidx.recyclerview.widget.RecyclerView;
/* loaded from: classes.dex */
public class f extends e {
    private static final SparseIntArray F = null;
    private final FrameLayout D;
    private long E;

    public f(androidx.databinding.e eVar, View view) {
        this(eVar, view, ViewDataBinding.u(eVar, view, 2, null, F));
    }

    private f(androidx.databinding.e eVar, View view, Object[] objArr) {
        super(eVar, view, 1, (RecyclerView) objArr[1]);
        this.E = -1L;
        this.B.setTag(null);
        FrameLayout frameLayout = (FrameLayout) objArr[0];
        this.D = frameLayout;
        frameLayout.setTag(null);
        D(view);
        I();
    }

    private boolean J(LiveData<Boolean> liveData, int i2) {
        if (i2 == 0) {
            synchronized (this) {
                this.E |= 1;
            }
            return true;
        }
        return false;
    }

    @Override // w1.e
    public void H(u1.d dVar) {
        this.C = dVar;
        synchronized (this) {
            this.E |= 2;
        }
        d(5);
        super.z();
    }

    public void I() {
        synchronized (this) {
            this.E = 4L;
        }
        z();
    }

    @Override // androidx.databinding.ViewDataBinding
    protected void l() {
        long j2;
        synchronized (this) {
            j2 = this.E;
            this.E = 0L;
        }
        u1.d dVar = this.C;
        boolean z2 = false;
        int i2 = ((j2 & 7) > 0L ? 1 : ((j2 & 7) == 0L ? 0 : -1));
        if (i2 != 0) {
            LiveData<Boolean> h2 = dVar != null ? dVar.h() : null;
            F(0, h2);
            z2 = ViewDataBinding.B(Boolean.valueOf(!ViewDataBinding.B(h2 != null ? h2.d() : null)));
        }
        if (i2 != 0) {
            this.B.setEnabled(z2);
        }
    }

    @Override // androidx.databinding.ViewDataBinding
    public boolean r() {
        synchronized (this) {
            return this.E != 0;
        }
    }

    @Override // androidx.databinding.ViewDataBinding
    protected boolean v(int i2, Object obj, int i3) {
        if (i2 != 0) {
            return false;
        }
        return J((LiveData) obj, i3);
    }
}
