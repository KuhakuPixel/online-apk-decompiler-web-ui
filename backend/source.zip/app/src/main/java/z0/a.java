package z0;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes.dex */
public enum a {
    RESPONSE_CODE_UNSPECIFIED(-999),
    SERVICE_TIMEOUT(-3),
    FEATURE_NOT_SUPPORTED(-2),
    SERVICE_DISCONNECTED(-1),
    OK(0),
    USER_CANCELED(1),
    SERVICE_UNAVAILABLE(2),
    BILLING_UNAVAILABLE(3),
    ITEM_UNAVAILABLE(4),
    DEVELOPER_ERROR(5),
    ERROR(6),
    ITEM_ALREADY_OWNED(7),
    ITEM_NOT_OWNED(8),
    EXPIRED_OFFER_TOKEN(11);
    

    /* renamed from: q  reason: collision with root package name */
    private static final e0 f5668q;

    /* renamed from: b  reason: collision with root package name */
    private final int f5670b;

    static {
        d0 d0Var = new d0();
        for (a aVar : values()) {
            d0Var.a(Integer.valueOf(aVar.f5670b), aVar);
        }
        f5668q = d0Var.b();
    }

    a(int i2) {
        this.f5670b = i2;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static a a(int i2) {
        e0 e0Var = f5668q;
        Integer valueOf = Integer.valueOf(i2);
        return !e0Var.containsKey(valueOf) ? RESPONSE_CODE_UNSPECIFIED : (a) e0Var.get(valueOf);
    }
}
