package androidx.appcompat.widget;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.Resources;
import android.graphics.Rect;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.TextView;
/* loaded from: classes.dex */
class x0 {

    /* renamed from: a  reason: collision with root package name */
    private final Context f998a;

    /* renamed from: b  reason: collision with root package name */
    private final View f999b;

    /* renamed from: c  reason: collision with root package name */
    private final TextView f1000c;

    /* renamed from: d  reason: collision with root package name */
    private final WindowManager.LayoutParams f1001d;

    /* renamed from: e  reason: collision with root package name */
    private final Rect f1002e;

    /* renamed from: f  reason: collision with root package name */
    private final int[] f1003f;

    /* renamed from: g  reason: collision with root package name */
    private final int[] f1004g;

    /* JADX INFO: Access modifiers changed from: package-private */
    public x0(Context context) {
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
        this.f1001d = layoutParams;
        this.f1002e = new Rect();
        this.f1003f = new int[2];
        this.f1004g = new int[2];
        this.f998a = context;
        View inflate = LayoutInflater.from(context).inflate(a.g.abc_tooltip, (ViewGroup) null);
        this.f999b = inflate;
        this.f1000c = (TextView) inflate.findViewById(a.f.message);
        layoutParams.setTitle(getClass().getSimpleName());
        layoutParams.packageName = context.getPackageName();
        layoutParams.type = 1002;
        layoutParams.width = -2;
        layoutParams.height = -2;
        layoutParams.format = -3;
        layoutParams.windowAnimations = a.i.Animation_AppCompat_Tooltip;
        layoutParams.flags = 24;
    }

    private void a(View view, int i2, int i3, boolean z2, WindowManager.LayoutParams layoutParams) {
        int height;
        int i4;
        layoutParams.token = view.getApplicationWindowToken();
        int dimensionPixelOffset = this.f998a.getResources().getDimensionPixelOffset(a.d.tooltip_precise_anchor_threshold);
        if (view.getWidth() < dimensionPixelOffset) {
            i2 = view.getWidth() / 2;
        }
        if (view.getHeight() >= dimensionPixelOffset) {
            int dimensionPixelOffset2 = this.f998a.getResources().getDimensionPixelOffset(a.d.tooltip_precise_anchor_extra_offset);
            height = i3 + dimensionPixelOffset2;
            i4 = i3 - dimensionPixelOffset2;
        } else {
            height = view.getHeight();
            i4 = 0;
        }
        layoutParams.gravity = 49;
        int dimensionPixelOffset3 = this.f998a.getResources().getDimensionPixelOffset(z2 ? a.d.tooltip_y_offset_touch : a.d.tooltip_y_offset_non_touch);
        View b2 = b(view);
        if (b2 == null) {
            Log.e("TooltipPopup", "Cannot find app view");
            return;
        }
        b2.getWindowVisibleDisplayFrame(this.f1002e);
        Rect rect = this.f1002e;
        if (rect.left < 0 && rect.top < 0) {
            Resources resources = this.f998a.getResources();
            int identifier = resources.getIdentifier("status_bar_height", "dimen", "android");
            int dimensionPixelSize = identifier != 0 ? resources.getDimensionPixelSize(identifier) : 0;
            DisplayMetrics displayMetrics = resources.getDisplayMetrics();
            this.f1002e.set(0, dimensionPixelSize, displayMetrics.widthPixels, displayMetrics.heightPixels);
        }
        b2.getLocationOnScreen(this.f1004g);
        view.getLocationOnScreen(this.f1003f);
        int[] iArr = this.f1003f;
        int i5 = iArr[0];
        int[] iArr2 = this.f1004g;
        iArr[0] = i5 - iArr2[0];
        iArr[1] = iArr[1] - iArr2[1];
        layoutParams.x = (iArr[0] + i2) - (b2.getWidth() / 2);
        int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
        this.f999b.measure(makeMeasureSpec, makeMeasureSpec);
        int measuredHeight = this.f999b.getMeasuredHeight();
        int[] iArr3 = this.f1003f;
        int i6 = ((iArr3[1] + i4) - dimensionPixelOffset3) - measuredHeight;
        int i7 = iArr3[1] + height + dimensionPixelOffset3;
        if (!z2 ? measuredHeight + i7 <= this.f1002e.height() : i6 < 0) {
            layoutParams.y = i6;
        } else {
            layoutParams.y = i7;
        }
    }

    private static View b(View view) {
        View rootView = view.getRootView();
        ViewGroup.LayoutParams layoutParams = rootView.getLayoutParams();
        if ((layoutParams instanceof WindowManager.LayoutParams) && ((WindowManager.LayoutParams) layoutParams).type == 2) {
            return rootView;
        }
        for (Context context = view.getContext(); context instanceof ContextWrapper; context = ((ContextWrapper) context).getBaseContext()) {
            if (context instanceof Activity) {
                return ((Activity) context).getWindow().getDecorView();
            }
        }
        return rootView;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void c() {
        if (d()) {
            ((WindowManager) this.f998a.getSystemService("window")).removeView(this.f999b);
        }
    }

    boolean d() {
        return this.f999b.getParent() != null;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void e(View view, int i2, int i3, boolean z2, CharSequence charSequence) {
        if (d()) {
            c();
        }
        this.f1000c.setText(charSequence);
        a(view, i2, i3, z2, this.f1001d);
        ((WindowManager) this.f998a.getSystemService("window")).addView(this.f999b, this.f1001d);
    }
}
