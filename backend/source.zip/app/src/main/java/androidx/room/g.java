package androidx.room;

import u0.c;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes.dex */
public final class g implements c.InterfaceC0072c {

    /* renamed from: a  reason: collision with root package name */
    private final c.InterfaceC0072c f2577a;

    /* renamed from: b  reason: collision with root package name */
    private final a f2578b;

    /* JADX INFO: Access modifiers changed from: package-private */
    public g(c.InterfaceC0072c interfaceC0072c, a aVar) {
        this.f2577a = interfaceC0072c;
        this.f2578b = aVar;
    }

    @Override // u0.c.InterfaceC0072c
    /* renamed from: b  reason: merged with bridge method [inline-methods] */
    public e a(c.b bVar) {
        return new e(this.f2577a.a(bVar), this.f2578b);
    }
}
