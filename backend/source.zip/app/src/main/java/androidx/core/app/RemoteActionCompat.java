package androidx.core.app;

import android.app.PendingIntent;
import androidx.core.graphics.drawable.IconCompat;
import x0.a;
/* loaded from: classes.dex */
public final class RemoteActionCompat implements a {

    /* renamed from: a  reason: collision with root package name */
    public IconCompat f1386a;

    /* renamed from: b  reason: collision with root package name */
    public CharSequence f1387b;

    /* renamed from: c  reason: collision with root package name */
    public CharSequence f1388c;

    /* renamed from: d  reason: collision with root package name */
    public PendingIntent f1389d;

    /* renamed from: e  reason: collision with root package name */
    public boolean f1390e;

    /* renamed from: f  reason: collision with root package name */
    public boolean f1391f;
}
