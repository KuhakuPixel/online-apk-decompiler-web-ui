package e0;

import android.os.Bundle;
import android.text.style.ClickableSpan;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityNodeProvider;
import f0.c;
import java.lang.ref.WeakReference;
import java.util.Collections;
import java.util.List;
/* loaded from: classes.dex */
public class a {

    /* renamed from: c  reason: collision with root package name */
    private static final View.AccessibilityDelegate f4280c = new View.AccessibilityDelegate();

    /* renamed from: a  reason: collision with root package name */
    private final View.AccessibilityDelegate f4281a;

    /* renamed from: b  reason: collision with root package name */
    private final View.AccessibilityDelegate f4282b;

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: e0.a$a  reason: collision with other inner class name */
    /* loaded from: classes.dex */
    public static final class C0051a extends View.AccessibilityDelegate {

        /* renamed from: a  reason: collision with root package name */
        final a f4283a;

        C0051a(a aVar) {
            this.f4283a = aVar;
        }

        @Override // android.view.View.AccessibilityDelegate
        public boolean dispatchPopulateAccessibilityEvent(View view, AccessibilityEvent accessibilityEvent) {
            return this.f4283a.a(view, accessibilityEvent);
        }

        @Override // android.view.View.AccessibilityDelegate
        public AccessibilityNodeProvider getAccessibilityNodeProvider(View view) {
            f0.d b2 = this.f4283a.b(view);
            if (b2 != null) {
                return (AccessibilityNodeProvider) b2.d();
            }
            return null;
        }

        @Override // android.view.View.AccessibilityDelegate
        public void onInitializeAccessibilityEvent(View view, AccessibilityEvent accessibilityEvent) {
            this.f4283a.f(view, accessibilityEvent);
        }

        @Override // android.view.View.AccessibilityDelegate
        public void onInitializeAccessibilityNodeInfo(View view, AccessibilityNodeInfo accessibilityNodeInfo) {
            f0.c v02 = f0.c.v0(accessibilityNodeInfo);
            v02.n0(q.T(view));
            v02.g0(q.O(view));
            v02.k0(q.p(view));
            this.f4283a.g(view, v02);
            v02.e(accessibilityNodeInfo.getText(), view);
            List<c.a> c2 = a.c(view);
            for (int i2 = 0; i2 < c2.size(); i2++) {
                v02.b(c2.get(i2));
            }
        }

        @Override // android.view.View.AccessibilityDelegate
        public void onPopulateAccessibilityEvent(View view, AccessibilityEvent accessibilityEvent) {
            this.f4283a.h(view, accessibilityEvent);
        }

        @Override // android.view.View.AccessibilityDelegate
        public boolean onRequestSendAccessibilityEvent(ViewGroup viewGroup, View view, AccessibilityEvent accessibilityEvent) {
            return this.f4283a.i(viewGroup, view, accessibilityEvent);
        }

        @Override // android.view.View.AccessibilityDelegate
        public boolean performAccessibilityAction(View view, int i2, Bundle bundle) {
            return this.f4283a.j(view, i2, bundle);
        }

        @Override // android.view.View.AccessibilityDelegate
        public void sendAccessibilityEvent(View view, int i2) {
            this.f4283a.l(view, i2);
        }

        @Override // android.view.View.AccessibilityDelegate
        public void sendAccessibilityEventUnchecked(View view, AccessibilityEvent accessibilityEvent) {
            this.f4283a.m(view, accessibilityEvent);
        }
    }

    public a() {
        this(f4280c);
    }

    public a(View.AccessibilityDelegate accessibilityDelegate) {
        this.f4281a = accessibilityDelegate;
        this.f4282b = new C0051a(this);
    }

    static List<c.a> c(View view) {
        List<c.a> list = (List) view.getTag(s.b.tag_accessibility_actions);
        return list == null ? Collections.emptyList() : list;
    }

    private boolean e(ClickableSpan clickableSpan, View view) {
        if (clickableSpan != null) {
            ClickableSpan[] p2 = f0.c.p(view.createAccessibilityNodeInfo().getText());
            for (int i2 = 0; p2 != null && i2 < p2.length; i2++) {
                if (clickableSpan.equals(p2[i2])) {
                    return true;
                }
            }
        }
        return false;
    }

    private boolean k(int i2, View view) {
        WeakReference weakReference;
        SparseArray sparseArray = (SparseArray) view.getTag(s.b.tag_accessibility_clickable_spans);
        if (sparseArray == null || (weakReference = (WeakReference) sparseArray.get(i2)) == null) {
            return false;
        }
        ClickableSpan clickableSpan = (ClickableSpan) weakReference.get();
        if (e(clickableSpan, view)) {
            clickableSpan.onClick(view);
            return true;
        }
        return false;
    }

    public boolean a(View view, AccessibilityEvent accessibilityEvent) {
        return this.f4281a.dispatchPopulateAccessibilityEvent(view, accessibilityEvent);
    }

    public f0.d b(View view) {
        AccessibilityNodeProvider accessibilityNodeProvider = this.f4281a.getAccessibilityNodeProvider(view);
        if (accessibilityNodeProvider != null) {
            return new f0.d(accessibilityNodeProvider);
        }
        return null;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public View.AccessibilityDelegate d() {
        return this.f4282b;
    }

    public void f(View view, AccessibilityEvent accessibilityEvent) {
        this.f4281a.onInitializeAccessibilityEvent(view, accessibilityEvent);
    }

    public void g(View view, f0.c cVar) {
        this.f4281a.onInitializeAccessibilityNodeInfo(view, cVar.u0());
    }

    public void h(View view, AccessibilityEvent accessibilityEvent) {
        this.f4281a.onPopulateAccessibilityEvent(view, accessibilityEvent);
    }

    public boolean i(ViewGroup viewGroup, View view, AccessibilityEvent accessibilityEvent) {
        return this.f4281a.onRequestSendAccessibilityEvent(viewGroup, view, accessibilityEvent);
    }

    public boolean j(View view, int i2, Bundle bundle) {
        List<c.a> c2 = c(view);
        boolean z2 = false;
        int i3 = 0;
        while (true) {
            if (i3 >= c2.size()) {
                break;
            }
            c.a aVar = c2.get(i3);
            if (aVar.b() == i2) {
                z2 = aVar.d(view, bundle);
                break;
            }
            i3++;
        }
        if (!z2) {
            z2 = this.f4281a.performAccessibilityAction(view, i2, bundle);
        }
        return (z2 || i2 != s.b.accessibility_action_clickable_span) ? z2 : k(bundle.getInt("ACCESSIBILITY_CLICKABLE_SPAN_ID", -1), view);
    }

    public void l(View view, int i2) {
        this.f4281a.sendAccessibilityEvent(view, i2);
    }

    public void m(View view, AccessibilityEvent accessibilityEvent) {
        this.f4281a.sendAccessibilityEventUnchecked(view, accessibilityEvent);
    }
}
