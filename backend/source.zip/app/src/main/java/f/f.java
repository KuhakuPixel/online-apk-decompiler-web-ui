package f;

import android.content.Context;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import f.b;
import java.util.ArrayList;
/* loaded from: classes.dex */
public class f extends ActionMode {

    /* renamed from: a  reason: collision with root package name */
    final Context f4370a;

    /* renamed from: b  reason: collision with root package name */
    final b f4371b;

    /* loaded from: classes.dex */
    public static class a implements b.a {

        /* renamed from: a  reason: collision with root package name */
        final ActionMode.Callback f4372a;

        /* renamed from: b  reason: collision with root package name */
        final Context f4373b;

        /* renamed from: c  reason: collision with root package name */
        final ArrayList<f> f4374c = new ArrayList<>();

        /* renamed from: d  reason: collision with root package name */
        final l.g<Menu, Menu> f4375d = new l.g<>();

        public a(Context context, ActionMode.Callback callback) {
            this.f4373b = context;
            this.f4372a = callback;
        }

        private Menu f(Menu menu) {
            Menu menu2 = this.f4375d.get(menu);
            if (menu2 == null) {
                g.d dVar = new g.d(this.f4373b, (y.a) menu);
                this.f4375d.put(menu, dVar);
                return dVar;
            }
            return menu2;
        }

        @Override // f.b.a
        public boolean a(b bVar, MenuItem menuItem) {
            return this.f4372a.onActionItemClicked(e(bVar), new g.c(this.f4373b, (y.b) menuItem));
        }

        @Override // f.b.a
        public boolean b(b bVar, Menu menu) {
            return this.f4372a.onCreateActionMode(e(bVar), f(menu));
        }

        @Override // f.b.a
        public void c(b bVar) {
            this.f4372a.onDestroyActionMode(e(bVar));
        }

        @Override // f.b.a
        public boolean d(b bVar, Menu menu) {
            return this.f4372a.onPrepareActionMode(e(bVar), f(menu));
        }

        public ActionMode e(b bVar) {
            int size = this.f4374c.size();
            for (int i2 = 0; i2 < size; i2++) {
                f fVar = this.f4374c.get(i2);
                if (fVar != null && fVar.f4371b == bVar) {
                    return fVar;
                }
            }
            f fVar2 = new f(this.f4373b, bVar);
            this.f4374c.add(fVar2);
            return fVar2;
        }
    }

    public f(Context context, b bVar) {
        this.f4370a = context;
        this.f4371b = bVar;
    }

    @Override // android.view.ActionMode
    public void finish() {
        this.f4371b.c();
    }

    @Override // android.view.ActionMode
    public View getCustomView() {
        return this.f4371b.d();
    }

    @Override // android.view.ActionMode
    public Menu getMenu() {
        return new g.d(this.f4370a, (y.a) this.f4371b.e());
    }

    @Override // android.view.ActionMode
    public MenuInflater getMenuInflater() {
        return this.f4371b.f();
    }

    @Override // android.view.ActionMode
    public CharSequence getSubtitle() {
        return this.f4371b.g();
    }

    @Override // android.view.ActionMode
    public Object getTag() {
        return this.f4371b.h();
    }

    @Override // android.view.ActionMode
    public CharSequence getTitle() {
        return this.f4371b.i();
    }

    @Override // android.view.ActionMode
    public boolean getTitleOptionalHint() {
        return this.f4371b.j();
    }

    @Override // android.view.ActionMode
    public void invalidate() {
        this.f4371b.k();
    }

    @Override // android.view.ActionMode
    public boolean isTitleOptional() {
        return this.f4371b.l();
    }

    @Override // android.view.ActionMode
    public void setCustomView(View view) {
        this.f4371b.m(view);
    }

    @Override // android.view.ActionMode
    public void setSubtitle(int i2) {
        this.f4371b.n(i2);
    }

    @Override // android.view.ActionMode
    public void setSubtitle(CharSequence charSequence) {
        this.f4371b.o(charSequence);
    }

    @Override // android.view.ActionMode
    public void setTag(Object obj) {
        this.f4371b.p(obj);
    }

    @Override // android.view.ActionMode
    public void setTitle(int i2) {
        this.f4371b.q(i2);
    }

    @Override // android.view.ActionMode
    public void setTitle(CharSequence charSequence) {
        this.f4371b.r(charSequence);
    }

    @Override // android.view.ActionMode
    public void setTitleOptionalHint(boolean z2) {
        this.f4371b.s(z2);
    }
}
