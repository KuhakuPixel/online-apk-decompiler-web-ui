package e0;
/* loaded from: classes.dex */
public interface j {
}
