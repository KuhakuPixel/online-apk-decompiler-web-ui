package q;

import java.util.ArrayList;
import p.d;
import p.e;
/* loaded from: classes.dex */
public class b {

    /* renamed from: a  reason: collision with root package name */
    private final ArrayList<p.e> f4980a = new ArrayList<>();

    /* renamed from: b  reason: collision with root package name */
    private a f4981b = new a();

    /* renamed from: c  reason: collision with root package name */
    private p.f f4982c;

    /* loaded from: classes.dex */
    public static class a {

        /* renamed from: k  reason: collision with root package name */
        public static int f4983k = 0;

        /* renamed from: l  reason: collision with root package name */
        public static int f4984l = 1;

        /* renamed from: m  reason: collision with root package name */
        public static int f4985m = 2;

        /* renamed from: a  reason: collision with root package name */
        public e.b f4986a;

        /* renamed from: b  reason: collision with root package name */
        public e.b f4987b;

        /* renamed from: c  reason: collision with root package name */
        public int f4988c;

        /* renamed from: d  reason: collision with root package name */
        public int f4989d;

        /* renamed from: e  reason: collision with root package name */
        public int f4990e;

        /* renamed from: f  reason: collision with root package name */
        public int f4991f;

        /* renamed from: g  reason: collision with root package name */
        public int f4992g;

        /* renamed from: h  reason: collision with root package name */
        public boolean f4993h;

        /* renamed from: i  reason: collision with root package name */
        public boolean f4994i;

        /* renamed from: j  reason: collision with root package name */
        public int f4995j;
    }

    /* renamed from: q.b$b  reason: collision with other inner class name */
    /* loaded from: classes.dex */
    public interface InterfaceC0068b {
        void a();

        void b(p.e eVar, a aVar);
    }

    public b(p.f fVar) {
        this.f4982c = fVar;
    }

    private boolean a(InterfaceC0068b interfaceC0068b, p.e eVar, int i2) {
        this.f4981b.f4986a = eVar.y();
        this.f4981b.f4987b = eVar.O();
        this.f4981b.f4988c = eVar.R();
        this.f4981b.f4989d = eVar.v();
        a aVar = this.f4981b;
        aVar.f4994i = false;
        aVar.f4995j = i2;
        e.b bVar = aVar.f4986a;
        e.b bVar2 = e.b.MATCH_CONSTRAINT;
        boolean z2 = bVar == bVar2;
        boolean z3 = aVar.f4987b == bVar2;
        boolean z4 = z2 && eVar.W > 0.0f;
        boolean z5 = z3 && eVar.W > 0.0f;
        if (z4 && eVar.f4921r[0] == 4) {
            aVar.f4986a = e.b.FIXED;
        }
        if (z5 && eVar.f4921r[1] == 4) {
            aVar.f4987b = e.b.FIXED;
        }
        interfaceC0068b.b(eVar, aVar);
        eVar.U0(this.f4981b.f4990e);
        eVar.v0(this.f4981b.f4991f);
        eVar.u0(this.f4981b.f4993h);
        eVar.k0(this.f4981b.f4992g);
        a aVar2 = this.f4981b;
        aVar2.f4995j = a.f4983k;
        return aVar2.f4994i;
    }

    /* JADX WARN: Code restructure failed: missing block: B:52:0x008d, code lost:
        if (r8 != r9) goto L56;
     */
    /* JADX WARN: Code restructure failed: missing block: B:54:0x0094, code lost:
        if (r5.W <= 0.0f) goto L56;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private void b(p.f r13) {
        /*
            r12 = this;
            java.util.ArrayList<p.e> r0 = r13.D0
            int r0 = r0.size()
            r1 = 64
            boolean r1 = r13.B1(r1)
            q.b$b r2 = r13.r1()
            r3 = 0
            r4 = 0
        L12:
            if (r4 >= r0) goto La4
            java.util.ArrayList<p.e> r5 = r13.D0
            java.lang.Object r5 = r5.get(r4)
            p.e r5 = (p.e) r5
            boolean r6 = r5 instanceof p.g
            if (r6 == 0) goto L22
            goto La0
        L22:
            boolean r6 = r5 instanceof p.a
            if (r6 == 0) goto L28
            goto La0
        L28:
            boolean r6 = r5.c0()
            if (r6 == 0) goto L30
            goto La0
        L30:
            if (r1 == 0) goto L47
            q.l r6 = r5.f4895e
            if (r6 == 0) goto L47
            q.n r7 = r5.f4897f
            if (r7 == 0) goto L47
            q.g r6 = r6.f5062e
            boolean r6 = r6.f5016j
            if (r6 == 0) goto L47
            q.g r6 = r7.f5062e
            boolean r6 = r6.f5016j
            if (r6 == 0) goto L47
            goto La0
        L47:
            p.e$b r6 = r5.s(r3)
            r7 = 1
            p.e$b r8 = r5.s(r7)
            p.e$b r9 = p.e.b.MATCH_CONSTRAINT
            if (r6 != r9) goto L60
            int r10 = r5.f4917p
            if (r10 == r7) goto L60
            if (r8 != r9) goto L60
            int r10 = r5.f4919q
            if (r10 == r7) goto L60
            r10 = 1
            goto L61
        L60:
            r10 = 0
        L61:
            if (r10 != 0) goto L97
            boolean r11 = r13.B1(r7)
            if (r11 == 0) goto L97
            boolean r11 = r5 instanceof p.k
            if (r11 != 0) goto L97
            if (r6 != r9) goto L7c
            int r11 = r5.f4917p
            if (r11 != 0) goto L7c
            if (r8 == r9) goto L7c
            boolean r11 = r5.Z()
            if (r11 != 0) goto L7c
            r10 = 1
        L7c:
            if (r8 != r9) goto L8b
            int r11 = r5.f4919q
            if (r11 != 0) goto L8b
            if (r6 == r9) goto L8b
            boolean r11 = r5.Z()
            if (r11 != 0) goto L8b
            r10 = 1
        L8b:
            if (r6 == r9) goto L8f
            if (r8 != r9) goto L97
        L8f:
            float r6 = r5.W
            r8 = 0
            int r6 = (r6 > r8 ? 1 : (r6 == r8 ? 0 : -1))
            if (r6 <= 0) goto L97
            goto L98
        L97:
            r7 = r10
        L98:
            if (r7 == 0) goto L9b
            goto La0
        L9b:
            int r6 = q.b.a.f4983k
            r12.a(r2, r5, r6)
        La0:
            int r4 = r4 + 1
            goto L12
        La4:
            r2.a()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: q.b.b(p.f):void");
    }

    private void c(p.f fVar, String str, int i2, int i3) {
        int G = fVar.G();
        int F = fVar.F();
        fVar.K0(0);
        fVar.J0(0);
        fVar.U0(i2);
        fVar.v0(i3);
        fVar.K0(G);
        fVar.J0(F);
        this.f4982c.b1();
    }

    public long d(p.f fVar, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10) {
        boolean z2;
        int i11;
        int i12;
        p.f fVar2;
        boolean z3;
        boolean z4;
        boolean z5;
        int i13;
        boolean z6;
        int i14;
        boolean z7;
        InterfaceC0068b r12 = fVar.r1();
        int size = fVar.D0.size();
        int R = fVar.R();
        int v2 = fVar.v();
        boolean b2 = p.j.b(i2, 128);
        boolean z8 = b2 || p.j.b(i2, 64);
        if (z8) {
            for (int i15 = 0; i15 < size; i15++) {
                p.e eVar = fVar.D0.get(i15);
                e.b y2 = eVar.y();
                e.b bVar = e.b.MATCH_CONSTRAINT;
                boolean z9 = (y2 == bVar) && (eVar.O() == bVar) && eVar.t() > 0.0f;
                if ((eVar.Z() && z9) || ((eVar.b0() && z9) || (eVar instanceof p.k) || eVar.Z() || eVar.b0())) {
                    z8 = false;
                    break;
                }
            }
        }
        if (z8) {
            boolean z10 = o.d.f4728r;
        }
        boolean z11 = z8 & ((i5 == 1073741824 && i7 == 1073741824) || b2);
        if (z11) {
            int min = Math.min(fVar.E(), i6);
            int min2 = Math.min(fVar.D(), i8);
            if (i5 == 1073741824 && fVar.R() != min) {
                fVar.U0(min);
                fVar.u1();
            }
            if (i7 == 1073741824 && fVar.v() != min2) {
                fVar.v0(min2);
                fVar.u1();
            }
            if (i5 == 1073741824 && i7 == 1073741824) {
                z2 = fVar.o1(b2);
                i11 = 2;
            } else {
                boolean p12 = fVar.p1(b2);
                if (i5 == 1073741824) {
                    p12 &= fVar.q1(b2, 0);
                    i11 = 1;
                } else {
                    i11 = 0;
                }
                if (i7 == 1073741824) {
                    z2 = fVar.q1(b2, 1) & p12;
                    i11++;
                } else {
                    z2 = p12;
                }
            }
            if (z2) {
                fVar.Y0(i5 == 1073741824, i7 == 1073741824);
            }
        } else {
            z2 = false;
            i11 = 0;
        }
        if (z2 && i11 == 2) {
            return 0L;
        }
        int s12 = fVar.s1();
        if (size > 0) {
            b(fVar);
        }
        e(fVar);
        int size2 = this.f4980a.size();
        if (size > 0) {
            c(fVar, "First pass", R, v2);
        }
        if (size2 > 0) {
            e.b y3 = fVar.y();
            e.b bVar2 = e.b.WRAP_CONTENT;
            boolean z12 = y3 == bVar2;
            boolean z13 = fVar.O() == bVar2;
            int max = Math.max(fVar.R(), this.f4982c.G());
            int max2 = Math.max(fVar.v(), this.f4982c.F());
            int i16 = 0;
            boolean z14 = false;
            while (i16 < size2) {
                p.e eVar2 = this.f4980a.get(i16);
                if (eVar2 instanceof p.k) {
                    int R2 = eVar2.R();
                    i14 = s12;
                    int v3 = eVar2.v();
                    boolean a2 = a(r12, eVar2, a.f4984l) | z14;
                    int R3 = eVar2.R();
                    int v4 = eVar2.v();
                    if (R3 != R2) {
                        eVar2.U0(R3);
                        if (z12 && eVar2.K() > max) {
                            max = Math.max(max, eVar2.K() + eVar2.m(d.b.RIGHT).e());
                        }
                        z7 = true;
                    } else {
                        z7 = a2;
                    }
                    if (v4 != v3) {
                        eVar2.v0(v4);
                        if (z13 && eVar2.p() > max2) {
                            max2 = Math.max(max2, eVar2.p() + eVar2.m(d.b.BOTTOM).e());
                        }
                        z7 = true;
                    }
                    z14 = z7 | ((p.k) eVar2).d1();
                } else {
                    i14 = s12;
                }
                i16++;
                s12 = i14;
            }
            i12 = s12;
            int i17 = 0;
            int i18 = 2;
            while (i17 < i18) {
                int i19 = 0;
                while (i19 < size2) {
                    p.e eVar3 = this.f4980a.get(i19);
                    if (((eVar3 instanceof p.h) && !(eVar3 instanceof p.k)) || (eVar3 instanceof p.g) || eVar3.Q() == 8 || ((z11 && eVar3.f4895e.f5062e.f5016j && eVar3.f4897f.f5062e.f5016j) || (eVar3 instanceof p.k))) {
                        z5 = z11;
                        i13 = size2;
                    } else {
                        int R4 = eVar3.R();
                        int v5 = eVar3.v();
                        z5 = z11;
                        int n2 = eVar3.n();
                        int i20 = a.f4984l;
                        i13 = size2;
                        if (i17 == 1) {
                            i20 = a.f4985m;
                        }
                        boolean a3 = a(r12, eVar3, i20) | z14;
                        int R5 = eVar3.R();
                        int v6 = eVar3.v();
                        if (R5 != R4) {
                            eVar3.U0(R5);
                            if (z12 && eVar3.K() > max) {
                                max = Math.max(max, eVar3.K() + eVar3.m(d.b.RIGHT).e());
                            }
                            z6 = true;
                        } else {
                            z6 = a3;
                        }
                        if (v6 != v5) {
                            eVar3.v0(v6);
                            if (z13 && eVar3.p() > max2) {
                                max2 = Math.max(max2, eVar3.p() + eVar3.m(d.b.BOTTOM).e());
                            }
                            z6 = true;
                        }
                        z14 = (!eVar3.U() || n2 == eVar3.n()) ? z6 : true;
                    }
                    i19++;
                    size2 = i13;
                    z11 = z5;
                }
                boolean z15 = z11;
                int i21 = size2;
                if (!z14) {
                    break;
                }
                c(fVar, "intermediate pass", R, v2);
                i17++;
                size2 = i21;
                z11 = z15;
                i18 = 2;
                z14 = false;
            }
            fVar2 = fVar;
            if (z14) {
                c(fVar2, "2nd pass", R, v2);
                if (fVar.R() < max) {
                    fVar2.U0(max);
                    z3 = true;
                } else {
                    z3 = false;
                }
                if (fVar.v() < max2) {
                    fVar2.v0(max2);
                    z4 = true;
                } else {
                    z4 = z3;
                }
                if (z4) {
                    c(fVar2, "3rd pass", R, v2);
                }
            }
        } else {
            i12 = s12;
            fVar2 = fVar;
        }
        fVar2.E1(i12);
        return 0L;
    }

    public void e(p.f fVar) {
        this.f4980a.clear();
        int size = fVar.D0.size();
        for (int i2 = 0; i2 < size; i2++) {
            p.e eVar = fVar.D0.get(i2);
            e.b y2 = eVar.y();
            e.b bVar = e.b.MATCH_CONSTRAINT;
            if (y2 == bVar || eVar.O() == bVar) {
                this.f4980a.add(eVar);
            }
        }
        fVar.u1();
    }
}
