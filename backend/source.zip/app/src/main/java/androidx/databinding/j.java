package androidx.databinding;
/* loaded from: classes.dex */
interface j<T> {
    void a(T t2);

    void b(androidx.lifecycle.g gVar);

    void d(T t2);
}
