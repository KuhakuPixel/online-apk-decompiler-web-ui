package androidx.cardview.widget;

import android.graphics.drawable.Drawable;
/* loaded from: classes.dex */
class e extends Drawable {

    /* renamed from: a  reason: collision with root package name */
    private static final double f1045a = Math.cos(Math.toRadians(45.0d));

    /* JADX INFO: Access modifiers changed from: package-private */
    public static float a(float f2, float f3, boolean z2) {
        return z2 ? (float) (f2 + ((1.0d - f1045a) * f3)) : f2;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static float b(float f2, float f3, boolean z2) {
        float f4 = f2 * 1.5f;
        return z2 ? (float) (f4 + ((1.0d - f1045a) * f3)) : f4;
    }
}
