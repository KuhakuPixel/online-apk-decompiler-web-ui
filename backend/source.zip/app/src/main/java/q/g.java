package q;

import q.f;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes.dex */
public class g extends f {

    /* renamed from: m  reason: collision with root package name */
    public int f5028m;

    public g(p pVar) {
        super(pVar);
        this.f5011e = pVar instanceof l ? f.a.HORIZONTAL_DIMENSION : f.a.VERTICAL_DIMENSION;
    }

    @Override // q.f
    public void d(int i2) {
        if (this.f5016j) {
            return;
        }
        this.f5016j = true;
        this.f5013g = i2;
        for (d dVar : this.f5017k) {
            dVar.a(dVar);
        }
    }
}
