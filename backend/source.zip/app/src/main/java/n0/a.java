package n0;
/* loaded from: classes.dex */
public class a<D> {
}
