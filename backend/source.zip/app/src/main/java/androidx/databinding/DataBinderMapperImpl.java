package androidx.databinding;
/* loaded from: classes.dex */
public class DataBinderMapperImpl extends MergedDataBinderMapper {
    /* JADX INFO: Access modifiers changed from: package-private */
    public DataBinderMapperImpl() {
        d(new com.sample.android.kuhakupixelinapppurchase.DataBinderMapperImpl());
    }
}
