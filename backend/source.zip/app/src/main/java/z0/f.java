package z0;
/* loaded from: classes.dex */
final class f extends b0 {

    /* renamed from: d  reason: collision with root package name */
    private final transient Object[] f5693d;

    /* renamed from: e  reason: collision with root package name */
    private final transient int f5694e;

    /* renamed from: f  reason: collision with root package name */
    private final transient int f5695f;

    /* JADX INFO: Access modifiers changed from: package-private */
    public f(Object[] objArr, int i2, int i3) {
        this.f5693d = objArr;
        this.f5694e = i2;
        this.f5695f = i3;
    }

    @Override // java.util.List
    public final Object get(int i2) {
        t.a(i2, this.f5695f, "index");
        Object obj = this.f5693d[i2 + i2 + this.f5694e];
        obj.getClass();
        return obj;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    @Override // z0.y
    public final boolean h() {
        return true;
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public final int size() {
        return this.f5695f;
    }
}
