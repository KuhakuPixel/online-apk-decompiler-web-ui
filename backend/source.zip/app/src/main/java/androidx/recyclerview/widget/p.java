package androidx.recyclerview.widget;

import androidx.recyclerview.widget.RecyclerView;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes.dex */
public class p {

    /* renamed from: a  reason: collision with root package name */
    final l.g<RecyclerView.d0, a> f2482a = new l.g<>();

    /* renamed from: b  reason: collision with root package name */
    final l.d<RecyclerView.d0> f2483b = new l.d<>();

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public static class a {

        /* renamed from: d  reason: collision with root package name */
        static d0.e<a> f2484d = new d0.f(20);

        /* renamed from: a  reason: collision with root package name */
        int f2485a;

        /* renamed from: b  reason: collision with root package name */
        RecyclerView.l.c f2486b;

        /* renamed from: c  reason: collision with root package name */
        RecyclerView.l.c f2487c;

        private a() {
        }

        static void a() {
            do {
            } while (f2484d.b() != null);
        }

        static a b() {
            a b2 = f2484d.b();
            return b2 == null ? new a() : b2;
        }

        static void c(a aVar) {
            aVar.f2485a = 0;
            aVar.f2486b = null;
            aVar.f2487c = null;
            f2484d.a(aVar);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public interface b {
        void a(RecyclerView.d0 d0Var);

        void b(RecyclerView.d0 d0Var, RecyclerView.l.c cVar, RecyclerView.l.c cVar2);

        void c(RecyclerView.d0 d0Var, RecyclerView.l.c cVar, RecyclerView.l.c cVar2);

        void d(RecyclerView.d0 d0Var, RecyclerView.l.c cVar, RecyclerView.l.c cVar2);
    }

    private RecyclerView.l.c l(RecyclerView.d0 d0Var, int i2) {
        a o2;
        RecyclerView.l.c cVar;
        int h2 = this.f2482a.h(d0Var);
        if (h2 >= 0 && (o2 = this.f2482a.o(h2)) != null) {
            int i3 = o2.f2485a;
            if ((i3 & i2) != 0) {
                int i4 = (~i2) & i3;
                o2.f2485a = i4;
                if (i2 == 4) {
                    cVar = o2.f2486b;
                } else if (i2 != 8) {
                    throw new IllegalArgumentException("Must provide flag PRE or POST");
                } else {
                    cVar = o2.f2487c;
                }
                if ((i4 & 12) == 0) {
                    this.f2482a.m(h2);
                    a.c(o2);
                }
                return cVar;
            }
        }
        return null;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void a(RecyclerView.d0 d0Var, RecyclerView.l.c cVar) {
        a aVar = this.f2482a.get(d0Var);
        if (aVar == null) {
            aVar = a.b();
            this.f2482a.put(d0Var, aVar);
        }
        aVar.f2485a |= 2;
        aVar.f2486b = cVar;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void b(RecyclerView.d0 d0Var) {
        a aVar = this.f2482a.get(d0Var);
        if (aVar == null) {
            aVar = a.b();
            this.f2482a.put(d0Var, aVar);
        }
        aVar.f2485a |= 1;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void c(long j2, RecyclerView.d0 d0Var) {
        this.f2483b.i(j2, d0Var);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void d(RecyclerView.d0 d0Var, RecyclerView.l.c cVar) {
        a aVar = this.f2482a.get(d0Var);
        if (aVar == null) {
            aVar = a.b();
            this.f2482a.put(d0Var, aVar);
        }
        aVar.f2487c = cVar;
        aVar.f2485a |= 8;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void e(RecyclerView.d0 d0Var, RecyclerView.l.c cVar) {
        a aVar = this.f2482a.get(d0Var);
        if (aVar == null) {
            aVar = a.b();
            this.f2482a.put(d0Var, aVar);
        }
        aVar.f2486b = cVar;
        aVar.f2485a |= 4;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void f() {
        this.f2482a.clear();
        this.f2483b.b();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public RecyclerView.d0 g(long j2) {
        return this.f2483b.e(j2);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public boolean h(RecyclerView.d0 d0Var) {
        a aVar = this.f2482a.get(d0Var);
        return (aVar == null || (aVar.f2485a & 1) == 0) ? false : true;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public boolean i(RecyclerView.d0 d0Var) {
        a aVar = this.f2482a.get(d0Var);
        return (aVar == null || (aVar.f2485a & 4) == 0) ? false : true;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void j() {
        a.a();
    }

    public void k(RecyclerView.d0 d0Var) {
        p(d0Var);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public RecyclerView.l.c m(RecyclerView.d0 d0Var) {
        return l(d0Var, 8);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public RecyclerView.l.c n(RecyclerView.d0 d0Var) {
        return l(d0Var, 4);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void o(b bVar) {
        RecyclerView.l.c cVar;
        RecyclerView.l.c cVar2;
        for (int size = this.f2482a.size() - 1; size >= 0; size--) {
            RecyclerView.d0 k2 = this.f2482a.k(size);
            a m2 = this.f2482a.m(size);
            int i2 = m2.f2485a;
            if ((i2 & 3) != 3) {
                if ((i2 & 1) != 0) {
                    cVar = m2.f2486b;
                    cVar2 = cVar != null ? m2.f2487c : null;
                } else {
                    if ((i2 & 14) != 14) {
                        if ((i2 & 12) == 12) {
                            bVar.d(k2, m2.f2486b, m2.f2487c);
                        } else if ((i2 & 4) != 0) {
                            cVar = m2.f2486b;
                        } else if ((i2 & 8) == 0) {
                        }
                        a.c(m2);
                    }
                    bVar.b(k2, m2.f2486b, m2.f2487c);
                    a.c(m2);
                }
                bVar.c(k2, cVar, cVar2);
                a.c(m2);
            }
            bVar.a(k2);
            a.c(m2);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void p(RecyclerView.d0 d0Var) {
        a aVar = this.f2482a.get(d0Var);
        if (aVar == null) {
            return;
        }
        aVar.f2485a &= -2;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void q(RecyclerView.d0 d0Var) {
        int l2 = this.f2483b.l() - 1;
        while (true) {
            if (l2 < 0) {
                break;
            } else if (d0Var == this.f2483b.m(l2)) {
                this.f2483b.k(l2);
                break;
            } else {
                l2--;
            }
        }
        a remove = this.f2482a.remove(d0Var);
        if (remove != null) {
            a.c(remove);
        }
    }
}
