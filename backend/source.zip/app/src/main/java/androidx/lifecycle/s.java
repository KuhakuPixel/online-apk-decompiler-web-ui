package androidx.lifecycle;
/* loaded from: classes.dex */
public class s {

    /* renamed from: a  reason: collision with root package name */
    private final a f1877a;

    /* renamed from: b  reason: collision with root package name */
    private final t f1878b;

    /* loaded from: classes.dex */
    public interface a {
        <T extends r> T a(Class<T> cls);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public static abstract class b extends c implements a {
        b() {
        }

        @Override // androidx.lifecycle.s.a
        public <T extends r> T a(Class<T> cls) {
            throw new UnsupportedOperationException("create(String, Class<?>) must be called on implementaions of KeyedFactory");
        }

        public abstract <T extends r> T c(String str, Class<T> cls);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public static class c {
        c() {
        }

        void b(r rVar) {
        }
    }

    public s(t tVar, a aVar) {
        this.f1877a = aVar;
        this.f1878b = tVar;
    }

    public s(u uVar, a aVar) {
        this(uVar.g(), aVar);
    }

    public <T extends r> T a(Class<T> cls) {
        String canonicalName = cls.getCanonicalName();
        if (canonicalName != null) {
            return (T) b("androidx.lifecycle.ViewModelProvider.DefaultKey:" + canonicalName, cls);
        }
        throw new IllegalArgumentException("Local and anonymous classes can not be ViewModels");
    }

    public <T extends r> T b(String str, Class<T> cls) {
        T t2 = (T) this.f1878b.b(str);
        if (cls.isInstance(t2)) {
            a aVar = this.f1877a;
            if (aVar instanceof c) {
                ((c) aVar).b(t2);
            }
            return t2;
        }
        a aVar2 = this.f1877a;
        T t3 = aVar2 instanceof b ? (T) ((b) aVar2).c(str, cls) : (T) aVar2.a(cls);
        this.f1878b.d(str, t3);
        return t3;
    }
}
