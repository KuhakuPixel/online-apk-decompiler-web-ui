package a;

import com.sample.android.kuhakupixelinapppurchase.R;
/* loaded from: classes.dex */
public final class j {
    public static final int A = 2;
    public static final int A0 = 0;
    public static final int A1 = 0;
    public static final int A2 = 9;
    public static final int A3 = 22;
    public static final int B = 3;
    public static final int B0 = 1;
    public static final int B1 = 1;
    public static final int B2 = 10;
    public static final int B3 = 23;
    public static final int C = 4;
    public static final int C0 = 84;
    public static final int C1 = 2;
    public static final int C2 = 11;
    public static final int C3 = 24;
    public static final int D = 5;
    public static final int D0 = 114;
    public static final int D1 = 3;
    public static final int D2 = 12;
    public static final int D3 = 25;
    public static final int E0 = 115;
    public static final int E1 = 4;
    public static final int E2 = 13;
    public static final int E3 = 26;
    public static final int F0 = 116;
    public static final int F1 = 5;
    public static final int F2 = 14;
    public static final int F3 = 27;
    public static final int G = 0;
    public static final int G0 = 117;
    public static final int G2 = 15;
    public static final int G3 = 28;
    public static final int H = 1;
    public static final int H0 = 118;
    public static final int H1 = 0;
    public static final int H2 = 16;
    public static final int H3 = 29;
    public static final int I = 2;
    public static final int I0 = 119;
    public static final int I1 = 1;
    public static final int J = 3;
    public static final int J0 = 120;
    public static final int J1 = 2;
    public static final int J2 = 0;
    public static final int J3 = 0;
    public static final int K = 4;
    public static final int K0 = 121;
    public static final int K1 = 3;
    public static final int K2 = 1;
    public static final int K3 = 4;
    public static final int L = 5;
    public static final int L0 = 122;
    public static final int L1 = 4;
    public static final int L2 = 2;
    public static final int M = 6;
    public static final int M0 = 123;
    public static final int M1 = 5;
    public static final int M2 = 3;
    public static final int M3 = 0;
    public static final int N = 7;
    public static final int N0 = 124;
    public static final int N1 = 6;
    public static final int N2 = 4;
    public static final int N3 = 1;
    public static final int O1 = 7;
    public static final int O3 = 2;
    public static final int P0 = 0;
    public static final int P1 = 8;
    public static final int Q1 = 9;
    public static final int Q3 = 0;
    public static final int R1 = 10;
    public static final int R3 = 1;
    public static final int S = 1;
    public static final int S0 = 0;
    public static final int S1 = 11;
    public static final int S2 = 0;
    public static final int S3 = 2;
    public static final int T = 2;
    public static final int T0 = 1;
    public static final int T1 = 12;
    public static final int T2 = 1;
    public static final int U = 3;
    public static final int U0 = 2;
    public static final int U1 = 13;
    public static final int U2 = 2;
    public static final int V0 = 3;
    public static final int V1 = 14;
    public static final int V2 = 3;
    public static final int W = 0;
    public static final int W1 = 15;
    public static final int W2 = 4;
    public static final int X = 1;
    public static final int X0 = 0;
    public static final int X1 = 16;
    public static final int X2 = 5;
    public static final int Y = 2;
    public static final int Y0 = 1;
    public static final int Y1 = 17;
    public static final int Y2 = 10;
    public static final int Z = 3;
    public static final int Z0 = 2;
    public static final int Z1 = 18;
    public static final int Z2 = 11;

    /* renamed from: a1  reason: collision with root package name */
    public static final int f17a1 = 3;
    public static final int a2 = 19;
    public static final int a3 = 12;

    /* renamed from: b  reason: collision with root package name */
    public static final int f18b = 0;

    /* renamed from: b0  reason: collision with root package name */
    public static final int f19b0 = 0;

    /* renamed from: b1  reason: collision with root package name */
    public static final int f20b1 = 4;
    public static final int b2 = 20;
    public static final int b3 = 13;

    /* renamed from: c  reason: collision with root package name */
    public static final int f21c = 1;

    /* renamed from: c0  reason: collision with root package name */
    public static final int f22c0 = 1;

    /* renamed from: c1  reason: collision with root package name */
    public static final int f23c1 = 5;
    public static final int c2 = 21;
    public static final int c3 = 14;

    /* renamed from: d  reason: collision with root package name */
    public static final int f24d = 2;

    /* renamed from: d0  reason: collision with root package name */
    public static final int f25d0 = 2;

    /* renamed from: d1  reason: collision with root package name */
    public static final int f26d1 = 6;
    public static final int d2 = 22;
    public static final int d3 = 15;

    /* renamed from: e  reason: collision with root package name */
    public static final int f27e = 3;

    /* renamed from: e0  reason: collision with root package name */
    public static final int f28e0 = 3;

    /* renamed from: e1  reason: collision with root package name */
    public static final int f29e1 = 7;

    /* renamed from: f  reason: collision with root package name */
    public static final int f30f = 7;

    /* renamed from: f0  reason: collision with root package name */
    public static final int f31f0 = 4;
    public static final int f2 = 1;
    public static final int f3 = 0;

    /* renamed from: g  reason: collision with root package name */
    public static final int f33g = 9;

    /* renamed from: g0  reason: collision with root package name */
    public static final int f34g0 = 5;
    public static final int g2 = 5;
    public static final int g3 = 2;

    /* renamed from: h  reason: collision with root package name */
    public static final int f36h = 10;

    /* renamed from: h0  reason: collision with root package name */
    public static final int f37h0 = 6;
    public static final int h2 = 7;
    public static final int h3 = 3;

    /* renamed from: i  reason: collision with root package name */
    public static final int f39i = 12;
    public static final int i2 = 8;
    public static final int i3 = 4;

    /* renamed from: j  reason: collision with root package name */
    public static final int f42j = 13;

    /* renamed from: j0  reason: collision with root package name */
    public static final int f43j0 = 1;
    public static final int j3 = 5;

    /* renamed from: k  reason: collision with root package name */
    public static final int f45k = 14;

    /* renamed from: k0  reason: collision with root package name */
    public static final int f46k0 = 2;

    /* renamed from: k1  reason: collision with root package name */
    public static final int f47k1 = 0;
    public static final int k2 = 0;
    public static final int k3 = 6;

    /* renamed from: l  reason: collision with root package name */
    public static final int f48l = 15;

    /* renamed from: l0  reason: collision with root package name */
    public static final int f49l0 = 3;

    /* renamed from: l1  reason: collision with root package name */
    public static final int f50l1 = 1;
    public static final int l2 = 2;
    public static final int l3 = 7;

    /* renamed from: m  reason: collision with root package name */
    public static final int f51m = 17;

    /* renamed from: m0  reason: collision with root package name */
    public static final int f52m0 = 4;

    /* renamed from: m1  reason: collision with root package name */
    public static final int f53m1 = 2;
    public static final int m3 = 8;

    /* renamed from: n  reason: collision with root package name */
    public static final int f54n = 20;

    /* renamed from: n0  reason: collision with root package name */
    public static final int f55n0 = 5;

    /* renamed from: n1  reason: collision with root package name */
    public static final int f56n1 = 3;
    public static final int n3 = 9;

    /* renamed from: o  reason: collision with root package name */
    public static final int f57o = 22;

    /* renamed from: o0  reason: collision with root package name */
    public static final int f58o0 = 6;

    /* renamed from: o1  reason: collision with root package name */
    public static final int f59o1 = 4;
    public static final int o2 = 0;
    public static final int o3 = 10;

    /* renamed from: p  reason: collision with root package name */
    public static final int f60p = 25;

    /* renamed from: p0  reason: collision with root package name */
    public static final int f61p0 = 7;

    /* renamed from: p1  reason: collision with root package name */
    public static final int f62p1 = 5;
    public static final int p2 = 1;
    public static final int p3 = 11;

    /* renamed from: q  reason: collision with root package name */
    public static final int f63q = 26;

    /* renamed from: q0  reason: collision with root package name */
    public static final int f64q0 = 8;

    /* renamed from: q1  reason: collision with root package name */
    public static final int f65q1 = 6;
    public static final int q3 = 12;

    /* renamed from: r  reason: collision with root package name */
    public static final int f66r = 27;

    /* renamed from: r0  reason: collision with root package name */
    public static final int f67r0 = 9;

    /* renamed from: r1  reason: collision with root package name */
    public static final int f68r1 = 7;
    public static final int r2 = 0;
    public static final int r3 = 13;

    /* renamed from: s  reason: collision with root package name */
    public static final int f69s = 28;

    /* renamed from: s0  reason: collision with root package name */
    public static final int f70s0 = 10;

    /* renamed from: s1  reason: collision with root package name */
    public static final int f71s1 = 8;
    public static final int s2 = 1;
    public static final int s3 = 14;

    /* renamed from: t0  reason: collision with root package name */
    public static final int f73t0 = 11;
    public static final int t2 = 2;
    public static final int t3 = 15;

    /* renamed from: u  reason: collision with root package name */
    public static final int f75u = 0;

    /* renamed from: u0  reason: collision with root package name */
    public static final int f76u0 = 12;

    /* renamed from: u1  reason: collision with root package name */
    public static final int f77u1 = 0;
    public static final int u2 = 3;
    public static final int u3 = 16;

    /* renamed from: v0  reason: collision with root package name */
    public static final int f79v0 = 13;

    /* renamed from: v1  reason: collision with root package name */
    public static final int f80v1 = 3;
    public static final int v2 = 4;
    public static final int v3 = 17;

    /* renamed from: w  reason: collision with root package name */
    public static final int f81w = 0;

    /* renamed from: w0  reason: collision with root package name */
    public static final int f82w0 = 14;
    public static final int w2 = 5;
    public static final int w3 = 18;

    /* renamed from: x0  reason: collision with root package name */
    public static final int f85x0 = 17;

    /* renamed from: x1  reason: collision with root package name */
    public static final int f86x1 = 0;
    public static final int x2 = 6;
    public static final int x3 = 19;

    /* renamed from: y0  reason: collision with root package name */
    public static final int f88y0 = 18;

    /* renamed from: y1  reason: collision with root package name */
    public static final int f89y1 = 1;
    public static final int y2 = 7;
    public static final int y3 = 20;

    /* renamed from: z  reason: collision with root package name */
    public static final int f90z = 0;
    public static final int z2 = 8;
    public static final int z3 = 21;

    /* renamed from: a  reason: collision with root package name */
    public static final int[] f15a = {R.attr.background, R.attr.backgroundSplit, R.attr.backgroundStacked, R.attr.contentInsetEnd, R.attr.contentInsetEndWithActions, R.attr.contentInsetLeft, R.attr.contentInsetRight, R.attr.contentInsetStart, R.attr.contentInsetStartWithNavigation, R.attr.customNavigationLayout, R.attr.displayOptions, R.attr.divider, R.attr.elevation, R.attr.height, R.attr.hideOnContentScroll, R.attr.homeAsUpIndicator, R.attr.homeLayout, R.attr.icon, R.attr.indeterminateProgressStyle, R.attr.itemPadding, R.attr.logo, R.attr.navigationMode, R.attr.popupTheme, R.attr.progressBarPadding, R.attr.progressBarStyle, R.attr.subtitle, R.attr.subtitleTextStyle, R.attr.title, R.attr.titleTextStyle};

    /* renamed from: t  reason: collision with root package name */
    public static final int[] f72t = {16842931};

    /* renamed from: v  reason: collision with root package name */
    public static final int[] f78v = {16843071};

    /* renamed from: x  reason: collision with root package name */
    public static final int[] f84x = new int[0];

    /* renamed from: y  reason: collision with root package name */
    public static final int[] f87y = {R.attr.background, R.attr.backgroundSplit, R.attr.closeItemLayout, R.attr.height, R.attr.subtitleTextStyle, R.attr.titleTextStyle};
    public static final int[] E = {R.attr.expandActivityOverflowButtonDrawable, R.attr.initialActivityCount};
    public static final int[] F = {16842994, R.attr.buttonIconDimen, R.attr.buttonPanelSideLayout, R.attr.listItemLayout, R.attr.listLayout, R.attr.multiChoiceItemLayout, R.attr.showTitle, R.attr.singleChoiceItemLayout};
    public static final int[] O = {16843036, 16843156, 16843157, 16843158, 16843532, 16843533};
    public static final int[] P = {16842960, 16843161};
    public static final int[] Q = {16843161, 16843849, 16843850, 16843851};
    public static final int[] R = {16843033, R.attr.srcCompat, R.attr.tint, R.attr.tintMode};
    public static final int[] V = {16843074, R.attr.tickMark, R.attr.tickMarkTint, R.attr.tickMarkTintMode};

    /* renamed from: a0  reason: collision with root package name */
    public static final int[] f16a0 = {16842804, 16843117, 16843118, 16843119, 16843120, 16843666, 16843667};

    /* renamed from: i0  reason: collision with root package name */
    public static final int[] f40i0 = {16842804, R.attr.autoSizeMaxTextSize, R.attr.autoSizeMinTextSize, R.attr.autoSizePresetSizes, R.attr.autoSizeStepGranularity, R.attr.autoSizeTextType, R.attr.drawableBottomCompat, R.attr.drawableEndCompat, R.attr.drawableLeftCompat, R.attr.drawableRightCompat, R.attr.drawableStartCompat, R.attr.drawableTint, R.attr.drawableTintMode, R.attr.drawableTopCompat, R.attr.firstBaselineToTopHeight, R.attr.fontFamily, R.attr.fontVariationSettings, R.attr.lastBaselineToBottomHeight, R.attr.lineHeight, R.attr.textAllCaps, R.attr.textLocale};

    /* renamed from: z0  reason: collision with root package name */
    public static final int[] f91z0 = {16842839, 16842926, R.attr.actionBarDivider, R.attr.actionBarItemBackground, R.attr.actionBarPopupTheme, R.attr.actionBarSize, R.attr.actionBarSplitStyle, R.attr.actionBarStyle, R.attr.actionBarTabBarStyle, R.attr.actionBarTabStyle, R.attr.actionBarTabTextStyle, R.attr.actionBarTheme, R.attr.actionBarWidgetTheme, R.attr.actionButtonStyle, R.attr.actionDropDownStyle, R.attr.actionMenuTextAppearance, R.attr.actionMenuTextColor, R.attr.actionModeBackground, R.attr.actionModeCloseButtonStyle, R.attr.actionModeCloseDrawable, R.attr.actionModeCopyDrawable, R.attr.actionModeCutDrawable, R.attr.actionModeFindDrawable, R.attr.actionModePasteDrawable, R.attr.actionModePopupWindowStyle, R.attr.actionModeSelectAllDrawable, R.attr.actionModeShareDrawable, R.attr.actionModeSplitBackground, R.attr.actionModeStyle, R.attr.actionModeWebSearchDrawable, R.attr.actionOverflowButtonStyle, R.attr.actionOverflowMenuStyle, R.attr.activityChooserViewStyle, R.attr.alertDialogButtonGroupStyle, R.attr.alertDialogCenterButtons, R.attr.alertDialogStyle, R.attr.alertDialogTheme, R.attr.autoCompleteTextViewStyle, R.attr.borderlessButtonStyle, R.attr.buttonBarButtonStyle, R.attr.buttonBarNegativeButtonStyle, R.attr.buttonBarNeutralButtonStyle, R.attr.buttonBarPositiveButtonStyle, R.attr.buttonBarStyle, R.attr.buttonStyle, R.attr.buttonStyleSmall, R.attr.checkboxStyle, R.attr.checkedTextViewStyle, R.attr.colorAccent, R.attr.colorBackgroundFloating, R.attr.colorButtonNormal, R.attr.colorControlActivated, R.attr.colorControlHighlight, R.attr.colorControlNormal, R.attr.colorError, R.attr.colorPrimary, R.attr.colorPrimaryDark, R.attr.colorSwitchThumbNormal, R.attr.controlBackground, R.attr.dialogCornerRadius, R.attr.dialogPreferredPadding, R.attr.dialogTheme, R.attr.dividerHorizontal, R.attr.dividerVertical, R.attr.dropDownListViewStyle, R.attr.dropdownListPreferredItemHeight, R.attr.editTextBackground, R.attr.editTextColor, R.attr.editTextStyle, R.attr.homeAsUpIndicator, R.attr.imageButtonStyle, R.attr.listChoiceBackgroundIndicator, R.attr.listChoiceIndicatorMultipleAnimated, R.attr.listChoiceIndicatorSingleAnimated, R.attr.listDividerAlertDialog, R.attr.listMenuViewStyle, R.attr.listPopupWindowStyle, R.attr.listPreferredItemHeight, R.attr.listPreferredItemHeightLarge, R.attr.listPreferredItemHeightSmall, R.attr.listPreferredItemPaddingEnd, R.attr.listPreferredItemPaddingLeft, R.attr.listPreferredItemPaddingRight, R.attr.listPreferredItemPaddingStart, R.attr.panelBackground, R.attr.panelMenuListTheme, R.attr.panelMenuListWidth, R.attr.popupMenuStyle, R.attr.popupWindowStyle, R.attr.radioButtonStyle, R.attr.ratingBarStyle, R.attr.ratingBarStyleIndicator, R.attr.ratingBarStyleSmall, R.attr.searchViewStyle, R.attr.seekBarStyle, R.attr.selectableItemBackground, R.attr.selectableItemBackgroundBorderless, R.attr.spinnerDropDownItemStyle, R.attr.spinnerStyle, R.attr.switchStyle, R.attr.textAppearanceLargePopupMenu, R.attr.textAppearanceListItem, R.attr.textAppearanceListItemSecondary, R.attr.textAppearanceListItemSmall, R.attr.textAppearancePopupMenuHeader, R.attr.textAppearanceSearchResultSubtitle, R.attr.textAppearanceSearchResultTitle, R.attr.textAppearanceSmallPopupMenu, R.attr.textColorAlertDialogListItem, R.attr.textColorSearchUrl, R.attr.toolbarNavigationButtonStyle, R.attr.toolbarStyle, R.attr.tooltipForegroundColor, R.attr.tooltipFrameBackground, R.attr.viewInflaterClass, R.attr.windowActionBar, R.attr.windowActionBarOverlay, R.attr.windowActionModeOverlay, R.attr.windowFixedHeightMajor, R.attr.windowFixedHeightMinor, R.attr.windowFixedWidthMajor, R.attr.windowFixedWidthMinor, R.attr.windowMinWidthMajor, R.attr.windowMinWidthMinor, R.attr.windowNoTitle};
    public static final int[] O0 = {R.attr.allowStacking};
    public static final int[] Q0 = {16843173, 16843551, R.attr.alpha};
    public static final int[] R0 = {16843015, R.attr.buttonCompat, R.attr.buttonTint, R.attr.buttonTintMode};
    public static final int[] W0 = {R.attr.arrowHeadLength, R.attr.arrowShaftLength, R.attr.barLength, R.attr.color, R.attr.drawableSize, R.attr.gapBetweenBars, R.attr.spinBars, R.attr.thickness};

    /* renamed from: f1  reason: collision with root package name */
    public static final int[] f32f1 = {R.attr.fontProviderAuthority, R.attr.fontProviderCerts, R.attr.fontProviderFetchStrategy, R.attr.fontProviderFetchTimeout, R.attr.fontProviderPackage, R.attr.fontProviderQuery};

    /* renamed from: g1  reason: collision with root package name */
    public static final int[] f35g1 = {16844082, 16844083, 16844095, 16844143, 16844144, R.attr.font, R.attr.fontStyle, R.attr.fontVariationSettings, R.attr.fontWeight, R.attr.ttcIndex};

    /* renamed from: h1  reason: collision with root package name */
    public static final int[] f38h1 = {16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 16844050, 16844051};

    /* renamed from: i1  reason: collision with root package name */
    public static final int[] f41i1 = {16843173, 16844052};

    /* renamed from: j1  reason: collision with root package name */
    public static final int[] f44j1 = {16842927, 16842948, 16843046, 16843047, 16843048, R.attr.divider, R.attr.dividerPadding, R.attr.measureWithLargestChild, R.attr.showDividers};

    /* renamed from: t1  reason: collision with root package name */
    public static final int[] f74t1 = {16842931, 16842996, 16842997, 16843137};

    /* renamed from: w1  reason: collision with root package name */
    public static final int[] f83w1 = {16843436, 16843437};

    /* renamed from: z1  reason: collision with root package name */
    public static final int[] f92z1 = {16842766, 16842960, 16843156, 16843230, 16843231, 16843232};
    public static final int[] G1 = {16842754, 16842766, 16842960, 16843014, 16843156, 16843230, 16843231, 16843233, 16843234, 16843235, 16843236, 16843237, 16843375, R.attr.actionLayout, R.attr.actionProviderClass, R.attr.actionViewClass, R.attr.alphabeticModifiers, R.attr.contentDescription, R.attr.iconTint, R.attr.iconTintMode, R.attr.numericModifiers, R.attr.showAsAction, R.attr.tooltipText};
    public static final int[] e2 = {16842926, 16843052, 16843053, 16843054, 16843055, 16843056, 16843057, R.attr.preserveIconSpacing, R.attr.subMenuArrow};
    public static final int[] j2 = {16843126, 16843465, R.attr.overlapAnchor};
    public static final int[] m2 = {R.attr.state_above_anchor};
    public static final int[] n2 = {R.attr.paddingBottomNoButtons, R.attr.paddingTopNoTitle};
    public static final int[] q2 = {16842970, 16843039, 16843296, 16843364, R.attr.closeIcon, R.attr.commitIcon, R.attr.defaultQueryHint, R.attr.goIcon, R.attr.iconifiedByDefault, R.attr.layout, R.attr.queryBackground, R.attr.queryHint, R.attr.searchHintIcon, R.attr.searchIcon, R.attr.submitBackground, R.attr.suggestionRowLayout, R.attr.voiceIcon};
    public static final int[] I2 = {16842930, 16843126, 16843131, 16843362, R.attr.popupTheme};
    public static final int[] O2 = {16843036, 16843156, 16843157, 16843158, 16843532, 16843533};
    public static final int[] P2 = {16843161};
    public static final int[] Q2 = {16843044, 16843045, 16843074, R.attr.showText, R.attr.splitTrack, R.attr.switchMinWidth, R.attr.switchPadding, R.attr.switchTextAppearance, R.attr.thumbTextPadding, R.attr.thumbTint, R.attr.thumbTintMode, R.attr.track, R.attr.trackTint, R.attr.trackTintMode};
    public static final int[] R2 = {16842901, 16842902, 16842903, 16842904, 16842906, 16842907, 16843105, 16843106, 16843107, 16843108, 16843692, 16844165, R.attr.fontFamily, R.attr.fontVariationSettings, R.attr.textAllCaps, R.attr.textLocale};
    public static final int[] e3 = {16842927, 16843072, R.attr.buttonGravity, R.attr.collapseContentDescription, R.attr.collapseIcon, R.attr.contentInsetEnd, R.attr.contentInsetEndWithActions, R.attr.contentInsetLeft, R.attr.contentInsetRight, R.attr.contentInsetStart, R.attr.contentInsetStartWithNavigation, R.attr.logo, R.attr.logoDescription, R.attr.maxButtonHeight, R.attr.menu, R.attr.navigationContentDescription, R.attr.navigationIcon, R.attr.popupTheme, R.attr.subtitle, R.attr.subtitleTextAppearance, R.attr.subtitleTextColor, R.attr.title, R.attr.titleMargin, R.attr.titleMarginBottom, R.attr.titleMarginEnd, R.attr.titleMarginStart, R.attr.titleMarginTop, R.attr.titleMargins, R.attr.titleTextAppearance, R.attr.titleTextColor};
    public static final int[] I3 = {16842752, 16842970, R.attr.paddingEnd, R.attr.paddingStart, R.attr.theme};
    public static final int[] L3 = {16842964, R.attr.backgroundTint, R.attr.backgroundTintMode};
    public static final int[] P3 = {16842960, 16842994, 16842995};
}
