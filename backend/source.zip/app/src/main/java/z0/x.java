package z0;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes.dex */
public final class x {
    /* JADX INFO: Access modifiers changed from: package-private */
    public static int a(int i2) {
        return (int) (Integer.rotateLeft((int) (i2 * (-862048943)), 15) * 461845907);
    }
}
