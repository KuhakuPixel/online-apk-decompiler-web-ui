package z0;

import java.util.Iterator;
import java.util.Map;
import javax.annotation.CheckForNull;
/* loaded from: classes.dex */
final class d extends f0 {

    /* renamed from: d  reason: collision with root package name */
    private final transient e0 f5682d;

    /* renamed from: e  reason: collision with root package name */
    private final transient Object[] f5683e;

    /* renamed from: f  reason: collision with root package name */
    private final transient int f5684f;

    /* JADX INFO: Access modifiers changed from: package-private */
    public d(e0 e0Var, Object[] objArr, int i2, int i3) {
        this.f5682d = e0Var;
        this.f5683e = objArr;
        this.f5684f = i3;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    @Override // z0.y
    public final int c(Object[] objArr, int i2) {
        return f().c(objArr, 0);
    }

    @Override // z0.y, java.util.AbstractCollection, java.util.Collection, java.util.List
    public final boolean contains(@CheckForNull Object obj) {
        if (obj instanceof Map.Entry) {
            Map.Entry entry = (Map.Entry) obj;
            Object key = entry.getKey();
            Object value = entry.getValue();
            if (value != null && value.equals(this.f5682d.get(key))) {
                return true;
            }
        }
        return false;
    }

    @Override // z0.y
    /* renamed from: g */
    public final i iterator() {
        return f().listIterator(0);
    }

    @Override // z0.y, java.util.AbstractCollection, java.util.Collection, java.lang.Iterable, java.util.List
    public final /* synthetic */ Iterator iterator() {
        return f().listIterator(0);
    }

    @Override // z0.f0
    final b0 j() {
        return new c(this);
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
    public final int size() {
        return this.f5684f;
    }
}
