package androidx.recyclerview.widget;

import android.content.Context;
import android.graphics.PointF;
import android.util.DisplayMetrics;
import android.view.View;
import androidx.recyclerview.widget.RecyclerView;
/* loaded from: classes.dex */
public class j extends n {

    /* renamed from: d  reason: collision with root package name */
    private i f2462d;

    /* renamed from: e  reason: collision with root package name */
    private i f2463e;

    /* loaded from: classes.dex */
    class a extends g {
        a(Context context) {
            super(context);
        }

        @Override // androidx.recyclerview.widget.g, androidx.recyclerview.widget.RecyclerView.z
        protected void o(View view, RecyclerView.a0 a0Var, RecyclerView.z.a aVar) {
            j jVar = j.this;
            int[] c2 = jVar.c(jVar.f2470a.getLayoutManager(), view);
            int i2 = c2[0];
            int i3 = c2[1];
            int w2 = w(Math.max(Math.abs(i2), Math.abs(i3)));
            if (w2 > 0) {
                aVar.d(i2, i3, w2, this.f2451j);
            }
        }

        @Override // androidx.recyclerview.widget.g
        protected float v(DisplayMetrics displayMetrics) {
            return 100.0f / displayMetrics.densityDpi;
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // androidx.recyclerview.widget.g
        public int x(int i2) {
            return Math.min(100, super.x(i2));
        }
    }

    private int l(RecyclerView.o oVar, View view, i iVar) {
        return (iVar.g(view) + (iVar.e(view) / 2)) - (iVar.m() + (iVar.n() / 2));
    }

    private View m(RecyclerView.o oVar, i iVar) {
        int J = oVar.J();
        View view = null;
        if (J == 0) {
            return null;
        }
        int m2 = iVar.m() + (iVar.n() / 2);
        int i2 = Integer.MAX_VALUE;
        for (int i3 = 0; i3 < J; i3++) {
            View I = oVar.I(i3);
            int abs = Math.abs((iVar.g(I) + (iVar.e(I) / 2)) - m2);
            if (abs < i2) {
                view = I;
                i2 = abs;
            }
        }
        return view;
    }

    private i n(RecyclerView.o oVar) {
        i iVar = this.f2463e;
        if (iVar == null || iVar.f2459a != oVar) {
            this.f2463e = i.a(oVar);
        }
        return this.f2463e;
    }

    private i o(RecyclerView.o oVar) {
        if (oVar.l()) {
            return p(oVar);
        }
        if (oVar.k()) {
            return n(oVar);
        }
        return null;
    }

    private i p(RecyclerView.o oVar) {
        i iVar = this.f2462d;
        if (iVar == null || iVar.f2459a != oVar) {
            this.f2462d = i.c(oVar);
        }
        return this.f2462d;
    }

    private boolean q(RecyclerView.o oVar, int i2, int i3) {
        return oVar.k() ? i2 > 0 : i3 > 0;
    }

    private boolean r(RecyclerView.o oVar) {
        PointF a2;
        int Y = oVar.Y();
        if (!(oVar instanceof RecyclerView.z.b) || (a2 = ((RecyclerView.z.b) oVar).a(Y - 1)) == null) {
            return false;
        }
        return a2.x < 0.0f || a2.y < 0.0f;
    }

    @Override // androidx.recyclerview.widget.n
    public int[] c(RecyclerView.o oVar, View view) {
        int[] iArr = new int[2];
        if (oVar.k()) {
            iArr[0] = l(oVar, view, n(oVar));
        } else {
            iArr[0] = 0;
        }
        if (oVar.l()) {
            iArr[1] = l(oVar, view, p(oVar));
        } else {
            iArr[1] = 0;
        }
        return iArr;
    }

    @Override // androidx.recyclerview.widget.n
    protected g e(RecyclerView.o oVar) {
        if (oVar instanceof RecyclerView.z.b) {
            return new a(this.f2470a.getContext());
        }
        return null;
    }

    @Override // androidx.recyclerview.widget.n
    public View g(RecyclerView.o oVar) {
        i n2;
        if (oVar.l()) {
            n2 = p(oVar);
        } else if (!oVar.k()) {
            return null;
        } else {
            n2 = n(oVar);
        }
        return m(oVar, n2);
    }

    @Override // androidx.recyclerview.widget.n
    public int h(RecyclerView.o oVar, int i2, int i3) {
        i o2;
        int Y = oVar.Y();
        if (Y == 0 || (o2 = o(oVar)) == null) {
            return -1;
        }
        int i4 = Integer.MIN_VALUE;
        int i5 = Integer.MAX_VALUE;
        int J = oVar.J();
        View view = null;
        View view2 = null;
        for (int i6 = 0; i6 < J; i6++) {
            View I = oVar.I(i6);
            if (I != null) {
                int l2 = l(oVar, I, o2);
                if (l2 <= 0 && l2 > i4) {
                    view2 = I;
                    i4 = l2;
                }
                if (l2 >= 0 && l2 < i5) {
                    view = I;
                    i5 = l2;
                }
            }
        }
        boolean q2 = q(oVar, i2, i3);
        if (!q2 || view == null) {
            if (q2 || view2 == null) {
                if (q2) {
                    view = view2;
                }
                if (view == null) {
                    return -1;
                }
                int h02 = oVar.h0(view) + (r(oVar) == q2 ? -1 : 1);
                if (h02 < 0 || h02 >= Y) {
                    return -1;
                }
                return h02;
            }
            return oVar.h0(view2);
        }
        return oVar.h0(view);
    }
}
