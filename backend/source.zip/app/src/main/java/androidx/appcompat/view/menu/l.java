package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Resources;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;
import androidx.appcompat.view.menu.j;
import androidx.appcompat.widget.i0;
import e0.q;
/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes.dex */
public final class l extends h implements PopupWindow.OnDismissListener, View.OnKeyListener {

    /* renamed from: w  reason: collision with root package name */
    private static final int f458w = a.g.abc_popup_menu_item_layout;

    /* renamed from: c  reason: collision with root package name */
    private final Context f459c;

    /* renamed from: d  reason: collision with root package name */
    private final e f460d;

    /* renamed from: e  reason: collision with root package name */
    private final d f461e;

    /* renamed from: f  reason: collision with root package name */
    private final boolean f462f;

    /* renamed from: g  reason: collision with root package name */
    private final int f463g;

    /* renamed from: h  reason: collision with root package name */
    private final int f464h;

    /* renamed from: i  reason: collision with root package name */
    private final int f465i;

    /* renamed from: j  reason: collision with root package name */
    final i0 f466j;

    /* renamed from: m  reason: collision with root package name */
    private PopupWindow.OnDismissListener f469m;

    /* renamed from: n  reason: collision with root package name */
    private View f470n;

    /* renamed from: o  reason: collision with root package name */
    View f471o;

    /* renamed from: p  reason: collision with root package name */
    private j.a f472p;

    /* renamed from: q  reason: collision with root package name */
    ViewTreeObserver f473q;

    /* renamed from: r  reason: collision with root package name */
    private boolean f474r;

    /* renamed from: s  reason: collision with root package name */
    private boolean f475s;

    /* renamed from: t  reason: collision with root package name */
    private int f476t;

    /* renamed from: v  reason: collision with root package name */
    private boolean f478v;

    /* renamed from: k  reason: collision with root package name */
    final ViewTreeObserver.OnGlobalLayoutListener f467k = new a();

    /* renamed from: l  reason: collision with root package name */
    private final View.OnAttachStateChangeListener f468l = new b();

    /* renamed from: u  reason: collision with root package name */
    private int f477u = 0;

    /* loaded from: classes.dex */
    class a implements ViewTreeObserver.OnGlobalLayoutListener {
        a() {
        }

        @Override // android.view.ViewTreeObserver.OnGlobalLayoutListener
        public void onGlobalLayout() {
            if (!l.this.c() || l.this.f466j.B()) {
                return;
            }
            View view = l.this.f471o;
            if (view == null || !view.isShown()) {
                l.this.dismiss();
            } else {
                l.this.f466j.a();
            }
        }
    }

    /* loaded from: classes.dex */
    class b implements View.OnAttachStateChangeListener {
        b() {
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewAttachedToWindow(View view) {
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewDetachedFromWindow(View view) {
            ViewTreeObserver viewTreeObserver = l.this.f473q;
            if (viewTreeObserver != null) {
                if (!viewTreeObserver.isAlive()) {
                    l.this.f473q = view.getViewTreeObserver();
                }
                l lVar = l.this;
                lVar.f473q.removeGlobalOnLayoutListener(lVar.f467k);
            }
            view.removeOnAttachStateChangeListener(this);
        }
    }

    public l(Context context, e eVar, View view, int i2, int i3, boolean z2) {
        this.f459c = context;
        this.f460d = eVar;
        this.f462f = z2;
        this.f461e = new d(eVar, LayoutInflater.from(context), z2, f458w);
        this.f464h = i2;
        this.f465i = i3;
        Resources resources = context.getResources();
        this.f463g = Math.max(resources.getDisplayMetrics().widthPixels / 2, resources.getDimensionPixelSize(a.d.abc_config_prefDialogWidth));
        this.f470n = view;
        this.f466j = new i0(context, null, i2, i3);
        eVar.c(this, context);
    }

    private boolean z() {
        View view;
        if (c()) {
            return true;
        }
        if (this.f474r || (view = this.f470n) == null) {
            return false;
        }
        this.f471o = view;
        this.f466j.K(this);
        this.f466j.L(this);
        this.f466j.J(true);
        View view2 = this.f471o;
        boolean z2 = this.f473q == null;
        ViewTreeObserver viewTreeObserver = view2.getViewTreeObserver();
        this.f473q = viewTreeObserver;
        if (z2) {
            viewTreeObserver.addOnGlobalLayoutListener(this.f467k);
        }
        view2.addOnAttachStateChangeListener(this.f468l);
        this.f466j.D(view2);
        this.f466j.G(this.f477u);
        if (!this.f475s) {
            this.f476t = h.o(this.f461e, null, this.f459c, this.f463g);
            this.f475s = true;
        }
        this.f466j.F(this.f476t);
        this.f466j.I(2);
        this.f466j.H(n());
        this.f466j.a();
        ListView l2 = this.f466j.l();
        l2.setOnKeyListener(this);
        if (this.f478v && this.f460d.x() != null) {
            FrameLayout frameLayout = (FrameLayout) LayoutInflater.from(this.f459c).inflate(a.g.abc_popup_menu_header_item_layout, (ViewGroup) l2, false);
            TextView textView = (TextView) frameLayout.findViewById(16908310);
            if (textView != null) {
                textView.setText(this.f460d.x());
            }
            frameLayout.setEnabled(false);
            l2.addHeaderView(frameLayout, null, false);
        }
        this.f466j.o(this.f461e);
        this.f466j.a();
        return true;
    }

    @Override // g.e
    public void a() {
        if (!z()) {
            throw new IllegalStateException("StandardMenuPopup cannot be used without an anchor");
        }
    }

    @Override // androidx.appcompat.view.menu.j
    public void b(e eVar, boolean z2) {
        if (eVar != this.f460d) {
            return;
        }
        dismiss();
        j.a aVar = this.f472p;
        if (aVar != null) {
            aVar.b(eVar, z2);
        }
    }

    @Override // g.e
    public boolean c() {
        return !this.f474r && this.f466j.c();
    }

    @Override // androidx.appcompat.view.menu.j
    public boolean d() {
        return false;
    }

    @Override // g.e
    public void dismiss() {
        if (c()) {
            this.f466j.dismiss();
        }
    }

    @Override // androidx.appcompat.view.menu.j
    public void h(j.a aVar) {
        this.f472p = aVar;
    }

    @Override // androidx.appcompat.view.menu.j
    public boolean i(m mVar) {
        if (mVar.hasVisibleItems()) {
            i iVar = new i(this.f459c, mVar, this.f471o, this.f462f, this.f464h, this.f465i);
            iVar.j(this.f472p);
            iVar.g(h.x(mVar));
            iVar.i(this.f469m);
            this.f469m = null;
            this.f460d.e(false);
            int f2 = this.f466j.f();
            int h2 = this.f466j.h();
            if ((Gravity.getAbsoluteGravity(this.f477u, q.B(this.f470n)) & 7) == 5) {
                f2 += this.f470n.getWidth();
            }
            if (iVar.n(f2, h2)) {
                j.a aVar = this.f472p;
                if (aVar != null) {
                    aVar.c(mVar);
                    return true;
                }
                return true;
            }
        }
        return false;
    }

    @Override // androidx.appcompat.view.menu.j
    public void j(boolean z2) {
        this.f475s = false;
        d dVar = this.f461e;
        if (dVar != null) {
            dVar.notifyDataSetChanged();
        }
    }

    @Override // androidx.appcompat.view.menu.h
    public void k(e eVar) {
    }

    @Override // g.e
    public ListView l() {
        return this.f466j.l();
    }

    @Override // android.widget.PopupWindow.OnDismissListener
    public void onDismiss() {
        this.f474r = true;
        this.f460d.close();
        ViewTreeObserver viewTreeObserver = this.f473q;
        if (viewTreeObserver != null) {
            if (!viewTreeObserver.isAlive()) {
                this.f473q = this.f471o.getViewTreeObserver();
            }
            this.f473q.removeGlobalOnLayoutListener(this.f467k);
            this.f473q = null;
        }
        this.f471o.removeOnAttachStateChangeListener(this.f468l);
        PopupWindow.OnDismissListener onDismissListener = this.f469m;
        if (onDismissListener != null) {
            onDismissListener.onDismiss();
        }
    }

    @Override // android.view.View.OnKeyListener
    public boolean onKey(View view, int i2, KeyEvent keyEvent) {
        if (keyEvent.getAction() == 1 && i2 == 82) {
            dismiss();
            return true;
        }
        return false;
    }

    @Override // androidx.appcompat.view.menu.h
    public void p(View view) {
        this.f470n = view;
    }

    @Override // androidx.appcompat.view.menu.h
    public void r(boolean z2) {
        this.f461e.d(z2);
    }

    @Override // androidx.appcompat.view.menu.h
    public void s(int i2) {
        this.f477u = i2;
    }

    @Override // androidx.appcompat.view.menu.h
    public void t(int i2) {
        this.f466j.e(i2);
    }

    @Override // androidx.appcompat.view.menu.h
    public void u(PopupWindow.OnDismissListener onDismissListener) {
        this.f469m = onDismissListener;
    }

    @Override // androidx.appcompat.view.menu.h
    public void v(boolean z2) {
        this.f478v = z2;
    }

    @Override // androidx.appcompat.view.menu.h
    public void w(int i2) {
        this.f466j.n(i2);
    }
}
