package a;
/* loaded from: classes.dex */
public final class e {

    /* renamed from: A */
    public static final int abc_seekbar_thumb_material = 2131230790;

    /* renamed from: B */
    public static final int abc_seekbar_tick_mark_material = 2131230791;

    /* renamed from: C */
    public static final int abc_seekbar_track_material = 2131230792;
    public static final int D = 2131230793;

    /* renamed from: E */
    public static final int abc_spinner_textfield_background_material = 2131230794;

    /* renamed from: F */
    public static final int abc_switch_thumb_material = 2131230795;
    public static final int G = 2131230796;

    /* renamed from: H */
    public static final int abc_tab_indicator_material = 2131230797;

    /* renamed from: I */
    public static final int abc_text_cursor_material = 2131230799;
    public static final int J = 2131230800;
    public static final int K = 2131230801;
    public static final int L = 2131230802;
    public static final int M = 2131230803;
    public static final int N = 2131230804;
    public static final int O = 2131230805;
    public static final int P = 2131230806;
    public static final int Q = 2131230807;
    public static final int R = 2131230808;
    public static final int S = 2131230809;

    /* renamed from: T */
    public static final int abc_textfield_search_material = 2131230810;

    /* renamed from: a  reason: collision with root package name */
    public static final int f4a = 2131230726;

    /* renamed from: b */
    public static final int abc_btn_borderless_material = 2131230728;

    /* renamed from: c */
    public static final int abc_btn_check_material = 2131230729;

    /* renamed from: d */
    public static final int abc_btn_check_material_anim = 2131230730;

    /* renamed from: e */
    public static final int abc_btn_colored_material = 2131230733;

    /* renamed from: f */
    public static final int abc_btn_default_mtrl_shape = 2131230734;

    /* renamed from: g */
    public static final int abc_btn_radio_material = 2131230735;

    /* renamed from: h */
    public static final int abc_btn_radio_material_anim = 2131230736;

    /* renamed from: i */
    public static final int abc_cab_background_internal_bg = 2131230741;

    /* renamed from: j */
    public static final int abc_cab_background_top_material = 2131230742;

    /* renamed from: k  reason: collision with root package name */
    public static final int f5k = 2131230743;

    /* renamed from: l */
    public static final int abc_dialog_material_background = 2131230745;

    /* renamed from: m */
    public static final int abc_edit_text_material = 2131230746;

    /* renamed from: n */
    public static final int abc_ic_ab_back_material = 2131230747;

    /* renamed from: o  reason: collision with root package name */
    public static final int f6o = 2131230750;

    /* renamed from: p  reason: collision with root package name */
    public static final int f7p = 2131230752;

    /* renamed from: q  reason: collision with root package name */
    public static final int f8q = 2131230753;

    /* renamed from: r  reason: collision with root package name */
    public static final int f9r = 2131230755;

    /* renamed from: s  reason: collision with root package name */
    public static final int f10s = 2131230756;

    /* renamed from: t  reason: collision with root package name */
    public static final int f11t = 2131230757;

    /* renamed from: u  reason: collision with root package name */
    public static final int f12u = 2131230769;

    /* renamed from: v  reason: collision with root package name */
    public static final int f13v = 2131230780;

    /* renamed from: w  reason: collision with root package name */
    public static final int f14w = 2131230781;

    /* renamed from: x */
    public static final int abc_ratingbar_indicator_material = 2131230782;

    /* renamed from: y */
    public static final int abc_ratingbar_material = 2131230783;

    /* renamed from: z */
    public static final int abc_ratingbar_small_material = 2131230784;
}
