package androidx.navigation;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import java.util.ArrayDeque;
import java.util.Iterator;
/* loaded from: classes.dex */
public final class i {

    /* renamed from: a  reason: collision with root package name */
    private final Context f1992a;

    /* renamed from: b  reason: collision with root package name */
    private final Intent f1993b;

    /* renamed from: c  reason: collision with root package name */
    private l f1994c;

    /* renamed from: d  reason: collision with root package name */
    private int f1995d;

    /* renamed from: e  reason: collision with root package name */
    private Bundle f1996e;

    public i(Context context) {
        this.f1992a = context;
        if (context instanceof Activity) {
            this.f1993b = new Intent(context, context.getClass());
        } else {
            Intent launchIntentForPackage = context.getPackageManager().getLaunchIntentForPackage(context.getPackageName());
            this.f1993b = launchIntentForPackage == null ? new Intent() : launchIntentForPackage;
        }
        this.f1993b.addFlags(268468224);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public i(NavController navController) {
        this(navController.f());
        this.f1994c = navController.j();
    }

    private void b() {
        ArrayDeque arrayDeque = new ArrayDeque();
        arrayDeque.add(this.f1994c);
        k kVar = null;
        while (!arrayDeque.isEmpty() && kVar == null) {
            k kVar2 = (k) arrayDeque.poll();
            if (kVar2.k() == this.f1995d) {
                kVar = kVar2;
            } else if (kVar2 instanceof l) {
                Iterator<k> it = ((l) kVar2).iterator();
                while (it.hasNext()) {
                    arrayDeque.add(it.next());
                }
            }
        }
        if (kVar != null) {
            this.f1993b.putExtra("android-support-nav:controller:deepLinkIds", kVar.f());
            return;
        }
        throw new IllegalArgumentException("Navigation destination " + k.j(this.f1992a, this.f1995d) + " cannot be found in the navigation graph " + this.f1994c);
    }

    public t.h a() {
        if (this.f1993b.getIntArrayExtra("android-support-nav:controller:deepLinkIds") == null) {
            if (this.f1994c == null) {
                throw new IllegalStateException("You must call setGraph() before constructing the deep link");
            }
            throw new IllegalStateException("You must call setDestination() before constructing the deep link");
        }
        t.h d2 = t.h.g(this.f1992a).d(new Intent(this.f1993b));
        for (int i2 = 0; i2 < d2.i(); i2++) {
            d2.h(i2).putExtra("android-support-nav:controller:deepLinkIntent", this.f1993b);
        }
        return d2;
    }

    public i c(Bundle bundle) {
        this.f1996e = bundle;
        this.f1993b.putExtra("android-support-nav:controller:deepLinkExtras", bundle);
        return this;
    }

    public i d(int i2) {
        this.f1995d = i2;
        if (this.f1994c != null) {
            b();
        }
        return this;
    }
}
