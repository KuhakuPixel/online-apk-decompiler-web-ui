package androidx.navigation;

import android.os.Bundle;
import android.os.Parcelable;
import java.io.Serializable;
/* loaded from: classes.dex */
public abstract class q<T> {

    /* renamed from: b  reason: collision with root package name */
    public static final q<Integer> f2038b = new c(false);

    /* renamed from: c  reason: collision with root package name */
    public static final q<Integer> f2039c = new d(false);

    /* renamed from: d  reason: collision with root package name */
    public static final q<int[]> f2040d = new e(true);

    /* renamed from: e  reason: collision with root package name */
    public static final q<Long> f2041e = new f(false);

    /* renamed from: f  reason: collision with root package name */
    public static final q<long[]> f2042f = new g(true);

    /* renamed from: g  reason: collision with root package name */
    public static final q<Float> f2043g = new h(false);

    /* renamed from: h  reason: collision with root package name */
    public static final q<float[]> f2044h = new i(true);

    /* renamed from: i  reason: collision with root package name */
    public static final q<Boolean> f2045i = new j(false);

    /* renamed from: j  reason: collision with root package name */
    public static final q<boolean[]> f2046j = new k(true);

    /* renamed from: k  reason: collision with root package name */
    public static final q<String> f2047k = new a(true);

    /* renamed from: l  reason: collision with root package name */
    public static final q<String[]> f2048l = new b(true);

    /* renamed from: a  reason: collision with root package name */
    private final boolean f2049a;

    /* loaded from: classes.dex */
    class a extends q<String> {
        a(boolean z2) {
            super(z2);
        }

        @Override // androidx.navigation.q
        public String c() {
            return "string";
        }

        @Override // androidx.navigation.q
        /* renamed from: j  reason: merged with bridge method [inline-methods] */
        public String b(Bundle bundle, String str) {
            return (String) bundle.get(str);
        }

        @Override // androidx.navigation.q
        /* renamed from: k  reason: merged with bridge method [inline-methods] */
        public String k(String str) {
            return str;
        }

        @Override // androidx.navigation.q
        /* renamed from: l  reason: merged with bridge method [inline-methods] */
        public void i(Bundle bundle, String str, String str2) {
            bundle.putString(str, str2);
        }
    }

    /* loaded from: classes.dex */
    class b extends q<String[]> {
        b(boolean z2) {
            super(z2);
        }

        @Override // androidx.navigation.q
        public String c() {
            return "string[]";
        }

        @Override // androidx.navigation.q
        /* renamed from: j  reason: merged with bridge method [inline-methods] */
        public String[] b(Bundle bundle, String str) {
            return (String[]) bundle.get(str);
        }

        @Override // androidx.navigation.q
        /* renamed from: k  reason: merged with bridge method [inline-methods] */
        public String[] k(String str) {
            throw new UnsupportedOperationException("Arrays don't support default values.");
        }

        @Override // androidx.navigation.q
        /* renamed from: l  reason: merged with bridge method [inline-methods] */
        public void i(Bundle bundle, String str, String[] strArr) {
            bundle.putStringArray(str, strArr);
        }
    }

    /* loaded from: classes.dex */
    class c extends q<Integer> {
        c(boolean z2) {
            super(z2);
        }

        @Override // androidx.navigation.q
        public String c() {
            return "integer";
        }

        @Override // androidx.navigation.q
        /* renamed from: j  reason: merged with bridge method [inline-methods] */
        public Integer b(Bundle bundle, String str) {
            return (Integer) bundle.get(str);
        }

        @Override // androidx.navigation.q
        /* renamed from: k  reason: merged with bridge method [inline-methods] */
        public Integer k(String str) {
            return Integer.valueOf(str.startsWith("0x") ? Integer.parseInt(str.substring(2), 16) : Integer.parseInt(str));
        }

        @Override // androidx.navigation.q
        /* renamed from: l  reason: merged with bridge method [inline-methods] */
        public void i(Bundle bundle, String str, Integer num) {
            bundle.putInt(str, num.intValue());
        }
    }

    /* loaded from: classes.dex */
    class d extends q<Integer> {
        d(boolean z2) {
            super(z2);
        }

        @Override // androidx.navigation.q
        public String c() {
            return "reference";
        }

        @Override // androidx.navigation.q
        /* renamed from: j  reason: merged with bridge method [inline-methods] */
        public Integer b(Bundle bundle, String str) {
            return (Integer) bundle.get(str);
        }

        @Override // androidx.navigation.q
        /* renamed from: k  reason: merged with bridge method [inline-methods] */
        public Integer k(String str) {
            return Integer.valueOf(str.startsWith("0x") ? Integer.parseInt(str.substring(2), 16) : Integer.parseInt(str));
        }

        @Override // androidx.navigation.q
        /* renamed from: l  reason: merged with bridge method [inline-methods] */
        public void i(Bundle bundle, String str, Integer num) {
            bundle.putInt(str, num.intValue());
        }
    }

    /* loaded from: classes.dex */
    class e extends q<int[]> {
        e(boolean z2) {
            super(z2);
        }

        @Override // androidx.navigation.q
        public String c() {
            return "integer[]";
        }

        @Override // androidx.navigation.q
        /* renamed from: j  reason: merged with bridge method [inline-methods] */
        public int[] b(Bundle bundle, String str) {
            return (int[]) bundle.get(str);
        }

        @Override // androidx.navigation.q
        /* renamed from: k  reason: merged with bridge method [inline-methods] */
        public int[] k(String str) {
            throw new UnsupportedOperationException("Arrays don't support default values.");
        }

        @Override // androidx.navigation.q
        /* renamed from: l  reason: merged with bridge method [inline-methods] */
        public void i(Bundle bundle, String str, int[] iArr) {
            bundle.putIntArray(str, iArr);
        }
    }

    /* loaded from: classes.dex */
    class f extends q<Long> {
        f(boolean z2) {
            super(z2);
        }

        @Override // androidx.navigation.q
        public String c() {
            return "long";
        }

        @Override // androidx.navigation.q
        /* renamed from: j  reason: merged with bridge method [inline-methods] */
        public Long b(Bundle bundle, String str) {
            return (Long) bundle.get(str);
        }

        @Override // androidx.navigation.q
        /* renamed from: k  reason: merged with bridge method [inline-methods] */
        public Long k(String str) {
            if (str.endsWith("L")) {
                str = str.substring(0, str.length() - 1);
            }
            return Long.valueOf(str.startsWith("0x") ? Long.parseLong(str.substring(2), 16) : Long.parseLong(str));
        }

        @Override // androidx.navigation.q
        /* renamed from: l  reason: merged with bridge method [inline-methods] */
        public void i(Bundle bundle, String str, Long l2) {
            bundle.putLong(str, l2.longValue());
        }
    }

    /* loaded from: classes.dex */
    class g extends q<long[]> {
        g(boolean z2) {
            super(z2);
        }

        @Override // androidx.navigation.q
        public String c() {
            return "long[]";
        }

        @Override // androidx.navigation.q
        /* renamed from: j  reason: merged with bridge method [inline-methods] */
        public long[] b(Bundle bundle, String str) {
            return (long[]) bundle.get(str);
        }

        @Override // androidx.navigation.q
        /* renamed from: k  reason: merged with bridge method [inline-methods] */
        public long[] k(String str) {
            throw new UnsupportedOperationException("Arrays don't support default values.");
        }

        @Override // androidx.navigation.q
        /* renamed from: l  reason: merged with bridge method [inline-methods] */
        public void i(Bundle bundle, String str, long[] jArr) {
            bundle.putLongArray(str, jArr);
        }
    }

    /* loaded from: classes.dex */
    class h extends q<Float> {
        h(boolean z2) {
            super(z2);
        }

        @Override // androidx.navigation.q
        public String c() {
            return "float";
        }

        @Override // androidx.navigation.q
        /* renamed from: j  reason: merged with bridge method [inline-methods] */
        public Float b(Bundle bundle, String str) {
            return (Float) bundle.get(str);
        }

        @Override // androidx.navigation.q
        /* renamed from: k  reason: merged with bridge method [inline-methods] */
        public Float k(String str) {
            return Float.valueOf(Float.parseFloat(str));
        }

        @Override // androidx.navigation.q
        /* renamed from: l  reason: merged with bridge method [inline-methods] */
        public void i(Bundle bundle, String str, Float f2) {
            bundle.putFloat(str, f2.floatValue());
        }
    }

    /* loaded from: classes.dex */
    class i extends q<float[]> {
        i(boolean z2) {
            super(z2);
        }

        @Override // androidx.navigation.q
        public String c() {
            return "float[]";
        }

        @Override // androidx.navigation.q
        /* renamed from: j  reason: merged with bridge method [inline-methods] */
        public float[] b(Bundle bundle, String str) {
            return (float[]) bundle.get(str);
        }

        @Override // androidx.navigation.q
        /* renamed from: k  reason: merged with bridge method [inline-methods] */
        public float[] k(String str) {
            throw new UnsupportedOperationException("Arrays don't support default values.");
        }

        @Override // androidx.navigation.q
        /* renamed from: l  reason: merged with bridge method [inline-methods] */
        public void i(Bundle bundle, String str, float[] fArr) {
            bundle.putFloatArray(str, fArr);
        }
    }

    /* loaded from: classes.dex */
    class j extends q<Boolean> {
        j(boolean z2) {
            super(z2);
        }

        @Override // androidx.navigation.q
        public String c() {
            return "boolean";
        }

        @Override // androidx.navigation.q
        /* renamed from: j  reason: merged with bridge method [inline-methods] */
        public Boolean b(Bundle bundle, String str) {
            return (Boolean) bundle.get(str);
        }

        @Override // androidx.navigation.q
        /* renamed from: k  reason: merged with bridge method [inline-methods] */
        public Boolean k(String str) {
            if ("true".equals(str)) {
                return Boolean.TRUE;
            }
            if ("false".equals(str)) {
                return Boolean.FALSE;
            }
            throw new IllegalArgumentException("A boolean NavType only accepts \"true\" or \"false\" values.");
        }

        @Override // androidx.navigation.q
        /* renamed from: l  reason: merged with bridge method [inline-methods] */
        public void i(Bundle bundle, String str, Boolean bool) {
            bundle.putBoolean(str, bool.booleanValue());
        }
    }

    /* loaded from: classes.dex */
    class k extends q<boolean[]> {
        k(boolean z2) {
            super(z2);
        }

        @Override // androidx.navigation.q
        public String c() {
            return "boolean[]";
        }

        @Override // androidx.navigation.q
        /* renamed from: j  reason: merged with bridge method [inline-methods] */
        public boolean[] b(Bundle bundle, String str) {
            return (boolean[]) bundle.get(str);
        }

        @Override // androidx.navigation.q
        /* renamed from: k  reason: merged with bridge method [inline-methods] */
        public boolean[] k(String str) {
            throw new UnsupportedOperationException("Arrays don't support default values.");
        }

        @Override // androidx.navigation.q
        /* renamed from: l  reason: merged with bridge method [inline-methods] */
        public void i(Bundle bundle, String str, boolean[] zArr) {
            bundle.putBooleanArray(str, zArr);
        }
    }

    /* loaded from: classes.dex */
    public static final class l<D extends Enum> extends p<D> {

        /* renamed from: n  reason: collision with root package name */
        private final Class<D> f2050n;

        public l(Class<D> cls) {
            super(false, cls);
            if (cls.isEnum()) {
                this.f2050n = cls;
                return;
            }
            throw new IllegalArgumentException(cls + " is not an Enum type.");
        }

        @Override // androidx.navigation.q.p, androidx.navigation.q
        public String c() {
            return this.f2050n.getName();
        }

        @Override // androidx.navigation.q.p
        /* renamed from: m  reason: merged with bridge method [inline-methods] and merged with bridge method [inline-methods] */
        public D k(String str) {
            for (D d2 : this.f2050n.getEnumConstants()) {
                if (d2.name().equals(str)) {
                    return d2;
                }
            }
            throw new IllegalArgumentException("Enum value " + str + " not found for type " + this.f2050n.getName() + ".");
        }
    }

    /* loaded from: classes.dex */
    public static final class m<D extends Parcelable> extends q<D[]> {

        /* renamed from: m  reason: collision with root package name */
        private final Class<D[]> f2051m;

        public m(Class<D> cls) {
            super(true);
            if (!Parcelable.class.isAssignableFrom(cls)) {
                throw new IllegalArgumentException(cls + " does not implement Parcelable.");
            }
            try {
                this.f2051m = (Class<D[]>) Class.forName("[L" + cls.getName() + ";");
            } catch (ClassNotFoundException e2) {
                throw new RuntimeException(e2);
            }
        }

        @Override // androidx.navigation.q
        public String c() {
            return this.f2051m.getName();
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null || m.class != obj.getClass()) {
                return false;
            }
            return this.f2051m.equals(((m) obj).f2051m);
        }

        public int hashCode() {
            return this.f2051m.hashCode();
        }

        @Override // androidx.navigation.q
        /* renamed from: j  reason: merged with bridge method [inline-methods] */
        public D[] b(Bundle bundle, String str) {
            return (D[]) ((Parcelable[]) bundle.get(str));
        }

        @Override // androidx.navigation.q
        public D[] k(String str) {
            throw new UnsupportedOperationException("Arrays don't support default values.");
        }

        @Override // androidx.navigation.q
        /* renamed from: l  reason: merged with bridge method [inline-methods] */
        public void i(Bundle bundle, String str, D[] dArr) {
            this.f2051m.cast(dArr);
            bundle.putParcelableArray(str, dArr);
        }
    }

    /* loaded from: classes.dex */
    public static final class n<D> extends q<D> {

        /* renamed from: m  reason: collision with root package name */
        private final Class<D> f2052m;

        public n(Class<D> cls) {
            super(true);
            if (Parcelable.class.isAssignableFrom(cls) || Serializable.class.isAssignableFrom(cls)) {
                this.f2052m = cls;
                return;
            }
            throw new IllegalArgumentException(cls + " does not implement Parcelable or Serializable.");
        }

        @Override // androidx.navigation.q
        public D b(Bundle bundle, String str) {
            return (D) bundle.get(str);
        }

        @Override // androidx.navigation.q
        public String c() {
            return this.f2052m.getName();
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null || n.class != obj.getClass()) {
                return false;
            }
            return this.f2052m.equals(((n) obj).f2052m);
        }

        @Override // androidx.navigation.q
        /* renamed from: h */
        public D k(String str) {
            throw new UnsupportedOperationException("Parcelables don't support default values.");
        }

        public int hashCode() {
            return this.f2052m.hashCode();
        }

        @Override // androidx.navigation.q
        public void i(Bundle bundle, String str, D d2) {
            this.f2052m.cast(d2);
            if (d2 == null || (d2 instanceof Parcelable)) {
                bundle.putParcelable(str, (Parcelable) d2);
            } else if (d2 instanceof Serializable) {
                bundle.putSerializable(str, (Serializable) d2);
            }
        }
    }

    /* loaded from: classes.dex */
    public static final class o<D extends Serializable> extends q<D[]> {

        /* renamed from: m  reason: collision with root package name */
        private final Class<D[]> f2053m;

        public o(Class<D> cls) {
            super(true);
            if (!Serializable.class.isAssignableFrom(cls)) {
                throw new IllegalArgumentException(cls + " does not implement Serializable.");
            }
            try {
                this.f2053m = (Class<D[]>) Class.forName("[L" + cls.getName() + ";");
            } catch (ClassNotFoundException e2) {
                throw new RuntimeException(e2);
            }
        }

        @Override // androidx.navigation.q
        public String c() {
            return this.f2053m.getName();
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null || o.class != obj.getClass()) {
                return false;
            }
            return this.f2053m.equals(((o) obj).f2053m);
        }

        public int hashCode() {
            return this.f2053m.hashCode();
        }

        @Override // androidx.navigation.q
        /* renamed from: j  reason: merged with bridge method [inline-methods] */
        public D[] b(Bundle bundle, String str) {
            return (D[]) ((Serializable[]) bundle.get(str));
        }

        @Override // androidx.navigation.q
        public D[] k(String str) {
            throw new UnsupportedOperationException("Arrays don't support default values.");
        }

        /* JADX WARN: Multi-variable type inference failed */
        @Override // androidx.navigation.q
        /* renamed from: l  reason: merged with bridge method [inline-methods] */
        public void i(Bundle bundle, String str, D[] dArr) {
            this.f2053m.cast(dArr);
            bundle.putSerializable(str, dArr);
        }
    }

    /* loaded from: classes.dex */
    public static class p<D extends Serializable> extends q<D> {

        /* renamed from: m  reason: collision with root package name */
        private final Class<D> f2054m;

        public p(Class<D> cls) {
            super(true);
            if (!Serializable.class.isAssignableFrom(cls)) {
                throw new IllegalArgumentException(cls + " does not implement Serializable.");
            } else if (!cls.isEnum()) {
                this.f2054m = cls;
            } else {
                throw new IllegalArgumentException(cls + " is an Enum. You should use EnumType instead.");
            }
        }

        p(boolean z2, Class<D> cls) {
            super(z2);
            if (Serializable.class.isAssignableFrom(cls)) {
                this.f2054m = cls;
                return;
            }
            throw new IllegalArgumentException(cls + " does not implement Serializable.");
        }

        @Override // androidx.navigation.q
        public String c() {
            return this.f2054m.getName();
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj instanceof p) {
                return this.f2054m.equals(((p) obj).f2054m);
            }
            return false;
        }

        public int hashCode() {
            return this.f2054m.hashCode();
        }

        @Override // androidx.navigation.q
        /* renamed from: j  reason: merged with bridge method [inline-methods] */
        public D b(Bundle bundle, String str) {
            return (D) bundle.get(str);
        }

        @Override // androidx.navigation.q
        public D k(String str) {
            throw new UnsupportedOperationException("Serializables don't support default values.");
        }

        @Override // androidx.navigation.q
        /* renamed from: l  reason: merged with bridge method [inline-methods] */
        public void i(Bundle bundle, String str, D d2) {
            this.f2054m.cast(d2);
            bundle.putSerializable(str, d2);
        }
    }

    q(boolean z2) {
        this.f2049a = z2;
    }

    public static q<?> a(String str, String str2) {
        String str3;
        q<Integer> qVar = f2038b;
        if (qVar.c().equals(str)) {
            return qVar;
        }
        q qVar2 = f2040d;
        if (qVar2.c().equals(str)) {
            return qVar2;
        }
        q<Long> qVar3 = f2041e;
        if (qVar3.c().equals(str)) {
            return qVar3;
        }
        q qVar4 = f2042f;
        if (qVar4.c().equals(str)) {
            return qVar4;
        }
        q<Boolean> qVar5 = f2045i;
        if (qVar5.c().equals(str)) {
            return qVar5;
        }
        q qVar6 = f2046j;
        if (qVar6.c().equals(str)) {
            return qVar6;
        }
        q<String> qVar7 = f2047k;
        if (qVar7.c().equals(str)) {
            return qVar7;
        }
        q qVar8 = f2048l;
        if (qVar8.c().equals(str)) {
            return qVar8;
        }
        q<Float> qVar9 = f2043g;
        if (qVar9.c().equals(str)) {
            return qVar9;
        }
        q qVar10 = f2044h;
        if (qVar10.c().equals(str)) {
            return qVar10;
        }
        q<Integer> qVar11 = f2039c;
        if (qVar11.c().equals(str)) {
            return qVar11;
        }
        if (str == null || str.isEmpty()) {
            return qVar7;
        }
        try {
            if (!str.startsWith(".") || str2 == null) {
                str3 = str;
            } else {
                str3 = str2 + str;
            }
            if (str.endsWith("[]")) {
                str3 = str3.substring(0, str3.length() - 2);
                Class<?> cls = Class.forName(str3);
                if (Parcelable.class.isAssignableFrom(cls)) {
                    return new m(cls);
                }
                if (Serializable.class.isAssignableFrom(cls)) {
                    return new o(cls);
                }
            } else {
                Class<?> cls2 = Class.forName(str3);
                if (Parcelable.class.isAssignableFrom(cls2)) {
                    return new n(cls2);
                }
                if (Enum.class.isAssignableFrom(cls2)) {
                    return new l(cls2);
                }
                if (Serializable.class.isAssignableFrom(cls2)) {
                    return new p(cls2);
                }
            }
            throw new IllegalArgumentException(str3 + " is not Serializable or Parcelable.");
        } catch (ClassNotFoundException e2) {
            throw new RuntimeException(e2);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static q d(String str) {
        try {
            try {
                try {
                    try {
                        q<Integer> qVar = f2038b;
                        qVar.k(str);
                        return qVar;
                    } catch (IllegalArgumentException unused) {
                        q<Boolean> qVar2 = f2045i;
                        qVar2.k(str);
                        return qVar2;
                    }
                } catch (IllegalArgumentException unused2) {
                    q<Float> qVar3 = f2043g;
                    qVar3.k(str);
                    return qVar3;
                }
            } catch (IllegalArgumentException unused3) {
                q<Long> qVar4 = f2041e;
                qVar4.k(str);
                return qVar4;
            }
        } catch (IllegalArgumentException unused4) {
            return f2047k;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static q e(Object obj) {
        if (obj instanceof Integer) {
            return f2038b;
        }
        if (obj instanceof int[]) {
            return f2040d;
        }
        if (obj instanceof Long) {
            return f2041e;
        }
        if (obj instanceof long[]) {
            return f2042f;
        }
        if (obj instanceof Float) {
            return f2043g;
        }
        if (obj instanceof float[]) {
            return f2044h;
        }
        if (obj instanceof Boolean) {
            return f2045i;
        }
        if (obj instanceof boolean[]) {
            return f2046j;
        }
        if ((obj instanceof String) || obj == null) {
            return f2047k;
        }
        if (obj instanceof String[]) {
            return f2048l;
        }
        if (obj.getClass().isArray() && Parcelable.class.isAssignableFrom(obj.getClass().getComponentType())) {
            return new m(obj.getClass().getComponentType());
        }
        if (obj.getClass().isArray() && Serializable.class.isAssignableFrom(obj.getClass().getComponentType())) {
            return new o(obj.getClass().getComponentType());
        }
        if (obj instanceof Parcelable) {
            return new n(obj.getClass());
        }
        if (obj instanceof Enum) {
            return new l(obj.getClass());
        }
        if (obj instanceof Serializable) {
            return new p(obj.getClass());
        }
        throw new IllegalArgumentException("Object of type " + obj.getClass().getName() + " is not supported for navigation arguments.");
    }

    public abstract T b(Bundle bundle, String str);

    public abstract String c();

    public boolean f() {
        return this.f2049a;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public T g(Bundle bundle, String str, String str2) {
        T k2 = k(str2);
        i(bundle, str, k2);
        return k2;
    }

    /* renamed from: h */
    public abstract T k(String str);

    public abstract void i(Bundle bundle, String str, T t2);

    public String toString() {
        return c();
    }
}
