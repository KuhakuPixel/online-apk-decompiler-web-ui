package z0;

import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
/* loaded from: classes.dex */
public final class l extends o implements n {
    /* JADX INFO: Access modifiers changed from: package-private */
    public l(IBinder iBinder) {
        super(iBinder, "com.android.vending.billing.IInAppBillingService");
    }

    @Override // z0.n
    public final Bundle b(int i2, String str, String str2, Bundle bundle, Bundle bundle2) {
        Parcel p2 = p();
        p2.writeInt(i2);
        p2.writeString(str);
        p2.writeString(str2);
        q.b(p2, bundle);
        q.b(p2, bundle2);
        Parcel q2 = q(901, p2);
        Bundle bundle3 = (Bundle) q.a(q2, Bundle.CREATOR);
        q2.recycle();
        return bundle3;
    }

    @Override // z0.n
    public final int c(int i2, String str, String str2) {
        Parcel p2 = p();
        p2.writeInt(i2);
        p2.writeString(str);
        p2.writeString(str2);
        Parcel q2 = q(1, p2);
        int readInt = q2.readInt();
        q2.recycle();
        return readInt;
    }

    @Override // z0.n
    public final int d(int i2, String str, String str2) {
        Parcel p2 = p();
        p2.writeInt(3);
        p2.writeString(str);
        p2.writeString(str2);
        Parcel q2 = q(5, p2);
        int readInt = q2.readInt();
        q2.recycle();
        return readInt;
    }

    @Override // z0.n
    public final int e(int i2, String str, String str2, Bundle bundle) {
        Parcel p2 = p();
        p2.writeInt(i2);
        p2.writeString(str);
        p2.writeString(str2);
        q.b(p2, bundle);
        Parcel q2 = q(10, p2);
        int readInt = q2.readInt();
        q2.recycle();
        return readInt;
    }

    @Override // z0.n
    public final Bundle f(int i2, String str, String str2, String str3) {
        Parcel p2 = p();
        p2.writeInt(3);
        p2.writeString(str);
        p2.writeString(str2);
        p2.writeString(str3);
        Parcel q2 = q(4, p2);
        Bundle bundle = (Bundle) q.a(q2, Bundle.CREATOR);
        q2.recycle();
        return bundle;
    }

    @Override // z0.n
    public final Bundle g(int i2, String str, String str2, Bundle bundle) {
        Parcel p2 = p();
        p2.writeInt(9);
        p2.writeString(str);
        p2.writeString(str2);
        q.b(p2, bundle);
        Parcel q2 = q(12, p2);
        Bundle bundle2 = (Bundle) q.a(q2, Bundle.CREATOR);
        q2.recycle();
        return bundle2;
    }

    @Override // z0.n
    public final Bundle h(int i2, String str, String str2, String str3, Bundle bundle) {
        Parcel p2 = p();
        p2.writeInt(9);
        p2.writeString(str);
        p2.writeString(str2);
        p2.writeString(str3);
        q.b(p2, bundle);
        Parcel q2 = q(11, p2);
        Bundle bundle2 = (Bundle) q.a(q2, Bundle.CREATOR);
        q2.recycle();
        return bundle2;
    }

    @Override // z0.n
    public final Bundle i(int i2, String str, String str2, String str3, String str4) {
        Parcel p2 = p();
        p2.writeInt(3);
        p2.writeString(str);
        p2.writeString(str2);
        p2.writeString(str3);
        p2.writeString(null);
        Parcel q2 = q(3, p2);
        Bundle bundle = (Bundle) q.a(q2, Bundle.CREATOR);
        q2.recycle();
        return bundle;
    }

    @Override // z0.n
    public final Bundle j(int i2, String str, String str2, String str3, String str4, Bundle bundle) {
        Parcel p2 = p();
        p2.writeInt(i2);
        p2.writeString(str);
        p2.writeString(str2);
        p2.writeString(str3);
        p2.writeString(null);
        q.b(p2, bundle);
        Parcel q2 = q(8, p2);
        Bundle bundle2 = (Bundle) q.a(q2, Bundle.CREATOR);
        q2.recycle();
        return bundle2;
    }

    @Override // z0.n
    public final Bundle l(int i2, String str, String str2, Bundle bundle) {
        Parcel p2 = p();
        p2.writeInt(3);
        p2.writeString(str);
        p2.writeString(str2);
        q.b(p2, bundle);
        Parcel q2 = q(2, p2);
        Bundle bundle2 = (Bundle) q.a(q2, Bundle.CREATOR);
        q2.recycle();
        return bundle2;
    }

    @Override // z0.n
    public final Bundle o(int i2, String str, String str2, Bundle bundle) {
        Parcel p2 = p();
        p2.writeInt(9);
        p2.writeString(str);
        p2.writeString(str2);
        q.b(p2, bundle);
        Parcel q2 = q(902, p2);
        Bundle bundle2 = (Bundle) q.a(q2, Bundle.CREATOR);
        q2.recycle();
        return bundle2;
    }
}
