package w1;

import android.content.res.TypedArray;
import android.util.SparseIntArray;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.databinding.ViewDataBinding;
import androidx.lifecycle.LiveData;
import com.sample.android.kuhakupixelinapppurchase.R;
import com.sample.android.kuhakupixelinapppurchase.ui.GameFragment;
import y1.a;
/* loaded from: classes.dex */
public class d extends c implements a.InterfaceC0083a {
    private static final SparseIntArray O;
    private final ScrollView K;
    private final View.OnClickListener L;
    private final View.OnClickListener M;
    private long N;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        O = sparseIntArray;
        sparseIntArray.put(R.id.constraint_layout, 5);
        sparseIntArray.put(R.id.title_view, 6);
    }

    public d(androidx.databinding.e eVar, View view) {
        this(eVar, view, ViewDataBinding.u(eVar, view, 7, null, O));
    }

    private d(androidx.databinding.e eVar, View view, Object[] objArr) {
        super(eVar, view, 3, (Button) objArr[4], (ConstraintLayout) objArr[5], (Button) objArr[3], (ImageView) objArr[1], (ImageView) objArr[2], (TextView) objArr[6]);
        this.N = -1L;
        this.B.setTag(null);
        this.D.setTag(null);
        this.E.setTag(null);
        this.F.setTag(null);
        ScrollView scrollView = (ScrollView) objArr[0];
        this.K = scrollView;
        scrollView.setTag(null);
        D(view);
        this.L = new y1.a(this, 1);
        this.M = new y1.a(this, 2);
        K();
    }

    private boolean L(LiveData<Boolean> liveData, int i2) {
        if (i2 == 0) {
            synchronized (this) {
                this.N |= 2;
            }
            return true;
        }
        return false;
    }

    private boolean M(LiveData<Integer> liveData, int i2) {
        if (i2 == 0) {
            synchronized (this) {
                this.N |= 1;
            }
            return true;
        }
        return false;
    }

    private boolean N(LiveData<Boolean> liveData, int i2) {
        if (i2 == 0) {
            synchronized (this) {
                this.N |= 4;
            }
            return true;
        }
        return false;
    }

    @Override // w1.c
    public void H(GameFragment gameFragment) {
        this.J = gameFragment;
        synchronized (this) {
            this.N |= 32;
        }
        d(1);
        super.z();
    }

    @Override // w1.c
    public void I(TypedArray typedArray) {
        this.I = typedArray;
        synchronized (this) {
            this.N |= 8;
        }
        d(2);
        super.z();
    }

    @Override // w1.c
    public void J(u1.b bVar) {
        this.H = bVar;
        synchronized (this) {
            this.N |= 16;
        }
        d(3);
        super.z();
    }

    public void K() {
        synchronized (this) {
            this.N = 64L;
        }
        z();
    }

    @Override // y1.a.InterfaceC0083a
    public final void b(int i2, View view) {
        if (i2 == 1) {
            GameFragment gameFragment = this.J;
            if (gameFragment != null) {
                gameFragment.p1();
            }
        } else if (i2 != 2) {
        } else {
            GameFragment gameFragment2 = this.J;
            if (gameFragment2 != null) {
                gameFragment2.q1(view);
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:22:0x004a  */
    /* JADX WARN: Removed duplicated region for block: B:32:0x006a  */
    @Override // androidx.databinding.ViewDataBinding
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    protected void l() {
        /*
            Method dump skipped, instructions count: 228
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: w1.d.l():void");
    }

    @Override // androidx.databinding.ViewDataBinding
    public boolean r() {
        synchronized (this) {
            return this.N != 0;
        }
    }

    @Override // androidx.databinding.ViewDataBinding
    protected boolean v(int i2, Object obj, int i3) {
        if (i2 != 0) {
            if (i2 != 1) {
                if (i2 != 2) {
                    return false;
                }
                return N((LiveData) obj, i3);
            }
            return L((LiveData) obj, i3);
        }
        return M((LiveData) obj, i3);
    }
}
