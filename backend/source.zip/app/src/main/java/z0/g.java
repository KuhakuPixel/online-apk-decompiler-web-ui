package z0;

import java.util.Arrays;
import javax.annotation.CheckForNull;
/* loaded from: classes.dex */
final class g extends e0 {

    /* renamed from: h  reason: collision with root package name */
    static final e0 f5697h = new g(null, new Object[0], 0);
    @CheckForNull

    /* renamed from: e  reason: collision with root package name */
    private final transient Object f5698e;

    /* renamed from: f  reason: collision with root package name */
    final transient Object[] f5699f;

    /* renamed from: g  reason: collision with root package name */
    private final transient int f5700g;

    private g(@CheckForNull Object obj, Object[] objArr, int i2) {
        this.f5698e = obj;
        this.f5699f = objArr;
        this.f5700g = i2;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r15v0 */
    /* JADX WARN: Type inference failed for: r5v11 */
    /* JADX WARN: Type inference failed for: r5v13, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r5v4, types: [int[]] */
    public static g h(int i2, Object[] objArr, d0 d0Var) {
        short[] sArr;
        Object[] objArr2;
        byte[] bArr;
        int i3 = i2;
        Object[] objArr3 = objArr;
        if (i3 == 0) {
            return (g) f5697h;
        }
        Object obj = null;
        if (i3 == 1) {
            Object obj2 = objArr3[0];
            obj2.getClass();
            Object obj3 = objArr3[1];
            obj3.getClass();
            w.a(obj2, obj3);
            return new g(null, objArr3, 1);
        }
        t.b(i3, objArr3.length >> 1, "index");
        char c2 = 2;
        int max = Math.max(i3, 2);
        int i4 = 1073741824;
        if (max < 751619276) {
            int highestOneBit = Integer.highestOneBit(max - 1);
            i4 = highestOneBit + highestOneBit;
            while (i4 * 0.7d < max) {
                i4 += i4;
            }
        } else if (max >= 1073741824) {
            throw new IllegalArgumentException("collection too large");
        }
        if (i3 == 1) {
            Object obj4 = objArr3[0];
            obj4.getClass();
            Object obj5 = objArr3[1];
            obj5.getClass();
            w.a(obj4, obj5);
        } else {
            int i5 = i4 - 1;
            char c3 = 65535;
            if (i4 <= 128) {
                byte[] bArr2 = new byte[i4];
                Arrays.fill(bArr2, (byte) -1);
                int i6 = 0;
                for (int i7 = 0; i7 < i3; i7++) {
                    int i8 = i7 + i7;
                    int i9 = i6 + i6;
                    Object obj6 = objArr3[i8];
                    obj6.getClass();
                    Object obj7 = objArr3[i8 ^ 1];
                    obj7.getClass();
                    w.a(obj6, obj7);
                    int a2 = x.a(obj6.hashCode());
                    while (true) {
                        int i10 = a2 & i5;
                        int i11 = bArr2[i10] & 255;
                        if (i11 == 255) {
                            bArr2[i10] = (byte) i9;
                            if (i6 < i7) {
                                objArr3[i9] = obj6;
                                objArr3[i9 ^ 1] = obj7;
                            }
                            i6++;
                        } else if (obj6.equals(objArr3[i11])) {
                            int i12 = i11 ^ 1;
                            Object obj8 = objArr3[i12];
                            obj8.getClass();
                            c0 c0Var = new c0(obj6, obj7, obj8);
                            objArr3[i12] = obj7;
                            obj = c0Var;
                            break;
                        } else {
                            a2 = i10 + 1;
                        }
                    }
                }
                if (i6 == i3) {
                    bArr = bArr2;
                    c2 = 2;
                    obj = bArr;
                } else {
                    sArr = new Object[]{bArr2, Integer.valueOf(i6), obj};
                }
            } else if (i4 <= 32768) {
                sArr = new short[i4];
                Arrays.fill(sArr, (short) -1);
                int i13 = 0;
                for (int i14 = 0; i14 < i3; i14++) {
                    int i15 = i14 + i14;
                    int i16 = i13 + i13;
                    Object obj9 = objArr3[i15];
                    obj9.getClass();
                    Object obj10 = objArr3[i15 ^ 1];
                    obj10.getClass();
                    w.a(obj9, obj10);
                    int a3 = x.a(obj9.hashCode());
                    while (true) {
                        int i17 = a3 & i5;
                        char c4 = (char) sArr[i17];
                        if (c4 == 65535) {
                            sArr[i17] = (short) i16;
                            if (i13 < i14) {
                                objArr3[i16] = obj9;
                                objArr3[i16 ^ 1] = obj10;
                            }
                            i13++;
                        } else if (obj9.equals(objArr3[c4])) {
                            int i18 = c4 ^ 1;
                            Object obj11 = objArr3[i18];
                            obj11.getClass();
                            c0 c0Var2 = new c0(obj9, obj10, obj11);
                            objArr3[i18] = obj10;
                            obj = c0Var2;
                            break;
                        } else {
                            a3 = i17 + 1;
                        }
                    }
                }
                if (i13 != i3) {
                    c2 = 2;
                    objArr2 = new Object[]{sArr, Integer.valueOf(i13), obj};
                    obj = objArr2;
                }
            } else {
                sArr = new int[i4];
                Arrays.fill((int[]) sArr, -1);
                int i19 = 0;
                int i20 = 0;
                while (i19 < i3) {
                    int i21 = i19 + i19;
                    int i22 = i20 + i20;
                    Object obj12 = objArr3[i21];
                    obj12.getClass();
                    Object obj13 = objArr3[i21 ^ 1];
                    obj13.getClass();
                    w.a(obj12, obj13);
                    int a4 = x.a(obj12.hashCode());
                    while (true) {
                        int i23 = a4 & i5;
                        ?? r15 = sArr[i23];
                        if (r15 == c3) {
                            sArr[i23] = i22;
                            if (i20 < i19) {
                                objArr3[i22] = obj12;
                                objArr3[i22 ^ 1] = obj13;
                            }
                            i20++;
                        } else if (obj12.equals(objArr3[r15])) {
                            int i24 = r15 ^ 1;
                            Object obj14 = objArr3[i24];
                            obj14.getClass();
                            c0 c0Var3 = new c0(obj12, obj13, obj14);
                            objArr3[i24] = obj13;
                            obj = c0Var3;
                            break;
                        } else {
                            a4 = i23 + 1;
                            c3 = 65535;
                        }
                    }
                    i19++;
                    c3 = 65535;
                }
                if (i20 != i3) {
                    c2 = 2;
                    objArr2 = new Object[]{sArr, Integer.valueOf(i20), obj};
                    obj = objArr2;
                }
            }
            bArr = sArr;
            c2 = 2;
            obj = bArr;
        }
        boolean z2 = obj instanceof Object[];
        Object obj15 = obj;
        if (z2) {
            Object[] objArr4 = (Object[]) obj;
            d0Var.f5687c = (c0) objArr4[c2];
            Object obj16 = objArr4[0];
            int intValue = ((Integer) objArr4[1]).intValue();
            objArr3 = Arrays.copyOf(objArr3, intValue + intValue);
            obj15 = obj16;
            i3 = intValue;
        }
        return new g(obj15, objArr3, i3);
    }

    @Override // z0.e0
    final y c() {
        return new f(this.f5699f, 1, this.f5700g);
    }

    @Override // z0.e0
    final f0 e() {
        return new d(this, this.f5699f, 0, this.f5700g);
    }

    @Override // z0.e0
    final f0 f() {
        return new e(this, new f(this.f5699f, 0, this.f5700g));
    }

    /* JADX WARN: Removed duplicated region for block: B:40:0x009e A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:41:0x009f A[RETURN] */
    @Override // z0.e0, java.util.Map
    @javax.annotation.CheckForNull
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final java.lang.Object get(@javax.annotation.CheckForNull java.lang.Object r10) {
        /*
            r9 = this;
            java.lang.Object r0 = r9.f5698e
            java.lang.Object[] r1 = r9.f5699f
            int r2 = r9.f5700g
            r3 = 0
            if (r10 != 0) goto Lc
        L9:
            r10 = r3
            goto L9c
        Lc:
            r4 = 1
            if (r2 != r4) goto L22
            r0 = 0
            r0 = r1[r0]
            r0.getClass()
            boolean r10 = r0.equals(r10)
            if (r10 == 0) goto L9
            r10 = r1[r4]
            r10.getClass()
            goto L9c
        L22:
            if (r0 != 0) goto L25
            goto L9
        L25:
            boolean r2 = r0 instanceof byte[]
            r5 = -1
            if (r2 == 0) goto L51
            r2 = r0
            byte[] r2 = (byte[]) r2
            int r0 = r2.length
            int r6 = r0 + (-1)
            int r0 = r10.hashCode()
            int r0 = z0.x.a(r0)
        L38:
            r0 = r0 & r6
            r5 = r2[r0]
            r7 = 255(0xff, float:3.57E-43)
            r5 = r5 & r7
            if (r5 != r7) goto L41
            goto L9
        L41:
            r7 = r1[r5]
            boolean r7 = r10.equals(r7)
            if (r7 == 0) goto L4e
            r10 = r5 ^ 1
            r10 = r1[r10]
            goto L9c
        L4e:
            int r0 = r0 + 1
            goto L38
        L51:
            boolean r2 = r0 instanceof short[]
            if (r2 == 0) goto L7d
            r2 = r0
            short[] r2 = (short[]) r2
            int r0 = r2.length
            int r6 = r0 + (-1)
            int r0 = r10.hashCode()
            int r0 = z0.x.a(r0)
        L63:
            r0 = r0 & r6
            short r5 = r2[r0]
            char r5 = (char) r5
            r7 = 65535(0xffff, float:9.1834E-41)
            if (r5 != r7) goto L6d
            goto L9
        L6d:
            r7 = r1[r5]
            boolean r7 = r10.equals(r7)
            if (r7 == 0) goto L7a
            r10 = r5 ^ 1
            r10 = r1[r10]
            goto L9c
        L7a:
            int r0 = r0 + 1
            goto L63
        L7d:
            int[] r0 = (int[]) r0
            int r2 = r0.length
            int r2 = r2 + r5
            int r6 = r10.hashCode()
            int r6 = z0.x.a(r6)
        L89:
            r6 = r6 & r2
            r7 = r0[r6]
            if (r7 != r5) goto L90
            goto L9
        L90:
            r8 = r1[r7]
            boolean r8 = r10.equals(r8)
            if (r8 == 0) goto La0
            r10 = r7 ^ 1
            r10 = r1[r10]
        L9c:
            if (r10 != 0) goto L9f
            return r3
        L9f:
            return r10
        La0:
            int r6 = r6 + 1
            goto L89
        */
        throw new UnsupportedOperationException("Method not decompiled: z0.g.get(java.lang.Object):java.lang.Object");
    }

    @Override // java.util.Map
    public final int size() {
        return this.f5700g;
    }
}
